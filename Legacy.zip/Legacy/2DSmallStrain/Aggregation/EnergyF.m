function [Ef,M] = EnergyF(PN,ED,I,Ar,UUvE,e,g)
NE = size(ED,1);
NN = size(PN,1);
ks = 9/10; % for circular bar
% ks = 5/6; % for rectangle bar

% first it is needed to calculate the stiffness matrix of each individual
% element and then by considering the deformation, we can calculate the
% energy stored in each node.
L=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,1);
    dg=PN(d,2);
    cs=PN(c,1);
    cg=PN(c,2);
    L(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end   

TETA=zeros(NE,1);
for i=1:NE
    q=ED(i,1);
    w=ED(i,2);
    qs=PN(q,1);
    qg=PN(q,2);
    ws=PN(w,1);
    wg=PN(w,2);
    TETA1=asin((wg-qg)/L(i,1));
    TETA2=acos((ws-qs)/L(i,1));
    
    if TETA1 >= 0
        if TETA2 <= pi/2
            TETA(i,1) = TETA1;
        else TETA(i,1) = TETA2;
        end
    else 
        if TETA2 <= pi/2
            TETA(i,1) = 2*pi + TETA1;
        else TETA(i,1) = 2*pi - TETA2;
        end
    end
    
end


I2 = zeros(NE,36);
J2 = zeros(NE,36);
K2 = zeros(NE,36);

Iadress = zeros(NE,6);
for i = 1:NE
    Iadress(i,1) = i*6-5;
    Iadress(i,2) = i*6-4;
    Iadress(i,3) = i*6-3;
    Iadress(i,4) = i*6-2;
    Iadress(i,5) = i*6-1;
    Iadress(i,6) = i*6;
end

for j = 1:6
    I2(:,6-(j-1)) = Iadress(:,1);
    I2(:,12-(j-1)) = Iadress(:,2);
    I2(:,18-(j-1)) = Iadress(:,3);
    I2(:,24-(j-1)) = Iadress(:,4);
    I2(:,30-(j-1)) = Iadress(:,5);
    I2(:,36-(j-1)) = Iadress(:,6);
end


for i = 1:6
    J2(:,i*6-5) = Iadress(:,1);
    J2(:,i*6-4) = Iadress(:,2);
    J2(:,i*6-3) = Iadress(:,3);
    J2(:,i*6-2) = Iadress(:,4);
    J2(:,i*6-1) = Iadress(:,5);
    J2(:,i*6) = Iadress(:,6);
end


ll=L(:,1);
    C = cos(TETA(:,1));
    S = sin(TETA(:,1));
    phi = 12.*e.*I./(ks.*Ar.*g.*ll.^2) ;

    K2(:,1) = (1+phi).*Ar.*(C.^2)+12.*I.*(S.^2)./(ll.^2);
    K2(:,2) = ((1+phi).*Ar-12.*I./(ll.^2)).*C.*S;
    K2(:,3) = -6.*I.*S./ll;
    K2(:,4) = -(1+phi).*Ar.*C.^2-12.*I.*(S.^2)./(ll.^2);
    K2(:,5) = -((1+phi).*Ar-12.*I./(ll.^2)).*C.*S;
    K2(:,6) = -6.*I.*S./ll;

    K2(:,7) = K2(:,2);
    K2(:,8) = (1+phi).*Ar.*(S.^2)+12.*I.*(C.^2)./(ll.^2);
    K2(:,9) = 6.*I.*C./ll;
    K2(:,10) = -K2(:,2);
    K2(:,11) = -K2(:,8);
    K2(:,12) = K2(:,9);
    
    K2(:,13) = K2(:,3);
    K2(:,14) = K2(:,9);
    K2(:,15) = (4+phi).*I;
    K2(:,16) = 6.*I.*S./ll;
    K2(:,17) = -6.*I.*C./ll;
    K2(:,18) = (2-phi).*I;
    
    K2(:,19) = K2(:,4);
    K2(:,20) = K2(:,10);
    K2(:,21) = K2(:,16);
    K2(:,22) = K2(:,1);
    K2(:,23) = K2(:,2);
    K2(:,24) = 6.*I.*S./ll;
    
    K2(:,25) = K2(:,5);
    K2(:,26) = K2(:,11);
    K2(:,27) = K2(:,17);
    K2(:,28) = K2(:,23);
    K2(:,29) = K2(:,8);
    K2(:,30) = -6.*I.*C./ll;
    
    K2(:,31) = K2(:,6);
    K2(:,32) = K2(:,12);
    K2(:,33) = K2(:,18);
    K2(:,34) = K2(:,24);
    K2(:,35) = K2(:,30);
    K2(:,36) = (4+phi).*I;

K2 = e./(ll.*(1+phi)).*K2;

M = sparse(I2,J2,K2,6*NE,6*NE);


Ef = zeros(NE,1);

for i = 1 : NE
    Me = M(i*6-5:i*6 , i*6-5:i*6);
    nn1 = ED(i,1);
    nn2 = ED(i,2);
    Ue = [UUvE(nn1*3-2:nn1*3) ; UUvE(nn2*3-2:nn2*3)];
    if i ==1
    Ue
    full(Me)
    end
    Ef(i,1) = 1/2*transpose(Ue)*Me*Ue;
end



end