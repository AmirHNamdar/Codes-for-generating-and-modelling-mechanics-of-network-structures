function [SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRandDN(x,y,L,Nf1,Nf2,lambda,flt,Pr,densityN1,densityN2,Pagg1,Pagg2,TR)
% clear all
% clc
% close all
density = densityN1 + densityN2;
% for kl = 1:10000

% lambda = 1;
% x = [0 lambda];
% y = [0 lambda];
% L = 1;
% N = 300;
% flt = 10^(-2)*lambda;

% tic
% creating the Fiber-----------------------------------------------------

[Fiber1f,xc1,yc1,nf1,PBN1f] =  FiberC(x,y,L,Nf1,lambda,Pr,Pagg1);
[Fiber2f,xc2,yc2,nf2,PBN2f] =  FiberC(x,y,L,Nf2,lambda,Pr,Pagg2);
Fiber2f(:,13) = Fiber2f(:,13) * TR; % thickness ratio of fibre type 2 to type 1 
Fiber1f(:,14) = Fiber1f(:,14) + nf1.*(Fiber1f(:,14) > 0);
Fiber1f(:,15) = Fiber1f(:,15) + nf1.*(Fiber1f(:,15) > 0);

PBN1f;
size(PBN1f);
PBN2f;

PBN2f(:,4) = PBN2f(:,4) +nf1;
PBN2f(:,5) = PBN2f(:,5) + size(PBN1f,1);
 
nf = nf1 + nf2;

Fiber = [Fiber1f;Fiber2f];
PBN = [PBN1f;PBN2f];

% [Fiber,xc,yc,nf,PBN] =  FiberCvarN(x,y,L,N,lambda,Pr,Pagg);

N = nf;
% return
% quit

% figure1 = figure;
% plot(PBN(:,1),PBN(:,2),'o')
% fibercT = toc
% the fibre network inside the squre box is created and the boundary
% nodes are found and put in the PBN

% figure to test


% tic
[Per,ip,pc,Fiber] = NetIntersecC(Fiber,x,y,PBN,nf,density);

% intersecT = toc
% intersection of fibres (with BC and eachother)...
% ... and allocating the cluster code
% pc represents the percolated cluster number (other...
% ...fibres should be deleted)
% % % % % % % % % figure1 = figure;
% % % % % % % % % for i = 1:size(Fiber)
% % % % % % % % %     if Fiber(i,8)==pc
% % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'r');
% % % % % % % % %     else
% % % % % % % % %         plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'b');
% % % % % % % % %     end
% % % % % % % % % hold on
% % % % % % % % % plot(PBN(:,1),PBN(:,2),'o')
% % % % % % % % % end
% % % % % % PBN
% % % % % % % % % % % % % % % % figure3 = figure;
% % % % % % % % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % % % % % % % hold on
% % % % % % % % % % % % % % % % plot(PBN(:,1), PBN(:,2),'o');
% % % % % % % % % % % % % % % % end

% Per represent the percolation 

if Per == false
    SDataH = 0;
    SDataV = 0;
    Fiber = 0;
    SDatatest = 0;
else % if the system is percolated then execute the rest of the code
  



% deleting the boundary nodes that are not connected to the main cluster

% tic 
sss=PBN;
PBN(:,5);
nn = 1; % node numebr

while nn <= size(PBN,1)
    pf = false; % percolated fibre
    for ipf = 1:size(pc,1)
        if Fiber(PBN(nn,4),8) == pc(ipf,1)
            pf = true;
        end
    end
    if pf == false
        
        for l = 1:size(PBN,1)
            if PBN(l,5) > nn
                if l ~=nn
                PBN(l,5) = PBN(l,5)-1;
                end
            end
        end
        
        if PBN(nn,5) == 0
        else
            PBN(PBN(nn,5),5) = 0;
        end
        
        PBN(nn,:) = [];
        nn = nn-1;
    end
    nn = nn+1;
end
PBN(:,5);







% PBN = sss;














% spb2 = size(PBN,1);
% kkk =1;
% % PBN(:,5)
% while kkk <= spb2
%     pf = false; % percolated fiber
%     for ipc = 1:size(pc,1)
%         if Fiber(PBN(kkk,4),8) == pc(ipc,1)
%             pf = true;
%         end
%     end
%     if pf == false
%         % reduce the ca of any further node by one
%         for ica = 1:size(PBN,1)
%             if PBN(ica,5) > kkk
%             PBN(ica,5) = PBN(ica,5)-1;
%             end
%         end
%         % change the couple node ca = 0
%         if PBN(kkk,5)~=0 % it might be a node that its couple is already deleted
%         PBN(PBN(kkk,5),5) = 0;
%         end
%         % delete the boundary node
%         PBN (kkk,:) = [];
%         kkk=kkk-1;
%         spb2 = spb2-1;
%     end
%     kkk=kkk+1;
% end
% PBN(:,5)
% figure1 = figure;
% for i = 1:size(Fiber)
%     if Fiber(i,8)==pc
% plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'r');
%     else
%         plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'b');
%     end
% hold on
% plot(PBN(:,1),PBN(:,2),'o')
% end


% figure to test
% % % % % % % % % % % % % figure2 = figure;
% % % % % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % % % % hold on
% % % % % % % % % % % % % end

 
% deleting the fibers that are not in the main cluster (fibres are either in the same cluster or are freely moving in the space which should be deleted)  
k=1;
nfd = 1; % to count the number of fibers
ndf = []; % deleted fibers
while k <= nf
    if Fiber(k,8)~=pc
        Fiber(k,:) =[];
%         ip(k,:) = []; % deleting the intersection of these fibers
%         ip(:,2*k-1:2*k) = [];
        nf = nf-1;
        k=k-1;
        ndf(end+1) = nfd; % to correct the address of fibres in the PBN
    end
    k=k+1;
    nfd = nfd+1;
end



% correcting the address of PBN (since some fibres are deleted)
PBN(:,6) = 0;
if ~isempty(ndf)
    for i=1:size(ndf,2)
        for j=1:size(PBN,1)
            if PBN(j,4)>ndf(1,i)
                PBN(j,6) = PBN(j,6)+1;
            end
        end
    end
end
PBN(:,4) = PBN(:,4)-PBN(:,6);
N = nf;

% finding the ip for the new network

% PBN2 = sortrows(PBN,3);

% sorting PBN while keeping the couple node information 
% PBN;
PBN2 = zeros(size(PBN,1),6);
tfa = 1; % to find address
for k=1:size(PBN,1)
    if PBN(k,3)==1
        PBN2(tfa,1:5) = PBN(k,1:5);
        PBN2(tfa,6) = k;
        tfa = tfa +1;
    end
end
for k=1:size(PBN,1)
    if PBN(k,3)==2
        PBN2(tfa,1:5) = PBN(k,1:5);
        PBN2(tfa,6) = k;
        tfa = tfa +1;
    end
end
for k=1:size(PBN,1)
    if PBN(k,3)==3
        PBN2(tfa,1:5) = PBN(k,1:5);
        PBN2(tfa,6) = k;
        tfa = tfa +1;
    end
end
for k=1:size(PBN,1)
    if PBN(k,3)==4
        PBN2(tfa,1:5) = PBN(k,1:5);
        PBN2(tfa,6) = k;
        tfa = tfa +1;
    end
end
% PBN2;
PBN3 = zeros(size(PBN2,1),1);

for k = 1:size(PBN2,1)
    if PBN2(k,5)~=0
        founc = false;
        l = 1;
        while founc == false
            if PBN2(k,5) == PBN2(l,6)
                PBN3(k,1) = l;
                founc = true;
            end
            l = l+1;
        end
    end
end

PBN2(:,5) = PBN3(:,1);
PBN3(:,1);
% look at all of the nodes with address 1
        % send the info to PBN2 (in order)
        % change the PBN(i,5) of the couple node to the new position
        
% look at all of the nodes with address 2
        % send the info to PBN2 (in order)
        % change the PBN(i,5) of the couple node to the new position
        
% do the same for nodes with address 3 and 4




% stuffT = toc



% figure1 = figure;
% for i =1:size(Fiber,1)
% plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'color','b');
% hold on
% end
% cbn = rand(size(PBN2,1),3); % color of the boundary node
% %     PBN
%     for j =1:size(PBN2,1)
%         l=1;
%         for k=1:j-1
%             if PBN2(k,5)==j
%                 l=k;
%                 break
%             else
%                 l = j;
%             end
%         end
% %         PBN(j,3)/4
%         plot([PBN2(j,1)],[PBN2(j,2)],'o','color',cbn(l,:),'MarkerSize',10,'MarkerFaceColor',cbn(l,:))
%     end
%           pbaspect([1 1 1])
          
          
% tic
[ip,Fiber,PI2,ED2] = NetIntersec(Fiber,x,y,PBN2,nf,density);
% [Per,ip,pc,Fiber] = NetIntersecOld(Fiber,x,y,PBN,nf,density);
% netintersec2T = toc



% Deleting the right and left boundaries and creating the vertical data.


% spbn2 = size(PBN2,1); % size of PBN2
% kk=1;
% while kk <= spbn2
%     if PBN2 (kk,3) == 1 || PBN2 (kk,3) == 2
%         PBN2(kk,:) = [];
%         spbn2 = spbn2-1;
%         kk=kk-1;
%     end
%     kk=kk+1;
% end

% % % % % % % % % % % % % % % % figure1 = figure;
% % % % % % % % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % % % % % % % hold on
% % % % % % % % % % % % % % % % plot(PBN2(:,1), PBN2(:,2),'o');
% % % % % % % % % % % % % % % % end
% tic
    [SData] = SortData(Fiber,N,PBN,PBN2,ip,L,lambda,density,PI2,ED2);
%     [SData] = SortDataOld(Fiber,N,PBN,PBN2,ip,L,lambda,density);
% sortdT = toc
    % this function gets raw data and changes it to the type that is ...
    % ...possible for the solver to understand. SDataH = Sorted data
    % horizental and V = vertical.
    % they include NN,NE,ED,PN, and data of boundaries.

NE = SData(1,6);
NN = SData(1,7);
PN = SData(1:NN,1:3);
ED = SData(1:NE,4:5);
nrb = SData(1,8);
nlb = SData(2,8);
ntb = SData(3,8);
nbb = SData(4,8);
nbn = nrb+nlb+ntb+nbb; % number of boundary nodes

% fogure1 = figure;
% for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'b')
%     hold on
% end

    Lf=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    Lf(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end 
    shortF = zeros(NE,1); % is it a short fibre? (1 = yes, 0 = no)
for i = 1:NE
    if Lf(i,1) < flt
        shortF(i,1) = 1;
    end
end
shF = shortF; % the shortF is manipulated and changed in the loop below.
% size(shortF);
nsF = sum(shortF(:) == 1); % number of short fibres

    
%     tic
    SDatatest = SData;
    SData = ModifyingNetworkLength(SData,flt);
    SDataV = SData;
%     lengthT = toc
% % % % % % % %     figure3 = figure;
% % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % hold on
% % % % % % % % end
    
    % Deleting the right and left boundaries and creating the vertical data.
% PBN2 = sortrows(PBN,3);
% 
% spbn2 = size(PBN2,1); % size of PBN2
% kk=1;
% while kk <= spbn2
%     if PBN2 (kk,3) == 3 || PBN2 (kk,3) == 4
%         PBN2(kk,:) = [];
%         spbn2 = spbn2-1;
%         kk=kk-1;
%     end
%     kk=kk+1;
% end


% % % % % % % % % % % % % % figure2 = figure;
% % % % % % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % % % % % hold on
% % % % % % % % % % % % % % plot(PBN2(:,1), PBN2(:,2),'o');
% % % % % % % % % % % % % % end

%     [SData] = SortData(Fiber,N,PBN,PBN2,ip,L);
%     SDataH = SData;

% deleting the dangling clusters using electrical current analysis (finding backbone)

NE = SDataV(1,6); % number of edges
NN = SDataV(1,7); % number of nodes
PN = SDataV(1:NN,1:3); % position of nodes
ED = SDataV(1:NE,4:5); % edge direction (node 1 to node 2)
nrb = SDataV(1,8); % number of boundary nodes on right side
nlb = SDataV(2,8); % number of boundary nodes on left side
ntb = SDataV(3,8); % number of boundary nodes on top side
nbb = SDataV(4,8); % number of boundary nodes on bottom side
nbn = nrb+nlb+ntb+nbb; % number of tottal boundary nodes
naf = SDataV(1:NE,10);
% fogure1 = figure;
% for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'b')
%     hold on
%     pbaspect([1 1 1])
% end
% xlim([0 10])
%
% fogure2 = figure;
% for j=1:size(ED2,1)
%     n=ED2(j,1);
%     m=ED2(j,2);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'b')
%     hold on
%     pbaspect([1 1 1])
% end
% size(ED)
% size(ED2)

% tic
% % % % % % % % % % % SDataV = BackboneCA(SDataV);
% bbT = toc


SDataH = 0;
% % % % % % % % % %     figure4 = figure;
% % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % hold on
% % % % % % % % % % end

% figure4 = figure;
% for i = 1:size(Fiber,1)
% plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'b','LineWidth',naf(i,1)*1.5);
% hold on
% pbaspect([1 1 1])
% end

% fogure1 = figure;
% for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
% %     naf(j,1) =1 ;
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'b','LineWidth',naf(j,1)*1.5)
% %     xt = PN(n,2)/2 + PN(m,2)/2;
% %     yt = PN(n,3)/2 + PN(m,3)/2;
% %     str = num2str(naf(j,1));
% %     text(xt,yt,str,'FontSize',14)
%     hold on
%     pbaspect([1 1 1])
% end

end
% end
end





