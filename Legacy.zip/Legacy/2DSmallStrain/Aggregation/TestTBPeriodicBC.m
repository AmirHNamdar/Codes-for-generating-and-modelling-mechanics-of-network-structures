% timoshenko beam code := Network theory with infnitisimle deformation in
% 2D using direct stiffness method
% Developed by Amir Hossein Namdar

clear
clc
close all


ks = 5/6; % for rectangle bar

% NN = 5;
% NE = 4;
% e = 100;
% g = e/3;
% Ar = 1; % area of the beam
% I = 1; % Area Moment of Inertia
% sM = false;
% E=e;
% G=g;
% PN = [3 3 ; 0 3 ; 2 3 ; 2 0 ; 1 3 ];
% ED = [1 5;2 5;3 5;4 5];
% coupn = [2;1;4;3];
% nrb = 1;
% nlb = 1;
% ntb = 1;
% nbb = 1;

NN = 7;
NE = 6;
e = 100;
g = e/3;
Ar = 1; % area of the beam
I = 1; % Area Moment of Inertia
sM = false;
E=e;
G=g;
PN = [3 1; 3 2; 0 1; 0 2; 2 3 ; 2 0 ; 1 3 ];
ED = [1 7;2 7;3 7;4 7;5 7; 6 7];
coupn = [3;4;1;2;6;5];
nrb = 2;
nlb = 2;
ntb = 1;
nbb = 1;




% NN = ;
% NE = 1;
% FF = [nan; nan; nan;0;10;0];
% UU = [0; 0; 0;nan;nan;nan]; 
% PN = [-0.2 3.65 0; 2.8 3.65 0; 0.8 0.65 0; 2.35 2.7 0; 1.8 -0.35 0; 2.3 -0.35 0];
% ED = [1 3; 3 4; 4 2; 3 5; 4 6];
BC(1,1) = 0; % right x (will be modified inside the code)
BC(2,1) = 0; % right y (will be modified inside the code)
BC(3,1) = 0; % right theta 
BC(4,1) = 0;  % left x (will be modified inside the code)
BC(5,1) = 0; % left y (will be modified inside the code)
BC(6,1) = 0;  % left theta
BC(7,1) = 0; % top x (will be modified inside the code)
BC(8,1) = 1; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% FF = [nan; nan; nan; nan; nan; nan; 0; 0; 0; 0; 0; 0; nan; nan; nan; nan; nan; nan];
% UU = [0; 0.0001; 0; 0; 0.0001; 0; nan; nan; nan; nan; nan; nan; 0; 0; 0; 0; 0; 0];

% PN222 = PN;
% PN = zeros(NN,2);
% PN(:,1) = PN222(:,2);
% PN(:,2) = PN222(:,3);

FF = zeros(3*NN,1);
UU = nan(3*NN,1);
% 

% FF(1:3:3*nrb) = BC(1,2);
% FF(2:3:3*nrb) = BC(2,2);
% FF(3:3:3*nrb) = BC(3,2);
% FF(3*nrb+1:3:3*(nlb+nrb)) = BC(4,2);
% FF(3*nrb+2:3:3*(nlb+nrb)) = BC(5,2);
% FF(3*nrb+3:3:3*(nlb+nrb)) = BC(6,2);
% FF(3*(nlb+nrb)+1:3:3*(nlb+nrb+ntb)) = BC(7,2);
% FF(3*(nlb+nrb)+2:3:3*(nlb+nrb+ntb)) = BC(8,2);
% FF(3*(nlb+nrb)+3:3:3*(nlb+nrb+ntb)) = BC(9,2);
% FF(3*(nlb+nrb+ntb)+1:3:3*(nlb+nrb+ntb+nbb)) = BC(10,2);
% FF(3*(nlb+nrb+ntb)+2:3:3*(nlb+nrb+ntb+nbb)) = BC(11,2);
% FF(3*(nlb+nrb+ntb)+3:3:3*(nlb+nrb+ntb+nbb)) = BC(12,2);

% for i = 1:nrb
% UU(3*i-2,1) = BCvx*(PN(i,2))/lambda; %%%%
% UU(3*i-1,1) = BCvy*(PN(i,2))/lambda; %%%%
% end
% UU(3:3:3*nrb) = BC(3,1);
% for i = nrb+1:nrb+nlb
% UU(3*i-2,1) = BCvx*(PN(i,2))/lambda; %%%%
% UU(3*i-1,1) = BCvy*(PN(i,2))/lambda; %%%%
% end
% UU(3*nrb+3:3:3*(nlb+nrb)) = BC(6,1);
% UU(3*(nlb+nrb)+1:3:3*(nlb+nrb+ntb)) = BC(7,1);
% UU(3*(nlb+nrb)+2:3:3*(nlb+nrb+ntb)) = BC(8,1);
% UU(3*(nlb+nrb)+3:3:3*(nlb+nrb+ntb)) = BC(9,1);
% UU(3*(nlb+nrb+ntb)+1:3:3*(nlb+nrb+ntb+nbb)) = BC(10,1);
% UU(3*(nlb+nrb+ntb)+2:3:3*(nlb+nrb+ntb+nbb)) = BC(11,1);
% UU(3*(nlb+nrb+ntb)+3:3:3*(nlb+nrb+ntb+nbb)) = BC(12,1);

% UU(1:3:3*nrb) = BC(1,1);
% UU(2:3:3*nrb) = BC(2,1);
% UU(3:3:3*nrb) = BC(3,1);
% UU(3*nrb+1:3:3*(nlb+nrb)) = BC(4,1);
% UU(3*nrb+2:3:3*(nlb+nrb)) = BC(5,1);
% UU(3*nrb+3:3:3*(nlb+nrb)) = BC(6,1);
% UU(3*(nlb+nrb)+1:3:3*(nlb+nrb+ntb)) = BC(7,1);
% UU(3*(nlb+nrb)+2:3:3*(nlb+nrb+ntb)) = BC(8,1);
% UU(3*(nlb+nrb)+3:3:3*(nlb+nrb+ntb)) = BC(9,1);
% UU(3*(nlb+nrb+ntb)+1:3:3*(nlb+nrb+ntb+nbb)) = BC(10,1);
% UU(3*(nlb+nrb+ntb)+2:3:3*(nlb+nrb+ntb+nbb)) = BC(11,1);
% UU(3*(nlb+nrb+ntb)+3:3:3*(nlb+nrb+ntb+nbb)) = BC(12,1);

% if sM ==true
%     UU(3*(nlb+nrb+ntb+1)-2) = 0; % at least one point should be fully constrained 
% end



% edges lenghts and angles_________________________________________________
L=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,1);
    dg=PN(d,2);
    cs=PN(c,1);
    cg=PN(c,2);
    L(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end   

TETA=zeros(NE,1);
for i=1:NE
    q=ED(i,1);
    w=ED(i,2);
    qs=PN(q,1);
    qg=PN(q,2);
    ws=PN(w,1);
    wg=PN(w,2);
    TETA1=asin((wg-qg)/L(i,1));
    TETA2=acos((ws-qs)/L(i,1));
    
    if TETA1 >= 0
        if TETA2 <= pi/2
            TETA(i,1) = TETA1;
        else TETA(i,1) = TETA2;
        end
    else 
        if TETA2 <= pi/2
            TETA(i,1) = 2*pi + TETA1;
        else TETA(i,1) = 2*pi - TETA2;
        end
    end
    
end

% stiffness matrix_________________________________________________________________

if sM == false

% M=(zeros(3*NN));
% % % % % % tic
% % % % % % M=spalloc(3*NN,3*NN,36*NE);
% % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % for i=1:NE
% % % % % % % % % % % % % % % % %     i
% % % % % % % % % % % % % % % % %     NE
% % % % % % % % % % % % % % % %     ll=L(i,1);
% % % % % % % % % % % % % % % %     t=TETA(i,1);
% % % % % % % % % % % % % % % %     C = cos(t);
% % % % % % % % % % % % % % % %     S = sin(t);
% % % % % % % % % % % % % % % %     phi = 12*e*I/(ks*Ar*g*ll^2) ;
% % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % %     % for Euler beam
% % % % % % % % % % % % % % % %     K = zeros(6);
% % % % % % % % % % % % % % % %     K(1,1) = (1+phi)*Ar*(C^2)+12*I*(S^2)/(ll^2);
% % % % % % % % % % % % % % % %     K(1,2) = ((1+phi)*Ar-12*I/(ll^2))*C*S;
% % % % % % % % % % % % % % % %     K(1,3) = -6*I*S/ll;
% % % % % % % % % % % % % % % %     K(1,4) = -(1+phi)*Ar*C^2-12*I*(S^2)/(ll^2);
% % % % % % % % % % % % % % % %     K(1,5) = -((1+phi)*Ar-12*I/(ll^2))*C*S;
% % % % % % % % % % % % % % % %     K(1,6) = -6*I*S/ll;
% % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % %     K(2,1) = K(1,2);
% % % % % % % % % % % % % % % %     K(2,2) = (1+phi)*Ar*(S^2)+12*I*(C^2)/(ll^2);
% % % % % % % % % % % % % % % %     K(2,3) = 6*I*C/ll;
% % % % % % % % % % % % % % % %     K(2,4) = -K(1,2);
% % % % % % % % % % % % % % % %     K(2,5) = -K(2,2);
% % % % % % % % % % % % % % % %     K(2,6) = K(2,3);
% % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % %     K(3,1) = K(1,3);
% % % % % % % % % % % % % % % %     K(3,2) = K(2,3);
% % % % % % % % % % % % % % % %     K(3,3) = (4+phi)*I;
% % % % % % % % % % % % % % % %     K(3,4) = 6*I*S/ll;
% % % % % % % % % % % % % % % %     K(3,5) = -6*I*C/ll;
% % % % % % % % % % % % % % % %     K(3,6) = (2-phi)*I;
% % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % %     K(4,1) = K(1,4);
% % % % % % % % % % % % % % % %     K(4,2) = K(2,4);
% % % % % % % % % % % % % % % %     K(4,3) = K(3,4);
% % % % % % % % % % % % % % % %     K(4,4) = K(1,1);
% % % % % % % % % % % % % % % %     K(4,5) = K(1,2);
% % % % % % % % % % % % % % % %     K(4,6) = 6*I*S/ll;
% % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % %     K(5,1) = K(1,5);
% % % % % % % % % % % % % % % %     K(5,2) = K(2,5);
% % % % % % % % % % % % % % % %     K(5,3) = K(3,5);
% % % % % % % % % % % % % % % %     K(5,4) = K(4,5);
% % % % % % % % % % % % % % % %     K(5,5) = K(2,2);
% % % % % % % % % % % % % % % %     K(5,6) = -6*I*C/ll;
% % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % %     K(6,1) = K(1,6);
% % % % % % % % % % % % % % % %     K(6,2) = K(2,6);
% % % % % % % % % % % % % % % %     K(6,3) = K(3,6);
% % % % % % % % % % % % % % % %     K(6,4) = K(4,6);
% % % % % % % % % % % % % % % %     K(6,5) = K(5,6);
% % % % % % % % % % % % % % % %     K(6,6) = (4+phi)*I;
% % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % %     K = e/(ll*(1+phi))*K;
% % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % %     KK = zeros(3*NN);
% % % % % % % % % % % % % % % % % % %     KK(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(1:3,1:3);
% % % % % % % % % % % % % % % % % % %     KK(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(1:3,4:6);
% % % % % % % % % % % % % % % % % % %     KK(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(4:6,1:3);
% % % % % % % % % % % % % % % % % % %     KK(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(4:6,4:6);
% % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % %     KK = sparse (KK);
% % % % % % % % % % % % % % % % % % %     M = M + KK; 
% % % % % % % % % % % % % % % % % % % %     M = sparse(M);
% % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % %     M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(1:3,1:3) + M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3);
% % % % % % % % % % % % % % % %     M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(1:3,4:6) + M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3);
% % % % % % % % % % % % % % % %     M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(4:6,1:3) + M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3);
% % % % % % % % % % % % % % % %     M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(4:6,4:6) + M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3);
% % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % end
% % % % % % % % % % % % % % % % Mtoc = toc
% tic
% Second method using cuvelier et. al. paper
I2 = zeros(NE,36);
J2 = zeros(NE,36);
K2 = zeros(NE,36);


    for j = 1:6
    I2(:,6-(j-1)) = ED(:,1).*3-2;
    I2(:,12-(j-1)) = ED(:,1).*3-1;
    I2(:,18-(j-1)) = ED(:,1).*3;
    I2(:,24-(j-1)) = ED(:,2).*3-2;
    I2(:,30-(j-1)) = ED(:,2).*3-1;
    I2(:,36-(j-1)) = ED(:,2).*3;
    end


for i = 1:6
    J2(:,i*6-5) = ED(:,1).*3-2;
    J2(:,i*6-4) = ED(:,1).*3-1;
    J2(:,i*6-3) = ED(:,1).*3;
    J2(:,i*6-2) = ED(:,2).*3-2;
    J2(:,i*6-1) = ED(:,2).*3-1;
    J2(:,i*6) = ED(:,2).*3;
end


%     size(I2)
    

% I2(:,1:3) = ED(:,1).*3-2 : ED(:,1).*3;
% I2(:,4:6) = ED(:,2).*3-2 : ED(:,2).*3;
% I2(:,7:9) = ED(:,1).*3-2 : ED(:,1).*3;
% I2(:,10:12) = ED(:,2).*3-2 : ED(:,2).*3;
% I2(:,13:15) = ED(:,1).*3-2 : ED(:,1).*3;
% I2(:,16:18) = ED(:,2).*3-2 : ED(:,2).*3;
% I2(:,19:21) = ED(:,1).*3-2 : ED(:,1).*3;
% I2(:,22:24) = ED(:,2).*3-2 : ED(:,2).*3;
% I2(:,25:27) = ED(:,1).*3-2 : ED(:,1).*3;
% I2(:,28:30) = ED(:,2).*3-2 : ED(:,2).*3;
% I2(:,31:33) = ED(:,1).*3-2 : ED(:,1).*3;
% I2(:,34:36) = ED(:,2).*3-2 : ED(:,2).*3;

% J2(:,1:3) = ED(:,1).*3-2 : ED(:,1).*3;
% J2(:,4:6) = ED(:,1).*3-2 : ED(:,1).*3;
% J2(:,7:9) = ED(:,1).*3-2 : ED(:,1).*3;
% J2(:,10:12) = ED(:,1).*3-2 : ED(:,1).*3;
% J2(:,13:15) = ED(:,1).*3-2 : ED(:,1).*3;
% J2(:,16:18) = ED(:,1).*3-2 : ED(:,1).*3;
% J2(:,19:21) = ED(:,2).*3-2 : ED(:,2).*3;
% J2(:,22:24) = ED(:,2).*3-2 : ED(:,2).*3;
% J2(:,25:27) = ED(:,2).*3-2 : ED(:,2).*3;
% J2(:,28:30) = ED(:,2).*3-2 : ED(:,2).*3;
% J2(:,31:33) = ED(:,2).*3-2 : ED(:,2).*3;
% J2(:,34:36) = ED(:,2).*3-2 : ED(:,2).*3;


    ll=L(:,1);
    C = cos(TETA(:,1));
    S = sin(TETA(:,1));
    phi = 12.*e.*I./(ks.*Ar.*g.*ll.^2) ;

    K2(:,1) = (1+phi).*Ar.*(C.^2)+12.*I.*(S.^2)./(ll.^2);
    K2(:,2) = ((1+phi).*Ar-12.*I./(ll.^2)).*C.*S;
    K2(:,3) = -6.*I.*S./ll;
    K2(:,4) = -(1+phi).*Ar.*C.^2-12.*I.*(S.^2)./(ll.^2);
    K2(:,5) = -((1+phi).*Ar-12.*I./(ll.^2)).*C.*S;
    K2(:,6) = -6.*I.*S./ll;

    K2(:,7) = K2(:,2);
    K2(:,8) = (1+phi).*Ar.*(S.^2)+12.*I.*(C.^2)./(ll.^2);
    K2(:,9) = 6.*I.*C./ll;
    K2(:,10) = -K2(:,2);
    K2(:,11) = -K2(:,8);
    K2(:,12) = K2(:,9);
    
    K2(:,13) = K2(:,3);
    K2(:,14) = K2(:,9);
    K2(:,15) = (4+phi).*I;
    K2(:,16) = 6.*I.*S./ll;
    K2(:,17) = -6.*I.*C./ll;
    K2(:,18) = (2-phi).*I;
    
    K2(:,19) = K2(:,4);
    K2(:,20) = K2(:,10);
    K2(:,21) = K2(:,16);
    K2(:,22) = K2(:,1);
    K2(:,23) = K2(:,2);
    K2(:,24) = 6.*I.*S./ll;
    
    K2(:,25) = K2(:,5);
    K2(:,26) = K2(:,11);
    K2(:,27) = K2(:,17);
    K2(:,28) = K2(:,23);
    K2(:,29) = K2(:,8);
    K2(:,30) = -6.*I.*C./ll;
    
    K2(:,31) = K2(:,6);
    K2(:,32) = K2(:,12);
    K2(:,33) = K2(:,18);
    K2(:,34) = K2(:,24);
    K2(:,35) = K2(:,30);
    K2(:,36) = (4+phi).*I;

K2 = e./(ll.*(1+phi)).*K2;

M = sparse(I2,J2,K2,3*NN,3*NN);

% M2toc = toc
end
% tic
% M = sparse(M);
% Solving__________________________________________________________________

AtMA = M;

F = FF;
U = UU;
AtMa2 = AtMA;


% updating F
if BC(1,1)~=0 || BC(2,1)~=0 || BC(3,1)~=0
    for i = 1:nrb
        if coupn(i,1)~=0
            cn = i; % couple node number
            cnx = 3*cn-2; % the degree of freedom in x
            cny = 3*cn-1;
            cnr = 3*cn;
            F = -AtMA(:,cnx)*BC(1,1)+F;
            F = -AtMA(:,cny)*BC(2,1)+F;
            F = -AtMA(:,cnr)*BC(3,1)+F;
        end
    end
end

for i = 1:nrb
    if coupn(i,1)~=0
        cn = coupn(i,1); % couple node number
        cnx = 3*cn-2; % the degree of freedom in x
        cny = 3*cn-1;
        cnr = 3*cn;
        F = -AtMA(:,cnx)*BC(4,1)+F;
        F = -AtMA(:,cny)*BC(5,1)+F;
        F = -AtMA(:,cnr)*BC(6,1)+F;
    end
end


    for i = nrb+nlb+1:nrb+nlb+ntb
        if coupn(i,1)~=0
            cn = i; % couple node number
            cnx = 3*cn-2; % the degree of freedom in x
            cny = 3*cn-1;
            cnr = 3*cn;
            F = -AtMA(:,cnx)*BC(7,1)+F;
            F = -AtMA(:,cny)*BC(8,1)+F;
            F = -AtMA(:,cnr)*BC(9,1)+F;
        end
    end


if BC(10,1)~=0 || BC(11,1)~=0 || BC(12,1)~=0
    for i = nrb+nlb+1:nrb+nlb+ntb
        if coupn(i,1)~=0
            cn = coupn(i,1); % couple node number
            cnx = 3*cn-2; % the degree of freedom in x
            cny = 3*cn-1;
            cnr = 3*cn;
            F = -AtMA(:,cnx)*BC(10,1)+F;
            F = -AtMA(:,cny)*BC(11,1)+F;
            F = -AtMA(:,cnr)*BC(12,1)+F;
        end
    end
end

coupn;
F

for i = 1:nrb
    if coupn(i,1)~=0
        cn = coupn(i,1);
        cnx = 3*cn-2; % the degree of freedom in x
        cny = 3*cn-1;
        cnr = 3*cn;
        F(3*i-2,1) = F(3*i-2,1)+F(cnx,1);
        F(3*i-1,1) = F(3*i-1,1)+F(cny,1);
        F(3*i,1) = F(3*i,1)+F(cnr,1);
    end
end

for i = nrb+nlb+1:nrb+nlb+ntb
    if coupn(i,1)~=0
        cn = coupn(i,1);
        cnx = 3*cn-2; % the degree of freedom in x
        cny = 3*cn-1;
        cnr = 3*cn;
        F(cnx,1) = F(3*i-2,1)+F(cnx,1);
        F(cny,1) = F(3*i-1,1)+F(cny,1);
        F(cnr,1) = F(3*i,1)+F(cnr,1);
    end
end
F
% 
% updating Stiffness matrix M
delM = [];
for i = 1:nrb % right and left boundary periodicity
    if coupn(i,1)~=0
        cn = coupn(i,1); % couple node number
        AtMA(:,3*i-2:3*i) = AtMA(:,3*i-2:3*i) + AtMA(:,3*cn-2:3*cn);
        AtMA(3*i-2:3*i,:) = AtMA(3*i-2:3*i,:) + AtMA(3*cn-2:3*cn,:);
%         AtMA(:,3*cn-2:3*cn) = [];
%         AtMA(3*cn-2:3*cn,:) = [];
       delM(end+1) = 3*cn-2;
       delM(end+1) = 3*cn-1;
       delM(end+1) = 3*cn;
    end
end
F
% AtMA(:,delM) = [];
% AtMA(delM,:) = [];
% 
% F(delM,:) = [];


% delM = [];
for i = nrb+nlb+1:nrb+nlb+ntb % top and bottom boundary periodicity
    if coupn(i,1)~=0
        cn = coupn(i,1);
        AtMA(:,3*cn-2:3*cn) = AtMA(:,3*i-2:3*i) + AtMA(:,3*cn-2:3*cn);
        AtMA(3*cn-2:3*cn,:) = AtMA(3*i-2:3*i,:) + AtMA(3*cn-2:3*cn,:);
%         AtMA(:,3*cn-2:3*cn) = [];
%         AtMA(3*cn-2:3*cn,:) = [];
       delM(end+1) = 3*i-2;
       delM(end+1) = 3*i-1;
       delM(end+1) = 3*i;
    end
end

AtMA(:,delM) = [];
AtMA(delM,:) = [];
F(delM,:) = [];

coupn;
F


% finding deformation U
% to solve it properly one point at one boundary should be fixed (x and y deformation). I have
% chosed the first node.
    
F(1:2,:) = [];
AtMA(1:2,:) = [];
AtMA(:,1:2) = [];    
%     F(4:5,:) = [];
% AtMA(4:5,:) = [];
% AtMA(:,4:5) = [];   


U=AtMA\F

% to create the U with all the B nodes

U = [0;0; U];
% U = [U(1:3); 0;0; U(4:7)];

for i = 1:nrb
    if coupn(i,1)~=0
        cn = coupn(i,1);
        Un = zeros(3,1); % Un = U(3*i-2:3*i,1); % the value of U will be added later
        U = [U(1:3*(cn-1),1); Un; U(3*(cn-1)+1:end,1)];
    end
end
for i = 1:nrb
    if coupn(i,1)~=0
        cn = coupn(i,1);
        Un = U(3*i-2:3*i,1); % Un = U(3*i-2:3*i,1); % the value of U will be added later
        U(3*cn-2:3*cn,1) = Un;
    end
end

for i = nrb+nlb+1:nrb+nlb+ntb
    if coupn(i,1)~=0
        cn = i;
        Un = zeros(3,1); % Un = U(3*coupn(i,1)-2:3*coupn(i,1),1); % the value of U will be added later
        U = [U(1:3*(cn-1),1); Un; U(3*(cn-1)+1:end,1)];
    end
end
for i = nrb+nlb+1:nrb+nlb+ntb
    if coupn(i,1)~=0
        cn = coupn(i,1);
        Un = U(3*coupn(i,1)-2:3*coupn(i,1),1); % Un = U(3*coupn(i,1)-2:3*coupn(i,1),1); % the value of U will be added later
        U(3*i-2:3*i) = Un;
    end
end
fu =  U
% adding the BC to deformation
if BC(1,1)~=0 || BC(2,1)~=0 || BC(3,1)~=0
    for i = 1:nrb
        if coupn(i,1)~=0
            cn = i; % couple node number
            cnx = 3*cn-2; % the degree of freedom in x
            cny = 3*cn-1;
            cnr = 3*cn;
            U(cnx,1) = BC(1,1)+U(cnx,1);
            U(cny,1) = BC(2,1)+U(cny,1);
            U(cnr,1) = BC(3,1)+U(cnr,1);
        end
    end
end

for i = 1:nrb
    if coupn(i,1)~=0
        cn = coupn(i,1); % couple node number
        cnx = 3*cn-2; % the degree of freedom in x
        cny = 3*cn-1;
        cnr = 3*cn;
        U(cnx,1) = BC(4,1)+U(cnx,1);
        U(cny,1) = BC(5,1)+U(cny,1);
        U(cnr,1) = BC(6,1)+U(cnr,1);
    end
end

if BC(7,1)~=0 || BC(8,1)~=0 || BC(9,1)~=0
    for i = nrb+nlb+1:nrb+nlb+ntb
        if coupn(i,1)~=0
            cn = i; % couple node number
            cnx = 3*cn-2; % the degree of freedom in x
            cny = 3*cn-1;
            cnr = 3*cn;
            U(cnx,1) = BC(7,1)+U(cnx,1);
            U(cny,1) = BC(8,1)+U(cny,1);
            U(cnr,1) = BC(9,1)+U(cnr,1);
        end
    end
end

for i = nrb+nlb+1:nrb+nlb+ntb
    if coupn(i,1)~=0
        cn = coupn(i,1); % couple node number
        cnx = 3*cn-2; % the degree of freedom in x
        cny = 3*cn-1;
        cnr = 3*cn;
        U(cnx,1) = BC(4,1)+U(cnx,1);
        U(cny,1) = BC(5,1)+U(cny,1);
        U(cnr,1) = BC(6,1)+U(cnr,1);
    end
end
UU = U;

% finding F

FF = M*UU;

% M = AtMA;


fM = full(M);
fA = full(AtMA);










% Solve
% for i=1:3*NN
%     if ~isnan(U(i,1))
%         F=-AtMA(:,i)*U(i,1)+F;
%     end
% end
% % toc1 = toc
% 
% % tic
% delN = []; % nodes that shall be deleted
% for i=1:(3)*NN
%     if ~isnan(U(i,1))
%         delN(end+1) = i;
%     end
% end
%         U(delN,:)=[];
%         AtMa2(:,delN)=[];
%         AtMa2(delN,:)=[];
%         F(delN,:)=[];
% tocneww = toc



% tic
% j=1;
% for i=1:3*NN
%     if ~isnan(U(j,1))
%         U(j,:)=[];
%         AtMa2(:,j)=[];
%         AtMa2(j,:)=[];
%         F(j,:)=[];
%     else
%         j=j+1;
%     end
% end
% oldtoc = toc

% sold = size(AtMa2)
% snew = size(MK)

% tic
% U=AtMa2\F;
% % Utoc = toc
% % tic
% k=1;
% for i=1:3*NN
%     if isnan(UU(i,1))
%         UU(i,1)=U(k,1);
%         k=k+1;
%     end
% end
% UU;
% % toc
% FF=AtMA*UU;
% Ftoc = toc
% Result___________________________________________________________________
% elements elongations
% dis = zeros(NN,3);
for i = 1:NN
    n = 3*i-2;
    dis(i,1) = UU(n,1);
    m = 3*i-1;
    dis(i,2) = UU(m,1);
    k = 3*i;
    dis(i,3) = UU(k,1);
end
% % C2= coordiantes after deformation 
C3=PN+dis(:,1:2);
% % L2= after elongation lenght of elements
% L2=zeros(NE,1);
% for i=1:NE
%     d=ED(i,1);
%     c=ED(i,2);
%     ds=C2(d,1);
%     dg=C2(d,2);
%     cs=C2(c,1);
%     cg=C2(c,2);
%     L2(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
% end
% 
% % dL=elements elongations
% dL=L2-L;
% % ddL= elements strains
% ddL=zeros(NE,1);
% for i=1:NE
%     ddL(i,1)=dL(i,1)/L(i,1);
% end
% ddL;
% % fo: elements forces
% fo=zeros(NE,1);
% for i=1:NE
%     fo(i,1)=ddL(i,1)*e;
% end
% fo;
% 
% 
% % plot:
% C3=PN+dis(:,1:2);
% 


% for k=1:

% if sM == true
figure1 = figure;
for j=1:NE
    n=ED(j,1);
    m=ED(j,2);
    plot([PN(n,1) PN(m,1)],[PN(n,2) PN(m,2)],'r','LineWidth',2)
    hold on
    plot([C3(n,1) C3(m,1)],[C3(n,2) C3(m,2)],'b','LineWidth',2)
    pbaspect([1 1 1])
    hold on
% end
end

% end






