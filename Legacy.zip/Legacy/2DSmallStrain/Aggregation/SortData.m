function [SData] = SortData(Fiber,N,PBN,PBN2,ip,L,lambda,density,PI2,ED2)

% it gets raw data and transfers two set of data taht can be used by
% sover. the two set is used for conditions that the BC is applied in two
% perpendicular directions

ED = ED2;

N = size(Fiber,1);
nrb = 0; % number of right boundary node
nlb = 0;
ntb = 0;
nbb = 0;

for i = 1:size(PBN2,1)
    if PBN2(i,3) == 1
        nrb = nrb + 1;
    elseif PBN2(i,3) == 2
        nlb = nlb + 1;
        elseif PBN2(i,3) == 3
          ntb = ntb + 1;
          elseif PBN2(i,3) == 4
            nbb = nbb + 1;
    end
end


PN(:,1:2) = PBN2(:,1:2);

% secondly sorting the fiber intersections considering the fact that the ip
% is diogonal matrix (i mean...u know!)
% tic
% PI = zeros(1,3); % position of intersections [number of nodes,x ,y]
k = size(PBN2,1) + 1;
% mip = (ip); % modified ip - data below the diogonal line is deleted
% for i = 1:N
%     for j = 1 : 2*i-1
%         mip(i,j) = 0;
%     end
% end
% toc1 = toc

% tic
% for i = 1:N
%     if nnz(mip(i,:)) ~= 0 % if any node that is not labled exist
%         for j = 1 : nnz(mip(i,:))/2
%             PI(k,1) = k;
%             pon = find(mip(i,:)); % pon = position of nodes in the mip
%             xn = mip(i,pon(2*j-1));
%             yn = mip(i,pon(2*j));
%             PI(k,2) = xn;
%             PI(k,3) = yn;
%             k=k+1;
%         end
%     end
% end
% toc2 = toc
% size(PBN2,1)
% size(PI2,1)

% PI = zeros(size(PI2,1)+size(PBN2,1),3);
% PI(k:end,:) = PI2;

PI = PI2;


PN = PI;
PN(1:nrb+nlb+ntb+nbb,2) = PBN2(:,1);
PN(1:nrb+nlb+ntb+nbb,3) = PBN2(:,2);
k = 1;
for i = 1:nrb+nlb+ntb+nbb
PN(i,1) = k;
k=k+1;
end

% % % % % % PBN2
% creating the edge direction----------------------------------------------
% we end up with two situation:1- the fibers has connection with the
% boundary. 2- it doesnt.
% tic
% ninter = floor(2*density/pi*N); % number of expected intersections
% mmip = spalloc (N,N,ninter); % modified ip that includes the number of nodes that each fiber is connected to
% mmip = zeros(N);
% k = nrb+nlb+ntb+nbb + 1;
% for i = 1:N
%     for j = 2*i:2*N
%         if rem(j,2)==0
%             if ip(i,j)~=0
%                 mmip(i,j/2) = k;
%                 k = k+1;
%             end
%         end
%     end
% end
% 
% for i = 1:N
%     for j = 1:i
%         mmip(i,j) = mmip(j,i);
%     end
% end
% toc3 = toc

% tic
% k = 1;
% ED = zeros(1,2);
% for i =1:N
%     drp = zeros(1,2); % distance to reference point which is the first point of the fiber
%     pon = find(mmip(i,:));
%     nnf = mmip(i,pon); % address of the nodes that exist on the fiber
%     lf = sqrt((Fiber(i,1)-Fiber(i,3))^2 + (Fiber(i,2)-Fiber(i,4))^2); % length of each fiber
%     if lf == L % the fiber doesn't have connection with the boundary
%         if nnz(mmip(i,:)) ~=0
%             for j = 1:nnz(mmip(i,:))
%                 drp(j,2) = sqrt((Fiber(i,1)-PN(nnf(1,j),2))^2 + (Fiber(i,2)-PN(nnf(1,j),3))^2); 
%                 drp(j,1) = nnf(1,j);
%             end
%             ged = sortrows(drp,2); % guide to create ED
%             if size(ged,1) > 1
%                 for l = 1:size(ged,1)-1
%                     ED(k,1) = ged(l+1,1);
%                     ED(k,2) = ged(l,1);
%                     k = k+1;
%                 end
%             end
%         end
%     else
%         [sb,ggf] = size(find(PBN2(:,4)==i)); % sb =  number of nodes at the boundary 
%         [nnb, jfdth] = find(PBN2(:,4)==i); % = address of node of the boundary
%         for h = 1:sb
%             sizel = size(nnf,2);
%             nnf(1,sizel+1) = nnb(h,1);
%         end
%         if nnz(mmip(i,:)) + sb ~=0
%             for j = 1:nnz(mmip(i,:)) + sb
%                 drp(j,2) = sqrt((Fiber(i,1)-PN(nnf(1,j),2))^2 + (Fiber(i,2)-PN(nnf(1,j),3))^2); 
%                 drp(j,1) = nnf(1,j);
%             end
%             ged = sortrows(drp,2); % guide to create ED
%             if size(ged,1) > 1
%                 for l = 1:size(ged,1)-1
%                     ED(k,1) = ged(l+1,1);
%                     ED(k,2) = ged(l,1);
%                     k = k+1;
%                 end
%             end
%         end
%     end
% end
% toc4 = toc

NE = size(ED,1);
NN = size(PN,1);


% Creating the SData Matrix that contains all the necessary information
SData = zeros(max(size(ED,1),size(PN,1)),8);
SData(1:size(PN,1),1:3) = PN;
SData(1:size(ED,1),4:5) = ED(:,1:2);
SData(1,6) = NE;
SData(1,7) = NN;
SData(1,8) = nrb;
SData(2,8) = nlb;
SData(3,8) = ntb;
SData(4,8) = nbb;
SData(1:size(PBN2,1),9) = PBN2(:,5);
PBN2(:,5);
SData(1:NE,10) = ED(:,3);
% ED(:,3)
% NE;
% size(ED(:,3));
% % % % % % % % % % % % % figure1=figure;
% % % % % % % % % % % % % for i=1:NE
% % % % % % % % % % % % %     n=ED(i,1);
% % % % % % % % % % % % %     m=ED(i,2);
% % % % % % % % % % % % %     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)])
% % % % % % % % % % % % %     texte = strcat(num2str(i));
% % % % % % % % % % % % %     texth1 = strcat(num2str(PN(n,1)));
% % % % % % % % % % % % %     texth2 = strcat(num2str(PN(m,1)));
% % % % % % % % % % % % %     text((PN(n,2)+PN(m,2))/2,(PN(n,3)+PN(m,3))/2,texte,'Color','green','FontSize',14)
% % % % % % % % % % % % %     text(PN(n,2)+1*lambda/100,PN(n,3),texth1,'Color','red','FontSize',14)
% % % % % % % % % % % % %     text(PN(m,2)-1*lambda/100,PN(m,3),texth2,'Color','black','FontSize',14)
% % % % % % % % % % % % % %     plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)])
% % % % % % % % % % % % %     hold on
% % % % % % % % % % % % %     plot(PN(:,2), PN(:,3),'o');
% % % % % % % % % % % % % end 

% % % % % % % % % % % % % % % figure2=figure;
% % % % % % % % % % % % % % % for i=1:size(Fiber,1)
% % % % % % % % % % % % % % % %     n=ED(i,1);
% % % % % % % % % % % % % % % %     m=ED(i,2);
% % % % % % % % % % % % % % % %     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)])
% % % % % % % % % % % % % % %     plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)])
% % % % % % % % % % % % % % %     hold on
% % % % % % % % % % % % % % %     plot(PN(:,2), PN(:,3),'o');
% % % % % % % % % % % % % % % end 

end