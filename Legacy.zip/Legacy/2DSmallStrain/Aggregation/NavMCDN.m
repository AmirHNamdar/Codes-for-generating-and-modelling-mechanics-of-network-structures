clear
clc
close all
% in this code, the dependancy of shear modulus to direction will be
% investigated.

Pr = 0.0;
Dc = 5.637;

Pagg1 = 0.0; % aggregation chance  +++++++++++++++++++++++++++
Pagg2 = 0.0; % aggregation chance  ///////////////////////////
TR = 5; % thickness ratio of fibre type 2 to type 1 % /////////////////////////
T2Fper = 0.1; % type two fibre 

minmidmax = 1; % 0=min, 1=mid, 2=max
% diam2 = [1e-2,1e-5,1e-4,1e-3,1e-2,1e-2,1e-2,1e-2,1e-3,1e-3,1e-3,1e-2];
% density2 = [10,10,10,10,20,25,30,40,15,20,25,100];
% diam2 = [1e-1,1e-1,1e-1,1e-1,1e-1,1e-1,1e-1,1e-1,1e-1];
% density2 = [7,8,9,10,15,20,30,50,70];
thickness2 = [1e-5,1e-4,1e-3];
diam2 = [1e-5];
% diam = 1e-1;
% diam2 = [1e-3,1e-3,1e-3,1e-3];
density2 = [25,30,35,40,50,60,75,100];


tb = 1;
if tb == 0
    IO = size(thickness2,2); % for rectangle bar
elseif tb == 1
    IO = size(diam2,2); % for circular bar
end

Z = [3.7910 3.8433 3.8747 3.9108 3.9374 3.954 3.97];




W = [];
for i = 1:size(density2,2)
    if tb == 1
        W(1,end+1:end+IO) = log10(density2(1,i).^7.*(diam2./4).^2);
    elseif tb == 0
        W(1,end+1:end+IO) = log10(density2(1,i).^7.*(thickness2./sqrt(12)).^2);
    end
end

% W = log10(density2.^7.*(thickness2./sqrt(12)).^2);
% lambda2 = zeros(1,size(diam2,2));
% lambda2 = zeros(1,size(thickness,2));

% for la = 1:size(diam2,2)
%     lambda2(1,la) = floor(10^(2.0)/(density2(1,la)-Dc)^(4/3))+1;
%     if lambda2(1,la)<5
%         lambda2(1,la)=5;
%     end
% end


wm = 2; % which method of creating the network? perfect squares = 1, random network wm = 2.
TM = true; % if timoshenko beam then true

N2s = 24; % number of study for each Nf
e = 100; % elastic modulus of beams
g = e/3; % for incompressible fibres

% tCN = zeros(Ns,1); % time allocated to create the network
% tSN = zeros(Ns,1); % time allocated to solve the network
% Nlambda = [28,20];
% Nslambda = (Nlambda(1,2) - Nlambda(1,1))/ Nlambda(1,3) + 1;

% Mslambda = zeros(Nslambda,N2s); % shear modulus relating to a given lambda;
% Melambda = zeros(Nslambda,N2s); % young modulus relating to a given lambda;
% MMslambda = zeros(Nslambda,1); % mean ...
% MMelambda = zeros(Nslambda,1); % mean ...


tic
% Ns = size(thickness2,2);
Ns = size(density2,2);

    Gs = zeros(N2s,IO*Ns);
    Ge = zeros(N2s,IO*Ns);
    mu = zeros(N2s,IO*Ns);
    den = zeros(N2s,IO*Ns); % to calculate density
    
for j = 1:Ns
%     thickness = thickness2(1,j);
% diam = diam2(1,j);
densityN1 = density2(1,j); % /////////////////////////
densityN2 = (T2Fper*densityN1); % /////////////////////////

    density = densityN1 + densityN2;
%     lambda = lambda2(1,j);
%     lambda = 2;
%     if density < 41
%         lambda = 25;
%     elseif density < 76
%         lambda = 20;
%     elseif density < 101
%         lambda = 15;
%     elseif density < 201
%         lambda = 10;
%     elseif density < 401
%         lambda = 10;   
%     elseif density < 501
%         lambda = 8;
%     end
    if density < 26
        lambda = 20;
        
    elseif density < 31
        lambda = 18;
        
    elseif density < 36
        lambda = 15;
        
    elseif density < 51
        lambda = 13;
        
    elseif density < 81
        lambda = 10;
        
    elseif density < 151
        lambda = 8; 
        
    elseif density < 501
        lambda = 6;
        
    end

  
%     lambda = 38;
    

BM = (lambda)/1000; % Boundary movement

 
    
   Nf1 = [(lambda)^2*densityN1]; % number of fibres data [initial nf, final nf, number of increase in each step]
Nf2 = floor((lambda)^2*densityN2); % number of fibres data [initial nf, final nf, number of increase in each step]

%     Ns = ; % number of considered density 


% input:
% Network generation
% lambda = 5;

% density = Nf(1,1)/(lambda)^2;

x=[0 lambda]; % boundary of x direction
y=[0 lambda]; % boundary of y direction
if wm == 1
N = 2 + 2*(ns); % for square beams
L = 300;
elseif wm == 2
N = Nf1 + Nf2; % Number of fibers
L=1; % Length of fibers
end
    Gv = zeros(N2s,IO);
    GvE = zeros(N2s,IO);
    mu1 = zeros(N2s,IO);
    denE = zeros(N2s,IO);
parfor ns = 1:N2s

ns
j

flt = 10^(-4)*L; % fibre lenght treshold. Edges smaller than flt will be deleted.


% tic % to record time


% e = 100; % elastic modulus of beams
% Ar = 1; % cross section of beams
% I = 1; % second moment


% using function NetworkRand to generate the random network and get the data
if wm == 1
[NN,NE,ED,PN,nrb,nlb,ntb,nbb,Fiber] = SquareBeams(x,y,L,N,lambda);
elseif wm == 2
[SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRandDN(x,y,L,Nf1,Nf2,lambda,flt,Pr,densityN1,densityN2,Pagg1,Pagg2,TR);
end
% tCN(ns,1) = toc;
if Per == false
    continue
end

% continue

NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);
nbn = nrb+nlb+ntb+nbb;
coupn = SDataV(1:nbn,9); % couple nodes
naf = SDataV(1:NE,10); %number of attached fibres% ++++++++++++++++++++++++++++++++++++++++++++++++++++++

% calculating density
n1 = ED(:,1);
n2 = ED(:,2);
xx = PN(:,2);
yy = PN(:,3);
edgeLengths = sqrt( (xx(n2) - xx(n1)).^2 + (yy(n2) - yy(n1)).^2);
weightedLengths = edgeLengths .* naf;
totalLength = sum(weightedLengths);
denl = totalLength / (lambda^2);



% % 1) normalize thickness into [minLW,maxLW]
% minLW = 0.5;
% maxLW = 5;
% naf_norm = (naf - min(naf)) ./ (max(naf)-min(naf));
% % lineWidths = naf_norm*(maxLW-minLW) + minLW;
% lineWidths = naf.*1;
% % 2) build a graph
% 
% tic
% % 3) plot it all at once
% figure2 = figure;
% for i = 1:NE
%     n1 = ED(i,1);
%     n2 = ED(i,2);
%     x = PN([n1 n2],2);
%     y = PN([n1 n2],3);
%     plot(x, y, 'k-', 'LineWidth', lineWidths(i));
%     hold on
% end
% axis equal off
% title('Random network – thickness ∝ line width')





BC = zeros(12,2);
% deformations
BC(1,1) = 0; % right x (will be modified inside the code)
BC(2,1) = 0; % right y (will be modified inside the code)
BC(3,1) = 0; % right theta 
BC(4,1) = 0;  % left x (will be modified inside the code)
BC(5,1) = 0; % left y (will be modified inside the code)
BC(6,1) = 0;  % left theta
BC(7,1) = BM; % top x (will be modified inside the code)
BC(8,1) = 0; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = nan;
BC(2,2) = nan;
BC(3,2) = nan;
BC(4,2) = nan;
BC(5,2) = nan;
BC(6,2) = nan;
BC(7,2) = nan;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = nan;
BC(11,2) = nan;
BC(12,2) = nan;

M = 0;
BCvx = 0;
BCvy = BM;


for o = 1 : IO
    if tb ==1
diam = diam2(1,o);
    elseif tb==0
thickness = thickness2(1,o);
    end
ArV = zeros(NE,1); % ++++++++++++++++++++++++++++++++++++++++++++++++++++++
IV = zeros(NE,1); % ++++++++++++++++++++++++++++++++++++++++++++++++++++++

if tb == 1
    for ari =1:NE  % ++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
%         ArV(ari,1) = pi*(diam*naf(ari,1))^2/4; % Ar vector
%         IV(ari,1) = pi*(diam*naf(ari,1))^4/64;
        
                % max bending increase
        if minmidmax == 2
        ArV(ari,1) = pi*(diam*naf(ari,1))^2/4; % Ar vector
        IV(ari,1) = pi*(diam*naf(ari,1))^4/64;
        
        % min bending increase 
        elseif minmidmax == 0
        ArV(ari,1) =naf(ari,1)*pi*(diam)^2/4; % Ar vector
        IV(ari,1) = naf(ari,1)*pi*(diam)^4/64;
        
        % mid bending increase 
        elseif minmidmax == 1
        ArV(ari,1) = naf(ari,1)*pi*(diam)^2/4; % Ar vector
        IV(ari,1) = pi*(sqrt(diam^2*naf(ari,1)))^4/64;
        
        % just investigating the structure
        elseif minmidmax ==3
        ArV(ari,1) = pi*(diam)^2/4; % Ar vector    
        IV(ari,1) = pi*(diam)^4/64;
        end
        
    end
elseif tb == 0
    for ari =1:NE  % ++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
        % max bending increase
        if minmidmax == 2
        ArV(ari,1) = (thickness)^2*naf(ari,1); % Ar vector
        IV(ari,1) = thickness*(thickness*naf(ari,1))^3/12; % bh^3/12
        
        % min bending increase 
        elseif minmidmax == 0
        ArV(ari,1) = (thickness)^2*naf(ari,1); % Ar vector
        IV(ari,1) = naf(ari,1)*thickness*(thickness)^3/12; % bh^3/12
        
        
        % mid bending increase 
        elseif minmidmax == 1
        ArV(ari,1) = (thickness)^2*naf(ari,1); % Ar vector
        IV(ari,1) = (thickness*sqrt(naf(ari,1)))^4/12; % bh^3/12
        end
        
    end 
end



sM = false;
[FFvE,UUvE,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,ArV,IV,sM,M,lambda,BCvx,BCvy,coupn,tb);
% [FFvE,UUvE,M] = BernoulliBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy,coupn,tb);

UTE = transpose(UUvE);
Etotal = 1/2*UTE*M*UUvE;


% modulus------------------------------------------------------------

sigx = 0; % stress in x direction
for si =nrb+nlb+1:nrb+nlb+ntb
    if coupn(si,1)~=0
    sigx = sigx+(FFvE(3*si-2,1));
    end
end
sigx = sigx/(x(2)-x(1));

sigy = 0; % stress in y direction
for si = nrb+nlb+1:nrb+nlb+ntb
    if coupn(si,1)~=0
    sigy = sigy+(FFvE(3*si-1,1));
    end
end
sigy = sigy/(y(2)-y(1));

mu1(ns,o) = sigx/sigy;
% GvE(ns,o) = (sigy^2-sigx^2)/(sigy*BM/(y(2)-y(1)));
GvE(ns,o) = 2*Etotal/lambda^2/(BM/lambda)^2;
denE(ns,o) = denl;

end
% denN(ns,o) = N;

end
mu(:,(j-1)*IO+1:j*IO) = mu1;
% Gs(:,j) = Gv;
Ge(:,(j-1)*IO+1:j*IO) = GvE;
% GE(:,3) = Gh;
% GE(:,4) = GhE;
den(:,(j-1)*IO+1:j*IO) = denE;

end

Mmu = zeros(1,Ns*IO);
% MGs = zeros(1,Ns); % Mean of Gs 
MGe = zeros(1,Ns*IO); % Mean of Ge
Mden = zeros(1,Ns*IO); % Mean of den


for i = 1: Ns*IO
%     Gs2 = Gs(:,i);
    Ge2 = Ge(:,i);
    mu2 = mu(:,i);
    den2 = den(:,i);
    k=1;
    for j = 1:N2s
        if Ge2(k,1) == 0
%             Gs2(k,:)=[];
            Ge2(k,:)=[];
            mu2(k,:)=[];
            den2(k,:)=[];
            k=k-1;
        end
        k=k+1;
    end
%     MGs(1,i) = mean(Gs2);
    MGe(1,i) = mean(Ge2);
    Mmu(1,i) = mean(mu2);
    Mden(1,i) = mean(den2);
end

% lMGs = zeros(1,Ns); % Mean of Gs 
lMGe = zeros(1,Ns*IO); % Mean of Ge

for i=1:Ns
if tb == 1
    lMGe(1,(i-1)*IO+1:i*IO) = log10(MGe(1,(i-1)*IO+1:i*IO)./0.38./density2(1,i)./(pi./4.*diam2.^2)./e);
elseif tb == 0
    lMGe(1,(i-1)*IO+1:i*IO) = log10(MGe(1,(i-1)*IO+1:i*IO)./0.38./density2(1,i)./(thickness2.^2)./e);
end
end
% (log10(MGe(1,5))-log10(MGe(1,1)))/(log10(density2(1,5))-log10(density2(1,1)))

% figure1 = figure;

% plot(W,lMGe,'o')
% figure1 = figure;
% plot(W,Mmu,'o')

% MMslambda(l,1) = MGs
% MMelambda(l,1) = MGe;


timeTottal = toc
% plot(MGs)


if wm ==1
    save('SSdata')      %-------------------*********************
elseif wm==2
%                                 -------------------*********************
if minmidmax==0
    h = 'Min';
elseif minmidmax==1
    h = 'Mid';
elseif minmidmax==2
    h = 'Max';
elseif minmidmax ==3
    h= 'Structure';
end
    nameS = strcat('MCAggDN',h,'T2Fper',num2str(T2Fper*10),'Pagg2',num2str(Pagg2*10));
    save(nameS)
end

% poly = polyfit(den,G,4);
% x1 = linspace(min(denN),max(denN));
% y1 = polyval(poly,x1);

% subplot(2,2,1)
% plot(den,G,'o')
% hold on
% plot(x1,y1)
% hold on
% subplot(2,2,2)
% plot(denN,G,'o')
% hold on
% subplot(2,2,3)
% plot(denf,G,'o')

% 
delE = [];
for i = 1:size(density2,2)
    delE(end+1) = i*IO-1;
    delE(end+1) = i*IO;
%     delE(end+1) = i*IO-2;
%     delE(end+1) = i*IO-4;
end
% % lMGe(:,delE) = [];
% % %     
% %    E = [lMGe(:,1),lMGe(:,5),lMGe(:,9),lMGe(:,13),lMGe(:,17),lMGe(:,21)]
 
    
    
    
    
    
    
    

