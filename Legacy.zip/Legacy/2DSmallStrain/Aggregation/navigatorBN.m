clear 
clc
close all

% this is for creating and testing batched networks 




Pr = 0.0;
Pagg = 0.9; % chance for moving toward other fibre +++++++++++++++++++++++++++

tb = 1; % type of bar 0 for rectangular bar and 1 for circular bar
thickness = 1e-5;
diam = 1e-5;
density = 30;
wm = 2;
% =-§12e[p[ network? perfect squares = 1, random network wm = 2.
TM = true; % if timoshenko beam then true
lambda = 5;

N2s = 1; % number of study for each Nf

Nf = [(lambda)^2*density,(lambda)^2*density,1]; % number of fibres data [initial nf, final nf, number of increase in each step]
Ns = (Nf(1,2) - Nf(1,1))/ Nf(1,3) + 1; % number of considered density

% tCN = zeros(Ns,1); % time allocated to create the network
% tSN = zeros(Ns,1); % time allocated to solve the network

Gs = zeros(N2s,Ns);
Ge = zeros(N2s,Ns);
% mu = zeros(N2s,Ns);
tic
for j = 1:Ns


% input:
% Network generation
% lambda = 5;

density = Nf(1,1)/(lambda)^2;

x=[0 lambda]; % boundary of x direction
y=[0 lambda]; % boundary of y direction
if wm == 1
N = 2 + 2*(ns); % for square beams
L = 300;
elseif wm == 2
N = (j-1) * Nf(1,3) + Nf(1,1); % Number of fibers
L=1; % Length of fibers
end
    Gv = zeros(N2s,1);
    GvE = zeros(N2s,1);
%     mu1 = zeros(N2s,1);
for ns = 1:N2s
ns
j
flt = 10^(-4)*L; % fibre lenght treshold. Edges smaller than flt will be deleted.


% tic % to record time


% e = 100; % elastic modulus of beams
% Ar = 1; % cross section of beams
% I = 1; % second moment


e = 100; % elastic modulus of beams
g = e/3; % for incompressible fibres


% Ar = 1;
% I = 1; 
BM = (x(2)-x(1))/1000; % Boundary movement

% using function NetworkRand to generate the random network and get the data
if wm == 1
[NN,NE,ED,PN,nrb,nlb,ntb,nbb,Fiber] = SquareBeams(x,y,L,N,lambda);
elseif wm == 2
[SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRandBN(x,y,L,N,lambda,flt,Pr,density,Pagg);
end
% toc
% tCN(ns,1) = toc;
if Per == false
    continue
end


NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);
nbn = nrb+nlb+ntb+nbb;
coupn = SDataV(1:nbn,9); % couple nodes
naf = SDataV(1:NE,10); %number of attached fibres% ++++++++++++++++++++++++++++++++++++++++++++++++++++++


ArV = zeros(NE,1); % ++++++++++++++++++++++++++++++++++++++++++++++++++++++
IV = zeros(NE,1); % ++++++++++++++++++++++++++++++++++++++++++++++++++++++

if tb == 1

        ArV(:,1) = pi*(diam)^2/4; % Ar vector
        IV(:,1) = pi*(diam)^4/64;
        
elseif tb == 0

        ArV(:,1) = (thickness)^2; % Ar vector
        IV(:,1) = thickness*(thickness)^3/12; % bh^3/12

end














% BB
% M = 0;
% sM = false;
% [fov,C3v,FFv,UUv,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);
% 
% BC(7,1) = 0;
% BC(8,1) = BM; % to investigate E
% sM = true;
% [fovE,C3vE,FFvE,UUvE,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);

% initializing BC for calculating shear modulus
BC = zeros(12,2);

% deformations
% deformations
BC(1,1) = nan; % right x (will be modified inside the code)
BC(2,1) = nan; % right y (will be modified inside the code)
BC(3,1) = nan; % right theta 
BC(4,1) = nan;  % left x (will be modified inside the code)
BC(5,1) = nan; % left y (will be modified inside the code)
BC(6,1) = nan;  % left theta
BC(7,1) = BM; % top x (will be modified inside the code)
BC(8,1) = 0; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = 0;
BC(2,2) = 0;
BC(3,2) = 0;
BC(4,2) = 0;
BC(5,2) = 0;
BC(6,2) = 0;
BC(7,2) = nan;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = nan;
BC(11,2) = nan;
BC(12,2) = nan;



% % % TB

M = 0;
M2 =0;
sM = false;
BCvx = BM; 
BCvy = 0;
% [fov,C3v,FFv,UUv,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy);

BC = zeros(12,2);
% deformations
BC(1,1) = 0; % right x (will be modified inside the code)
BC(2,1) = 0; % right y (will be modified inside the code)
BC(3,1) = 0; % right theta 
BC(4,1) = 0;  % left x (will be modified inside the code)
BC(5,1) = 0; % left y (will be modified inside the code)
BC(6,1) = 0;  % left theta
BC(7,1) = BM; % top x (will be modified inside the code)
BC(8,1) = 0; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = nan;
BC(2,2) = nan;
BC(3,2) = nan;
BC(4,2) = nan;
BC(5,2) = nan;
BC(6,2) = nan;
BC(7,2) = nan;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = nan;
BC(11,2) = nan;
BC(12,2) = nan;

BCvx = 0;
BCvy = BM;

sM = false;
% tic
mean(naf)
var(naf)
[FFvE,UUvE,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,ArV,IV,sM,M,lambda,BCvx,BCvy,coupn,tb);

 
Ed = EnergyF2(PN,ED,IV,ArV,UUvE,e,g,tb,NE,NN);
bEN = sum(Ed(:,1)); % bending portion of the network
sEN = sum(Ed(:,2)); % stretching //
shEN = sum(Ed(:,3)); % shear //

allE = bEN+ sEN + shEN;
BendingToAllRatio = bEN/allE

Esegment = Ed(:,1) + Ed(:,2) + Ed(:,3);



% toc
% shear modulus------------------------------------------------------------
% aggregation of forces in x direction devided by rotation

% sfv = 0; % shear force on the boundary V
% for i = (nlb+nrb)+1:(nlb+nrb+ntb)
%     sfv = FFv(i*3-2,1)+sfv;
% end
% sfv2 = 0; % the force on bottom boundary (to check the equilibrium)
% for i = (nlb+nrb+ntb)+1:(nlb+nrb+ntb+nbb)
%     sfv2 = FFv(i*3-2,1)+sfv2;
% end
% 
% Gv(ns,1) = sfv/lambda / tan(BM / (y(2)-y(1)));
% UT = transpose(UUv);
% Energy = UT*M*UUv;
% shear = Energy/(BM)^2;

% sfvE = 0; % shear force on the boundary V
% for i = (nlb+nrb)+1:(nlb+nrb+ntb)
%     sfvE = FFvE(i*3-1,1)+sfvE;
% end
% sfvE2 = 0; % the force on bottom boundary (to check the equilibrium)
% for i = (nlb+nrb+ntb)+1:(nlb+nrb+ntb+nbb)
%     sfvE2 = FFvE(i*3-1,1)+sfvE2;
% end
% sfvEr = 0; % right
% for i = 1:(nrb)
%     sfvEr = FFvE(i*3-2,1)+sfvEr;
% end
% sfvE;
% sfvEr;
% % GvE(ns,1) = sfvE/lambda / (BM/lambda);


UTE = transpose(UUvE);
Energy = 1/2*UTE*M*UUvE;
% young2 = 2*Energy/(BM)^2;
% GvE(ns,1) = young2;

% finding mu and then E
% mu = 1-2*shear/young2;
% young = 2*shear*(1+mu);

sigx = 0; % stress in x direction
for si =1:nrb
    if coupn(si,1)~=0
    sigx = sigx+(FFvE(3*si-2,1));
    end
end
sigx = sigx/(x(2)-x(1));

sigy = 0; % stress in y direction
for si = nrb+nlb+1:nrb+nlb+ntb
    if coupn(si,1)~=0
    sigy = sigy+(FFvE(3*si-1,1));
    end
end
sigy = sigy/(y(2)-y(1));

mu1 = sigx/sigy;
GvE = (sigy^2-sigx^2)/(sigy*BM/(y(2)-y(1)));


% mu1(ns,1) = GvE(ns,1)/Gv(ns,1)/2-1;
denN(ns,1) = N;

end

% Gs(:,j) = Gv;
Ge(:,j) = GvE;
mu(:,j) = mu1;
% GE(:,3) = Gh;
% GE(:,4) = GhE;

end


% MGs = zeros(1,Ns); % Mean of Gs 
MGe = zeros(1,Ns); % Mean of Ge



for i = 1: Ns
%     Gs2 = Gs(:,i);
    Ge2 = Ge(:,i);
    
    k=1;
    for j = 1:N2s
        if Ge2(k,1) == 0
%             Gs2(k,:)=[];
            Ge2(k,:)=[];
            k=k-1;
        end
        k=k+1;
    end
%     MGs(1,i) = mean(Gs2);
    MGe(1,i) = mean(Ge2);
end
toc
% plot(MGs)
GvE
mu
% log10(GvE/100/diam^2/pi*4/100/0.38)
mean(naf)





%%%%%%% calculating E(N^1/2 * w)/E(w) and compare to E(N^1/2) (N = naf);
w = Esegment./sum(Esegment);
Ew = mean(w);
EN12W = mean(sqrt(naf) .* w)/Ew
EN12 = mean(sqrt(naf))


Lf=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    Lf(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end 

sum(Lf)/lambda^2*mean(naf)/density


% if wm ==1
%     save('SSdata')      %-------------------*********************
% elseif wm==2
%                                 %-------------------*********************
%     nameS = strcat('SSdensity',num2str(density),'diam',num2str(diam),'Pr',num2str(Pr*100),'lambda',num2str(lambda),'-ConvStudy');
%     save(nameS)
% end

% poly = polyfit(den,G,4);
% x1 = linspace(min(denN),max(denN));
% y1 = polyval(poly,x1);

% subplot(2,2,1)
% plot(den,G,'o')
% hold on
% plot(x1,y1)
% hold on
% subplot(2,2,2)
% plot(denN,G,'o')
% hold on
% subplot(2,2,3)
% plot(denf,G,'o')

% plotting the network
% figure1 = figure;
% for j=1:NE
%     n=ED(j,1);
%     m=ED(j,2);
%     t = naf(j,1);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'color',[0.0000 0.2 0.8],'LineWidth',t)
%     hold on
%     ax = gca;  % or [ax1 ax2] if you have multiple axes
% 
%     set(ax,'XTick',[],'YTick',[]);
%     plot([C3(n,1) C3(m,1)],[C3(n,2) C3(m,2)],'b','LineWidth',2)
%     pbaspect([1 1 1])
%     hold on
% end
% end


% looking at the profile of deformation 

% figure1 = figure;
% for i =1:nrb
%     if coupn(i,1)~=0
%     plot(UUvE(3*i-2,1),PN(i,3),'o')
%     hold on
%     end
% % end
% figure1 = figure;
% for i =1:nrb
%     if coupn(i,1)~=0
%     plot(UUvE(3*i-1,1),PN(i,3),'o')
%     hold on
%     end
% end
% figure1 = figure;
% for i =1:nrb
%     if coupn(i,1)~=0
%     plot(UUvE(3*i,1),PN(i,3),'o')
%     hold on
%     end
% end
% 
% figure1 = figure;
% for i =nrb+nlb+1:nrb+nlb+ntb
%     if coupn(i,1)~=0
%     plot(PN(i,2),UUvE(3*i-1,1),'o')
%     hold on
%     end
% end
% 
% ar = 0;
% for i =1:nrb
%     if coupn(i,1)~=0
%     ar = ar+(FFvE(3*i-1,1));
%    
%     end
% end
% 
% ar
% 
% ar = 0;
% for i =nrb+1:nrb+nlb
%     if coupn(i,1)~=0
%     ar = ar+(FFvE(3*i-1,1));
%    
%     end
% end
% 
% ar

% ar = 0;
% for i = nrb+nlb+1:nrb+nlb+ntb
%     if coupn(i,1)~=0
%     ar = ar+(FFvE(3*i-1,1));
%    
%     end
% end
% 
% ar
% 
% ar = 0;
% for i = nrb+nlb+ntb+1:nrb+nlb+ntb+nbb
%     if coupn(i,1)~=0
%     ar = ar+(FFvE(3*i-1,1));
%    
%     end
% end
% 
% ar

% ar = 0;
% c = 0;
% for i = nrb+nlb+1:nrb+nlb+ntb
%     if coupn(i,1)~=0
%     ar = ar+(UUvE(3*i-1,1));
%    c = c+1;
%     end
% end 
% 

% plotting energy distribution
% calculating energy of each fibre
% [Ef,Mf] = EnergyF(PN,ED,I,Ar,UUvE,e,g); % energy of fibres 


% log10(GvE/e/thickness^2/density/0.38)
% log10(GvE/e/diam^2/pi*4/density/0.38)
% log10(density^7*(thickness/sqrt(12))^2)
% log10(density^7*(diam/4)^2)



% ar/c
% 
% ar = 0;
% c = 0;
% for i = nrb+nlb+ntb+1:nrb+nlb+ntb+nbb
%     if coupn(i,1)~=0
%     ar = ar+(UUvE(3*i-1,1));
%       c = c+1;
%     end
% end
% 
% ar/c










% analysing data of how the energy is stored
% _________________________________________________________________________



Etottal = sum(Esegment); 
tes = 0.50; % tottal energy storage
nof = [1:NE]; % number of fibres
Esegment2 = [nof;Esegment']';
Esegment2 = sortrows(Esegment2,2,'descend');

Estored = 0;
i=0;
while Estored <= tes % Estored = energy stored 
    i = i+1;
    Estored = Esegment2(i,2)/Etottal+Estored;
end

netes = Esegment2(1:i,1); % nodes that store tes

nntes = size(netes,1)/NE % how many nodes store tes

Mfstes = mean(naf(netes))
Mf = mean(naf)








