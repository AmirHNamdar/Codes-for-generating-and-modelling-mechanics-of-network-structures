clear
clc
close all
% in this code, the dependancy of shear modulus to direction will be
% investigated.

Pr = 0.0;
Dc = 5.637;
low = true;

% diam2 = [1e-2,1e-5,1e-4,1e-3,1e-2,1e-2,1e-2,1e-2,1e-3,1e-3,1e-3,1e-2];
% density2 = [10,10,10,10,20,25,30,40,15,20,25,100];
% diam2 = [1e-1,1e-1,1e-1,1e-1,1e-1,1e-1,1e-1,1e-1,1e-1];
% density2 = [7,8,9,10,15,20,30,50,70];
if low == true
    thickness2 = [1e-6];
    diam2 = [5e-5];
    % diam = 1e-1;
    % diam2 = [1e-3,1e-3,1e-3,1e-3];
%     density2 = [25,27,30,32,35,37,40,42,45,47,50,52,55,57,60];
    density2 = [25,30,35,40,35,50];
    
N2s1 = 12;
N2s = N2s1; % number of study for each Nf

else
    thickness2 = [1e-6,3e-6,6e-6,1e-5,5e-5,1e-4,1e-3,5e-3,1e-2];
    diam2 = [1e-5,1e-4,1e-3,1e-2,1e-1];
    % diam = 1e-1;
    % diam2 = [1e-3,1e-3,1e-3,1e-3];
    density2 = [75]; 
    
N2s1 = 72;
N2s = N2s1; % number of study for each Nf

end


tb = 1;
if tb == 0
    IO = size(thickness2,2); % for rectangle bar
elseif tb == 1
    IO = size(diam2,2); % for circular bar
end

Z = [3.7910 3.8433 3.8747 3.9108 3.9374 3.954 3.97];




W = [];
for i = 1:size(density2,2)
    if tb == 1
        W(1,end+1:end+IO) = log10(density2(1,i).^7.*(diam2./4).^2);
    elseif tb == 0
        W(1,end+1:end+IO) = log10(density2(1,i).^7.*(thickness2./sqrt(12)).^2);
    end
end
% W = log10(density2.^7.*(thickness2./sqrt(12)).^2);
% lambda2 = zeros(1,size(diam2,2));
% lambda2 = zeros(1,size(thickness,2));

% for la = 1:size(diam2,2)
%     lambda2(1,la) = floor(10^(2.0)/(density2(1,la)-Dc)^(4/3))+1;
%     if lambda2(1,la)<5
%         lambda2(1,la)=5;
%     end
% end


wm = 2; % which method of creating the network? perfect squares = 1, random network wm = 2.
TM = true; % if timoshenko beam then true
e = 100; % elastic modulus of beams
g = e/3; % for incompressible fibres

% tCN = zeros(Ns,1); % time allocated to create the network
% tSN = zeros(Ns,1); % time allocated to solve the network
% Nlambda = [28,20];
% Nslambda = (Nlambda(1,2) - Nlambda(1,1))/ Nlambda(1,3) + 1;

% Mslambda = zeros(Nslambda,N2s); % shear modulus relating to a given lambda;
% Melambda = zeros(Nslambda,N2s); % young modulus relating to a given lambda;
% MMslambda = zeros(Nslambda,1); % mean ...
% MMelambda = zeros(Nslambda,1); % mean ...


tic
% Ns = size(thickness2,2);
Ns = size(density2,2);

    Gs = zeros(N2s,IO*Ns);
    Ge = zeros(N2s,IO*Ns);
    mu = zeros(N2s,IO*Ns);
    EmodeB = zeros(N2s,IO*Ns);
    Emodes = zeros(N2s,IO*Ns);
    Emodesh = zeros(N2s,IO*Ns);
    Etotal = zeros(N2s,IO*Ns);
    
for j = 1:Ns
%     thickness = thickness2(1,j);
% diam = diam2(1,j);
    density = density2(1,j);
%     lambda = lambda2(1,j);
%     lambda = 2;
    if density < 26
        lambda = 22;
        N2s = N2s1;
    elseif density < 31
        lambda = 20;
        N2s = N2s1;
    elseif density < 36
        lambda = 18;
        N2s = N2s1;
    elseif density < 51
        lambda = 15;
        N2s = N2s1;
    elseif density < 81
        lambda = 12;
        N2s = N2s1;
    elseif density < 151
        lambda = 10; 
        N2s = N2s1;
    elseif density < 501
        lambda = 5;
        N2s = N2s1;
    end
  
%     lambda = 38;
    

BM = (lambda)/1000; % Boundary movement

 
    
    Nf = (lambda)^2*density; % number of fibres data 
%     Ns = ; % number of considered density 


% input:
% Network generation
% lambda = 5;

% density = Nf(1,1)/(lambda)^2;

x=[0 lambda]; % boundary of x direction
y=[0 lambda]; % boundary of y direction
if wm == 1
N = 2 + 2*(ns); % for square beams
L = 300;
elseif wm == 2
N = Nf; % Number of fibers
L=1; % Length of fibers
end
    Gv = zeros(N2s1,IO);
    GvE = zeros(N2s1,IO);
    mu1 = zeros(N2s1,IO);
    EmodeBending2 = zeros(N2s1,IO);
    EmodeStretching2 = zeros(N2s1,IO);
    Emodeshear2 = zeros(N2s1,IO);
    Etotal2 = zeros(N2s1,IO);
    
parfor ns = 1:N2s

ns
j

flt = 10^(-3)*L/density; % fibre lenght treshold. Edges smaller than flt will be deleted.


% tic % to record time


% e = 100; % elastic modulus of beams
% Ar = 1; % cross section of beams
% I = 1; % second moment


% using function NetworkRand to generate the random network and get the data
if wm == 1
[NN,NE,ED,PN,nrb,nlb,ntb,nbb,Fiber] = SquareBeams(x,y,L,N,lambda);
elseif wm == 2
[SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRand(x,y,L,N,lambda,flt,Pr,density);
end
% tCN(ns,1) = toc;
if Per == false
    continue
end

% continue

NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);
nbn = nrb+nlb+ntb+nbb;
coupn = SDataV(1:nbn,9); % couple nodes


BC = zeros(12,2);
% deformations
BC(1,1) = 0; % right x (will be modified inside the code)
BC(2,1) = 0; % right y (will be modified inside the code)
BC(3,1) = 0; % right theta 
BC(4,1) = 0;  % left x (will be modified inside the code)
BC(5,1) = 0; % left y (will be modified inside the code)
BC(6,1) = 0;  % left theta
BC(7,1) = BM; % top x (will be modified inside the code)
BC(8,1) = 0; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = nan;
BC(2,2) = nan;
BC(3,2) = nan;
BC(4,2) = nan;
BC(5,2) = nan;
BC(6,2) = nan;
BC(7,2) = nan;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = nan;
BC(11,2) = nan;
BC(12,2) = nan;

M = 0;
BCvx = 0;
BCvy = BM;


if tb == 1
    Ar2 = pi.*diam2.^2./4; % cross section of circular beams
    I2 = pi.*diam2.^4./64; % second moment of circular bars 
elseif tb == 0
   Ar2 = thickness2.^2; % cross section of square beams    
   I2 = (thickness2).^4./12; % second moment of square bars 
end

for o = 1 : IO
Ar = Ar2(1,o);
I = I2(1,o);

sM = false;
[FFvE,UUvE,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy,coupn,tb);
% [FFvE,UUvE,M] = BernoulliBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy,coupn,tb);

% finding eneregy distribution:
Ed = EnergyF2(PN,ED,I,Ar,UUvE,e,g,tb,NE); % Ed = energy distribution (each fibre and each mode)
bEN = sum(Ed(:,1)) % bending portion of the network
sEN = sum(Ed(:,2)) % stretching //
shEN = sum(Ed(:,3)) % shear //

% ooo = o;
EmodeBending2(ns,o) = bEN;
EmodeStretching2(ns,o) = sEN;
Emodeshear2(ns,o) = shEN;



UTE = transpose(UUvE);
Etotal2(ns,o) = 1/2*UTE*M*UUvE;




% modulus------------------------------------------------------------

sigx = 0; % stress in x direction
for si =nrb+nlb:nrb
    if coupn(si,1)~=0
    sigx = sigx+(FFvE(3*si-2,1));
    end
end
sigx = sigx/(x(2)-x(1));

sigy = 0; % stress in y direction
for si = nrb+nlb+1:nrb+nlb+ntb
    if coupn(si,1)~=0
    sigy = sigy+(FFvE(3*si-2,1));
    end
end
sigy = sigy/(y(2)-y(1));

mu1(ns,o) = sigx/sigy;
GvE(ns,o) = sigy/(BM/(y(2)-y(1)));


end
% denN(ns,o) = N;

end

mu(:,(j-1)*IO+1:j*IO) = mu1;
% Gs(:,j) = Gv;
Ge(:,(j-1)*IO+1:j*IO) = GvE;

    EmodeB(:,(j-1)*IO+1:j*IO) = EmodeBending2;
    Emodes(:,(j-1)*IO+1:j*IO) = EmodeStretching2;
    Emodesh(:,(j-1)*IO+1:j*IO) = Emodeshear2;
    Etotal(:,(j-1)*IO+1:j*IO) = Etotal2;

% GE(:,3) = Gh;
% GE(:,4) = GhE;

end

Mmu = zeros(1,Ns*IO);
% MGs = zeros(1,Ns); % Mean of Gs 
MGe = zeros(1,Ns*IO); % Mean of Ge



for i = 1: Ns*IO
%     Gs2 = Gs(:,i);
    Ge2 = Ge(:,i);
    mu2 = mu(:,i);
    k=1;
    for j = 1:N2s1
        if Ge2(k,1) == 0
%             Gs2(k,:)=[];
            Ge2(k,:)=[];
            mu2(k,:)=[];
            k=k-1;
        end
        k=k+1;
    end
%   MGs(1,i) = mean(Gs2);
    MGe(1,i) = mean(Ge2);
    Mmu(1,i) = mean(mu2);
end

% lMGs = zeros(1,Ns); % Mean of Gs 
lMGe = zeros(1,Ns*IO); % Mean of Ge

for i=1:Ns
if tb == 1
    lMGe(1,(i-1)*IO+1:i*IO) = log10(MGe(1,(i-1)*IO+1:i*IO)./0.38./density2(1,i)./(pi./4.*diam2.^2)./e);
elseif tb == 0
    lMGe(1,(i-1)*IO+1:i*IO) = log10(MGe(1,(i-1)*IO+1:i*IO)./0.38./density2(1,i)./(thickness2.^2)./e);
end
end
% (log10(MGe(1,5))-log10(MGe(1,1)))/(log10(density2(1,5))-log10(density2(1,1)))

% figure1 = figure;

% plot(W,lMGe,'o')
% figure1 = figure;
% plot(W,Mmu,'o')

% MMslambda(l,1) = MGs
% MMelambda(l,1) = MGe;


timeTottal = toc
% plot(MGs)


% if wm ==1
%     save('SSdata')      %-------------------*********************
% elseif wm==2
% %                                 -------------------*********************
% if low == false
%     lowhigh = 'high';
% else
%     lowhigh = 'low';
% end
    nameS = strcat('G-Response','Pr',num2str(Pr*100));
    save(nameS)


% nameS = strcat('nu-test','Pr',num2str(Pr*100));
%     save(nameS)


% poly = polyfit(den,G,4);
% x1 = linspace(min(denN),max(denN));
% y1 = polyval(poly,x1);

% subplot(2,2,1)
% plot(den,G,'o')
% hold on
% plot(x1,y1)
% hold on
% subplot(2,2,2)
% plot(denN,G,'o')
% hold on
% subplot(2,2,3)
% plot(denf,G,'o')


delE = [];
for i = 1:size(density2,2)
    delE(end+1) = i*IO-1;
%     delE(end+1) = i*IO;
end
% lMGe(:,delE) = [];
%     








