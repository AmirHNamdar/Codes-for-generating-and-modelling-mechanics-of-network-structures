
function SData = ModifyingNetworkLength(SData,flt)

% getting data from SData
NE = SData(1,6); % number of edges
NN = SData(1,7); % number of nodes
PN = SData(1:NN,1:3); % position of nodes
ED = SData(1:NE,4:5); % edge direction (node 1 to node 2)
nrb = SData(1,8); % number of boundary nodes on right side
nlb = SData(2,8); % number of boundary nodes on left side
ntb = SData(3,8); % number of boundary nodes on top side
nbb = SData(4,8); % number of boundary nodes on bottom side
nbn = nrb+nlb+ntb+nbb; % number of tottal boundary nodes
coupn = SData(1:nbn,9);
% NE
% Calculating the length of each fibre
Lf=zeros(NE,1);
% for i=1:NE
    d=ED(:,1);
    c=ED(:,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    Lf(:,1)=sqrt((ds-cs).^2+(dg-cg).^2);
% end

% for i=1:NE
%     d=ED(i,1);
%     c=ED(i,2);
%     ds=PN(d,2);
%     dg=PN(d,3);
%     cs=PN(c,2);
%     cg=PN(c,3);
%     Lf(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
% end

% figure _________________________________________________________________________________
% fogure2 = figure;
% for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'b')
%     hold on
%     pbaspect([1 1 1])
% end
% cbn = rand(size(coupn,1),3); % color of the boundary node
% %     PBN
%     for j =1:size(coupn,1)
%         l=1;
%         for k=1:j-1
%             if coupn(k,1)==j
%                 l=k;
%                 break
%             else
%                 l = j;
%             end
%         end
% %         PBN(j,3)/4
%         plot([PN(j,2)],[PN(j,3)],'o','color',cbn(l,:),'MarkerSize',10,'MarkerFaceColor',cbn(l,:))
%     end
% ____________________________________________________________________________________________________________ 
    

% which edges are shorter than the treshold?

% shortF = zeros(NE,1); % is it a short fibre? (1 = yes, 0 = no)
% for i = 1:NE
%     if Lf(i,1) < flt % flt is hte threshold
%         shortF(i,1) = 1;
%     end
% end
shortF = Lf(:,1) < flt;

shF = shortF; % the shortF is manipulated and changed in the loop below.
% size(shortF);
nsF = sum(shortF(:) == 1); % number of short fibres

% cou = 0;
i = 1; % the edge that is under study
EDs = size(ED,1);
while i <= EDs
    if shortF(i,1) == 1
%         cou=cou+1;
        fN = ED(i,1); % first node number
        sN = ED(i,2); % second node number
        

        intE = 0; % edges on top of eachother (yes: intE >= 2, no: intE = 1)
        for l = 1:size(ED,1)
            if ED(l,1) == fN && ED(l,2) == sN
                intE = intE + 1;
            end
            if ED(l,2) == fN && ED(l,1) == sN
                intE = intE + 1;
            end
        end

        if intE == 1 % if there is only one edge involved
            
                    % new position of the node
        npn = zeros(1,3); % new position of the node
        if fN < nbn + 1
            npn = PN(fN,:);
            CNode = fN; % chosed node
            DNode = sN; % deleted node
        elseif sN < nbn + 1
            npn = PN(sN,:);
            CNode = sN;
            DNode = fN;
        else
            npn (1,1) = PN(fN,1); % I keeep the first node and delete the second
            npn (1,2) = (PN(fN,2) + PN(sN,2))/2;
            npn (1,3) = (PN(fN,3) + PN(sN,3))/2;
            CNode = fN;
            DNode = sN;
        end
        
        % if both of fN and sN are Bnodes, we chose the one that doesn't
        % have a couple to be deleted
        if sN <= nbn && fN <= nbn
            if coupn(DNode) ~= 0 && coupn(CNode) == 0
                dnode = CNode;
                cnode = DNode;
                CNode = cnode;
                DNode = dnode;
            end
        end
        
        
        % updating the coupn (couple nodes)
        % if Dnode is in the boundary : 2- look if it has a couple
        %                               1- update the coupn of other nodes
        %                               (reduce it by one)
        %                               3- make the coupn of the couple
        %                               node to be 0
        %                               4- delete the info of the DNode
        
        if DNode <= nbn
            DNode;
            nbn;
            5;
            % modifying the address of other nodes
            for ica = 1:size(coupn,1)% 1- update the coupn of other nodes (reduce it by one)
                if coupn(ica,1) > DNode
                    if ica ~= DNode
                    coupn(ica,1) = coupn(ica,1)-1;
                    end
                end
            end   
            
            if coupn(DNode,1) ~= 0 % 2- look if it has a couple
                coupn(coupn(DNode,1),1) = 0; % 3- make the coupn of the couple node to be 0
            end
            % 4- delete the info of the DNode
            coupn(DNode,:) = [];
        end
            
            
            
            
            
        
            % if both fN and sN are at the boundary one of them will be
            % deleted so the ntb or nbb should be modified.
        if sN <= nrb && fN <= nrb
            nrb = nrb-1;
            nbn = nrb+nlb+ntb+nbb;
            1;
        elseif nrb < sN && sN <= nlb + nrb && nrb < fN && fN <= nlb + nrb 
            nlb = nlb-1;
            nbn = nrb+nlb+ntb+nbb;
            2;
        elseif nlb + nrb < sN && sN <= ntb + nrb + nlb && nlb + nrb < fN && fN <= ntb + nrb + nlb
            ntb = ntb-1;
            nbn = nrb+nlb+ntb+nbb;
            3;
        elseif ntb + nrb + nlb < sN && sN <= nbb + ntb + nrb + nlb && ntb + nrb + nlb < fN && fN <= nbb + ntb + nrb + nlb
            nbb = nbb-1;
            nbn = nrb+nlb+ntb+nbb;
            4;
        elseif sN <= nbn && fN <= nbn % two nodes are connected to different Boundaries
            if DNode <= nrb
                nrb = nrb-1;
                nbn = nrb+nlb+ntb+nbb;
            elseif DNode <= nrb + nlb
                nlb = nlb-1;
                nbn = nrb+nlb+ntb+nbb;
            elseif DNode <= nrb + nlb + ntb
                ntb = ntb-1;
                nbn = nrb+nlb+ntb+nbb;
            elseif DNode <= nrb + nlb + ntb + nbb
                nbb = nbb-1;
                nbn = nrb+nlb+ntb+nbb;
            end
        end
        


        
        
         
        
        
        
        
        
        % updating the position of the chosen node and deleting the other node
        PN(CNode,:) = npn;
        PN(DNode,:) = [];
        
%         if CNode == fN
%             PN(fN,:) = npn; % updating the chosed node position
%             PN(sN,:) = []; % deleting the other node
%         elseif CNode == sN
%             PN(sN,:) = npn;
%             PN(fN,:) = [];
%         end
        
        % dealing with ED (updating ED) with 2 step:
        % 1- changing the direction of edges that were connected to DNode
        % 2- since we have deleted some node, we should update the number
        % of nodes in ED.
        % Note: in some conditions 2 side of a triangle are below the limit
        % but the other side is above. In this condition we will end up
        % with a zero length edge that both ED(i,1) and ED(i,2) are the
        % same node. This edge must be deleted.
        
        
        % 1st stage:
        ED(i,:) = [];
        [rD,cD] = find(ED==DNode); % row deleted, column deleted 
        nce = size(rD,1); % number of connected edge to the deleted node
        for j = 1:nce
            ED(rD(j,1),cD(j,1)) = CNode;
        end
        
        % please note that since we have deleted some row in PN the
        % address in ED doesn't mach the correct point. It is dealt with 
        % in the coming lines.
        
        % 2nd stage:
        for k = 1:size(ED,1)
            for kk = 1:2
                if ED(k,kk) > DNode
                    ED(k,kk) = ED(k,kk)-1;
                end
            end
        end
        
        elseif intE >=2 % if there exist more than one edge between two nodes
           ED (i,:) = []; 
        end
        
        shortF(i,:) = [];
        i = i-1; % in order to investigate the ED that is dropped to the 
                 % position of the resently deleted ED
         
    end
    i = i+1;
    EDs = size(ED,1);
%     sshF = size(shortF);
end

% deleting the edges with zero length.
j = 1;
while j <= size(ED,1)
    if ED(j,1) == ED(j,2)
        ED(j,:) = [];
        j=j-1;
    end
    j=j+1;
end

% creating the modified SData
SData = zeros(max(size(ED,1),size(PN,1)),8);
SData(1:size(PN,1),1:3) = PN;
SData(1:size(ED,1),4:5) = ED;
SData(1,6) = size(ED,1);
SData(1,7) = size(PN,1);
SData(1,8) = nrb;
SData(2,8) = nlb;
SData(3,8) = ntb;
SData(4,8) = nbb;
SData(1:size(coupn),9) = coupn;
coupn;
size(coupn);
nbn;
% % % % % % % % % % % % % % % % NE = size(ED,1);
% % % % % % % % % % % % % % % % NN = size(PN,1);
% % % % % % % % % % % % % % % % figure2=figure;
% % % % % % % % % % % % % % % % for i=1:NE
% % % % % % % % % % % % % % % %     n=ED(i,1);
% % % % % % % % % % % % % % % %     m=ED(i,2);
% % % % % % % % % % % % % % % %     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)])
% % % % % % % % % % % % % % % %     texte = strcat(num2str(i));
% % % % % % % % % % % % % % % %     texth1 = strcat(num2str(PN(n,1)));
% % % % % % % % % % % % % % % %     texth2 = strcat(num2str(PN(m,1)));
% % % % % % % % % % % % % % % %     text((PN(n,2)+PN(m,2))/2,(PN(n,3)+PN(m,3))/2,texte,'Color','green','FontSize',14)
% % % % % % % % % % % % % % % %     text(PN(n,2)+1*lambda/100,PN(n,3),texth1,'Color','red','FontSize',14)
% % % % % % % % % % % % % % % %     text(PN(m,2)-1*lambda/100,PN(m,3),texth2,'Color','black','FontSize',14)
% % % % % % % % % % % % % % % % %     plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)])
% % % % % % % % % % % % % % % %     hold on
% % % % % % % % % % % % % % % %     plot(PN(:,2), PN(:,3),'o');
% % % % % % % % % % % % % % % % end 
% figure _________________________________________________________________________________
% fogure2 = figure;
% for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'b')
%     hold on
%     pbaspect([1 1 1])
% end
% cbn = rand(size(coupn,1),3); % color of the boundary node
% %     PBN
%     for j =1:size(coupn,1)
%         l=1;
%         for k=1:j-1
%             if coupn(k,1)==j
%                 l=k;
%                 break
%             else
%                 l = j;
%             end
%         end
% %         PBN(j,3)/4
%         plot([PN(j,2)],[PN(j,3)],'o','color',cbn(l,:),'MarkerSize',10,'MarkerFaceColor',cbn(l,:))
%     end
%     ____________________________________________________________________________________________________________

    % calculating the new length and calling this fuction again if
    % neccesary
    
    NE = size(ED,1);
    
    Lf2=zeros(NE,1);
% for i=1:NE
    d=ED(:,1);
    c=ED(:,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    Lf2(:,1)=sqrt((ds-cs).^2+(dg-cg).^2);
% end
% for i=1:NE
%     d=ED(i,1);
%     c=ED(i,2);
%     ds=PN(d,2);
%     dg=PN(d,3);
%     cs=PN(c,2);
%     cg=PN(c,3);
%     Lf2(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
% end
    % which edges are shorter than the treshold?

shortF = zeros(NE,1); % is it a short fibre? (1 = yes, 0 = no)
% for i = 1:NE
%     if Lf2(i,1) < flt % flt is hte threshold
%         shortF(i,1) = 1;
%     end
% end
shortF = Lf(:,1) < flt;

shF = shortF; % the shortF is manipulated and changed in the loop below.
% size(shortF);
nsF = sum(shortF(:) == 1); % number of short fibres
nsF;
if nsF >= 1
    
SData = ModifyingNetworkLength(SData,flt);
end
end