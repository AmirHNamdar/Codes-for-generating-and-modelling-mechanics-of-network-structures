function [fiber,pbn,mobn] = BfiberSide(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Fiber,Acode,L,lambda,PBN)
% this is a function to deal with boundary fibres in the sides
    
    
mobn = [];
p1 = 0; % position of one end of the fibre
p2 = 0; % position of the other end of the fibre
    % bp1: boundary position 1 (right 1, left 2, top 3, bottom 4, not 5)
    % bp2: boundary position 2 (right 1, left 2, top 3, bottom 4, not 5)
    
    x1os = x1o;
    x2os = x2o;
    y1os = y1o;
    y2os = y2o;
    
    
if x1o < x(2) && x1o > x(1) && y1o < y(2) && y1o > y(1)
    p1 = 1; % point 1 is in the range
end

if x2o < x(2) && x2o > x(1) && y2o < y(2) && y2o > y(1)
    p2 = 1; % point 1 is in the range
end

%____________________condition 1________________________
% if both point are in the range, then whole fibre is in the range
% in this case a double for the centre of the node should be created which
% might effect the dispersity of networks

if p1 == 1 && p2 == 1
%     str = 'condition 1';

    x1 = x1o;
    x2 = x2o;
    y1 = y1o;
    y2 = y2o;
    bp1 = 5;
    bp2 = 5;
    
    fiber(1,1)=x1;
    fiber(1,2)=y1;
    fiber(1,3)=x2;
    fiber(1,4)=y2;
    fiber(1,5)=theta;
    fiber(1,6)=xm;
    fiber(1,7)=ym;
    fiber(1,8) = size(Fiber,1)+1;
    fiber(1,9) = Acode(1,1);
    fiber(1,10) = Acode(1,2);
    fiber(1,11) = bp1;
    fiber(1,12) = bp2;
    
    pbn = [];
    
    if Acode(1,1) == 1 && Acode(1,2) ~= 1 && Acode(1,2) ~= lambda/L % left - requires 1 node
        mobn(end+1,:) = [xm + lambda,ym,theta];
    end
    if Acode(1,1) == lambda/L && Acode(1,2) ~= 1 && Acode(1,2) ~= lambda/L % right - requires 1 node
        mobn(end+1,:) = [xm - (lambda),ym,theta];
    end    
    if Acode(1,2) == 1 && Acode(1,1) ~= 1 && Acode(1,1) ~= lambda/L % bottom - requires 1 node
        mobn(end+1,:) = [xm ,ym + (lambda),theta];
    end      
    if Acode(1,2) == lambda/L && Acode(1,1) ~= 1 && Acode(1,1) ~= lambda/L % top - requires 1 node
        mobn(end+1,:) = [xm ,ym - (lambda),theta];
    end
    
    % 
    
end

%____________________condition 2_________________________
% if one point is in the range and the other is outside then there is
% intersection with the boundary which should be find

if p1 == 0 && p2 == 1 % changing the direction of the fibre
    
    x1o = x2os;
    x2o = x1os;
    y1o = y2os;
    y2o = y1os;
    theta = theta + pi;
    
    x1os = x1o;
    x2os = x2o;
    y1os = y1o;
    y2os = y2o;
    
    p1 = 1;
    p2 = 0;
end
    
    
    
if p1 == 1 && p2 == 0 % point 1 is in the range and the other outside
%     str = 'condition 2';
    x1 = x1o;
    y1 = y1o;
    bp1 = 5;
    
    
    if x2o > x(2)
        y2o = tan(theta)*x(2) + y1o - tan(theta)*x1o; 
        x2o = x(2);
        bp2 = 1;
        lx = -1; % to find the info of the second fibre
        ly = 0; % to find the info of the second fibre
    elseif x2o < x(1)
        y2o = tan(theta)*x(1) + y2o - tan(theta)*x2o; 
        x2o = x(1);
        bp2 = 2;
        lx = 1;
        ly = 0;
    end
    
    if y2o > y(2)
        x2o = (y(2)-y1o)/(y2o-y1o)*(x2o-x1o) + x1o;
        y2o = y(2);
        bp2 = 3;
        lx = 0;
        ly = -1;
        
    elseif y2o < y(1)
        x2o = (y(1)-y1o)/(y2o-y1o)*(x2o-x1o) + x1o;
        y2o = y(1);
        bp2 = 4;
        lx = 0;
        ly = 1;
    end
    
    x2 = x2o;
    y2 = y2o;
    
        fiber(1,1)=x1;
    fiber(1,2)=y1;
    fiber(1,3)=x2;
    fiber(1,4)=y2;
    fiber(1,5)=theta;
    fiber(1,6)=xm;
    fiber(1,7)=ym;
    fiber(1,8) = size(Fiber,1)+1;
    fiber(1,9) = Acode(1,1);
    fiber(1,10) = Acode(1,2);
    fiber(1,11) = bp1;
    fiber(1,12) = bp2;
    
        pbn(1,1) = x2;
        pbn(1,2) = y2;
        pbn(1,3) = bp2;
        pbn(1,4) = size(Fiber,1)+1;
        pbn(1,5) = size(PBN,1)+2; % the couple node
        
        % second fibre on the other side
        
    fiber(2,1)=x2+lx*lambda;
    fiber(2,2)=y2+ly*lambda;
    fiber(2,3)=x2os+lx*lambda;
    fiber(2,4)=y2os+ly*lambda;
    fiber(2,5)=theta;
    fiber(2,6)=xm+lx*lambda;
    fiber(2,7)=ym+ly*lambda;
    fiber(2,8) = size(Fiber,1)+2;
    fiber(2,9) = Acode(1,1)+lx*(lambda/L-1);
    fiber(2,10) = Acode(1,2)+ly*(lambda/L-1);
    fiber(2,11) = bp1;
    
    if bp2 ==1 
    fiber(2,12) = 2;
    elseif bp2 ==2
        fiber(2,12) = 1;
        elseif bp2 == 3
        fiber(2,12) = 4;
        elseif bp2 ==4
        fiber(2,12) = 3;
    end
        
        pbn(2,1) = fiber(2,1);
        pbn(2,2) = fiber(2,2);
        pbn(2,3) = fiber(2,12);
        pbn(2,4) = size(Fiber,1)+2;
        pbn(2,5) = size(PBN,1)+1;
        
        
end

% if p1 == 0 && p2 == 1 % point 2 is in the range and the other outside
% %     str = 'condition 2';
% 
%     x2 = x2o;
%     y2 = y2o;
%     bp2 = 5;
%     
%     if x1o > x(2)
%         y1o = tan(theta)*x(2) + y2o - tan(theta)*x2o; 
%         x1o = x(2);
%         bp1 = 1;
%     elseif x1o < x(1)
%         y1o = tan(theta)*x(1) + y1o - tan(theta)*x1o; 
%         x1o = x(1);
%         bp1 = 2;
%     end
%     
%     if y1o > y(2)
%         x1o = (y(2)-y2o)/(y1o-y2o)*(x1o-x2o) + x2o;
%         y1o = y(2);
%         bp1 = 3;
%     elseif y1o < y(1)
%         x1o = (y(1)-y1o)/(y2o-y1o)*(x2o-x1o) + x1o;
%         y1o = y(1);
%         bp1 = 4;
%     end
%     
%     x1 = x1o;
%     y1 = y1o;
%     
%         fiber(1,1)=x1;
%     fiber(1,2)=y1;
%     fiber(1,3)=x2;
%     fiber(1,4)=y2;
%     fiber(1,5)=theta;
%     fiber(1,6)=xm;
%     fiber(1,7)=ym;
%     fiber(1,8) = size(Fiber,1)+1;
%     fiber(1,9) = Acode(1,1);
%     fiber(1,10) = Acode(1,2);
%     fiber(1,11) = bp1;
%     fiber(1,12) = bp2;
%     
%     
%             % second fibre on the other side
%         
%     fiber(2,1)=x1os+lx*L;
%     fiber(2,2)=y1os+ly*L;
%     fiber(2,3)=x1+lx*L;
%     fiber(2,4)=y1+ly*L;
%     fiber(2,5)=theta;
%     fiber(2,6)=xm+lx*L;
%     fiber(2,7)=ym+ly*L;
%     fiber(2,8) = size(Fiber,1)+2;
%     fiber(2,9) = Acode(1,1)+lx*(lambda/L-1);
%     fiber(2,10) = Acode(1,2)+ly*(lambda/L-1);
%     
%     if bp1 ==1 
%     fiber(2,11) = 2;
%     elseif bp1 ==2
%         fiber(2,11) = 1;
%         elseif bp1 == 3
%         fiber(2,11) = 4;
%         elseif bp1 ==4
%         fiber(2,11) = 3;
%     end
%     
%         fiber(2,12) = bp2;
%         
%         
%         pbn(2,1) = fiber(2,3);
%         pbn(2,2) = fiber(2,4);
%         pbn(2,3) = fiber(2,11);
%         pbn(2,4) = size(Fiber,1)+2;
% 
% end


end