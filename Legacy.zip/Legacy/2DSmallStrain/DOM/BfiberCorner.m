function [fiber,pbn,mobn] = BfiberCorner(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Fiber,Acode,L,lambda,PBN)
% this is a function to deal with boundary fibres in the sides

mobn = [];
p1 = 0; % position of one end of the fibre
p2 = 0; % position of the other end of the fibre
    % bp1: boundary position 1 (right 1, left 2, top 3, bottom 4, not 5)
    % bp2: boundary position 2 (right 1, left 2, top 3, bottom 4, not 5)
    
    bp1 = 5;
    bp2 = 5;
    
    x1os = x1o;
    x2os = x2o;
    y1os = y1o;
    y2os = y2o;
    
    
    
if x1o < x(2) && x1o > x(1) && y1o < y(2) && y1o > y(1)
    p1 = 1; % point 1 is in the range
end

if x2o < x(2) && x2o > x(1) && y2o < y(2) && y2o > y(1)
    p2 = 1; % point 1 is in the range
end

%____________________condition 1________________________
% if both point are in the range, then whole fibre is in the range
if p1 == 1 && p2 == 1
%     str = 'condition 1';

    x1 = x1o;
    x2 = x2o;
    y1 = y1o;
    y2 = y2o;
    bp1 = 5;
    bp2 = 5;
    
    fiber(1,1)=x1;
    fiber(1,2)=y1;
    fiber(1,3)=x2;
    fiber(1,4)=y2;
    fiber(1,5)=theta;
    fiber(1,6)=xm;
    fiber(1,7)=ym;
    fiber(1,8) = size(Fiber,1)+1;
    fiber(1,9) = Acode(1,1);
    fiber(1,10) = Acode(1,2);
    fiber(1,11) = bp1;
    fiber(1,12) = bp2;
    
    pbn = [];
    
    if Acode(1,1) == 1 && Acode(1,2) == 1 % bottom left - requires 3 new node
        mobn(end+1,:) = [xm,ym+(lambda),theta]; % top one
        mobn(end+1,:) = [xm + (lambda),ym + (lambda),theta]; % top right one
        mobn(end+1,:) = [xm + (lambda),ym,theta]; % right one
    end
    if Acode(1,1) == lambda/L && Acode(1,2) == 1 % bottom right - requires 3 new node
        mobn(end+1,:) = [xm,ym+(lambda),theta]; % top one
        mobn(end+1,:) = [xm-(lambda),ym+(lambda),theta]; % top left one
        mobn(end+1,:) = [xm-(lambda),ym,theta]; % left one
    end    
    if Acode(1,1) == lambda/L && Acode(1,2) == lambda/L % top right - requires 3 new node
        mobn(end+1,:) = [xm,ym-(lambda),theta]; % bottom one
        mobn(end+1,:) = [xm - (lambda),ym - (lambda),theta]; % bottom left one
        mobn(end+1,:) = [xm - (lambda),ym,theta]; % left one
    end
    if Acode(1,1) == 1 && Acode(1,2) == lambda/L % top left - requires 3 new node
        mobn(end+1,:) = [xm,ym-(lambda),theta]; % bottom one
        mobn(end+1,:) = [xm+(lambda),ym-(lambda),theta]; % bottom right one
        mobn(end+1,:) = [xm+(lambda),ym,theta]; % right one
    end

end

%____________________condition 2_________________________
% if one point is in the range and the other is outside then there is
% intersection with the boundary which should be find

if p1 == 0 && p2 == 1 % changing the direction of the fibre
    
    x1o = x2os;
    x2o = x1os;
    y1o = y2os;
    y2o = y1os;
    theta = theta + pi;
    
    x1os = x1o;
    x2os = x2o;
    y1os = y1o;
    y2os = y2o;
    
    p1 = 1;
    p2 = 0;
end

if p1 == 1 && p2 == 0 % point 1 is in the range and the other outside
%   str = 'condition 2';
    x1 = x1o;
    y1 = y1o;
    bp1 = 5;
    
    fli = 0; % 0= if the other side of the fibre lies inside. numbers= otherwise 1 bottom left,2 top right, 3 bottom right, 4 top left.
    
    if x2o < x(1) && y2o<y(1) 
        fli = 1;
    elseif x2o > x(2) && y2o > y(2)
        fli = 2;
    elseif  x2o > x(2) && y2o < y(1)
        fli = 3;
    elseif x2o < x(1) && y2o > y(2)
        fli = 4;
    end
    
    
    if fli ==0 
        [fiber,pbn,mobn] = BfiberSide(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Fiber,Acode,L,lambda,PBN);
        
        mobn = []; % the other side of the fibre has a centre
        [xi1,yi1,xi2,yi2] = CornerIntersection(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Acode); % intersection points with boundaries
            if xi1 < x(1)+(x(2)-x(1))/1000000
                if Acode(1,2) == 1
                    mobn(end+1,:) = [xm,ym+(lambda),theta]; % top one
                    mobn(end+1,:) = [xm + (lambda),ym + (lambda),theta]; % top right one
%                     mobn(end+1,:) = [xm + (lambda),ym,theta]; % right one
                else
                    mobn(end+1,:) = [xm,ym-(lambda),theta]; % bottom one
                    mobn(end+1,:) = [xm + (lambda),ym - (lambda),theta]; % bottom right one
%                     mobn(end+1,:) = [xm + (lambda),ym,theta]; % right one
                end
            elseif xi1 > x(2)-(x(2)-x(1))/1000000
                if Acode(1,2) == 1
                    mobn(end+1,:) = [xm,ym+(lambda),theta]; % top one
                    mobn(end+1,:) = [xm-(lambda),ym+(lambda),theta]; % top left one
%                     mobn(end+1,:) = [xm-(lambda),ym,theta]; % left one
                else
                    mobn(end+1,:) = [xm,ym-(lambda),theta]; % bottom one
                    mobn(end+1,:) = [xm - (lambda),ym - (lambda),theta]; % bottom left one
%                     mobn(end+1,:) = [xm - (lambda),ym,theta]; % left one
                end
            elseif yi1 < y(1)+(y(2)-y(1))/1000000
                if Acode(1,1) == 1
%                     mobn(end+1,:) = [xm,ym+(lambda),theta]; % top one
                    mobn(end+1,:) = [xm + (lambda),ym + (lambda),theta]; % top right one
                    mobn(end+1,:) = [xm + (lambda),ym,theta]; % right one
                else
%                     mobn(end+1,:) = [xm,ym-(lambda),theta]; % top one
                    mobn(end+1,:) = [xm - lambda ,ym + (lambda),theta]; % top left one
                    mobn(end+1,:) = [xm - (lambda),ym,theta]; % left one
                end
            elseif yi1 > y(2)-(y(2)-y(1))/1000000
                if Acode(1,1) == 1
%                     mobn(end+1,:) = [xm,ym+(lambda),theta]; % top one
                    mobn(end+1,:) = [xm + (lambda),ym - (lambda),theta]; % bottom right one
                    mobn(end+1,:) = [xm + (lambda),ym,theta]; % right one
                else
%                     mobn(end+1,:) = [xm,ym-(lambda),theta]; % top one
                    mobn(end+1,:) = [xm - lambda ,ym - (lambda),theta]; % bottom left one
                    mobn(end+1,:) = [xm - (lambda),ym,theta]; % left one
                end
            end


    
    elseif  fli == 1 % bottom left
        [xi1,yi1,xi2,yi2] = CornerIntersection(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Acode); % intersection points with boundaries
        % xi1 is for the one connected ot the original box (closer to the x1 end of the fibre)
        if xi1 > x(1)+(x(2)-x(1))/1000000 % second term is there for numerical error
            x2 = xi1;
            y2 = yi1;
            lx = 0;
            ly = 1;
            lx3 = 1;
            ly3 = 1;
            mobn(end+1,:) = [xm + (lambda),ym,theta]; % right
        else
            x2 = xi1;
            y2 = yi1;
            lx = 1;
            ly = 0;
            lx3 = 1;
            ly3 = 1;
            mobn(end+1,:) = [xm ,ym+lambda,theta]; % top
        end
        
    elseif fli == 2 % top right
        
        [xi1,yi1,xi2,yi2] = CornerIntersection(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Acode); % intersection points with boundary
        % xi1 is for the one connected ot the original box
        if xi1 < x(2)-(x(2)-x(1))/1000000 % second term is there for numerical error
            x2 = xi1;
            y2 = yi1;
            lx = 0;
            ly = -1;
            lx3 = -1;
            ly3 = -1;
            mobn(end+1,:) = [xm - (lambda),ym,theta]; % left
        else
            x2 = xi1;
            y2 = yi1;
            lx = -1;
            ly = 0;
            lx3 = -1;
            ly3 = -1;
            mobn(end+1,:) = [xm ,ym-lambda,theta]; % bottom
        end
        
    elseif fli == 3 % bottom right
        [xi1,yi1,xi2,yi2] = CornerIntersection(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Acode); % intersection points with boundary
        % xi1 is for the one connected ot the original box
        if xi1 < x(2)-(x(2)-x(1))/1000000 % second term is there for numerical error
            x2 = xi1;
            y2 = yi1;
            lx = 0;
            ly = 1;
            lx3 = -1;
            ly3 = 1;
            mobn(end+1,:) = [xm - lambda,ym,theta]; % left
        else
            x2 = xi1;
            y2 = yi1;
            lx = -1;
            ly = 0;
            lx3 = -1;
            ly3 = 1;
            mobn(end+1,:) = [xm ,ym + lambda,theta]; % top
        end 
        
    elseif fli == 4 % top left
           [xi1,yi1,xi2,yi2] = CornerIntersection(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Acode); % intersection points with boundary
        % xi1 is for the one connected ot the original box
        if xi1 > x(1)+(x(2)-x(1))/1000000 % second term is there for numerical error
            x2 = xi1;
            y2 = yi1;
            lx = 0;
            ly = -1;
            lx3 = 1;
            ly3 = -1;
            mobn(end+1,:) = [xm + (lambda),ym,theta]; % right
        else
            x2 = xi1;
            y2 = yi1;
            lx = 1;
            ly = 0;
            lx3 = 1;
            ly3 = -1;
            mobn(end+1,:) = [xm ,ym-lambda,theta]; % bottom
        end 
        
    end
    %%
    
    
    if fli ~=0
        
        
        % first fiber and BC intersection
    fiber(1,1)=x1;
    fiber(1,2)=y1;
    fiber(1,3)=x2;
    fiber(1,4)=y2;
    fiber(1,5)=theta;
    fiber(1,6)=xm;
    fiber(1,7)=ym;
    fiber(1,8) = size(Fiber,1)+1;
    fiber(1,9) = Acode(1,1);
    fiber(1,10) = Acode(1,2);
    fiber(1,11) = bp1;
    
    if fiber(1,3) < x(2)+(x(2)-x(1))/1000000 && fiber(1,3) > x(2)-(x(2)-x(1))/1000000
        fiber(1,12) = 1;
    elseif fiber(1,3) < x(1)+(x(2)-x(1))/1000000 && fiber(1,3) > x(1)-(x(2)-x(1))/1000000
        fiber(1,12) = 2;
    elseif fiber(1,4) < y(1)+(x(2)-x(1))/1000000 && fiber(1,4) > y(1)-(x(2)-x(1))/1000000
        fiber(1,12) = 4;
    elseif fiber(1,4) < y(2)+(x(2)-x(1))/1000000 && fiber(1,4) > y(2)-(x(2)-x(1))/1000000
        fiber(1,12) = 3;
    end 
        
        pbn(1,1) = x2;
        pbn(1,2) = y2;
        pbn(1,3) = fiber(1,12);
        pbn(1,4) = size(Fiber,1)+1;
        pbn(1,5) = size(PBN,1)+2;
        
        % second fiber and BC intersection
        
    fiber(2,1)=xi1+lx*lambda;
    fiber(2,2)=yi1+ly*lambda;
    fiber(2,3)=xi2+lx*lambda;
    fiber(2,4)=yi2+ly*lambda;
    fiber(2,5)=theta;
    fiber(2,6)=xm+lx*lambda;
    fiber(2,7)=ym+ly*lambda;
    fiber(2,8) = size(Fiber,1)+2;
    fiber(2,9) = Acode(1,1)+lx*(lambda/L-1);
    fiber(2,10) = Acode(1,2)+ly*(lambda/L-1);
    
    if fiber(2,1) < x(2)+(x(2)-x(1))/1000000 && fiber(2,1) > x(2)-(x(2)-x(1))/1000000
        fiber(2,11) = 1;
    elseif fiber(2,1) < x(1)+(x(2)-x(1))/1000000 && fiber(2,1) > x(1)-(x(2)-x(1))/1000000
        fiber(2,11) = 2;
    elseif fiber(2,2) < y(1)+(x(2)-x(1))/1000000 && fiber(2,2) > y(1)-(x(2)-x(1))/1000000
        fiber(2,11) = 4;
    elseif fiber(2,2) < y(2)+(x(2)-x(1))/1000000 && fiber(2,2) > y(2)-(x(2)-x(1))/1000000
        fiber(2,11) = 3;
    end
    
    if fiber(2,3) < x(2)+(x(2)-x(1))/1000000 && fiber(2,3) > x(2)-(x(2)-x(1))/1000000
        fiber(2,12) = 1;
    elseif fiber(2,3) < x(1)+(x(2)-x(1))/1000000 && fiber(2,3) > x(1)-(x(2)-x(1))/1000000
        fiber(2,12) = 2;
    elseif fiber(2,4) < y(1)+(x(2)-x(1))/1000000 && fiber(2,4) > y(1)-(x(2)-x(1))/1000000
        fiber(2,12) = 4;
    elseif fiber(2,4) < y(2)+(x(2)-x(1))/1000000 && fiber(2,4) > y(2)-(x(2)-x(1))/1000000
        fiber(2,12) = 3;
    end    
    
    
        
        pbn(2,1) = fiber(2,1);
        pbn(2,2) = fiber(2,2);
        pbn(2,3) = fiber(2,11);
        pbn(2,4) = size(Fiber,1)+2;
        pbn(2,5) = size(PBN,1)+1;
        
        pbn(3,1) = fiber(2,3);
        pbn(3,2) = fiber(2,4);
        pbn(3,3) = fiber(2,12);
        pbn(3,4) = size(Fiber,1)+2;
        pbn(3,5) = size(PBN,1)+4;
        
        % Third fiber and BC intersection
        
    fiber(3,1)=xi2+lx3*lambda;
    fiber(3,2)=yi2+ly3*lambda;
    fiber(3,3)=x2os+lx3*lambda;
    fiber(3,4)=y2os+ly3*lambda;
    fiber(3,5)=theta;
    fiber(3,6)=xm+lx3*lambda;
    fiber(3,7)=ym+ly3*lambda;
    fiber(3,8) = size(Fiber,1)+3;
    fiber(3,9) = Acode(1,1)+lx3*(lambda/L-1);
    fiber(3,10) = Acode(1,2)+ly3*(lambda/L-1);
    
    
    if fiber(3,1) < x(2)+(x(2)-x(1))/1000000 && fiber(3,1) > x(2)-(x(2)-x(1))/1000000
        fiber(3,11) = 1;
    elseif fiber(3,1) < x(1)+(x(2)-x(1))/1000000 && fiber(3,1) > x(1)-(x(2)-x(1))/1000000
        fiber(3,11) = 2;
    elseif fiber(3,2) < y(1)+(x(2)-x(1))/1000000 && fiber(3,2) > y(1)-(x(2)-x(1))/1000000
        fiber(3,11) = 4;
    elseif fiber(3,2) < y(2)+(x(2)-x(1))/1000000 && fiber(3,2) > y(2)-(x(2)-x(1))/1000000
        fiber(3,11) = 3;
    end
    
    fiber(3,12) = 5;
    
        pbn(4,1) = fiber(3,1);
        pbn(4,2) = fiber(3,2);
        pbn(4,3) = fiber(3,11);
        pbn(4,4) = size(Fiber,1)+3;
        pbn(4,5) = size(PBN,1)+3;
    
        
    end
end
   %% 
    %_____________________condition 3_________________________

if p1 == 0 && p2 == 0
    [xi1,yi1,xi2,yi2] = CornerIntersection(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Acode); % intersection points with boundary
    % xi1 is for the one closer to the fibre 1
    x1 = xi1;
    y1 = yi1;
    x2 = xi2;
    y2 = yi2;
    
    % first fibre (origin)
    
    fiber(1,1)=x1;
    fiber(1,2)=y1;
    fiber(1,3)=x2;
    fiber(1,4)=y2;
    fiber(1,5)=theta;
    fiber(1,6)=xm;
    fiber(1,7)=ym;
    fiber(1,8) = size(Fiber,1)+1;
    fiber(1,9) = Acode(1,1);
    fiber(1,10) = Acode(1,2);
    
    if Acode(1,1) == 1
        if Acode(1,2) ==1
            mobn(end+1,:) = [xm+lambda ,ym+lambda,theta]; % top right
        else
            mobn(end+1,:) = [xm+lambda ,ym-lambda,theta]; % bottom right
        end
    else
        if Acode(1,2) ==1
            mobn(end+1,:) = [xm-lambda ,ym+lambda,theta];% top left
        else
            mobn(end+1,:) = [xm-lambda ,ym-lambda,theta]; % bottom left
        end
    end
    
    if fiber(1,1) < x(2)+(x(2)-x(1))/1000000 && fiber(1,1) > x(2)-(x(2)-x(1))/1000000
        fiber(1,11) = 1;
        lx1 = -1;
        ly1 = 0;
    elseif fiber(1,1) < x(1)+(x(2)-x(1))/1000000 && fiber(1,1) > x(1)-(x(2)-x(1))/1000000
        fiber(1,11) = 2;
        lx1 = 1;
        ly1 = 0;
    elseif fiber(1,2) < y(1)+(x(2)-x(1))/1000000 && fiber(1,2) > y(1)-(x(2)-x(1))/1000000
        fiber(1,11) = 4;
        lx1 = 0;
        ly1 = 1;
    elseif fiber(1,2) < y(2)+(x(2)-x(1))/1000000 && fiber(1,2) > y(2)-(x(2)-x(1))/1000000
        fiber(1,11) = 3;
        lx1 = 0;
        ly1 = -1;
    end
    
    if fiber(1,3) < x(2)+(x(2)-x(1))/1000000 && fiber(1,3) > x(2)-(x(2)-x(1))/1000000
        fiber(1,12) = 1;
        lx2 = -1;
        ly2 = 0;
    elseif fiber(1,3) < x(1)+(x(2)-x(1))/1000000 && fiber(1,3) > x(1)-(x(2)-x(1))/1000000
        fiber(1,12) = 2;
        lx2 = 1;
        ly2 = 0;
    elseif fiber(1,4) < y(1)+(x(2)-x(1))/1000000 && fiber(1,4) > y(1)-(x(2)-x(1))/1000000
        fiber(1,12) = 4;
        lx2 = 0;
        ly2 = 1;
    elseif fiber(1,4) < y(2)+(x(2)-x(1))/1000000 && fiber(1,4) > y(2)-(x(2)-x(1))/1000000
        fiber(1,12) = 3;
        lx2 = 0;
        ly2 = -1;
    end
        
        pbn(1,1) = x1;
        pbn(1,2) = y1;
        pbn(1,3) = fiber(1,11);
        pbn(1,4) = size(Fiber,1)+1;
        pbn(1,5) = size(PBN,1)+3;
        
        pbn(2,1) = x2;
        pbn(2,2) = y2;
        pbn(2,3) = fiber(1,12);
        pbn(2,4) = size(Fiber,1)+1;
        pbn(2,5) = size(PBN,1)+4;
        
    % second and third fibre 
    
    fiber(2,1)=x1os+lx1*lambda;
    fiber(2,2)=y1os+ly1*lambda;
    fiber(2,3)=x1+lx1*lambda;
    fiber(2,4)=y1+ly1*lambda;
    fiber(2,5)=theta;
    fiber(2,6)=xm+lx1*lambda;
    fiber(2,7)=ym+ly1*lambda;
    fiber(2,8) = size(Fiber,1)+2;
    fiber(2,9) = Acode(1,1)+lx1*(lambda/L-1);
    fiber(2,10) = Acode(1,2)+ly1*(lambda/L-1);
    fiber(2,11) = 5;
    if fiber(2,3) < x(2)+(x(2)-x(1))/1000000 && fiber(2,3) > x(2)-(x(2)-x(1))/1000000
        fiber(2,12) = 1;
    elseif fiber(2,3) < x(1)+(x(2)-x(1))/1000000 && fiber(2,3) > x(1)-(x(2)-x(1))/1000000
        fiber(2,12) = 2;
    elseif fiber(2,4) < y(1)+(x(2)-x(1))/1000000 && fiber(2,4) > y(1)-(x(2)-x(1))/1000000
        fiber(2,12) = 4;
    elseif fiber(2,4) < y(2)+(x(2)-x(1))/1000000 && fiber(2,4) > y(2)-(x(2)-x(1))/1000000
        fiber(2,12) = 3;
    end
    
        pbn(3,1) = fiber(2,3);
        pbn(3,2) = fiber(2,4);
        pbn(3,3) = fiber(2,12);
        pbn(3,4) = size(Fiber,1)+2;
        pbn(3,5) = size(PBN,1)+1;
        
    fiber(3,1)=x2+lx2*lambda;
    fiber(3,2)=y2+ly2*lambda;
    fiber(3,3)=x2os+lx2*lambda;
    fiber(3,4)=y2os+ly2*lambda;
    fiber(3,5)=theta;
    fiber(3,6)=xm+lx2*lambda;
    fiber(3,7)=ym+ly2*lambda;
    fiber(3,8) = size(Fiber,1)+3;
    fiber(3,9) = Acode(1,1)+lx2*(lambda/L-1);
    fiber(3,10) = Acode(1,2)+ly2*(lambda/L-1);
    if fiber(3,1) < x(2)+(x(2)-x(1))/1000000 && fiber(3,1) > x(2)-(x(2)-x(1))/1000000
        fiber(3,11) = 1;
    elseif fiber(3,1) < x(1)+(x(2)-x(1))/1000000 && fiber(3,1) > x(1)-(x(2)-x(1))/1000000
        fiber(3,11) = 2;
    elseif fiber(3,2) < y(1)+(x(2)-x(1))/1000000 && fiber(3,2) > y(1)-(x(2)-x(1))/1000000
        fiber(3,11) = 4;
    elseif fiber(3,2) < y(2)+(x(2)-x(1))/1000000 && fiber(3,2) > y(2)-(x(2)-x(1))/1000000
        fiber(3,11) = 3;
    end
    fiber(3,12) = 5;    
        
        pbn(4,1) = fiber(3,1);
        pbn(4,2) = fiber(3,2);
        pbn(4,3) = fiber(3,11);
        pbn(4,4) = size(Fiber,1)+3;        
        pbn(4,5) = size(PBN,1)+2;
end
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
%     if x2o > x(2)
%         y2o = tan(theta)*x(2) + y1o - tan(theta)*x1o; 
%         x2o = x(2);
%         bp2 = 1;
%         lx = -1; % to find the info of the second fibre
%         ly = 0; % to find the info of the second fibre
%         if y2o>y(2) %|| y2o<y(1)
%             fli = 1;
%             
%         end
%         
%     elseif x2o < x(1)
%         if y2o>y(2) || y2o<y(1)
%             fli = 1;
%         end
%         y2o = tan(theta)*x(1) + y2o - tan(theta)*x2o; 
%         x2o = x(1);
%         bp2 = 2;
%         lx = 1;
%         ly = 0;
%     end
%     
%     if y2o > y(2)
%         if x2o>x(2) || x2o<x(1)
%             fli = 1;
%         end
%         x2o = (y(2)-y1o)/(y2o-y1o)*(x2o-x1o) + x1o;
%         y2o = y(2);
%         bp2 = 3;
%         lx = 0;
%         ly = -1;
%         
%     elseif y2o < y(1)
%         if x2o>x(2) || x2o<x(1)
%             fli = 1;
%         end
%         x2o = (y(1)-y1o)/(y2o-y1o)*(x2o-x1o) + x1o;
%         y2o = y(1);
%         bp2 = 4;
%         lx = 0;
%         ly = 1;
%     end
%     
%     x2 = x2o;
%     y2 = y2o;
%     
%         fiber(1,1)=x1;
%     fiber(1,2)=y1;
%     fiber(1,3)=x2;
%     fiber(1,4)=y2;
%     fiber(1,5)=theta;
%     fiber(1,6)=xm;
%     fiber(1,7)=ym;
%     fiber(1,8) = size(Fiber,1)+1;
%     fiber(1,9) = Acode(1,1);
%     fiber(1,10) = Acode(1,2);
%     fiber(1,11) = bp1;
%     fiber(1,12) = bp2;
%     
%         pbn(1,1) = x2;
%         pbn(1,2) = y2;
%         pbn(1,3) = bp2;
%         pbn(1,4) = size(Fiber,1)+1;
%         
%         % second fibre on the other side
%         % there is two possible outcome: 1 - end of the fibres lies inside
%         % of the box, or 2 - it again passes through the box
%         
%         if fli ==0
%     fiber(2,1)=x2+lx*L;
%     fiber(2,2)=y2+ly*L;
%     fiber(2,3)=x2o+lx*L;
%     fiber(2,4)=y2o+ly*L;
%     fiber(2,5)=theta;
%     fiber(2,6)=xm+lx*L;
%     fiber(2,7)=ym+ly*L;
%     fiber(2,8) = size(Fiber,1)+2;
%     fiber(2,9) = Acode(1,1)+lx*(lambda/L-1);
%     fiber(2,10) = Acode(1,2)+ly*(lambda/L-1);
%     fiber(2,11) = bp1;
%     
%     if bp2 ==1 
%     fiber(2,12) = 2;
%     elseif bp2 ==2
%         fiber(2,12) = 1;
%         elseif bp2 == 3
%         fiber(2,12) = 4;
%         elseif bp2 ==4
%         fiber(2,12) = 3;
%     end
%         
%         pbn(2,1) = fiber(2,1);
%         pbn(2,2) = fiber(2,2);
%         pbn(2,3) = fiber(2,12);
%         pbn(2,4) = size(Fiber,1)+2;
%         
%     elseif fli == 1
%             
%         
%         
% end
% 
% if p1 == 0 && p2 == 1 % point 2 is in the range and the other outside
% %     str = 'condition 2';
% 
%     x2 = x2o;
%     y2 = y2o;
%     bp2 = 5;
%     
%     if x1o > x(2)
%         y1o = tan(theta)*x(2) + y2o - tan(theta)*x2o; 
%         x1o = x(2);
%         bp1 = 1;
%     elseif x1o < x(1)
%         y1o = tan(theta)*x(1) + y1o - tan(theta)*x1o; 
%         x1o = x(1);
%         bp1 = 2;
%     end
%     
%     if y1o > y(2)
%         x1o = (y(2)-y2o)/(y1o-y2o)*(x1o-x2o) + x2o;
%         y1o = y(2);
%         bp1 = 3;
%     elseif y1o < y(1)
%         x1o = (y(1)-y1o)/(y2o-y1o)*(x2o-x1o) + x1o;
%         y1o = y(1);
%         bp1 = 4;
%     end
%     
%     x1 = x1o;
%     y1 = y1o;
%     
%         fiber(1,1)=x1;
%     fiber(1,2)=y1;
%     fiber(1,3)=x2;
%     fiber(1,4)=y2;
%     fiber(1,5)=theta;
%     fiber(1,6)=xm;
%     fiber(1,7)=ym;
%     fiber(1,8) = size(Fiber,1)+1;
%     fiber(1,9) = Acode(1,1);
%     fiber(1,10) = Acode(1,2);
%     fiber(1,11) = bp1;
%     fiber(1,12) = bp2;
%     
%     
%             % second fibre on the other side
%         
%     fiber(2,1)=x1o+lx*L;
%     fiber(2,2)=y1o+ly*L;
%     fiber(2,3)=x1+lx*L;
%     fiber(2,4)=y1+ly*L;
%     fiber(2,5)=theta;
%     fiber(2,6)=xm+lx*L;
%     fiber(2,7)=ym+ly*L;
%     fiber(2,8) = size(Fiber,1)+2;
%     fiber(2,9) = Acode(1,1)+lx*(lambda/L-1);
%     fiber(2,10) = Acode(1,2)+ly*(lambda/L-1);
%     
%     if bp1 ==1 
%     fiber(2,11) = 2;
%     elseif bp1 ==2
%         fiber(2,11) = 1;
%         elseif bp1 == 3
%         fiber(2,11) = 4;
%         elseif bp1 ==4
%         fiber(2,11) = 3;
%     end
%     
%         fiber(2,12) = bp2;
%         
%         
%         pbn(2,1) = fiber(2,3);
%         pbn(2,2) = fiber(2,4);
%         pbn(2,3) = fiber(2,11);
%         pbn(2,4) = size(Fiber,1)+2;
% 
% end






end