
clear
clc
close all
% in this code, the dependancy of shear modulus to direction will be
% investigated.



% local = parcluster('local');
% sz = str2num(getenv('SLURM_NPROCS'));
% if isempty(sz)
%     % Not running in a Slurm job, so default to 44
%     sz = 4;
% end
% local.NumWorkers = sz;
% pool = local.parpool(sz);




Pr = 0.8;
ptheta = pi/2;
tb = 0; % type of bar 0 for rectangular bar and 1 for circular bar
thickness = 1e-5;
diam = 1e-5;   
density = 50;    
wm = 2; % which method of creating the network? perfect squares = 1, random network wm = 2.
TM = true; % if timoshenko beam then true

N2s1 = 24; % number of study for each Nf


% tCN = zeros(Ns,1); % time allocated to create the network
% tSN = zeros(Ns,1); % time allocated to solve the network 
Nlambda = [12,18,2];
Nslambda = (Nlambda(1,2) - Nlambda(1,1))/ Nlambda(1,3) + 1;

Mslambda = zeros(Nslambda,N2s1); % shear modulus relating to a given lambda;
Melambda = zeros(Nslambda,N2s1); % young modulus relating to a given lambda;
Mmulambda = zeros(Nslambda,N2s1);
Mmuvlambda = zeros(Nslambda,N2s1);
MMslambda = zeros(Nslambda,1); % mean ...
MMelambda = zeros(Nslambda,1); % mean ...
MMmulambda = zeros(Nslambda,1);
MMmuvlambda = zeros(Nslambda,1);

tic
for l = 1:Nslambda
    lambda = Nlambda(1,1) + (l-1) * Nlambda(1,3);

    if lambda < 11
        N2s = N2s1;
    elseif lambda < 21
        N2s = N2s1;
    elseif lambda <51
        N2s = N2s1/10;
    elseif lambda < 71
        N2s = N2s1/20;
    else
        N2s = N2s1;
    end
    
    Nf = [(lambda)^2*density,(lambda)^2*density,10]; % number of fibres data [initial nf, final nf, number of increase in each step]
    Ns = (Nf(1,2) - Nf(1,1))/ Nf(1,3) + 1; % number of considered density 
    Gs = zeros(N2s1,Ns);
    Ge = zeros(N2s1,Ns);
    mu = zeros(N2s1,Ns);
    muv = zeros(N2s1,Ns);
for j = 1:Ns


% input:
% Network generation
% lambda = 5;

density = Nf(1,1)/(lambda)^2;

x=[0 lambda]; % boundary of x direction
y=[0 lambda]; % boundary of y direction
if wm == 1
N = 2 + 2*(ns); % for square beams
L = 300;
elseif wm == 2
N = (j-1) * Nf(1,3) + Nf(1,1); % Number of fibers
L=1; % Length of fibers
end
    Gv = zeros(N2s1,1);
    GvE = zeros(N2s1,1);
    mu1 = zeros(N2s1,1);
    mu1v = zeros(N2s1,1);
parfor ns = 1:N2s
l
ns
j
flt = 10^(-3)*L/density; % fibre lenght treshold. Edges smaller than flt will be deleted.


% tic % to record time


% e = 100; % elastic modulus of beams
% Ar = 1; % cross section of beams
% I = 1; % second moment


e = 100; % elastic modulus of beams
g = e/3; % for incompressible fibres
if tb == 1
    Ar = pi*diam^2/4; % cross section of circular beams
    I = pi*diam^4/64; % second moment of circular bars 
elseif tb == 0
   Ar = thickness^2; % cross section of square beams    
   I = (thickness)^4/12; % second moment of square bars 
end

BM = (x(2)-x(1))/1000; % Boundary movement


% using function NetworkRand to generate the random network and get the data
if wm == 1
[NN,NE,ED,PN,nrb,nlb,ntb,nbb,Fiber] = SquareBeams(x,y,L,N,lambda);
elseif wm == 2
[SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRand(x,y,L,N,lambda,flt,Pr,ptheta,density);
end
% tCN(ns,1) = toc;
if Per == false
    continue
end


NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);
nbn = nrb+nlb+ntb+nbb;
coupn = SDataV(1:nbn,9); % couple nodes



% BC = zeros(12,2);
% deformations
% BC(1,1) = nan; % right x (will be modified inside the code)
% BC(2,1) = nan; % right y (will be modified inside the code)
% BC(3,1) = nan; % right theta 
% BC(4,1) = nan;  % left x (will be modified inside the code)
% BC(5,1) = nan; % left y (will be modified inside the code)
% BC(6,1) = nan;  % left theta
% BC(7,1) = BM; % top x (will be modified inside the code)
% BC(8,1) = 0; % top y (will be modified inside the code)
% BC(9,1) = 0; % top theta
% BC(10,1) = 0; % bottom x (will be modified inside the code)
% BC(11,1) = 0; % bottom y (will be modified inside the code)
% BC(12,1) = 0; % bottom theta
% % forces
% BC(1,2) = 0;
% BC(2,2) = 0;
% BC(3,2) = 0;
% BC(4,2) = 0;
% BC(5,2) = 0;
% BC(6,2) = 0;
% BC(7,2) = nan;
% BC(8,2) = nan;
% BC(9,2) = nan;
% BC(10,2) = nan;
% BC(11,2) = nan;
% BC(12,2) = nan;

% BB
% % M = 0;
% % sM = false;
% % [fov,C3v,FFv,UUv,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);
% % 
% % BC(7,1) = 0;
% % BC(8,1) = BM; % to investigate E
% % sM = true;
% % [fovE,C3vE,FFvE,UUvE,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);

% TB
M = 0;
M2 = 0;
sM = false;
% BCvx = 0; 
% BCvy = BM;
% [fov,C3v,FFv,UUv,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy);

BC = zeros(12,2);
% deformations
BC(1,1) = 0; % right x (will be modified inside the code)
BC(2,1) = 0; % right y (will be modified inside the code)
BC(3,1) = 0; % right theta 
BC(4,1) = 0;  % left x (will be modified inside the code)
BC(5,1) = 0; % left y (will be modified inside the code)
BC(6,1) = 0;  % left theta
BC(7,1) = BM; % top x (will be modified inside the code)
BC(8,1) = 0; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = nan;
BC(2,2) = nan;
BC(3,2) = nan;
BC(4,2) = nan;
BC(5,2) = nan;
BC(6,2) = nan;
BC(7,2) = nan;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = nan;
BC(11,2) = nan;
BC(12,2) = nan;

BCvx = 0;
BCvy = BM;

sM = false;

[FFvE,UUvE,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy,coupn,tb);

% shear modulus------------------------------------------------------------
% aggregation of forces in x direction devided by rotation

% sfv = 0; % shear force on the boundary V
% for i = nlb+nrb+1:nlb+nrb+ntb
%     sfv = FFv(i*3-1,1)+sfv;
% end
% sfv2 = 0; % the force on bottom boundary (to check the equilibrium)
% for i = nlb+nrb+ntb+1:nlb+nrb+ntb+nbb
%     sfv2 = FFv(i*3-1,1)+sfv2;
% end

% UT = transpose(UUv);
% Energy = UT*M*UUv;
% Gv(ns,1) = Energy/(BM)^2;
% sfv/BM;
% sfv2/BM;

% eerv = 0; % the force on bottom boundary (to check the equilibrium)
% for i = 1:nrb
%     eerv = UUv(i*3-2,1)+eerv;
% end
% eerv = eerv/nrb;
% eelv = 0; % the force on bottom boundary (to check the equilibrium)
% for i = nrb+1:nrb+nlb
%     eelv = UUv(i*3-2,1)+eelv;
% end
% eelv = eelv/nlb;
% mu1v(ns,1) = -(eerv-eelv)/BM;

% sfvE = 0; % shear force on the boundary V
% for i = nlb+nrb+1:nlb+nrb+ntb
%     sfvE = FFvE(i*3-1,1)+sfvE;
% end
% sfvE2 = 0; % the force on bottom boundary (to check the equilibrium)
% for i = nlb+nrb+ntb+1:nlb+nrb+ntb+nbb
%     sfvE2 = FFvE(i*3-1,1)+sfvE2;
% end
% 
% eer = 0; % the force on bottom boundary (to check the equilibrium)
% for i = 1:nrb
%     eer = UUvE(i*3-2,1)+eer;
% end
% eer = eer/nrb;
% eel = 0; % the force on bottom boundary (to check the equilibrium)
% for i = nrb+1:nrb+nlb
%     eel = UUvE(i*3-2,1)+eel;
% end
% eel = eel/nlb;
% mu1(ns,1) = -(eer-eel)/BM;
% 
% 
% UTE = transpose(UUvE);
% Energy = UTE*M*UUvE;
% young2 = Energy/(BM)^2;

% finding mu and then E
% mu = 1-2*Gv(ns,1)/young2;
% GvE(ns,1) = young2;
% sfvE/BM;
% sfvE2/BM;

% GvE(ns,1) = sfvE/lambda / (BM/lambda);

sigx = 0; % stress in x direction
for si =1:nrb
    if coupn(si,1)~=0
    sigx = sigx+(FFvE(3*si-2,1));
    end
end
sigx = sigx/(x(2)-x(1));

sigy = 0; % stress in y direction
for si = nrb+nlb+1:nrb+nlb+ntb
    if coupn(si,1)~=0
    sigy = sigy+(FFvE(3*si-2,1));
    end
end
sigy = sigy/(y(2)-y(1));

mu1(ns,1) = sigx/sigy;
% GvE(ns,1) = (sigy^2-sigx^2)/(sigy*BM/(y(2)-y(1)));
GvE = sigy/(BM/(y(2)-y(1)));

denN(ns,1) = N;

end
mu(:,j) = mu1;
% muv(:,j) = mu1v;
% Gs(:,j) = Gv;
Ge(:,j) = GvE;
% GE(:,3) = Gh;
% GE(:,4) = GhE;

end

% Mslambda(l,:) = Gs(:,1);
Melambda(l,:) = Ge(:,1);
Mmulambda(l,:) = mu(:,1);
% Mmuvlambda(l,:) = muv(:,1);

Mmu = zeros(1,Ns);
% Mmuv = zeros(1,Ns);
% MGs = zeros(1,Ns); % Mean of Gs 
MGe = zeros(1,Ns); % Mean of Ge



for i = 1: Ns
%     Gs2 = Gs(:,i);
    Ge2 = Ge(:,i);
    mu2 = mu(:,i);
%     mu2v = muv(:,i);
    k=1;
    for j = 1:N2s
        if Ge2(k,1) == 0
%             Gs2(k,:)=[];
            Ge2(k,:)=[];
            mu2(k,:)=[];
%             mu2v(k,:)=[];
            k=k-1;
        end
        k=k+1;
    end
%     MGs(1,i) = mean(Gs2);
    MGe(1,i) = mean(Ge2);
    Mmu(1,i) = mean(mu2);
%     Mmuv(1,i) = mean(mu2v);
end

% MMslambda(l,1) = MGs;
MMelambda(l,1) = MGe;
MMmulambda(l,1) = Mmu;
% MMmuvlambda(l,1) = Mmuv;
end

for i = 1:size(Melambda,1)
%     Gs2 = Mslambda(i,:);
    Ge2 = Melambda(i,:);
    mu2 = Mmulambda(i,:);
%     mu2v = Mmuvlambda(i,:);
    k=1;
    for j = 1:N2s1
        if Ge2(1,k) == 0
%             Gs2(:,k)=[];
            Ge2(:,k)=[];
            mu2(:,k)=[];
%             mu2v(:,k)=[];
            k=k-1;
        end
        k=k+1;
    end
%     MMslambda(i,1) = mean(Gs2);
    MMelambda(i,1) = mean(Ge2);
    MMmulambda(i,1) =  mean(mu2);
%     MMmuvlambda(i,1) =  mean(mu2v);
end



timeTottal = toc

% 
% figure1 = figure;
% plot(MMelambda,'r')
% hold on
% plot(MMslambda,'b')
% figure1 = figure;
% plot(MMmulambda,'o','color','r')
% hold on
% plot(MMmuvlambda,'o','color','b')


if wm ==1
    save('SSdata')      %-------------------*********************
elseif wm==2
                                %-------------------*********************
%     nameS = strcat('NEW-Size',num2str(density),'Pr',num2str(Pr*100));
    nameS = strcat('nu-Size',num2str(density),'Theta',num2str(ptheta),'Pr',num2str(Pr*100),'thickness',num2str(thickness));
    save(nameS)
end

% poly = polyfit(den,G,4);
% x1 = linspace(min(denN),max(denN));
% y1 = polyval(poly,x1);

% subplot(2,2,1)
% plot(den,G,'o')
% hold on
% plot(x1,y1)
% hold on
% subplot(2,2,2)
% plot(denN,G,'o')
% hold on
% subplot(2,2,3)
% plot(denf,G,'o')





