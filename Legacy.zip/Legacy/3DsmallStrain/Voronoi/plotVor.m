function [] = plotVor(edges,nodes,bndCounts)

figure; hold on;
for k = 1:size(edges,1)
    i = edges(k,1);
    j = edges(k,2);
    plot3( [nodes(i,1) nodes(j,1)], ...
           [nodes(i,2) nodes(j,2)], ...
           [nodes(i,3) nodes(j,3)], ...
           '-k', 'LineWidth', 0.7 );
end
faceColors = {'r','g','b','c','m','y'};    % x=L, x=0, y=L, y=0, z=L, z=0
markerSize = 60;
offset = 0;

for f = 1:6
    cnt = bndCounts(f);
    if cnt>0
        idx = offset + (1:cnt);
        scatter3( nodes(idx,1), nodes(idx,2), nodes(idx,3), ...
                  markerSize, ...
                  'Marker','o', ...
                  'MarkerEdgeColor', faceColors{f}, ...
                  'MarkerFaceColor', 'none', ...
                  'LineWidth', 1.5 );
        offset = offset + cnt;
    end
end
axis equal tight
view(3)
xlabel('X'); ylabel('Y'); zlabel('Z')
title('3D Voronoi Network – Hollow Colored Boundary Nodes')
hE = plot3(NaN,NaN,NaN,'-k','LineWidth',0.7);
hB = gobjects(6,1);
for f=1:6
    hB(f) = scatter3(NaN,NaN,NaN, markerSize, 'Marker','o', ...
                     'MarkerEdgeColor',faceColors{f}, ...
                     'MarkerFaceColor','none', 'LineWidth',1.5);
end
legend([hE; hB], ...
       ['Edges'; {'x = L';'x = 0';'y = L';'y = 0';'z = L';'z = 0'}], ...
       'Location','bestoutside');

end