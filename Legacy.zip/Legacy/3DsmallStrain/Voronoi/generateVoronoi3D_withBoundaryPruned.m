function [nodes, edges, bndIdx, bndCounts] = ...
         generateVoronoi3D_prunedFirst(P, L)
%GENERATEVORONOI3D_PRUNEDFIRST  
%   [nodes,edges,bndIdx,bndCounts] = generateVoronoi3D_prunedFirst(N,L)
%   builds the 3D Voronoi in [0,L]^3, prunes to the main component
%   (leaving its exact geometry intact), then identifies and orders
%   boundary nodes.

  %% 1) Scatter, triangulate, circumcenters
%   N = (3*L)^3*N;
%   margin = L;
%   P      = rand(N,3)*(L+2*margin) - margin;
  dt     = delaunayTriangulation(P);
  V      = circumcenter(dt);       % all Voronoi vertices
  nbr    = dt.neighbors;           % tetra‐neighbors

  %% 2) Build raw edge list (one edge per shared Delaunay face)
  T      = size(nbr,1);
  Eall   = zeros(T*2,2); ec = 0;
  for i = 1:T
    for f = 1:4
      j = nbr(i,f);
      if j > i
        ec = ec + 1;
        Eall(ec,:) = [i j];
      end
    end
  end
  Eall = Eall(1:ec,:);

  %% 3) Clip edges to [0,L]^3, collect nodes
  inside = all(V>=0 & V<=L, 2);
  inIdx   = find(inside);
  nodes   = V(inIdx,:);
  newIdx  = zeros(size(V,1),1);
  newIdx(inIdx) = 1:numel(inIdx);

  edges = zeros(ec,2); ec2 = 0;
  for k = 1:ec
    i = Eall(k,1); j = Eall(k,2);
    v1 = V(i,:);  v2 = V(j,:);
    in1 = inside(i); in2 = inside(j);
    if in1 && in2
      ec2 = ec2+1;
      edges(ec2,:) = [newIdx(i), newIdx(j)];
    elseif xor(in1,in2)
      if in1, vi=v1; vo=v2; idxi=newIdx(i);
      else    vi=v2; vo=v1; idxi=newIdx(j);
      end
      d = vo - vi; tmin = Inf; faceHit = 0;
      % test faces in fixed order
      if d(1)>0, t=(L-vi(1))/d(1); if 0<t&&t<1&&t<tmin, tmin=t; end; end
      if d(1)<0, t=-vi(1)/d(1);    if 0<t&&t<1&&t<tmin, tmin=t; end; end
      if d(2)>0, t=(L-vi(2))/d(2); if 0<t&&t<1&&t<tmin, tmin=t; end; end
      if d(2)<0, t=-vi(2)/d(2);    if 0<t&&t<1&&t<tmin, tmin=t; end; end
      if d(3)>0, t=(L-vi(3))/d(3); if 0<t&&t<1&&t<tmin, tmin=t; end; end
      if d(3)<0, t=-vi(3)/d(3);    if 0<t&&t<1&&t<tmin, tmin=t; end; end
      if isfinite(tmin)
        Pint = vi + tmin*d;
        nodes(end+1,:) = Pint;
        ec2 = ec2+1;
        edges(ec2,:) = [ idxi, size(nodes,1) ];
      end
    end
  end
  edges = edges(1:ec2,:);

  %% 4) Prune to the largest connected component
  G      = graph(edges(:,1), edges(:,2));
  comp   = conncomp(G);
  mainC  = mode(comp);
  keepV  = find(comp==mainC);
  old2new = zeros(numel(comp),1);
  old2new(keepV) = 1:numel(keepV);

  nodes = nodes(keepV,:);
  maskE = ismember(edges(:,1),keepV) & ismember(edges(:,2),keepV);
  edges = edges(maskE,:);
  edges = [ old2new(edges(:,1)), old2new(edges(:,2)) ];

  %% 5) Identify & count boundary nodes on the pruned network
  tol = 1e-8;
  X   = nodes(:,1); Y = nodes(:,2); Z = nodes(:,3);
  faceMasks = {
    abs(X-L)<tol, ...,  % 1: x=L
    abs(X-0)<tol, ...,  % 2: x=0
    abs(Y-L)<tol, ...,  % 3: y=L
    abs(Y-0)<tol, ...,  % 4: y=0
    abs(Z-L)<tol, ...,  % 5: z=L
    abs(Z-0)<tol       % 6: z=0
  };
  bndCounts = cellfun(@nnz, faceMasks);

  %% 6) Order boundary indices & finalize
  used  = false(size(nodes,1),1);
  bndIdx = zeros(sum(bndCounts),1);
  ptr    = 1;
  for f = 1:6
    idx = find(faceMasks{f} & ~used);
    n   = numel(idx);
    bndIdx(ptr:ptr+n-1) = idx;
    used(idx) = true;
    ptr = ptr + n;
  end
  % catch any corners accidentally missed
  stray = find(~used & any(cat(2,faceMasks{:}),2));
  bndIdx(ptr:ptr+numel(stray)-1) = stray;
  % interior nodes follow (if you still want that ordering):
  % intIdx  = find(~used & ~ismember((1:size(nodes,1))',bndIdx));
  % finalOrder = [bndIdx; intIdx];
  % nodes = nodes(finalOrder,:);
  % edges = old2new(edges);  % remap similarly if you reorder further

end
