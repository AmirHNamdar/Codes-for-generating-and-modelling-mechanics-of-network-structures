function [nodes, edges, bndIdx] = generateVoronoi3D_withBoundary2(N, L)
%GENERATEVORONOI3D_WITHBOUNDARY  
%   [nodes, edges, bndIdx] = generateVoronoi3D_withBoundary(N,L)
%   returns:
%     nodes  — M×3 array of Voronoi‐vertex coords, with all boundary nodes
%              first in the order [x=L; x=0; y=L; y=0; z=L; z=0]
%     edges  — K×2 array of node‐index pairs (undirected edges)
%     bndIdx — B×1 list of indices into nodes that lie on ∂[0,L]^3,
%              ordered by the 6 faces above.

  %–– 1) scatter seeds in [–L,2L]^3 to close boundary cells
  margin = L;
  P = rand(N,3)*(L+2*margin) - margin;

  %–– 2) Delaunay + circumcenters
  dt  = delaunayTriangulation(P);
  V   = circumcenter(dt);       % T-by-3
  nbr = dt.neighbors;           % T-by-4

  %–– 3) build raw edge list (one per shared face)
  T = size(nbr,1);
  Eall = zeros(T*2,2); cnt=0;
  for i=1:T
    for f=1:4
      j = nbr(i,f);
      if j>i
        cnt=cnt+1;
        Eall(cnt,:) = [i j];
      end
    end
  end
  Eall = Eall(1:cnt,:);

  %–– 4) mark interior vs “in‐box” circumcenters
  inside = all(V>=0 & V<=L, 2);

  %–– 5) build initial node list (just interior ones)
  inIdx = find(inside);
  nodes = V(inIdx,:);
  newIdx = zeros(size(V,1),1);
  newIdx(inIdx) = 1:numel(inIdx);

  %–– 6) clip edges and append boundary‐intersection nodes
  edges = zeros(cnt,2); ec=0;
  for k=1:cnt
    i = Eall(k,1); j = Eall(k,2);
    v1 = V(i,:);  v2 = V(j,:);
    in1 = inside(i); in2 = inside(j);

    if in1 && in2
      % interior–interior
      ec=ec+1;
      edges(ec,:) = [ newIdx(i), newIdx(j) ];

    elseif xor(in1,in2)
      % interior–outside → find intersection point on box
      if in1, vi=v1; vo=v2; idx_in=newIdx(i);
      else    vi=v2; vo=v1; idx_in=newIdx(j);
      end
      d = vo-vi; tmin = Inf;
      % test each face
      if d(1)<0, t = -vi(1)/d(1); if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(1)>0, t = (L-vi(1))/d(1); if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(2)<0, t = -vi(2)/d(2); if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(2)>0, t = (L-vi(2))/d(2); if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(3)<0, t = -vi(3)/d(3); if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(3)>0, t = (L-vi(3))/d(3); if t>0&&t<1&&t<tmin, tmin=t; end; end

      if isfinite(tmin)
        Pint = vi + tmin*d;
        nodes(end+1,:) = Pint;
        ec=ec+1;
        edges(ec,:) = [ idx_in, size(nodes,1) ];
      end
    end
    % both outside → ignore
  end
  edges = edges(1:ec,:);

  %–– 7) identify and order all boundary nodes by face
  tol = 1e-8;
  X=nodes(:,1); Y=nodes(:,2); Z=nodes(:,3);
  used = false(size(nodes,1),1);
  bndIdx = [];
  % faces in the user‐requested order:
  faces = { X, L; X, 0; Y, L; Y, 0; Z, L; Z, 0 };
  for f=1:6
    coord = faces{f,1};
    val   = faces{f,2};
    idx = find(~used & abs(coord - val)<tol);
    used(idx) = true;
    bndIdx = [bndIdx; idx];
  end
  % now append any stray floating‐point‐error nodes exactly on two faces
  stray = find(~used & (abs(X)<tol|abs(X-L)<tol|abs(Y)<tol|abs(Y-L)<tol|abs(Z)<tol|abs(Z-L)<tol));
  used(stray) = true;
  bndIdx = [bndIdx; stray];

  % interior nodes come last
  intIdx = find(~used);
  newOrder = [bndIdx; intIdx];

  %–– 8) reorder nodes & remap edges
  nodes = nodes(newOrder,:);
  map   = zeros(size(nodes,1),1);
  map(newOrder) = (1:numel(newOrder))';
  edges = map(edges);

end
