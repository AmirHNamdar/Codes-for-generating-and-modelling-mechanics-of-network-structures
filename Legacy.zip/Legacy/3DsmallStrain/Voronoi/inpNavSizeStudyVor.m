clear
clc
close all


% this script creates a series inp file to do a study of effect of size of
% lambda (Study box size) in small deformation of Voronoi netowrks.

% The simulation happens to get bulk and shear modulus and then poisson
% ratio is extracted. We will have different box sizes and different nnG (as
% defined below).

% The necessary input___________________________________________________________________________
% Specific input for generating the network
lambda2 = [0.015, 0.02, 0.03, 0.05]; % side length of the box
% lambda2 = [2,3,4,5];
% lambda2 = [6,7];
nnG2 = [1,3,4,5]; % number of nodes in each group for BC matter
NO2 = [12,12,12,12]; % number of observation
% NO2 = [48,36,24,12];
% NO2 = [12,12];

N = 10000000;
outFolder = '/home/m60315an/abaqus/Abaqus/GeneratingInputFile/3D/Voronoi/BCStudy'; % direction of where i want to write my .inp file

% The General input___________________________________________________________________________

MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio
e = 100; % elastic modulus of beams
g = e/2/(1+Matnu);
CheckPlot = false; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = false; % to check the time of excution of each main function
radius = 1e-4;


% THE LOOP___________________________________________________________________________

% I will have two loops (the first one for the density and the other for the nnG)


nS = size(lambda2,2);
tic
for i = 1:nS
    lambda = lambda2(1,i);
%     N = (lambda+2).^3.*density; % number of fibres data [initial nf, final nf, number of increase in each step]
%     x = [0 lambda]; % boundary of x direction
%     y = [0 lambda]; % boundary of y direction
%     z = [0 lambda];
%     
    defHShear = [0 1/1000 0;
            0 0 0;
            0 0 0]; % the appllied farfield BC
        
    defHBulk = [1/1000 0 0;
            0 1/1000 0;
            0 0 1/1000]; % the appllied farfield BC

    % number of observation for each case depending on the size
    NO = NO2(1,i);
    
    parfor j=1:NO
% for j=1:NO
        % create the netwrok
        [nodes, edges, bndIdx, bndCounts] = generateVoronoi3D_prunedFirst2(N,lambda);
        
            NE = size(edges,1); % number of edges
            NN = size(nodes,1); % number of nodes 
            PN = nodes; % position of nodes
            ED = edges; % position of edges
            nrb = bndCounts(1,1); % number of right boundary node (x +)
            nlb = bndCounts(1,2); % number of left boundary node (x -)
            ntb = bndCounts(1,3); % number of top boundary node (y +)
            nbb = bndCounts(1,4); % number of botttom boundary node (y -)
            nfb = bndCounts(1,5); % number of front boundary node (z +)
            nreb = bndCounts(1,6); % number of rear boundary node (z -)
            nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes

            % deleting the short fibres 
            
            diffs = nodes(edges(:,1), :) - nodes(edges(:,2), :);
            edgeLengths = sqrt( sum( diffs.^2, 2 ) );
            aveL = mean(edgeLengths);
            flt = aveL/100;
            [NE,NN,PN,ED,nrb,nlb,ntb,nbb,nfb,nreb,nbn] = ModifyingNetworkLengthVor(NE,NN,PN,ED,nrb,nlb,ntb,nbb,nfb,nreb,nbn,edgeLengths,flt);

            % write various .inp file for different nnGs and BC.
            % in the nase it should be clear which shear/bulk are for the same
            % network and nnG so that the poisson ratio can be investigated.

            for k =1:2 
                if k == 1
                    defH = defHShear;
                else
                    defH = defHBulk;
                end

                nBCnnG = size(nnG2,2);
                for l = 1:nBCnnG
                    nnG = nnG2(1,l);

                    % inpName should be specified here
                    inpName = strcat('BCNoShortFibre-','N',num2str(N),'radius',num2str(radius),'lambda',num2str(lambda),'DefKind',num2str(k),'nnG',num2str(nnG),'Observ',num2str(j));
                    i
                    j
                    

                    % calculating the equation needed for BC___________________________________________________________________________
                    if timeCheck == true
                        tic
                    end
                    [equations,errorArea] = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nfb,nreb,nnG,defH);
                    if timeCheck == true
                        time_Equation = toc
                    end
                    % I also need to save the data to use in the PP section
%                     save(inpName)

                    % writing the .inp file___________________________________________________________________________
                    if errorArea == false
                        if timeCheck == true
                            tic
                        end
                    [ToPrint,prp] = writeFunction(PN,ED,inpName,radius,MatDen,Matnu,e,equations,nbn,lambda,CheckPlot,outFolder);
                        if timeCheck == true
                            time_write = toc
                        end
                    end
                end
            end
    end
end


timeAll = toc




























