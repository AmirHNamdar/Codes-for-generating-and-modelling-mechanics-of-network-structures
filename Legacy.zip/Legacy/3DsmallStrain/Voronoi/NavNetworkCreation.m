clear
clc
close all

% this code creates 3D voronoi network.

N = 1000; % density of number of initial seeds
L = 1.0;



N = (3*L)^3*N;
  margin = L;
  P      = rand(N,3)*(L+2*margin) - margin;
  
  tic
[nodes, edges, bndIdx, bndCounts] = generateVoronoi3D_withBoundary3(P,L);
toc

% display the number of BC
disp(table( ...
  {'x=L';'x=0';'y=L';'y=0';'z=L';'z=0'}, ...
   bndCounts, ...
  'VariableNames',{'Face','NodeCount'}))

G    = graph(edges(:,1), edges(:,2));
comp = conncomp(G);
max(comp)
size(comp)

% figure; hold on;
% for k=1:size(edges,1)
%   p = edges(k,1); q = edges(k,2);
%   plot3([nodes(p,1) nodes(q,1)], [nodes(p,2) nodes(q,2)], [nodes(p,3) nodes(q,3)], '-k');
% end
% axis equal tight; view(3)
% xlabel('X'); ylabel('Y'); zlabel('Z')
% title('3D Voronoi with Ordered Boundary Nodes')



tic
[nodes2, edges2, bndIdx2, bndCounts2] = generateVoronoi3D_withBoundaryPruned(P, L);
toc
% display the number of BC
disp(table( ...
  {'x=L';'x=0';'y=L';'y=0';'z=L';'z=0'}, ...
   bndCounts2', ...
  'VariableNames',{'Face','NodeCount'}))
G2    = graph(edges2(:,1), edges2(:,2));
comp2 = conncomp(G2);
max(comp2)
size(comp2)

tic
[nodes3, edges3, bndIdx3, bndCounts3] = generateVoronoi3D_prunedFirst2(P, L);
toc
% display the number of BC
disp(table( ...
  {'x=L';'x=0';'y=L';'y=0';'z=L';'z=0'}, ...
   bndCounts2', ...
  'VariableNames',{'Face','NodeCount'}))
G3    = graph(edges3(:,1), edges3(:,2));
comp3 = conncomp(G3);
max(comp3)
size(comp3)


% figure; hold on;
% for k=1:size(edges2,1)
%   p = edges2(k,1); q = edges2(k,2);
%   plot3([nodes2(p,1) nodes2(q,1)], [nodes2(p,2) nodes2(q,2)], [nodes2(p,3) nodes2(q,3)], '-k');
% end
% axis equal tight; view(3)
% xlabel('X'); ylabel('Y'); zlabel('Z')
% title('3D Voronoi with Ordered Boundary Nodes')




% compute differences for each edge
diffs = nodes(edges(:,1), :) - nodes(edges(:,2), :);

% Euclidean length of each edge
edgeLengths = sqrt( sum( diffs.^2, 2 ) );




















