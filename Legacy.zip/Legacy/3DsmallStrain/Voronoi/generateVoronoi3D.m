function [nodes, edges] = generateVoronoi3D(N, L)
%GENERATEVORONOI3D  Build a 3D Voronoi “fiber” network inside [0,L]^3.
%
%   [nodes, edges] = generateVoronoi3D(N, L) returns:
%     nodes  — M-by-3 list of Voronoi‐vertex positions inside the box
%     edges  — K-by-2 list of indices into nodes, one per Voronoi edge
%
%   Inputs:
%     N    — number of random seeds to scatter (use 1000–5000 for moderate
%             resolution)
%     L    — side‐length of the cube within which the final network lives
%
%   The algorithm:
%     • Scatter N points in an extended cube [–L, 2L]^3, so that all Voronoi
%       cells intersecting [0,L]^3 are “closed” by neighboring seeds.
%     • Build the 3D Delaunay triangulation of those seeds.
%     • Compute the circumcenter of each tetrahedron → these are your
%       candidate Voronoi vertices.
%     • For every pair of tetrahedra sharing a face, connect their
%       circumcenters with an edge.
%     • Discard any vertex or edge that lies (even partially) outside [0,L]^3.
%
%   This runs in roughly O(N) time once the triangulation is built.
  
  % 1) scatter seeds in [–L, 2L]
  margin = L;
  P = rand(N,3)*(L+2*margin) - margin;

  % 2) Delaunay triangulation
  dt = delaunayTriangulation(P);

  % 3) circumcenters of each tetrahedron
  %    (size = T-by-3, where T = # of tetrahedra)
  V = circumcenter(dt);

  % 4) walk neighbors to build edges
  nbr = dt.neighbors;        % T-by-4: neighbor tetra for each of the 4 faces
  T   = size(nbr,1);
  % estimate ~2 edges per tet → prealloc
  estEdges = 2*T;
  E = zeros(estEdges,2);
  cnt = 0;
  for i = 1:T
    for f = 1:4
      j = nbr(i,f);
      if j>i   % only once per shared face
        cnt = cnt+1;
        E(cnt,:) = [i j];
      end
    end
  end
  E = E(1:cnt,:);

  % 5) trim to inside [0,L]^3
  inBox = all(V>=0 & V<=L, 2);
  keep = inBox(E(:,1)) & inBox(E(:,2));
  E = E(keep,:);
  % renumber the survivors
  old2new = zeros(size(inBox));
  idx     = find(inBox);
  old2new(idx) = 1:numel(idx);
  edges  = old2new(E);

  nodes = V(idx,:);

end
