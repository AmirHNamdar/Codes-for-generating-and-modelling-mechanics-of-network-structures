clear
clc
close all

% this creates an .inp file for abaqus based on voronoi netwokr creation.
% This is for mesh study.


% inputs t ocreate the network _______________________________________

meshl2 = [1,0.001,0.0005,0.0001];  % for den = 40 and CD = L/5, mean length is 0.05425

outFolder = '/Users/Code/Abaqus/GeneratingInputFile/3D/Voronoi/MeshStudy'; % direction of where i want to write my .inp file
% make sure it exists (creates it if it doesn’t)
if ~exist(outFolder,'dir')
    mkdir(outFolder)
end



N = 5e6; % density of number of initial seeds
lambda = 0.07; % size of the study box
nnG = 4; % number of nodes in each group for BC
defH = [1/1000 0 0;
        0 1/1000 0;
        0 0 1/1000]; % the appllied farfield BC
MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio
e = 100; % elastic modulus of beams
g = e/2/(1+Matnu);
CheckPlot = false; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = true; % to check the time of excution of each main function
radius = 1e-5;


% generating network___________________________________________________________________________
if timeCheck == true
    tic
end
[nodes, edges, bndIdx, bndCounts] = generateVoronoi3D_prunedFirst2(N,lambda);
if timeCheck == true
    time_NetworkCreation = toc
end

G    = graph(edges(:,1), edges(:,2));
comp = conncomp(G); 
NumberofClusters = max(comp) % the number of clusters in the network (it should be one)

% compute differences for each edge
diffs = nodes(edges(:,1), :) - nodes(edges(:,2), :);

% Euclidean length of each edge
edgeLengths = sqrt( sum( diffs.^2, 2 ) );


NE = size(edges,1); % number of edges
NN = size(nodes,1); % number of nodes 
PN = nodes; % position of nodes
ED = edges; % position of edges
nrb = bndCounts(1,1); % number of right boundary node (x +)
nlb = bndCounts(1,2); % number of left boundary node (x -)
ntb = bndCounts(1,3); % number of top boundary node (y +)
nbb = bndCounts(1,4); % number of botttom boundary node (y -)
nfb = bndCounts(1,5); % number of front boundary node (z +)
nreb = bndCounts(1,6); % number of rear boundary node (z -)
nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes

if CheckPlot == true
plotVor(edges,nodes,bndCounts)
end


% calculating the equation needed for BC___________________________________________________________________________
if timeCheck == true
    tic
end
[equations,errorArea] = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nfb,nreb,nnG,defH);
if timeCheck == true
    time_Equation = toc
end



% writing the .inp file___________________________________________________________________________

for nm = 1:size(meshl2,2) % number of mesh studies
if errorArea == false
    if timeCheck == true
        tic
    end
    
    meshl = meshl2 (1,nm); % mesh length
    inpName = strcat('MeshStudy-Bulk2-','N',num2str(N),'radius',num2str(radius),'lambda',num2str(lambda),'MeshSize',num2str(meshl));
    
    [ToPrint,prp] = writeFunctionMesh(PN,ED,inpName,radius,MatDen,Matnu,e,equations,nbn,lambda,CheckPlot,meshl,outFolder);
    if timeCheck == true
        time_write = toc
    end
end
disp(ToPrint);
end















