% clear
% close all
% clc
% tic
% lambda = 4;
% points = rand(7500,2)*lambda;

function [areas,errorArea] = SurfaceVoronoiArea(lambda,points)
errorArea = false;

tr = delaunayTriangulation(points);

midpoint = []; % point of mid point
per_normal = []; % normal vector of the perpendicular line to the triangle side 
for i=1:size(tr.ConnectivityList,1)
    fp = tr.ConnectivityList(i,1); % first point
    sp = tr.ConnectivityList(i,2); % first point
    tp = tr.ConnectivityList(i,3); % first point
    mid_point1(1,1) = (tr.Points(fp,1) + tr.Points(sp,1))/2;
    mid_point1(1,2) = (tr.Points(fp,2) + tr.Points(sp,2))/2;
    mid_point2(1,1) = (tr.Points(fp,1) + tr.Points(tp,1))/2;
    mid_point2(1,2) = (tr.Points(fp,2) + tr.Points(tp,2))/2;   
    mid_point3(1,1) = (tr.Points(tp,1) + tr.Points(sp,1))/2;
    mid_point3(1,2) = (tr.Points(tp,2) + tr.Points(sp,2))/2;
    
    mid_point(i,:) = [mid_point1,mid_point2,mid_point3];
end

% calculating the point of triangles for which the perpendicular line intersect
[circumcenters, radii] = circumcenter(tr);


% calculating the 1 or 2 or 3 neighbors of each triangle (and plotting the line)
% for triangle that have 2 neghbor the line intersects with boundary
neighboringTriangles = neighbors(tr);


% looking at each point and considering a centre for a rectangle. the
% nfollowing the neighboring triangle that has connection with the point
% and therefore we can complete the cell
attachedTriangles = {};
for i =1:size(points,1)
attachedTriangles{i} = vertexAttachments(tr, i);
end

% knowing the sides of a cell we can calculate the area.
c_node = []; % corner nodes
for i =1:size(points,1) % do it for all the points
    TrList = attachedTriangles{i}{1};
    enode = false; % enclosed node (by triangles)
    % if first and last triangle share more than one point then enode =
    % true
    first_tr = tr.ConnectivityList(TrList(1,1),:);
    last_tr = tr.ConnectivityList(TrList(1,end),:);
    n_shared_N = 0;
    for k=1:3
        n_shared_N = n_shared_N + sum(first_tr(1,k) == last_tr); % number of shared nodes
    end
    if n_shared_N == 2 && size(TrList,2) > 2 % it should have more than 2 triangle
        enode = true;
        
    end
    if enode == false
        c_node(end+1,1) = i;
    end
end

c_temp = [];
VCell = {}; % voronoi cells confined to the boundaries of the square
for i =1:size(points,1) % do it for all the points
    Vpos = []; % position of points in the voronoi cell
    TrList = attachedTriangles{i}{1};
    enode = false; % enclosed node (by triangles)
    % if first and last triangle share more than one point then enode =
    % true
    first_tr = tr.ConnectivityList(TrList(1,1),:);
    last_tr = tr.ConnectivityList(TrList(1,end),:);
    n_shared_N = 0;
    for k=1:3
        n_shared_N = n_shared_N + sum(first_tr(1,k) == last_tr); % number of shared nodes
    end
    if n_shared_N == 2 && size(TrList,2) > 2 % it should have more than 2 triangle
        enode = true;
        
    end
    
    if enode == true
        anyNO = false; % any node outside?
        for j=1:size(TrList,2)
            xcir = circumcenters(TrList(1,j),1); % x position
            ycir = circumcenters(TrList(1,j),2); % y position
            Vpos(j,:) = [xcir,ycir];
            if xcir > lambda || xcir < 0 || ycir > lambda || ycir < 0 
                anyNO = true;
            end
        end
        if anyNO == true % trim the polygon
            polySquare = polyshape([0, lambda, lambda, 0], [0, 0, lambda, lambda]);
            polyOriginal = polyshape(Vpos(:,1), Vpos(:,2));
            polyIntersect = intersect(polyOriginal, polySquare);
            Vpos = [];
            [Vpos(:,1), Vpos(:,2)] = boundary(polyIntersect);
            Vpos(end,:) = [];
        end
    else
        c_temp(end+1,1) = points(i,1); % corner temp for plotting
        c_temp(end,2) = points(i,2); % corner temp for plotting
        
        % find the middle of the first and last triangle. which line is the
        % outer one? the one which has connection to the other outside
        % node.
        f_out_line = []; % second node of first out line 
        l_out_line = []; % second node of last out line
        steps_temp = nonzeros((first_tr ~= i).*[1 2 3]);
%         for k = 1:3
        for k = steps_temp'
            
%             if first_tr(1,k) ~= i
                if sum(first_tr(1,k)==c_node) == 1
                    if isempty(f_out_line)
                    % some times all three node of a tr corner node. we
                    % should make sure we chose the write one. we consider
                    % a node, if the tr that they sahre is the f or l tr of
                    % the other one, then it is the one.
                        f_out_line_temp = first_tr(1,k);
                        TrLtemp = attachedTriangles{f_out_line_temp}{1};
                        if TrLtemp(1,1) == TrList(1,1) || TrLtemp(1,end) == TrList(1,1)
                            f_out_line = f_out_line_temp;
                        end
                        % sometimes the corner tr has 3 corner node...
                        if k ~= steps_temp(end,1) && first_tr(1,steps_temp(end,1)) ~= i
                            
                            sizeTr = size(attachedTriangles{first_tr(1,steps_temp(end,1))}{1},2);
                            if sum(first_tr(1,steps_temp(end,1))==c_node) == 1 && sizeTr == 1
                                f_out_line = first_tr(1,steps_temp(end,1));
                            end
                        end
                    end


                end
%             end
        end
        
        steps_temp = fliplr(nonzeros((last_tr ~= i).*[1 2 3])');
%         for k = 3:-1:1
          for k = steps_temp
%             if last_tr(1,k) ~= i
                if sum(last_tr(1,k)==c_node) == 1
                    if isempty(l_out_line)
%                         l_out_line = last_tr(1,k);
                        l_out_line_temp = last_tr(1,k);
                        TrLtemp = attachedTriangles{l_out_line_temp}{1};
                        if TrLtemp(1,1) == TrList(1,end) || TrLtemp(1,end) == TrList(1,end)
                            l_out_line = l_out_line_temp;
                        end
                        % sometimes the corner tr has 3 corner node...
                        if k ~= steps_temp(1,end) && last_tr(1,steps_temp(1,end)) ~= i
                            
                            sizeTr = size(attachedTriangles{last_tr(1,steps_temp(1,end))}{1},2);
                            if sum(last_tr(1,steps_temp(end,1))==c_node) == 1 && sizeTr == 1
                                l_out_line = last_tr(1,steps_temp(1,end));
                            end
                        end
                    end
                end
%             end
        end
        
        % we can calculate the norm from midpoint to the circumcentre and
        % compare it to norm of midpoint to centre of triangle. if the
        % inner product is positive then the direction of the norm must
        % change. (i didnt really used norm sometimes!).
        
        c_tr_first = [(points(first_tr(1,1),1)...
            + points(first_tr(1,2),1) ...
            + points(first_tr(1,3),1))/3, ...
            (points(first_tr(1,1),2)...
            + points(first_tr(1,2),2) ...
            + points(first_tr(1,3),2))/3];
        mid_first = [(points(f_out_line,1) + points(i,1))/2,...
            (points(f_out_line,2) + points(i,2))/2];
        c_norm_f = c_tr_first - mid_first;
        
        surf_norm_f = (circumcenters(TrList(1,1),:) - mid_first) / ...
            norm(circumcenters(TrList(1,1),:) - mid_first);

        if dot(surf_norm_f, c_norm_f) > 0
            surf_norm_f = - surf_norm_f;
        end
        
        
        
        c_tr_last = [(points(last_tr(1,1),1)...
            + points(last_tr(1,2),1) ...
            + points(last_tr(1,3),1))/3, ...
            (points(last_tr(1,1),2)...
            + points(last_tr(1,2),2) ...
            + points(last_tr(1,3),2))/3];
        mid_last = [(points(l_out_line,1) + points(i,1))/2,...
            (points(l_out_line,2) + points(i,2))/2];
        c_norm_l = c_tr_last - mid_last;
        
        surf_norm_l = (circumcenters(TrList(1,end),:) - mid_last) / ...
            norm(circumcenters(TrList(1,end),:) - mid_last);

        if dot(surf_norm_l, c_norm_l) > 0
            surf_norm_l = - surf_norm_l;
        end
        
        f_circum = circumcenters(TrList(1,1),:);
        l_circum = circumcenters(TrList(1,end),:);
        [fl_Vpos,V_exist] = fl_function(lambda,mid_first,mid_last,surf_norm_f,surf_norm_l,f_circum,l_circum,circumcenters,TrList);
        
        for j=1:size(TrList,2)
            xcir = circumcenters(TrList(1,j),1); % x position
            ycir = circumcenters(TrList(1,j),2); % y position
            Vpos(j,:) = [xcir,ycir];
        end
        if V_exist(1,1) == 1
            Vpos = [fl_Vpos(1,:);Vpos];
        end
        if V_exist(1,2) == 1
            Vpos = [Vpos;fl_Vpos(2,:)];
        end
        if V_exist(1,3) == 1
            Vpos = [Vpos;fl_Vpos(3,:)];
        end
        
        polySquare = polyshape([0, lambda, lambda, 0], [0, 0, lambda, lambda]);
%         i
%         Vpos
            polyOriginal = polyshape(Vpos(:,1), Vpos(:,2));
            polyIntersect = intersect(polyOriginal, polySquare);
            Vpos = [];
            [Vpos(:,1), Vpos(:,2)] = boundary(polyIntersect);
            Vpos(end,:) = [];

        
    end
            
    VCell{i} = Vpos;
            
    end
        
            

% toc


numPolygons = numel(VCell);
areas = zeros(numPolygons,1);

for i = 1:numPolygons
    XY = VCell{i};         % Nx2 array of [x, y]
    x = XY(:,1);
    y = XY(:,2);
    areas(i) = polyarea(x, y);
end
sum(areas);
    lambda^2;
if abs((sum(areas) - lambda^2)/lambda^2) > 1e-9
    disp('sum area is not close to lambda square.')
    sum(areas)
    lambda^2
    errorArea = true;
end



% 
% 
% 
% 
% % plotting
% triangles = tr.ConnectivityList;
% % Compute the center (centroid) of each triangle
% centroids = zeros(size(triangles, 1), 2); % Preallocate for centroids
% for i = 1:size(triangles, 1)
%     % Get vertices of the triangle
%     verts = tr.Points(triangles(i, :), :);
%     % Compute centroid (average of vertices)
%     centroids(i, :) = mean(verts, 1);
% end
% 
% 
% 
% 
%     figure; hold on; axis equal;
%     title('Delaunay Triangulation');
%     triplot(tr, 'Color',[0.7 0.7 0.7]);  % light gray triangulation lines
% 
% % Label each triangle at its centroids
% for i = 1:size(triangles, 1)
%     text(centroids(i, 1), centroids(i, 2), num2str(i), ...
%         'FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
% end
%     % 3) Plot the original points
%     plot(points(:,1), points(:,2),'ro','MarkerFaceColor','r');
%     hold on
%     plot(c_temp(:,1), c_temp(:,2),'o','MarkerFaceColor','k');
%     hold on
% %     plot(mid_point(:,1),mid_point(:,2),'bo','MarkerFaceColor','b')
% %     hold on 
% for i = 1:size(tr.ConnectivityList,1)
%     plot(circumcenters(i,1),circumcenters(i,2),'go','MarkerFaceColor','g')
%     hold on
% end
% % Label each triangle at its circumcenters
% for i = 1:size(triangles, 1)
%     text(circumcenters(i, 1), circumcenters(i, 2), num2str(i), ...
%         'FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center', 'Color',[0.7 0.7 0.7]);
% end
% 
% %     plot([0 lambda lambda 0 0], [0 0 lambda lambda 0])
% %     hold on
%     xlim([0, lambda]); % X-axis limits
% ylim([0, lambda]); % Y-axis limits
%     
% for i=1:size(VCell,2)
%     Vnodes = VCell{i};
%     if ~isempty(Vnodes)
%         Vnodes(end+1,:) = Vnodes(1,:);
% %         cell_color = rand(1,3);
% %         cell_line_w = rand(1)*2;
%             cell_color = 'b';
%             cell_line_w = 1.5;
%         for k=1:size(Vnodes,1)-1
%             plot([Vnodes(k,1), Vnodes(k+1,1)],[Vnodes(k,2), Vnodes(k+1,2)],'Color', cell_color, 'LineWidth', cell_line_w);
%             hold on
%         end
%     else
%         1
%     end
% end
%     
    
%     % Compute Voronoi diagram
%     x = points(:,1);
%     y = points(:,2);
% [vx, vy] = voronoi(points(:,1), points(:,2));
% 
% % Plot the Voronoi diagram
% figure;
% hold on;
% triplot(tr, 'Color',[0.7 0.7 0.7]);  % light gray triangulation lines
% hold on
% plot([0 lambda lambda 0 0], [0 0 lambda lambda 0])
%     hold on
% % Plot Voronoi edges
% plot(vx, vy, 'b-', 'LineWidth', 1.5);
% 
% % Plot the original points
% plot(x, y, 'ro', 'MarkerFaceColor', 'r', 'MarkerSize', 6);
% 
% % Customize plot
% title('Voronoi Diagram');
% xlabel('X-coordinate');
% ylabel('Y-coordinate');
% axis equal;
% grid on;
% xlim([0, lambda]); % X-axis limits
% ylim([0, lambda]); % Y-axis limits
end

