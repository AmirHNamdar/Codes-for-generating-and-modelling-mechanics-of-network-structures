% function [Equations,errorArea] = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nfb,nreb,nnG,defH)




NE = 7; % number of edges
NN = 8; % number of nodes 
PN = [1,1/3,0 
    1,2/3 + 1/10,0
    0,1/3,0
    0,2/3,0
    1/2,1,0
    1/2,0,0
    1/2,1/3,0
    1/2,2/3,0]; % position of nodes
ED = [1,7
    2,8
    3,7
    4,8
    5,8
    6,7]; % position of edges
nrb = 2; % number of right boundary node (x +)
nlb = 2; % number of left boundary node (x -)
ntb = 1; % number of top boundary node (y +)
nbb = 1; % number of botttom boundary node (y -)
nfb = 0; % number of front boundary node (z +)
nreb = 0; % number of rear boundary node (z -)
nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes

nnG = 2;
defH = [0 1 0
    0 0 0
    0 0 0];

% normal vector in right, left, top, and bottom side of the boundary
nr = [1; 0; 0];  % x
nl = [-1; 0; 0];
nt = [0; 1; 0];  % y
nb = [0; -1; 0];
nf = [0; 0; 1]; % z
nre = [0; 0; -1];

PN2 = PN;
PN = zeros(size(PN,1),4);
PN(:,1) = [1:size(PN,1)]';
PN(:,2:4) = PN2;

% area associated with each boundary node__________________________________
% A = []; % area associated to each node
% for i =1:6 % the 6 boundary surface
%     if i==1
%         points = PN(1:nrb, 3:4); % the 2d position that we use in the function
%     elseif i==2
%         points = PN(nrb + 1 : nrb + nlb, 3:4);
%     elseif i==3
%         points = PN(nrb + nlb + 1 : nrb + nlb + ntb, 2:2:4);
%     elseif i==4
%         points = PN(nrb + nlb + ntb + 1 : nrb + nlb + ntb + nbb, 2:2:4);
%     elseif i==5
%         points = PN(nrb + nlb + ntb + nbb + 1 : nrb + nlb + ntb + nbb + nfb, 2:3);
%     elseif i==6
%         points = PN(nrb + nlb + ntb + nbb + nfb + 1 : nrb + nlb + ntb + nbb + nfb + nreb, 2:3);
%     end
%     [areas,errorArea] = SurfaceVoronoiArea(lambda,points);
%     A = [A;areas];
% end
A = [1/2
    1/2
    1/2
    1/2
    1
    1];

% node info [x, y, z, A, nx, ny, nz]_______________________________________
Ninf = zeros(nbn,7);
Ninf = [PN(1:nbn,2),PN(1:nbn,3),PN(1:nbn,4),A];
Ninf(1 : nrb,5) = 1;
Ninf(1+nrb : nrb+nlb,5) = -1;
Ninf(1+nrb+nlb : nrb+nlb+ntb,6) = 1;
Ninf(1+nrb+nlb+ntb : nrb+nlb+ntb+nbb,6) = -1;
Ninf(1+nrb+nlb+ntb+nbb : nrb+nlb+ntb+ntb+nbb+nfb,7) = 1;
Ninf(1+nrb+nlb+ntb+ntb+nbb+nfb : nbn,7) = -1;


% total number of groups exist in the boundary
if floor(nbn/nnG) == nbn/nnG
    tG = floor(nbn/nnG);
else
    tG = floor(nbn/nnG) + 1;
end


% grouped nodes
Gn = zeros(tG,nnG);
random_indices = randperm(nbn, nbn);
for i=1:tG-1
    Gn(i,:) = random_indices((i-1)*nnG+1:i*nnG);
end
Gn(tG,1:size(random_indices((tG-1)*nnG+1:end),2)) = random_indices((tG-1)*nnG+1:end);
Gn
% Hi = Hi of each group after one another__________________________________
Hi = zeros(3*tG,3);

for i = 1:tG
    
    Hnode2 = zeros(3,3);
    
    for j=1:size(nonzeros(Gn(i,:)),1) % nonzeros gives a vertical vector
%         size(nonzeros(Gn(i,:)),1)
        Gn(i,:);
        % the node under consideration
        node = Gn(i,j); 
        
        % normal vector
        normV = [Ninf(node,5); Ninf(node,6); Ninf(node,7)];
        
        % position vector
        posv = [Ninf(node,1); Ninf(node,2); Ninf(node,3)];
        
        % to calculate pos*norm'*A of each groups node (note that diadic product is [a;b]*[c,d])
        Hnode = (posv*normV')*A(node,1);
        
        % // of the group
        Hnode2 = Hnode2 + Hnode;
    end
    Hig = defH*(Hnode2);
    
    Hi((i-1)*3+1:i*3,1:3) = Hig;
end


% To get the set of equations. [node number 1, related DOF, A1; ___________
%                               node number 2, related DOF, A2;
%                               ...                           ;
%                               0            , 0          , -H]

Equations = {};

for i =1:tG
    
    % the corrosponding Hi to the group
    Hinode = Hi((i-1)*3+1:3*i,:);
    
    % 9 possible equations (some of them might be 0=0)
    eq1 = [];
    eq2 = [];
    eq3 = [];
    eq4 = [];
    eq5 = [];
    eq6 = [];
    eq7 = [];
    eq8 = [];
    eq9 = [];
    
    % calculating the node, dof and constant that appears in the equation
    nniG = size(nonzeros(Gn(i,:)),1); %(number of nodes in the group)
    for j=1:nniG
        node = Gn(i,j);
%         eq1(end+1,:) = [node,1,A(node)*Ninf(node,5)];
%         eq2(end+1,:) = [node,1,A(node)*Ninf(node,5)];
%         eq3(end+1,:) = [node,1,A(node)*Ninf(node,5)];
%         eq4(end+1,:) = [node,2,A(node)*Ninf(node,6)];
%         eq5(end+1,:) = [node,2,A(node)*Ninf(node,6)];
%         eq6(end+1,:) = [node,2,A(node)*Ninf(node,6)];
%         eq7(end+1,:) = [node,3,A(node)*Ninf(node,7)];
%         eq8(end+1,:) = [node,3,A(node)*Ninf(node,7)];
%         eq9(end+1,:) = [node,3,A(node)*Ninf(node,7)];
        eq1(end+1,:) = [node,1,A(node)*Ninf(node,5)];
        eq2(end+1,:) = [node,1,A(node)*Ninf(node,6)];
        eq3(end+1,:) = [node,1,A(node)*Ninf(node,7)];
        eq4(end+1,:) = [node,2,A(node)*Ninf(node,5)];
        eq5(end+1,:) = [node,2,A(node)*Ninf(node,6)];
        eq6(end+1,:) = [node,2,A(node)*Ninf(node,7)];
        eq7(end+1,:) = [node,3,A(node)*Ninf(node,5)];
        eq8(end+1,:) = [node,3,A(node)*Ninf(node,6)];
        eq9(end+1,:) = [node,3,A(node)*Ninf(node,7)];
        
    end
    
    % the last term of each eqution which is a constant
    eq1(end+1,:) = [0,0,-Hinode(1,1)];
    eq2(end+1,:) = [0,0,-Hinode(1,2)];
    eq3(end+1,:) = [0,0,-Hinode(1,3)];
    eq4(end+1,:) = [0,0,-Hinode(2,1)];
    eq5(end+1,:) = [0,0,-Hinode(2,2)];
    eq6(end+1,:) = [0,0,-Hinode(2,3)];
    eq7(end+1,:) = [0,0,-Hinode(3,1)];
    eq8(end+1,:) = [0,0,-Hinode(3,2)];
    eq9(end+1,:) = [0,0,-Hinode(3,3)];

    % checking and deleting the 0=0 equations
    deleq1 = []; % the rows that needs to be deleted
    deleq2 = []; % the rows that needs to be deleted
    deleq3 = []; % the rows that needs to be deleted
    deleq4 = []; % the rows that needs to be deleted
    deleq5 = []; % the rows that needs to be deleted
    deleq6 = []; % the rows that needs to be deleted
    deleq7 = []; % the rows that needs to be deleted
    deleq8 = []; % the rows that needs to be deleted
    deleq9 = []; % the rows that needs to be deleted
    
    for j=1:nniG+1
        if eq1(j,end) == 0
            deleq1(end+1,1) = j;
        end
        if eq2(j,end) == 0
            deleq2(end+1,1) = j;
        end
        if eq3(j,end) == 0
            deleq3(end+1,1) = j;
        end
        if eq4(j,end) == 0
            deleq4(end+1,1) = j;
        end
        if eq5(j,end) == 0
            deleq5(end+1,1) = j;
        end
        if eq6(j,end) == 0
            deleq6(end+1,1) = j;
        end
        if eq7(j,end) == 0
            deleq7(end+1,1) = j;
        end
        if eq8(j,end) == 0
            deleq8(end+1,1) = j;
        end
        if eq9(j,end) == 0
            deleq9(end+1,1) = j;
        end
    end
    eq1;
    eq1(deleq1,:) = [];
    eq2(deleq2,:) = [];
    eq3(deleq3,:) = [];
    eq4(deleq4,:) = [];
    eq5(deleq5,:) = [];
    eq6(deleq6,:) = [];
    eq7(deleq7,:) = [];
    eq8(deleq8,:) = [];
    eq9(deleq9,:) = [];
    eq1;
    % adding the equation in the main set
    if ~isempty(eq1)
        Equations{end+1} = eq1;
    end
    if ~isempty(eq2)
        Equations{end+1} = eq2;
    end
    if ~isempty(eq3)
        Equations{end+1} = eq3;
    end
    if ~isempty(eq4)
        Equations{end+1} = eq4;
    end
    if ~isempty(eq5)
        Equations{end+1} = eq5;
    end
    if ~isempty(eq6)
        Equations{end+1} = eq6;
    end
    if ~isempty(eq7)
        Equations{end+1} = eq7;
    end
    if ~isempty(eq8)
        Equations{end+1} = eq8;
    end
    if ~isempty(eq9)
        Equations{end+1} = eq9;
    end
end
    
%     
% end

