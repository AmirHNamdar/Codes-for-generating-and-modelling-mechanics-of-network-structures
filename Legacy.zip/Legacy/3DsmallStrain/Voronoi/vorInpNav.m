clear
% clc
% close all

% this creates an .inp file for abaqus based on voronoi netwokr creation



% inputs t ocreate the network _______________________________________
N = 10e6; % density of number of initial seeds
lambda = 0.04; % size of the study box
nnG = 1; % number of nodes in each group for BC
defH = [1/2 0 0;
        0 1/2 0;
        0 0 1/2]; % the appllied farfield BC
MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio
e = 100; % elastic modulus of beams
g = e/2/(1+Matnu);
inpName = 'TestBulk'; % name of the .inp file
CheckPlot = true; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = true; % to check the time of excution of each main function
radius = 1e-5;
outFolder = '/Users/Code/Abaqus/GeneratingInputFile/3D/Voronoi';

% generating network___________________________________________________________________________
if timeCheck == true
    tic
end
[nodes, edges, bndIdx, bndCounts] = generateVoronoi3D_prunedFirst2(N,lambda);
if timeCheck == true
    time_NetworkCreation = toc
end

G    = graph(edges(:,1), edges(:,2));
comp = conncomp(G); 
NumberofClusters = max(comp) % the number of clusters in the network (it should be one)

% compute differences for each edge
diffs = nodes(edges(:,1), :) - nodes(edges(:,2), :);

% Euclidean length of each edge
edgeLengths = sqrt( sum( diffs.^2, 2 ) );
aveL = mean(edgeLengths);
density = sum(edgeLengths)/lambda^3
Llc = lambda/mean(edgeLengths)
w = log10(density*(radius)^2)
polymerRatio = density*radius^2*pi

NE = size(edges,1) % number of edges
NN = size(nodes,1); % number of nodes
PN = nodes; % position of nodes
ED = edges; % position of edges
nrb = bndCounts(1,1); % number of right boundary node (x +)
nlb = bndCounts(1,2); % number of left boundary node (x -)
ntb = bndCounts(1,3); % number of top boundary node (y +)
nbb = bndCounts(1,4); % number of botttom boundary node (y -)
nfb = bndCounts(1,5); % number of front boundary node (z +)
nreb = bndCounts(1,6); % number of rear boundary node (z -)
nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes
nbn
if CheckPlot == true
plotVor(edges,nodes,bndCounts)
end

figure1 = figure;
histogram(edgeLengths)

% deleting the short fibres 
flt = aveL/100;
[NE,NN,PN,ED,nrb,nlb,ntb,nbb,nfb,nreb,nbn] = ModifyingNetworkLengthVor(NE,NN,PN,ED,nrb,nlb,ntb,nbb,nfb,nreb,nbn,edgeLengths,flt);
NE
nbn

if CheckPlot == true
plotVor2(NE,NN,PN,ED,nrb,nlb,ntb,nbb,nfb,nreb,nbn)
end



% calculating the equation needed for BC___________________________________________________________________________
if timeCheck == true
    tic
end
[equations,errorArea] = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nfb,nreb,nnG,defH);
if timeCheck == true
    time_Equation = toc
end

% I also need to save the data to use in the PP section
% save(inpName)
% 
% 

% writing the .inp file___________________________________________________________________________
if errorArea == false
    if timeCheck == true
        tic
    end
[ToPrint,prp] = writeFunction(PN,ED,inpName,radius,MatDen,Matnu,e,equations,nbn,lambda,CheckPlot,outFolder);
    if timeCheck == true
        time_write = toc
    end
disp(ToPrint);
end






