function [nodes, edges, bndIdx, bndCounts] = generateVoronoi3D_prunedFirst2(N, L)
%GENERATEVORONOI3D_PRUNEDFIRST  Build 3D Voronoi in [0,L]^3, prune to main component,
% then reorder so boundary nodes occupy the first rows.
%
% [nodes, edges, bndIdx, bndCounts] = generateVoronoi3D_prunedFirst(N, L)
%   nodes       — P×3 coords (boundary nodes first)
%   edges       — Q×2 node-index pairs
%   bndIdx      — indices of boundary nodes (1:length(boundary))
%   bndCounts   — 6×1 counts per face [x=L; x=0; y=L; y=0; z=L; z=0]

  %% 1) Scatter seeds, Delaunay + circumcenters
  N = floor((3*L)^3*N);
  margin = L;
  P = rand(N,3)*(L+2*margin) - margin;
  dt = delaunayTriangulation(P);
  V  = circumcenter(dt);
  nbr= dt.neighbors;

  %% 2) Build raw edge list
  T    = size(nbr,1);
  Eall = zeros(T*2,2);
  ec   = 0;
  for i=1:T
    for f=1:4
      j = nbr(i,f);
      if j>i
        ec=ec+1;
        Eall(ec,:)=[i j];
      end
    end
  end
  Eall = Eall(1:ec,:);

  %% 3) Clip edges to [0,L]^3 and collect nodes
  inside = all(V>=0 & V<=L,2);
  inIdx   = find(inside);
  nodes0  = V(inIdx,:);
  newIdx  = zeros(size(V,1),1);
  newIdx(inIdx) = 1:numel(inIdx);

  edges0 = zeros(ec,2);
  ec2    = 0;
  for k=1:ec
    i = Eall(k,1); j = Eall(k,2);
    v1 = V(i,:);  v2 = V(j,:);
    in1 = inside(i); in2 = inside(j);
    if in1 && in2
      ec2=ec2+1;
      edges0(ec2,:)=[newIdx(i), newIdx(j)];
    elseif xor(in1,in2)
      if in1, vi=v1; vo=v2; idx_in=newIdx(i);
      else    vi=v2; vo=v1; idx_in=newIdx(j);
      end
      d = vo-vi; tmin=Inf;
      % find intersection t
      if d(1)>0, t=(L-vi(1))/d(1); if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(1)<0, t=-vi(1)/d(1);    if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(2)>0, t=(L-vi(2))/d(2); if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(2)<0, t=-vi(2)/d(2);    if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(3)>0, t=(L-vi(3))/d(3); if t>0&&t<1&&t<tmin, tmin=t; end; end
      if d(3)<0, t=-vi(3)/d(3);    if t>0&&t<1&&t<tmin, tmin=t; end; end
      if isfinite(tmin)
        Pint = vi + tmin*d;
        nodes0(end+1,:) = Pint;
        ec2 = ec2+1;
        edges0(ec2,:)=[idx_in, size(nodes0,1)];
      end
    end
  end
  edges0 = edges0(1:ec2,:);

  %% 4) Prune to main connected component
  G    = graph(edges0(:,1), edges0(:,2));
  comp = conncomp(G);
  mainC = mode(comp);
  keepV = find(comp==mainC);

  % keep nodes and edges of main component
  nodes_pruned = nodes0(keepV,:);
  maskE = ismember(edges0(:,1),keepV) & ismember(edges0(:,2),keepV);
  e_sub = edges0(maskE,:);

  % map to new indices
  mapV = zeros(size(nodes0,1),1);
  mapV(keepV) = 1:numel(keepV);
  edges_pruned = [mapV(e_sub(:,1)), mapV(e_sub(:,2))];

  %% 5) Identify & count boundary nodes
  tol = 1e-8;
  X = nodes_pruned(:,1); Y = nodes_pruned(:,2); Z = nodes_pruned(:,3);
  faceMasks = { abs(X-L)<tol, abs(X)<tol, abs(Y-L)<tol, abs(Y)<tol, abs(Z-L)<tol, abs(Z)<tol };
  bndCounts = cellfun(@nnz, faceMasks);

  %% 6) Reorder so boundary nodes are first
  % indices of boundary nodes in pruned list:
  bndIdxList = [];
  for f = 1:6
    bndIdxList = [bndIdxList; find(faceMasks{f})];
  end
  % remove duplicates (corners)
  bndIdxList = unique(bndIdxList, 'stable');
  % interior nodes
  allIdx = (1:size(nodes_pruned,1))';
  intIdx = setdiff(allIdx, bndIdxList, 'stable');
  % new ordering
  newOrder = [bndIdxList; intIdx];

  % apply reorder
  nodes = nodes_pruned(newOrder,:);
  remap = zeros(size(nodes,1),1);
  remap(newOrder) = 1:numel(newOrder);
  edges = [remap(edges_pruned(:,1)), remap(edges_pruned(:,2))];

  % final boundary index vector
  bndIdx = (1:numel(bndIdxList))';
end
