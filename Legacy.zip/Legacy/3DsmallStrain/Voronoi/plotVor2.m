function plotVor2(NE,NN,PN,ED,nrb,nlb,ntb,nbb,nfb,nreb,nbn)


figure1 = figure;
for i =1:size(ED,1)
    n = ED(i,1);
    m = ED(i,2);
    plot3([PN(n,1) PN(m,1)],[PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)], 'LineWidth', 2,'color','k')
    hold on
end


axis equal tight
view(3)
xlabel('X'); ylabel('Y'); zlabel('Z')
title('3D Voronoi Network – Hollow Colored Boundary Nodes')



end