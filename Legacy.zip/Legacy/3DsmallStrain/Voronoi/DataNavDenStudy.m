clear
clc
close all


% this script creates a series inp file to do a study of effect of density of
% Voronoi netowrks.

% The simulation happens to get bulk and shear modulus and then poisson
% ratio is extracted. We will have different densities and radiuses (as
% defined below).



% The necessary input___________________________________________________________________________
% Specific input for generating the network
N2 = [0.1,0.5,1,5,10,20,50]*1e6;
lambda2 = [0.31,0.25,0.15,0.09,0.07,0.052,0.042]; % side length of the box (Llc will be around 35)
% lambda2 = [2,3,4,5];
% lambda2 = [6,7];
nnG2 = 4; % number of nodes in each group for BC matter
NO2 = [12,12,12,12,12,12,12]; % number of observation
% NO2 = [48,36,24,12];
% NO2 = [12,12];
radius2 = [1e-4,1e-5];
outFolder = '/home/m60315an/abaqus/Abaqus/GeneratingInputFile/3D/Voronoi/denStudy'; % direction of where i want to write my .inp file

% The General input___________________________________________________________________________

MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio
e = 100; % elastic modulus of beams
g = e/2/(1+Matnu);
CheckPlot = false; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = false; % to check the time of excution of each main function


% THE LOOP___________________________________________________________________________

% I will have two loops (the first one for the N and the other for the radius)



nS = size(N2,2);
tic
for i = 1:nS
    lambda = lambda2(1,i);
    N = N2(1,i);
%     N = (lambda+2).^3.*density; % number of fibres data [initial nf, final nf, number of increase in each step]
%     x = [0 lambda]; % boundary of x direction
%     y = [0 lambda]; % boundary of y direction
%     z = [0 lambda];
%     
    defHShear = [0 1/1000 0;
            0 0 0;
            0 0 0]; % the appllied farfield BC
        
    defHBulk = [1/1000 0 0;
            0 1/1000 0;
            0 0 1/1000]; % the appllied farfield BC

    % number of observation for each case depending on the size
    NO = NO2(1,i);
    
    for j=1:NO
% for j=1:NO
        % create the netwrok
        [nodes, edges, bndIdx, bndCounts] = generateVoronoi3D_prunedFirst2(N,lambda);
        
            NE = size(edges,1); % number of edges
            NN = size(nodes,1); % number of nodes 
            PN = nodes; % position of nodes
            ED = edges; % position of edges
            nrb = bndCounts(1,1); % number of right boundary node (x +)
            nlb = bndCounts(1,2); % number of left boundary node (x -)
            ntb = bndCounts(1,3); % number of top boundary node (y +)
            nbb = bndCounts(1,4); % number of botttom boundary node (y -)
            nfb = bndCounts(1,5); % number of front boundary node (z +)
            nreb = bndCounts(1,6); % number of rear boundary node (z -)
            nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes

            % write various .inp file for different nnGs and BC.
            % in the nase it should be clear which shear/bulk are for the same
            % network and nnG so that the poisson ratio can be investigated.

            for k =1:2 
                if k == 1
                    defH = defHShear;
                else
                    defH = defHBulk;
                end

                nradi = size(radius2,2);
                
                for l = 1:nradi
                    radius = radius2(1,l);
                    nnG = nnG2;

                    % inpName should be specified here
                    inpName = strcat('Den-','N',num2str(N),'radius',num2str(radius),'lambda',num2str(lambda),'DefKind',num2str(k),'nnG',num2str(nnG),'Observ',num2str(j));
                    i
                    j
                    filename = fullfile(outFolder, [inpName, '.mat']);
                    % compute differences for each edge
                    diffs = nodes(edges(:,1), :) - nodes(edges(:,2), :);

                    edgeLengths = sqrt( sum( diffs.^2, 2 ) );
                    aveL = mean(edgeLengths);
                    density = sum(edgeLengths)/lambda^3;
                    Llc = lambda/mean(edgeLengths);
                    w = log10(density*(radius)^2/4);
                    polymerRatio = density*radius^2*pi;
                    
                    
                    
                    save(filename, ...
                          'edgeLengths', ...
                          'aveL', ...
                          'density', ...
                          'Llc', ...
                          'w', ...
                          'polymerRatio')


                end
            end
    end
end


timeAll = toc














