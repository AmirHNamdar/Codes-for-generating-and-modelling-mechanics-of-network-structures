function [nodes, edges, bndIdx, bndCounts] = generateVoronoi3D_withBoundary3(P, L)
%GENERATEVORONOI3D_WITHBOUNDARY  
%   [nodes, edges, bndIdx, bndCounts] = generateVoronoi3D_withBoundary(N,L)
%   returns:
%     nodes     — M×3 Voronoi‐vertex coords (boundary nodes first)
%     edges     — K×2 node‐index pairs
%     bndIdx    — indices of those boundary nodes (in the 6‐face order)
%     bndCounts — 6×1 vector: counts of nodes on each face
%
%   Face order for bndIdx & bndCounts:
%     1. x = L  
%     2. x = 0  
%     3. y = L  
%     4. y = 0  
%     5. z = L  
%     6. z = 0  
%   N = (3*L)^3*N;
%   % 1) scatter seeds in [–L, 2L]^3
%   margin = L;
%   P = rand(N,3)*(L+2*margin) - margin;

  % 2) Delaunay + circumcenters
  dt  = delaunayTriangulation(P);
  V   = circumcenter(dt);       % T-by-3
  nbr = dt.neighbors;           % T-by-4

  % 3) build raw edge list (one per shared face)
  T = size(nbr,1);
  Eall = zeros(T*2,2); cnt=0;
  for i=1:T
    for f=1:4
      j = nbr(i,f);
      if j>i
        cnt=cnt+1;
        Eall(cnt,:) = [i j];
      end
    end
  end
  Eall = Eall(1:cnt,:);

  % 4) mark which circumcenters lie inside [0,L]^3
  inside = all(V>=0 & V<=L, 2);

  % 5) collect interior nodes first
  inIdx = find(inside);
  nodes = V(inIdx,:);
  newIdx = zeros(size(V,1),1);
  newIdx(inIdx) = 1:numel(inIdx);

  % 6) clip interior–outside edges, append boundary nodes
  edges = zeros(cnt,2); ec=0;
  for k=1:cnt
    i = Eall(k,1); j = Eall(k,2);
    v1 = V(i,:);  v2 = V(j,:);
    in1 = inside(i); in2 = inside(j);

    if in1 && in2
      % interior–interior
      ec=ec+1;
      edges(ec,:) = [ newIdx(i), newIdx(j) ];

    elseif xor(in1,in2)
      % interior–outside → find intersection face & point
      if in1, vi=v1; vo=v2; idx_in=newIdx(i);
      else    vi=v2; vo=v1; idx_in=newIdx(j);
      end
      d = vo - vi;
      tmin = Inf; faceHit = 0;
      % check each face in the fixed order:
      % 1: x= L, 2: x=0, 3: y= L, 4: y=0, 5: z= L, 6: z=0
      if d(1)>0, t = (L-vi(1))/d(1); if 0<t && t<1 && t<tmin, tmin=t; faceHit=1; end; end
      if d(1)<0, t = -vi(1)/d(1);    if 0<t && t<1 && t<tmin, tmin=t; faceHit=2; end; end
      if d(2)>0, t = (L-vi(2))/d(2); if 0<t && t<1 && t<tmin, tmin=t; faceHit=3; end; end
      if d(2)<0, t = -vi(2)/d(2);    if 0<t && t<1 && t<tmin, tmin=t; faceHit=4; end; end
      if d(3)>0, t = (L-vi(3))/d(3); if 0<t && t<1 && t<tmin, tmin=t; faceHit=5; end; end
      if d(3)<0, t = -vi(3)/d(3);    if 0<t && t<1 && t<tmin, tmin=t; faceHit=6; end; end

      if faceHit>0
        % record intersection
        Pint = vi + tmin*d;
        nodes(end+1,:) = Pint;
        ec=ec+1;
        edges(ec,:) = [ idx_in, size(nodes,1) ];

        % increment our face‐counter on the fly
        % (we'll tally any “pure” boundary nodes below)
        if ~exist('bndCounts','var')
          bndCounts = zeros(6,1);
        end
        bndCounts(faceHit) = bndCounts(faceHit) + 1;
      end
    end
    % both outside → ignore
  end
  edges = edges(1:ec,:);

  % ensure bndCounts exists even if no interior‐outside edges hit
  if ~exist('bndCounts','var')
    bndCounts = zeros(6,1);
  end

  % 7) now catch any circumcenters that by chance lie exactly on a face
  tol = 1e-8;
  X=nodes(:,1); Y=nodes(:,2); Z=nodes(:,3);
  faceMasks = {
    abs(X-L)<tol,   % 1: x=L
    abs(X-0)<tol,   % 2: x=0
    abs(Y-L)<tol,   % 3: y=L
    abs(Y-0)<tol,   % 4: y=0
    abs(Z-L)<tol,   % 5: z=L
    abs(Z-0)<tol    % 6: z=0
  };
  for f=1:6
    % subtract any already‐counted intersection nodes
    % (we tagged those when constructing bndCounts above)
    totalOnFace = nnz(faceMasks{f});
    bndCounts(f) = max(bndCounts(f), totalOnFace);
  end

  % 8) identify & order boundary node indices
  used = false(size(nodes,1),1);
  bndIdx = zeros(sum(bndCounts),1);
  ptr = 1;
  for f = 1:6
    idx = find(faceMasks{f} & ~used);
    used(idx) = true;
    n = numel(idx);
    bndIdx(ptr:ptr+n-1) = idx;
    ptr = ptr + n;
  end
  % append any strays (corners) that slipped through
  stray = find(~used & any(cat(2,faceMasks{:}),2));
  bndIdx(ptr:ptr+numel(stray)-1) = stray;
  used(stray) = true;

  % 9) append interior nodes, reorder everything
  intIdx = find(~used);
  newOrder = [bndIdx; intIdx];
  nodes = nodes(newOrder,:);
  map   = zeros(size(nodes,1),1);
  map(newOrder) = (1:numel(newOrder))';
  edges = map(edges);

end
