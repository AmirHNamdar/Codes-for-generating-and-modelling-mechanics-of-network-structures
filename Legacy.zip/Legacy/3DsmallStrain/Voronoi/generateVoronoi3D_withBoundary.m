function [nodes, edges] = generateVoronoi3D_withBoundary(N, L)
%GENERATEVORONOIID_WITHBOUNDARY  3D Voronoi network clipped in [0,L]^3,
%   retaining edges from interior cells to the box boundary.

  % 1) scatter seeds in [–L, 2L]^3 to close all cells on [0,L]^3
  margin = L;
  P = rand(N,3)*(L+2*margin) - margin;

  % 2) Delaunay triangulation + circumcenters
  dt = delaunayTriangulation(P);
  V  = circumcenter(dt);     % T-by-3
  nbr = dt.neighbors;        % T-by-4 neighbor‐tetra indices

  % 3) build all unique Voronoi edges (one per shared face)
  T = size(nbr,1);
  Eall = zeros(T*2,2);  % ~2 edges per tet
  cnt = 0;
  for i = 1:T
    for f = 1:4
      j = nbr(i,f);
      if j>i
        cnt=cnt+1;
        Eall(cnt,:) = [i j];
      end
    end
  end
  Eall = Eall(1:cnt,:);

  % 4) mark which circumcenters lie inside the box
  inside = all(V>=0 & V<=L, 2);

  % 5) start building new node list = all interior Vs
  inIdx = find(inside);
  nodes = V(inIdx,:);
  % map old→new indices for interior
  newIdx = zeros(size(V,1),1);
  newIdx(inIdx) = 1:numel(inIdx);

  % 6) walk edges, keep interior–interior; clip interior–outside
  edges = zeros(cnt,2); ec=0;
  for k = 1:cnt
    i = Eall(k,1);  j = Eall(k,2);
    v1 = V(i,:);    v2 = V(j,:);
    in1 = inside(i); in2 = inside(j);

    if in1 && in2
      % purely interior edge
      ec=ec+1;
      edges(ec,:) = [ newIdx(i), newIdx(j) ];

    elseif xor(in1,in2)
      % crosses the boundary: find intersection point
      if in1, vi=v1; vo=v2; idx_in = newIdx(i);
      else    vi=v2; vo=v1; idx_in = newIdx(j);
      end
      d = vo - vi;
      tmin = Inf;
      % test each of 6 faces:
      % plane x=0  → t = -vi(1)/d(1)
      if d(1)<0
        t = -vi(1)/d(1);
        if t>0 && t<1 && t<tmin, tmin=t; end
      end
      % x=L
      if d(1)>0
        t = (L-vi(1))/d(1);
        if t>0 && t<1 && t<tmin, tmin=t; end
      end
      % y=0
      if d(2)<0
        t = -vi(2)/d(2);
        if t>0 && t<1 && t<tmin, tmin=t; end
      end
      % y=L
      if d(2)>0
        t = (L-vi(2))/d(2);
        if t>0 && t<1 && t<tmin, tmin=t; end
      end
      % z=0
      if d(3)<0
        t = -vi(3)/d(3);
        if t>0 && t<1 && t<tmin, tmin=t; end
      end
      % z=L
      if d(3)>0
        t = (L-vi(3))/d(3);
        if t>0 && t<1 && t<tmin, tmin=t; end
      end

      % if we found a valid intersection, add it
      if isfinite(tmin)
        Pint = vi + tmin*d;
        nodes(end+1,:) = Pint;      % new boundary node
        ec = ec+1;
        edges(ec,:) = [ idx_in, size(nodes,1) ];
      end
    end
    % else both outside → ignore
  end

  % trim unused prealloc rows
  edges = edges(1:ec,:);

end
