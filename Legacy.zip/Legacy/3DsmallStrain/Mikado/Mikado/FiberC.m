function [Fiber,xc,yc,zc,nf,PBN] = FiberC(x,y,z,L,N,lambda)




xc = [x(1)-L , x(2)+L]; % x to create the network
yc = [y(1)-L , y(2)+L];
zc = [z(1)-L , z(2)+L];

nobf = 0; % number of out of the box fiber
PBN = []; % data for on the boundary nodes | x-intersection | y-intersection | which bondary? | Which fiber? | z-intersection

for i=1:N
    % data of a fibre
    xm=min(xc)+(max(xc)-min(xc))*rand(1); % x middle
    ym=min(yc)+(max(yc)-min(yc))*rand(1); % y middle
    zm = min(zc)+(max(zc)-min(zc))*rand(1);
%     theta=pi*rand(1); % angle from the z axis
u     = 2*rand(1)-1;     % uniform in [-1,1]
theta = acos(u);         % polar angle from z-axis, sin-weighted

    phi = 2*pi*rand(1); % angle in xy plane
    x1o = xm + L/2*(sin(theta)*cos(phi));
    y1o = ym + L/2*(sin(theta)*sin(phi));
    z1o = zm + L/2*(cos(theta));
    x2o = xm - L/2*(sin(theta)*cos(phi));
    y2o = ym - L/2*(sin(theta)*sin(phi));
    z2o = zm - L/2*(cos(theta));

    % finding Acode = address code - where is its centre?
    ssms = L; % small square mesh size
    xma = xm + ssms;
    yma = ym + ssms;
    zma = zm + ssms;
    Acode (1,1) = floor(xma/ssms)+1; % it starts from 1 to lambda/L+2
    Acode (1,2) = floor(yma/ssms)+1;
    Acode (1,3) = floor(zma/ssms)+1;
    
    % working with fibres that posibly has intersection with the boundary
    % or completely outside of the box.
    bp1 = 7; % boundary point 1 (one fibre only can have 2 boundary intersection)
    bp2 = 7;
%     if Acode(1,1) < 3 || Acode(1,1) > lambda/L || Acode (1,2) <3 || Acode(1,2) > lambda/L || Acode (1,3) <3 || Acode(1,3) > lambda/L
    if any([x1o,x2o] < x(1)) || any([x1o,x2o] > x(2)) ...
       || any([y1o,y2o] < y(1)) || any([y1o,y2o] > y(2)) ...
       || any([z1o,z2o] < z(1)) || any([z1o,z2o] > z(2))
   
        [nir,x1,x2,y1,y2,z1,z2,bp1,bp2,theta,phi] = portion(x1o,x2o,y1o,y2o,z1o,z2o,x,y,z,xm,ym,zm,theta,phi,lambda); 
    % nir==> if not in the range nir =0, otherwise = 1;
    % bp1: boundary position 1 (right 1, left 2, top 3, bottom 4, front 5, rear 6, no connectin 7)
    % bp2: boundary position 2 
    % o stands for old version 
        
%     tol = lambda*1e-8;
% 
% % Check bp1 against (x1,y1,z1)
% switch bp1
%   case 1  % right face x = x(2)
%     if abs(x1 - x(2)) > tol
%       warning('bp1=1 but x1=%g ≠ x(2)=%g', x1, x(2));
%     end
%   case 2  % left face x = x(1)
%     if abs(x1 - x(1)) > tol
%       warning('bp1=2 but x1=%g ≠ x(1)=%g', x1, x(1));
%     end
%   case 3  % top face y = y(2)
%     if abs(y1 - y(2)) > tol
%       warning('bp1=3 but y1=%g ≠ y(2)=%g', y1, y(2));
%     end
%   case 4  % bottom face y = y(1)
%     if abs(y1 - y(1)) > tol
%       warning('bp1=4 but y1=%g ≠ y(1)=%g', y1, y(1));
%     end
%   case 5  % front face z = z(2)
%     if abs(z1 - z(2)) > tol
%       warning('bp1=5 but z1=%g ≠ z(2)=%g', z1, z(2));
%     end
%   case 6  % rear face z = z(1)
%     if abs(z1 - z(1)) > tol
%       warning('bp1=6 but z1=%g ≠ z(1)=%g', z1, z(1));
%     end
%   case 7
%     % no boundary, nothing to check
%   otherwise
%     warning('Unexpected bp1 = %d', bp1);
% end
% 
% % Check bp2 against (x2,y2,z2)
% switch bp2
%   case 1  % right face x = x(2)
%     if abs(x2 - x(2)) > tol
%       warning('bp2=1 but x2=%g ≠ x(2)=%g', x2, x(2));
%     end
%   case 2  % left face x = x(1)
%     if abs(x2 - x(1)) > tol
%       warning('bp2=2 but x2=%g ≠ x(1)=%g', x2, x(1));
%     end
%   case 3  % top face y = y(2)
%     if abs(y2 - y(2)) > tol
%       warning('bp2=3 but y2=%g ≠ y(2)=%g', y2, y(2));
%     end
%   case 4  % bottom face y = y(1)
%     if abs(y2 - y(1)) > tol
%       warning('bp2=4 but y2=%g ≠ y(1)=%g', y2, y(1));
%     end
%   case 5  % front face z = z(2)
%     if abs(z2 - z(2)) > tol
%       warning('bp2=5 but z2=%g ≠ z(2)=%g', z2, z(2));
%     end
%   case 6  % rear face z = z(1)
%     if abs(z2 - z(1)) > tol
%       warning('bp2=6 but z2=%g ≠ z(1)=%g', z2, z(1));
%     end
%   case 7
%     % no boundary, nothing to check
%   otherwise
%     warning('Unexpected bp2 = %d', bp2);
% end

    
    

    if nir == 0 
        nobf = nobf+1;
        continue % goes to the next iteration
    end
    
    else % if no node is in the boundary
        x1 = x1o;
        x2 = x2o;
        y1 = y1o;
        y2 = y2o;
        z1 = z1o;
        z2 = z2o;
    end
    
    % the information of the boundary nodes
    if bp1 == 1 || bp1 == 2 || bp1 == 3 || bp1 == 4 || bp1 == 5 || bp1 == 6
        PBN(end+1,1) = x1;
        PBN(end,2) = y1;
        PBN(end,5) = z1;
        PBN(end,3) = bp1;
        PBN(end,4) = i-nobf;
    end
    if bp2 == 1 || bp2 == 2 || bp2 == 3 || bp2 == 4 || bp2 == 5 || bp2 == 6
        PBN(end+1,1) = x2;
        PBN(end,2) = y2;
        PBN(end,3) = bp2;
        PBN(end,4) = i-nobf;
        PBN(end,5) = z2;
    end
    
    
    % adding its information into fiber matrix
    Fiber(i-nobf,1)=x1;
    Fiber(i-nobf,2)=y1;
    Fiber(i-nobf,3)=x2;
    Fiber(i-nobf,4)=y2;
    Fiber(i-nobf,5)=theta;
    Fiber(i-nobf,6)=xm;
    Fiber(i-nobf,7)=ym;
    Fiber(i-nobf,8) = i-nobf;
    Fiber(i-nobf,9) = Acode(1,1);
    Fiber(i-nobf,10) = Acode(1,2);
    Fiber(i-nobf,11) = bp1;
    Fiber(i-nobf,12) = bp2;
    Fiber(i-nobf,13)=z1;
    Fiber(i-nobf,14)=z2;
    Fiber(i-nobf,15)=phi;
    Fiber(i-nobf,16)=Acode(1,3);
    Fiber(i-nobf,17)=zm;
    
end
    nf = size(Fiber,1);
    PBN(:,3);
    
end



    
    
    
    
    
    
    
    
    
    
    
    
    
    