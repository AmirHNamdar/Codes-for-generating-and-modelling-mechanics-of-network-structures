function plot3D(ED2,PI2,lambda,PBN2,TopTitle,Fiber,CoupleNodes)


if strcmp(TopTitle,'Plot after FiberC')
    PBN = PBN2;
    figure1 = figure;
for i=1:size(Fiber(:,1),1)
plot3([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],[Fiber(i,13) Fiber(i,14)], 'LineWidth', 2,'color','k')
hold on
end
xxx = linspace(0, lambda, 20); % Range for x
yyy = linspace(0, lambda, 20); % Range for y
zzz = linspace(0, lambda, 20); % Range for z
% Create grids for X and Y
[X, Y] = meshgrid(xxx, yyy); % Grid for X and Y
[~, Z] = meshgrid(xxx, zzz); % Grid for Z when x or y are fixed
% Plot surfaces
% Surface z = 0 (bottom face)
surf(X, Y, zeros(size(X)), 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface z = 2 (top face)
surf(X, Y, lambda * ones(size(X)), 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface x = 0 (left face)
surf(zeros(size(X)), X, Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface x = 2 (right face)
surf(lambda * ones(size(X)), X, Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface y = 0 (front face)
surf(X, zeros(size(X)), Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface y = 2 (back face)
surf(X, lambda * ones(size(X)), Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Set axis properties
plot3([0 lambda lambda 0 0 0 0 0 lambda lambda lambda lambda lambda 0 0 lambda],...
    [0 0 0 0 0 lambda lambda 0 0 lambda lambda 0 lambda lambda lambda lambda],...
    [0 0 lambda lambda 0 0 lambda lambda lambda lambda 0 0 0 0 lambda lambda], 'k-', 'LineWidth', 0.5); % Edge along x-axis
hold on
xlabel('X-axis');
ylabel('Y-axis');
zlabel('Z-axis');
title('Plot after FibreC');
axis equal; % Make axes equal for better visualization
grid on;
axis equal; % Enforce 1:1:1 ratio for all axes
view(3); % Set 3D view

plot3(PBN(:,1),PBN(:,2),PBN(:,5),'o','MarkerSize', 15, 'LineWidth', 3);

else
    
figure2 = figure;
for i =1:size(ED2,1)
    n = ED2(i,1);
    m = ED2(i,2);
    plot3([PI2(n,2) PI2(m,2)],[PI2(n,3) PI2(m,3)],[PI2(n,4) PI2(m,4)], 'LineWidth', 2,'color','k')
    hold on
end
xxx = linspace(0, lambda, 20); % Range for x
yyy = linspace(0, lambda, 20); % Range for y
zzz = linspace(0, lambda, 20); % Range for z
% Create grids for X and Y
[X, Y] = meshgrid(xxx, yyy); % Grid for X and Y
[~, Z] = meshgrid(xxx, zzz); % Grid for Z when x or y are fixed
% Plot surfaces
% Surface z = 0 (bottom face)
surf(X, Y, zeros(size(X)), 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface z = 2 (top face)
surf(X, Y, lambda * ones(size(X)), 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface x = 0 (left face)
surf(zeros(size(X)), X, Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface x = 2 (right face)
surf(lambda * ones(size(X)), X, Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface y = 0 (front face)
surf(X, zeros(size(X)), Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Surface y = 2 (back face)
surf(X, lambda * ones(size(X)), Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% Set axis properties
plot3([0 lambda lambda 0 0 0 0 0 lambda lambda lambda lambda lambda 0 0 lambda],...
    [0 0 0 0 0 lambda lambda 0 0 lambda lambda 0 lambda lambda lambda lambda],...
    [0 0 lambda lambda 0 0 lambda lambda lambda lambda 0 0 0 0 lambda lambda], 'k-', 'LineWidth', 0.5); % Edge along x-axis
hold on
xlabel('X-axis');
ylabel('Y-axis');
zlabel('Z-axis');
title(TopTitle);
axis equal; % Make axes equal for better visualization
grid on;
axis equal; % Enforce 1:1:1 ratio for all axes
view(3); % Set 3D view
% plot3(PBN2(:,1),PBN2(:,2),PBN2(:,5),'o','MarkerSize', 10, 'LineWidth', 3);
if isempty(CoupleNodes)
for i = size(PBN2,1)+1:size(PI2,1)
    if PI2(i,5) ~= 0
    plot3([PI2(i,2) PI2(PI2(i,5),2)],[PI2(i,3) PI2(PI2(i,5),3)],[PI2(i,4) PI2(PI2(i,5),4)],'LineWidth', 1,'color','r' )
    hold on
    end
end
else
for i =1:size(CoupleNodes,1)
    if CoupleNodes(i,2) ~= 0
fN = CoupleNodes(i,1);
sN = CoupleNodes(i,2);
size(PI2,1);
    plot3([PI2(fN,2) PI2(sN,2)],[PI2(fN,3) PI2(sN,3)],[PI2(fN,4) PI2(sN,4)],'LineWidth', 1,'color','r' )
    hold on
    end
end  
    
    
end

end










end