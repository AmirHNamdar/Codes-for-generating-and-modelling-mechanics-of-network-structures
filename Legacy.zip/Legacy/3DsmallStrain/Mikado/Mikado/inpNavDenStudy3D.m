clear
clc
close all


% this script creates a series inp file to do a study of effect of density of
% Mikado netowrks.

% the simulation is for shear modulus

% The necessary input___________________________________________________________________________
% Specific input for generating the network
L=1e-2; % Length of fibers
density2 = [0.9,1.15,1.45,1.85,3,5]*1e6;
lambda2 = [3,3,3,3,3,2].*L; % side length of the box (Llc will be around 35)
% lambda2 = [2,3,4,5];
% lambda2 = [6,7];
consCD = 8; % ContactDistance = radius*consCD; % the distance below which the contact occures

flt = 10^(-4)*L; % fibre lenght treshold. Edges smaller than flt will be deleted.

nnG2 = 8; % number of nodes in each group for BC matter
NO2 = [9,9,9,9,9,9,9]; % number of observation
% NO2 = [48,36,24,12];
% NO2 = [12,12];
radius2 = 1e-4; %___________%%%%%%%%% only one radius is allowed %%%%%%%%___________
ContactDistance = radius2*consCD; % the distance below which the contact occures
outFolder = '/home/m60315an/abaqus/Abaqus/GeneratingInputFile/3D/Mikado/denStudy';
% outFolder = '/Users/Code/Abaqus/GeneratingInputFile/3D/Mikado/denStudy';

% w = zeros(1,size(density2,2)*size(radius2,2));
% for i=1: size(radius2,2)
% w(1, (i-1)*size(density2,2)+1 : (i)*size(density2,2)) = log10((density2.*L.^2).^2*(radius2(1,i)./L./4).^2);
% end
% w
% 
% phiC_c = zeros(1,size(density2,2)*size(radius2,2));
% for i=1: size(radius2,2)
% phiC_c(1, (i-1)*size(density2,2)+1 : (i)*size(density2,2)) = 0.56.*(L./(radius2(1,i).*consCD)).^(-0.95);
% end
% 
% phiC = zeros(1,size(density2,2)*size(radius2,2));
% for i=1: size(radius2,2)
% phiC(1, (i-1)*size(density2,2)+1 : (i)*size(density2,2)) = density2.*(radius2(1,i).*consCD).^2.*pi/4;
% end
% 
% phiphi_c = phiC./phiC_c

% The General input___________________________________________________________________________

MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio
e = 100; % elastic modulus of beams
g = e/2/(1+Matnu);
CheckPlot = false; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = false; % to check the time of excution of each main function


% THE LOOP___________________________________________________________________________

% I will have two loops (the first one for the N and the other for the radius)





nS = size(density2,2);
tic
for i = 1:nS
    i
    lambda = lambda2(1,i);
    density = density2(1,i);
    N = (lambda+2*L).^3.*density/L; % number of fibres data [initial nf, final nf, number of increase in each step]
    x = [0 lambda]; % boundary of x direction
    y = [0 lambda]; % boundary of y direction
    z = [0 lambda];
%     
    defHShear = [0 1/1000 0;
            0 0 0;
            0 0 0]; % the appllied farfield BC
        
%     defHBulk = [1/1000 0 0;
%             0 1/1000 0;
%             0 0 1/1000]; % the appllied farfield BC

    % number of observation for each case depending on the size
    NO = NO2(1,i);
    
    parfor j=1:NO
% create the netwrok
        [SDataH,SDataV,Fiber,Per,SDatatest,CoupleNodes,DataRaw] = NetworkSemiRand(x,y,z,L,N,lambda,flt,density,ContactDistance,CheckPlot,timeCheck);
        
        if Per == false % if the network not percoalted 
            disp('not percolated network')
        else
            NE = SDataV(1,8); % number of edges
            NN = SDataV(1,9); % number of nodes 
            PN = SDataV(1:NN,1:5); % position of nodes
            ED = SDataV(1:NE,6:7); % position of edges
            nrb = SDataV(1,10); % number of right boundary node (x +)
            nlb = SDataV(2,10); % number of left boundary node (x -)
            ntb = SDataV(3,10); % number of top boundary node (y +)
            nbb = SDataV(4,10); % number of botttom boundary node (y -)
            nfb = SDataV(5,10); % number of front boundary node (z +)
            nreb = SDataV(6,10); % number of rear boundary node (z -)
            nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes



            for k =1:1
                if k == 1
                    defH = defHShear;
                else
                    defH = defHBulk;
                end

                nradi = size(radius2,2);
                
                for l = 1:nradi
                    radius = radius2(1,l);
                    nnG = nnG2;
                    

                    % inpName should be specified here
                    inpName = strcat('MC-','Den',num2str(density),'radius',num2str(radius),'lambda',num2str(lambda),'DefKind',num2str(k),'CD',num2str(ContactDistance),'Observ',num2str(j));
                    i
                    j

                    % calculating the equation needed for BC___________________________________________________________________________
                    if timeCheck == true
                        tic
                    end
                    [equations,errorArea] = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nfb,nreb,nnG,defH);
                    if timeCheck == true
                        time_Equation = toc
                    end
                    % I also need to save the data to use in the PP section
%                     save(inpName)

                    % writing the .inp file___________________________________________________________________________
                    if errorArea == false
                        if timeCheck == true
                            tic
                        end
                    [ToPrint,prp] = writeFunction(PN,ED,inpName,radius,MatDen,Matnu,e,equations,nbn,lambda,CoupleNodes,CheckPlot,outFolder);
                        if timeCheck == true
                            time_write = toc
                        end
                    end
                end
            end
        end    
    end
end


timeAll = toc







