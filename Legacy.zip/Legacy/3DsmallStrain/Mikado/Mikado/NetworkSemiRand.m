function [SDataH,SDataV,Fiber,Per,SDatatest,CoupleNodes,DataRaw] = NetworkSemiRand(x,y,z,L,N,lambda,flt,density,ContactDistance,CheckPlot,timeCheck)
% this function creates the network for Mikado case



% creating the Fiber netwok-----------------------------------------------------
if timeCheck == true
    tic
end
[Fiber,xc,yc,zc,nf,PBN] =  FiberC(x,y,z,L,N,lambda);
N = nf; % nf = number of fibres in the network (some fibres will be deleted )
if timeCheck == true
    time_FiberC = toc
end
% plotting the network
RAWnrb = size(nonzeros(PBN(:,3)==1));
RAWnlb = size(nonzeros(PBN(:,3)==2));
RAWntb = size(nonzeros(PBN(:,3)==3));
RAWnbb = size(nonzeros(PBN(:,3)==4));
RAWnfb = size(nonzeros(PBN(:,3)==5));
RAWnreb = size(nonzeros(PBN(:,3)==6));


if CheckPlot == true
    TopTitle = 'Plot after FiberC';
    plot3D([],[],lambda,PBN,TopTitle,Fiber,[])
end


% investigating the initial connection of the network-----------------------------------------------------

timeIntersection2 = 0;
if timeCheck == true
    tic
end
time_intersection_Check = false;
[Per,ip,pc,Fiber,timeIntersection2] = NetIntersecC_fast2(Fiber,x,y,PBN,nf,density,ContactDistance,timeIntersection2,flt,lambda,time_intersection_Check,L);
if timeCheck == true
    time_NetIntersecC = toc
end
if time_intersection_Check == true
    timeIntersection2
end
% tic
% [Per2,ip2,pc2,Fiber2,timeIntersection22] = NetIntersecC(Fiber,x,y,PBN,nf,density,ContactDistance,timeIntersection2,flt,lambda,time_intersection_Check,L);
% toc
% [Fiber(:,8),Fiber2(:,8)]

% %=== compare logical/scalar outputs ===
% assert( Per  == Per2,  'Mismatch in Per flag' );
% assert( pc   == pc2,   'Mismatch in percolating cluster ID' );
% 
% %=== compare arrays ===
% assert( isequal(Fiber, Fiber2), 'Mismatch in Fiber(:,8) labels');


    pc;
    size(find(Fiber(:,8)==pc));
    size(Fiber,1);



% Per represent the percolation 

if Per == false
    disp('Network is not percolated');
    SDataH = 0;
    SDataV = 0;
    Fiber = 0;
    SDatatest = 0;
else % if the system is percolated then do the rest of the code

% deleting the boundary nodes that are not connected to the main cluster

spb2 = size(PBN,1);
kkk =1;
while kkk <= spb2
    if Fiber(PBN(kkk,4),8) ~= pc
        PBN (kkk,:) = [];
        kkk=kkk-1;
        spb2 = spb2-1;
    end
    kkk=kkk+1;
end

% deleting the fibers that are not in the main cluster (fibres are either in the same cluster or are freely moving in the space which should be deleted)  
if timeCheck == true
    Number_of_Initial_Fibres = size(Fiber,1)
end
k=1;
nfd = 1; % to count the number of fibers
ndf = []; % deleted fibers
while k <= nf
    if Fiber(k,8)~=pc
        Fiber(k,:) =[];
%         ip(k,:) = []; % deleting the intersection of these fibers
%         ip(:,2*k-1:2*k) = [];
        nf = nf-1;
        k=k-1;
        ndf(end+1) = nfd; % to correct the address of fibres in the PBN
    end
    k=k+1;
    nfd = nfd+1;
end

if timeCheck == true
    
    Number_of_deleted_Fibres = size(ndf,2)
end
% correcting the address of PBN (since some fibres are deleted)
PBN(:,6) = 0;
if ~isempty(ndf)
    for i=1:size(ndf,2)
        for j=1:size(PBN,1)
            if PBN(j,4)>ndf(1,i)
                PBN(j,6) = PBN(j,6)+1;
            end
        end
    end
end
PBN(:,4) = PBN(:,4)-PBN(:,6);
N = nf;
% stuffT = toc
% finding the ip for the new network
PBN2 = sortrows(PBN,3);
% if CheckPlot == true
%     TopTitle = 'Plot after FiberC';
%     plot3D([],[],lambda,PBN,TopTitle,Fiber,[])
% end

% investigating the connection of the network-----------------------------------------------------
if timeCheck == true
    tic
end
[ip,Fiber,PI2,ED2,nrb,nlb,ntb,nbb,nfb,nreb] = NetIntersec(Fiber,x,y,PBN2,nf,density,ContactDistance,flt,lambda,L);
if timeCheck == true
    time_NetIntersec = toc
end




if CheckPlot == true
    TopTitle = 'Plot after NetIntersec';
    plot3D(ED2,PI2,lambda,PBN2,TopTitle,Fiber,[])
end

if timeCheck == true
    tic
end

%__________________________________________________________________________
    
    NE = size(ED2,1);
    NN = size(PI2,1);
    nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes
    Lf=zeros(NE,1);
for i=1:NE
    e1=ED2(i,1); % first end
    e2=ED2(i,2); % second end
    xe1 = PI2(e1,2);
    ye1 = PI2(e1,3);
    ze1 = PI2(e1,4);
    xe2 = PI2(e2,2);
    ye2 = PI2(e2,3);
    ze2 = PI2(e2,4);
    
    Lf(i,1) = sqrt((xe1 - xe2)^2 + (ye1 - ye2)^2 + (ze1 - ze2)^2);
end 
Lf;
azdE_temp = Lf < 1e-13;
azdE = find(azdE_temp == 1); % address of zeros distance edges
n0E = size(azdE,1); % number of zeros distance nodes
for i=1:n0E
    wE = azdE(i,1); % wihch edge?
    wn1 = ED2(wE,1); % wich node?
    wn2 = ED2(wE,2);
    if wn1<nbn || wn2<nbn
        wn1
        wn2
        disp('Look at NetworkSemiRand 172');
    end
end
DataRaw = zeros(max(size(ED2,1),size(PI2,1)),10);
DataRaw(1:size(PI2,1),1:5) = PI2;
DataRaw(1:size(ED2,1),6:7) = ED2;
DataRaw(1,8) = NE;
DataRaw(1,9) = NN;
DataRaw(1,10) = nrb; % in + x direction
DataRaw(2,10) = nlb; % in - x direction
DataRaw(3,10) = ntb; % in + y direction
DataRaw(4,10) = nbb; % in - y direction
DataRaw(5,10) = nfb; % in + z direction
DataRaw(6,10) = nreb; % in - z direction


%____________________________________________________________________________


[PBN2,ED2,PI2] = ModifyingConnection(PBN2,ED2,PI2);
if timeCheck == true
    time_ModifyingConnection = toc
end



if CheckPlot == true
    TopTitle = 'Plot after ModifyingConnection';
    plot3D(ED2,PI2,lambda,PBN2,TopTitle,Fiber,[])
end

NE = size(ED2,1);
NN = size(PI2,1);


% Creating the SData Matrix that contains all the necessary information
SDataV = zeros(max(size(ED2,1),size(PI2,1)),10);
SDataV(1:size(PI2,1),1:5) = PI2;
SDataV(1:size(ED2,1),6:7) = ED2;
SDataV(1,8) = NE;
SDataV(1,9) = NN;
SDataV(1,10) = nrb; % in + x direction
SDataV(2,10) = nlb; % in - x direction
SDataV(3,10) = ntb; % in + y direction
SDataV(4,10) = nbb; % in - y direction
SDataV(5,10) = nfb; % in + z direction
SDataV(6,10) = nreb; % in - z direction


% checking if any edge is shorter than flt - if so must be deleted
    
    Lf=zeros(NE,1);
for i=1:NE
    e1=ED2(i,1); % first end
    e2=ED2(i,2); % second end
    xe1 = PI2(e1,2);
    ye1 = PI2(e1,3);
    ze1 = PI2(e1,4);
    xe2 = PI2(e2,2);
    ye2 = PI2(e2,3);
    ze2 = PI2(e2,4);
    
    Lf(i,1) = sqrt((xe1 - xe2)^2 + (ye1 - ye2)^2 + (ze1 - ze2)^2);
end 
Lf;
NE;
    shortF = Lf < flt; % is it a short fibre? (1 = yes, 0 = no)
nsF = sum(shortF(:) == 1); % number of short fibres
    
if timeCheck == true
    tic
end


for kk =1:NN
    if sum(ED2(:,1)==kk) == 0
        if sum(ED2(:,2)==kk) == 0 
            kk
            disp('Look at NetworkSemiRand 249');
        end
    end
end

SDataV2 = SDataV;
SDatatest = 0;
CoupleNodes = [];
    SDatatest = SDataV;
    [SData,CoupleNodes] = ModifyingNetworkLength(SDataV,flt,Lf,shortF,lambda,PBN2,CheckPlot,CoupleNodes,L);
    SDataV = SData;
NE = SData(1,8); % number of edges
NN = SData(1,9); % number of nodes 


if timeCheck == true
    time_ModifyingNetworkLength = toc
end
% tic
% [SData,CoupleNodes] = ModifyingNetworkLength_fast2(SDataV2,flt,Lf,shortF,lambda,PBN2,CheckPlot,CoupleNodes,L);
% toc
% NE2 = SData2(1,8) % number of edges
% NN2 = SData2(1,9) % number of nodes 
% [CoupleNodes(end-10:end,:), CoupleNodes2(end-10:end,:)]
% assert( isequal(CoupleNodes, CoupleNodes2), 'Mismatch in CoupleNodes');
% assert( isequal(SData, SData2), 'Mismatch in SData');


NE = SDataV(1,8); % number of edges
NN = SDataV(1,9); % number of nodes 
PI2 = SDataV(1:NN,1:5); % position of nodes
ED2 = SDataV(1:NE,6:7); % position of nodes
nrb = SDataV(1,10); % number of boundary nodes on right side
nlb = SDataV(2,10); % number of boundary nodes on left side
ntb = SDataV(3,10); % number of boundary nodes on top side
nbb = SDataV(4,10); % number of boundary nodes on bottom side
nfb = SDataV(5,10); % number of front boundary node
nreb = SDataV(6,10); % number of rear boundary node
nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes

kkk = [];
for kk =1:NN
    if sum(ED2(:,1)==kk) == 0
        if sum(ED2(:,2)==kk) == 0 
            kk
            disp('Look at NetworkSemiRand 294');
            kkk(end+1,1) = kk;
        end
    end
end
% for ff =1:size(kkk,1)
%         kkk(ff,1)
%     if sum(PI2(:,5)==kkk(ff,1)) == 0
%         kkk(ff,1)
%     end
% end


Lf=zeros(NE,1);
for i=1:NE
    e1=ED2(i,1); % first end
    e2=ED2(i,2); % second end
    xe1 = PI2(e1,2);
    ye1 = PI2(e1,3);
    ze1 = PI2(e1,4);
    xe2 = PI2(e2,2);
    ye2 = PI2(e2,3);
    ze2 = PI2(e2,4);
    
    Lf(i,1) = sqrt((xe1 - xe2)^2 + (ye1 - ye2)^2 + (ze1 - ze2)^2);
end 
Lf;
% mean(Lf)
% histogram(Lf,'Normalization', 'pdf')
    shortF = Lf < flt; % is it a short fibre? (1 = yes, 0 = no)
nsF = sum(shortF(:) == 1); % number of short fibres
    
NE;




if CheckPlot == true
    TopTitle = 'Plot after ModifyingNetworkLength';
    plot3D(ED2,PI2,lambda,PBN2,TopTitle,Fiber,CoupleNodes)
end



SDataH = 0;
end
end
