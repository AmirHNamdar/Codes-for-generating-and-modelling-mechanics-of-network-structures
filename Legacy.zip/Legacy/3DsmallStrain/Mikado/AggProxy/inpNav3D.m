clear
clc
close all
% in this code we generate the .inp file needed by abaqus in matlab for 3D
% small deformation case. All beams are in circular shape.
% this is for a simple mikado network.
% for this code we create a network in a volume with side length of L+2 and
% then cut the portion of fibres that are outside of the box with side length of L.
% format short


% The necessary input ___________________________________________________________________________
% input for generating the network
radius = 1e-4; % the radius of a single fibre
density = 1e6; % line density

% radius = 1e-3; % the radius of a single fibre
% density = 300; % line density


L = 1e-2; % Length of fibers
lambda = L*2; % side length of the box
N = floor((lambda+2*L)^3*density/L); % number of fibres data [initial nf, final nf, number of increase in each step]
x = [0 lambda]; % boundary of x direction
y = [0 lambda]; % boundary of y direction
z = [0 lambda];
ContactDistance = radius*8; %L/5; % the distance below which the contact occures


ragg = L/4;
Pagg = 0.8;



phiC_c = 0.56*(L/ContactDistance)^(-0.95) % percolation threshold colume fraction
phiC = density*ContactDistance^2*pi/4 % volume fraction where the radius is the connection distance
phiphi_c = phiC/phiC_c
w = log10((density*L^2)^2*(radius/L/4)^2)


flt = 10^(-4)*L; % fibre lenght treshold. Edges smaller than flt will be deleted.
nnG = 1; % number of nodes in each group for BC matter
defH = [0 1/1000 0;
        0 0 0;
        0 0 0]; % the appllied farfield BC
MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio
e = 100; % elastic modulus of beams
g = e/2/(1+Matnu);
inpName = '3DAgg'; % name of the .inp file
CheckPlot = false; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = true; % to check the time of excution of each main function
outFolder = '/Users/Code/Abaqus/GeneratingInputFile/3D/Mikado/Lsmall/AggProxy';


% generating network___________________________________________________________________________
 [SDataH,SDataV,Fiber,Per,SDatatest,CoupleNodes,DataRaw] = NetworkSemiRand(x,y,z,L,N,lambda,flt,density,ContactDistance,CheckPlot,timeCheck,ragg,Pagg);
if Per == false % if the network not percoalted 
    disp('not percolated network')
else
NE = SDataV(1,8); % number of edges
NN = SDataV(1,9); % number of nodes
PN = SDataV(1:NN,1:5); % position of nodes
ED = SDataV(1:NE,6:7); % position of edges
nrb = SDataV(1,10); % number of right boundary node (x +)
nlb = SDataV(2,10); % number of left boundary node (x -)
ntb = SDataV(3,10); % number of top boundary node (y +)
nbb = SDataV(4,10); % number of botttom boundary node (y -)
nfb = SDataV(5,10); % number of front boundary node (z +)
nreb = SDataV(6,10); % number of rear boundary node (z -)
nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes
naf = SDataV(1:NE,11);

% NE = 3;
% NN = 6;
% PN = [1 1.5 2 0 0; 2 0.5 0 0 0;  3 1 1 0 4; 4 1 1 0 3; 5 0.75 1.5 0 6; 6 0.75 1.5 0 5];
% ED = [1 6; 5 4; 3 2];
% nrb = 0;
% nlb = 0;
% ntb = 1;
% nbb = 1;
% nfb = 0; % number of front boundary node (z +)
% nreb = 0; % number of rear boundary node (z -)
% nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes
    fn = ED(:,1);
    sn = ED(:,2);
    xf = PN(fn,2);
    yf = PN(fn,3);
    zf = PN(fn,4);
    xs = PN(sn,2);
    ys = PN(sn,3);
    zs = PN(sn,4);    
    edgeLengths = sqrt( (xf-xs).^2 + (yf-ys).^2 + (zf-zs).^2);


aveL = mean(edgeLengths)
densityL = sum(edgeLengths.*naf)/lambda^3;
ActualDenRatio = densityL/density
Llc = lambda/mean(edgeLengths)
w = log10((density*L^2)^2*(radius/L/4)^2)
wa = log10((densityL*L^2)^2*(radius/L/4)^2)
polymerRatio = densityL*radius^2*pi
lblc = radius/aveL



  fn = CoupleNodes(:,1);
    sn = CoupleNodes(:,2);
    xf = PN(fn,2);
    yf = PN(fn,3);
    zf = PN(fn,4);
    xs = PN(sn,2);
    ys = PN(sn,3);
    zs = PN(sn,4);
    LCN = sqrt( (xf-xs).^2 + (yf-ys).^2 + (zf-zs).^2);

    
    


% calculating the equation needed for BC___________________________________________________________________________
if timeCheck == true
    tic
end
[equations,errorArea] = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nfb,nreb,nnG,defH);
if timeCheck == true
    time_Equation = toc
end

% I also need to save the data to use in the PP section
% save(inpName)


% writing the .inp file___________________________________________________________________________
if errorArea == false
    if timeCheck == true
        tic
    end
[ToPrint,prp] = writeFunctionProxy(PN,ED,inpName,radius,MatDen,Matnu,e,equations,nbn,lambda,CoupleNodes,CheckPlot,outFolder,naf);
    if timeCheck == true
        time_write = toc
    end
disp(ToPrint);
end





end


% load 'Fiber2Data.mat'
