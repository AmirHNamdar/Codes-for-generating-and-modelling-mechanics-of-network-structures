clear
clc
close all

% name of the file that is required to be read
fileName = 'TestEnergy';

% NRP = Number of Reference Points (the data structure of them is different)
% if nnG = 1; % number of nodes in each group for BC matter
%     NRP = 0;
% else
%     NRP = 1;
% end
NRP = 0;


% U = nodal displacement 
% URP = displacement of the reference point
% NF = nodal force 
% NFRP = nodal force of the reference point
[U,URP,NF,NFRP] = datFileRead(fileName,NRP);

% we also need to have data of the original network which we get from a
% saved file

% load(fileName)
% load TestAll
% diam = diam * 2;


U = [2 0 0 0 0 0 0;
    3 0.5348 -0.2655 0.1335 -3.6941e-3 -7.6559e-3 1.080e-5;
    4 0.5348 -0.2655 0.1335 -3.6941e-3 -7.6559e-3 1.080e-5;
    5 0 0 0.2 0 0 0];


diam = 1e-4*2;
NN =4;
NE = 2;
ED = [1 2; 3 4];
PN = [1, 1.20000000,   0.50000000,   0.00000000, 0;...
2,   1.00000000,   0.60000000,   1.00000000, 3;...
3,   1.00000000,   0.64896124,   1.00000000, 2;...
	 4,   1.10000000,   0.60000000,   2.00000000, 0];
 e = 100;
 g = 33.33333;
 

% post process to gain energy in each segment.
Ed = EnergyF3D(PN,ED,U,e,g,NE,diam); % Ed = energy distribution (each fibre and each mode)





