function [fl_Vpos,V_exist] = fl_function(lambda,mid_first,mid_last,surf_norm_f,surf_norm_l,f_circum,l_circum,circumcenters,TrList)

% 5 if circumcentre is outside then consider something slightly furtheraway
% to be the new point and if it is inside, then the intersection with the
% boundary will be our new point.

% i have the norm. i knwo which boundaries might be intersected by them. i
% check each and consider the first intersection. if the 2 intersection
% area not in the same side the corner is also should be added as a node.
V_exist=[0,0,0]; % If the circumcenter is outside then we do not add any new node since it is not necessary
fl_Vpos = [0,0; 0,0 ; 0,0];
c_f = []; % connection first 
c_l = []; % connection last 

% if f_circum(1,1) > 0 && f_circum(1,1) < lambda && f_circum(1,2) > 0 && f_circum(1,2) < lambda
    
    if surf_norm_f(1,1) > 0 % it might intersect with x = lambda
       t_v = (lambda - mid_first(1,1))/surf_norm_f(1,1);
       c_f(1,1) = 1;
    else % x = 0
        t_v = (0 - mid_first(1,1))/surf_norm_f(1,1);
        c_f(1,1) = 2;
    end

    if surf_norm_f(1,2) > 0 % it might intersect with y = lambda
       t_h = (lambda - mid_first(1,2))/surf_norm_f(1,2);
       c_f(1,2) = 3;
    else % y = 0
      t_h = (0 - mid_first(1,2))/surf_norm_f(1,2);
       c_f(1,2) = 4;
    end
    
    if t_h < t_v
       c_f2 = c_f(1,2);
    else
     c_f2 = c_f(1,1);
    end
    tf = min(t_h,t_v); % the smaller means the closer one

    
    
    if f_circum(1,1) > 0 && f_circum(1,1) < lambda && f_circum(1,2) > 0 && f_circum(1,2) < lambda
        fl_Vpos(1,1:2) = [ mid_first(1,1) + surf_norm_f(1,1) * tf, ...
        mid_first(1,2) + surf_norm_f(1,2) * tf];
        V_exist(1,1) = 1;
%     else
%         switch c_f2
%             case 1
%                 fl_Vpos(1,1:2) = f_circum ;
%             case 2 
%                 fl_Vpos(1,1:2) = f_circum ;
%             case 3
%                 fl_Vpos(1,1:2) = f_circum ;
%             case 4
%                 fl_Vpos(1,1:2) = f_circum ;
%         end
    end





% if l_circum(1,1) > 0 && l_circum(1,1) < lambda && l_circum(1,2) > 0 && l_circum(1,2) < lambda
    if surf_norm_l(1,1) > 0 % it might intersect with x = lambda
        t_v2 = (lambda - mid_last(1,1))/surf_norm_l(1,1);
        c_l(1,1) = 1;
    else % x = 0
        t_v2 = (0 - mid_last(1,1))/surf_norm_l(1,1);
        c_l(1,1) = 2;
    end

    if surf_norm_l(1,2) > 0 % it might intersect with y = lambda
        t_h2 = (lambda - mid_last(1,2))/surf_norm_l(1,2);
        c_l(1,2) = 3;
    else % y = 0
      t_h2 = (0 - mid_last(1,2))/surf_norm_l(1,2);
      c_l(1,2) = 4;
    end
    
    if t_h2 < t_v2
        c_l2 = c_l(1,2);
    else
        c_l2 = c_l(1,1);
    end
    tf2 = min(t_h2,t_v2); % the smaller means the closer one

    if l_circum(1,1) > 0 && l_circum(1,1) < lambda && l_circum(1,2) > 0 && l_circum(1,2) < lambda
    fl_Vpos(2,1:2) = [ mid_last(1,1) + surf_norm_l(1,1) * tf2, ...
    mid_last(1,2) + surf_norm_l(1,2) * tf2];
    V_exist(1,2) = 1;
%     else
%         switch c_l2
%             case 1
%                 fl_Vpos(2,1:2) = l_circum + [1, 0];
%             case 2 
%                 fl_Vpos(2,1:2) = l_circum + [-1, 0];
%             case 3
%                 fl_Vpos(2,1:2) = l_circum + [0, 1];
%             case 4
%                 fl_Vpos(2,1:2) = l_circum + [0, -1];
%         end
    end





% if the 2 intersection belongs to different boundaries
if c_l2 ~= c_f2
    if any([c_l2,c_f2] == 1)
        if any([c_l2,c_f2] == 3)
            fl_Vpos(3,1:2) = [lambda + 1, lambda + 1];
            V_exist(1,3) = 1;
        elseif any([c_l2,c_f2] == 4)
            fl_Vpos(3,1:2) = [lambda + 1, 0 - 1];
            V_exist(1,3) = 1;
        end
    end
    if any([c_l2,c_f2] == 2)
        if any([c_l2,c_f2] == 3)
            fl_Vpos(3,1:2) = [0 - 1, lambda + 1];
            V_exist(1,3) = 1;
        elseif any([c_l2,c_f2] == 4)
            fl_Vpos(3,1:2) = [0 - 1, 0 - 1];
            V_exist(1,3) = 1;
        end
    end
    
end

% sometimes V_exist looks like this [1 0 1]. in this case the polygon might
% have intersection. the reason is taht actually in this condition there is
% a chance that the line of first tr to the next tr intersects the boundary
% at the same boundary as 1 one.

if TrList > 1
if V_exist(1,3) == 1
    if V_exist(1,1) == 0
        f_circum = circumcenters(TrList(1,1),:);
        s_circum = circumcenters(TrList(1,2),:);
        fs_norm = (f_circum - s_circum)/norm(f_circum - s_circum);

        if fs_norm(1,1) > 0 % it might intersect with x = lambda
            t_v = (lambda - s_circum(1,1))/fs_norm(1,1);
            c_f(1,1) = 1;
        else % x = 0
            t_v = (0 - s_circum(1,1))/fs_norm(1,1);
            c_f(1,1) = 2;
        end

        if fs_norm(1,2) > 0 % it might intersect with y = lambda
            t_h = (lambda - s_circum(1,2))/fs_norm(1,2);
            c_f(1,2) = 3;
        else % y = 0
            t_h = (0 - s_circum(1,2))/fs_norm(1,2);
            c_f(1,2) = 4;
        end
    
        if t_h < t_v
            c_f2 = c_f(1,2);
        else
            c_f2 = c_f(1,1);
        end
        
    end
    
    if V_exist(1,2) == 0
        f_circum = circumcenters(TrList(1,end),:);
        s_circum = circumcenters(TrList(1,end-1),:);
        fs_norm = (f_circum - s_circum)/norm(f_circum - s_circum);

        if fs_norm(1,1) > 0 % it might intersect with x = lambda
            t_v = (lambda - s_circum(1,1))/fs_norm(1,1);
            c_f(1,1) = 1;
        else % x = 0
            t_v = (0 - s_circum(1,1))/fs_norm(1,1);
            c_f(1,1) = 2;
        end

        if fs_norm(1,2) > 0 % it might intersect with y = lambda
            t_h = (lambda - s_circum(1,2))/fs_norm(1,2);
            c_f(1,2) = 3;
        else % y = 0
            t_h = (0 - s_circum(1,2))/fs_norm(1,2);
            c_f(1,2) = 4;
        end
    
        if t_h < t_v
            c_l2 = c_f(1,2);
        else
            c_l2 = c_f(1,1);
        end
        
    end
    
    if c_f2 == c_l2
        V_exist(1,3) = 0;
    end
    
    
end
end



end