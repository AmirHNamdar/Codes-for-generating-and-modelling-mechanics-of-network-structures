function [Fiber,xc,yc,zc,nf,PBN] = FiberC(x,y,z,L,N,lambda,ragg,Pagg)
% Create a 3D network of fibres with probabilistic aggregation.
% Aggregation is checked FIRST (with periodic neighbor search). If the fibre
% exists, we then trim via 'portion'. Fibres that "exist" but are later
% deleted by 'portion' still remain as environment representatives that can
% attract/aggregate later fibres.
%
% Inputs:
%   x,y,z   : [min max] box limits in each direction
%   L       : fibre length
%   N       : number of proposals
%   lambda  : your box-size parameter (passed to 'portion' as in your code)
%   ragg    : aggregation radius (periodic neighbor sphere)
%   Pagg    : aggregation "stickiness" parameter in (0,1)
%
% Outputs:
%   Fiber   : accepted representative fibres (one row per representative)
%             cols:
%               1-4:   x1 y1 x2 y2
%               5:     theta
%               6-7:   xm ym  (centre)
%               8:     representative index (row number)
%               9-10:  Acode x,y   (with ssms = L)
%               11-12: bp1, bp2 (boundary flags)
%               13-14: z1 z2
%               15:    phi
%               16:    Acode z
%               17:    zm  (centre z)
%               18:    AggCount (# of additional fibres aggregated here)
%   xc,yc,zc: extended sampling ranges (min-L, max+L)
%   nf      : number of representatives in Fiber
%   PBN     : boundary node info [x y whichBoundary whichFibre z]
%
% Requires: 'portion' function (unchanged).


    % ------------ Geometry / periodic lengths for aggregation ------------
    Lx = x(2) - x(1);
    Ly = y(2) - y(1);
    Lz = z(2) - z(1);

    % Extended sampling ranges so fibres can cross the box and be trimmed
    xc = [x(1)-L , x(2)+L];
    yc = [y(1)-L , y(2)+L];
    zc = [z(1)-L , z(2)+L];
    
    Lxt = xc(2) - xc(1);
    Lyt = yc(2) - yc(1);
    Lzt = zc(2) - zc(1);

    % ------------ Data structures ------------
    Fiber      = zeros(0,18);  % reps that survive trimming (columns defined above)
    PBN        = [];           % boundary nodes
    k          = 0;            % # of rows in Fiber (representatives)

    % Environment representatives for aggregation probability (periodic):
    % - includes both in-box reps (mapped to a Fiber row) and "ghost" reps
    %   that were deleted by portion (mapped to 0).
    envCenters = zeros(0,3);   % [xm, ym, zm]
    env2fiber  = zeros(0,1);   % map env index -> Fiber row index (0 if ghost)

    ssms = L;  % coarse address code cell size

    % ------------ Main loop ------------
    for i = 1:N
        % --- 1) Propose centre & orientation ---
        xm = min(xc) + (max(xc)-min(xc)) * rand(1);
        ym = min(yc) + (max(yc)-min(yc)) * rand(1);
        zm = min(zc) + (max(zc)-min(zc)) * rand(1);

%         theta = pi   * rand(1);   % from +z
        
        u     = 2*rand(1)-1;     % uniform in [-1,1]
        theta = acos(u);         % polar angle from z-axis, sin-weighted


        phi   = 2*pi * rand(1);   % azimuth
        dirx  = sin(theta)*cos(phi);
        diry  = sin(theta)*sin(phi);
        dirz  = cos(theta);

        % Endpoints (before trimming)
        x1o = xm + 0.5*L*dirx;   y1o = ym + 0.5*L*diry;   z1o = zm + 0.5*L*dirz;
        x2o = xm - 0.5*L*dirx;   y2o = ym - 0.5*L*diry;   z2o = zm - 0.5*L*dirz;

        % Coarse address (unchanged)
        xma = xm + ssms;  yma = ym + ssms;  zma = zm + ssms;
        Acode = [floor(xma/ssms)+1, floor(yma/ssms)+1, floor(zma/ssms)+1];

        % --- 2) Aggregation check FIRST (periodic min-image to env reps) ---
        Pexi = 1.0;
        aggTargetEnv = 0;

        if ~isempty(envCenters)
            del = [xm,ym,zm] - envCenters;  % raw deltas
            % minimum-image convention:
%             del(:,1) = del(:,1) - round(del(:,1)/Lx)*Lx;
%             del(:,2) = del(:,2) - round(del(:,2)/Ly)*Ly;
%             del(:,3) = del(:,3) - round(del(:,3)/Lz)*Lz;
            
            del(:,1) = del(:,1) - round(del(:,1)/Lxt)*Lxt;
            del(:,2) = del(:,2) - round(del(:,2)/Lyt)*Lyt;
            del(:,3) = del(:,3) - round(del(:,3)/Lzt)*Lzt;

            
            
            dist = sqrt(sum(del.^2,2));
            neighIdx = find(dist < ragg);
            nod2 = numel(neighIdx);

            if nod2 > 0
                Pexi = (1 - Pagg)^nod2;
                if rand() > Pexi
                    % Randomely chosing a fibre to aggregate to
                    idx = neighIdx( randi(numel(neighIdx)) );
                    aggTargetEnv = idx;
                end
            end
        end

        if aggTargetEnv > 0
            % ----- Aggregates: no new env rep, no trimming -----
            tgtFiberRow = env2fiber(aggTargetEnv);
            if tgtFiberRow > 0
                % aggregated onto an in-box representative
                Fiber(tgtFiberRow,18) = Fiber(tgtFiberRow,18) + 1;
            end
            % if aggregated to a ghost rep, nothing to record in Fiber
            continue
        end

        % ----- Exists as a representative: add to environment immediately -----
        envCenters(end+1,:) = [xm, ym, zm];
        env2fiber(end+1,1)  = 0;  % we don't know yet if it will make a Fiber row

        % --- 3) Trimming / boundary handling (non-periodic, as before) ---
        bp1 = 7; bp2 = 7;  % default: no boundary hit
        % Check if any endpoint is outside
        needsTrim = any([x1o,x2o] < x(1)) || any([x1o,x2o] > x(2)) || ...
                    any([y1o,y2o] < y(1)) || any([y1o,y2o] > y(2)) || ...
                    any([z1o,z2o] < z(1)) || any([z1o,z2o] > z(2));

        if needsTrim
            [nir,x1,x2,y1,y2,z1,z2,bp1,bp2,theta,phi] = ...
                portion(x1o,x2o,y1o,y2o,z1o,z2o,x,y,z,xm,ym,zm,theta,phi,lambda);

            if nir == 0
                % Deleted by portion -> remains a GHOST env rep (influences later fibres)
                % env2fiber(end) already 0, nothing else to do
                continue
            end
        else
            % fully inside
            x1 = x1o; y1 = y1o; z1 = z1o;
            x2 = x2o; y2 = y2o; z2 = z2o;
        end

        % --- 4) Survived trimming -> create a Fiber row (representative) ---
        k = k + 1;

        % Boundary nodes tied to this k
        if ismember(bp1,1:6)
            PBN(end+1,1) = x1;  PBN(end,2) = y1;  PBN(end,3)   = bp1;
            PBN(end,4) = k; PBN(end,5) = z1;
        end
        if ismember(bp2,1:6)
            PBN(end+1,1) = x2;  PBN(end,2) = y2;  PBN(end,3) = bp2;
            PBN(end,4)   = k;   PBN(end,5) = z2;
        end

        % Populate Fiber row (same columns as your original + AggCount)
        Fiber(k,1)  = x1;
        Fiber(k,2)  = y1;
        Fiber(k,3)  = x2;
        Fiber(k,4)  = y2;
        Fiber(k,5)  = theta;
        Fiber(k,6)  = xm;
        Fiber(k,7)  = ym;
        Fiber(k,8)  = k;             % representative index
        Fiber(k,9)  = Acode(1);
        Fiber(k,10) = Acode(2);
        Fiber(k,11) = bp1;
        Fiber(k,12) = bp2;
        Fiber(k,13) = z1;
        Fiber(k,14) = z2;
        Fiber(k,15) = phi;
        Fiber(k,16) = Acode(3);
        Fiber(k,17) = zm;
        Fiber(k,18) = 0;             % AggCount = followers (starts at 0) - will add 1 later

        % Link the just-added environment representative to this Fiber row
        env2fiber(end) = k;
    end
    Fiber(:,18) = Fiber(:,18) + 1; % number of fibres 
    nf = size(Fiber,1);
end
