function CL = fixingCL(CL,nfixn,i,zzz)

    zzz = zzz + 1;
    newNodeList = nonzeros(nfixn .* [1:size(nfixn,1)]');
    conn2 = CL(newNodeList,:);
    
    for l=1:size(conn2,1)
        conn = conn2(l,:);
    %         fixnodes = []; % nodes that needs to be fixed
    %         fixnodes(end+1,1) = conn(1,2);
            nfixn2 = CL(:,1) == conn(1,2); % number of fixed nodes
            if size(nonzeros(nfixn2),1) == 0
                CL(newNodeList(l,1),:) = flip(CL(newNodeList(l,1),:));
            else
                CL = fixingCL(CL,nfixn2,newNodeList(l,1),zzz);
                
            end
            
    end

    CL(i,:) = flip(CL(i,:));

end