function ec = intersection2_2new(Fiber,i,j,ContactDistance,~,lambda)
  % Extract endpoints
  A = [Fiber(i,1); Fiber(i,2); Fiber(i,13)];
  B = [Fiber(i,3); Fiber(i,4); Fiber(i,14)];
  C = [Fiber(j,1); Fiber(j,2); Fiber(j,13)];
  D = [Fiber(j,3); Fiber(j,4); Fiber(j,14)];

  % Direction vectors
  u = B - A;
  v = D - C;
  w = A - C;

  % Dot products
  a = dot(u,u);  b = dot(u,v);  c = dot(v,v);
  d = dot(u,w);  e = dot(v,w);

  % Solve for the unconstrained parameters
  denom = a*c - b^2;
  epsD  = lambda*1e-8;
  if denom > epsD
    s = ( b*e - c*d ) / denom;
    t = ( a*e - b*d ) / denom;
  else
    % nearly parallel: project A onto CD
    s = 0;
    t = e / c;
  end

  % Always clamp into [0,1]
  s_cl = max(0, min(1, s));
  t_cl = max(0, min(1, t));

  % Compute the four “endpoint‐to‐opposite‐segment” distances
  % plus the interior–interior distance
  P   = A + s_cl*u;
  Q   = C + t_cl*v;
  d1  = norm(P - Q);
  % A→CD
  tA  = max(0, min(1, dot(v, (A-C))/c));
  QA  = C + tA*v;
  d2  = norm(A - QA);
  % B→CD
  tB  = max(0, min(1, dot(v, (B-C))/c));
  QB  = C + tB*v;
  d3  = norm(B - QB);
  % C→AB
  sC  = max(0, min(1, dot(u, (C-A))/a));
  PC  = A + sC*u;
  d4  = norm(C - PC);
  % D→AB
  sD  = max(0, min(1, dot(u, (D-A))/a));
  PD  = A + sD*u;
  d5  = norm(D - PD);

  % True minimum
  minD = min([d1; d2; d3; d4; d5]);

  % Flag intersection if ≤ threshold
  ec = (minD < ContactDistance);
end
