function [SDataV2, CoupleNodes2] = ModifyingNetworkLength_fast(...
    SDataV, flt, ~, ~, lambda, PBN2, ~, CoupleNodes)

  %–– 1) unpack
  NE  = SDataV(1,8);
  NN  = SDataV(1,9);
  PN  = SDataV(1:NN,1:5);    % [id,x,y,z, partnered_id]
  ED  = SDataV(1:NE,6:7);    % [node1, node2]
  nFaces = sum(SDataV(:,10)>0);
  bCounts = SDataV(1:nFaces,10);
  nbn = sum(bCounts);

  %–– 2) find “short” edges
  coords = PN(:,2:4);
  Lf     = sqrt(sum( (coords(ED(:,1),:) - coords(ED(:,2),:)).^2 ,2));
  shortE = find(Lf < flt);
  if isempty(shortE)
    SDataV2      = SDataV;
    CoupleNodes2 = CoupleNodes;
    return
  end

  %–– 3) union–find on nodes connected by short edges
  parent = 1:NN;
  function r = findp(u)
    if parent(u)~=u
      parent(u) = findp(parent(u));
    end
    r = parent(u);
  end
  function unite(u,v)
    ru = findp(u); rv = findp(v);
    if ru~=rv
      % always attach non-boundary under boundary, else lower idx
      if ru<=nbn && rv>nbn, parent(rv)=ru;
      elseif rv<=nbn && ru>nbn, parent(ru)=rv;
      else parent(rv)=ru;
      end
    end
  end

  for e = shortE'
    a = ED(e,1); b = ED(e,2);
    unite(a,b);
  end

  %–– 4) build new node map
  reps = arrayfun(@findp, 1:NN).';
  % ensure boundary nodes remain their own rep
  reps(1:nbn) = 1:nbn;

  [uniqueReps, ~, newIdx] = unique(reps,'stable');

  %–– 5) compute new PN
  M = numel(uniqueReps);
  PN2 = zeros(M,5);
  PN2(:,1) = uniqueReps;    % old IDs
  % for each group, pick boundary if present else centroid
  for k=1:M
    members = find(reps==uniqueReps(k));
    isB = members<=nbn;
    if any(isB)
      % pick the first boundary node in that group
      sel = members(find(isB,1));
      PN2(k,2:4) = coords(sel,:);
    else
      PN2(k,2:4) = mean(coords(members,:),1);
    end
    % update partner pointer (will remap below)
    PN2(k,5) = PN(members(1),5);
  end

  %–– 6) rebuild edges
  ED2 = newIdx(ED);          % remap both cols in one go
  % drop self‐loops
  keep = ED2(:,1)~=ED2(:,2);
  ED2 = ED2(keep,:);
  % drop duplicates
  ED2 = unique(sort(ED2,2),'rows');

  %–– 7) remap PN2(:,5) and build CoupleNodes2
  % before: PN2(:,5) = newIdx(PN2(:,5));
%–– fix: only remap positive pointers
oldP = PN2(:,5);
newP = zeros(size(oldP));                  % default = 0 for “no partner”
mask = oldP > 0;                           % only those that need remapping
newP(mask) = newIdx(oldP(mask));          % lookup their new indices
PN2(:,5) = newP;
  C = PN2(:,[1 5]);             % [oldID, newPartnerOldID]
  % C(:,1) are old IDs → remap only positive ones
old1 = C(:,1);
mask1 = old1 > 0;
C(mask1,1) = newIdx(old1(mask1));

% C(:,2) are old partner‐IDs → remap only positive ones
old2 = C(:,2);
mask2 = old2 > 0;
C(mask2,2) = newIdx(old2(mask2));  C(C(:,2)==0,:) = [];          % drop zeros
  C(C(:,1)==C(:,2),:) = [];     % drop self‐partners

  %–– 8) reassemble SDataV2
  SDataV2 = zeros(max(size(ED2,1),size(PN2,1)),10);
  SDataV2(1:size(PN2,1),1:5)  = PN2;
  SDataV2(1:size(ED2,1),6:7)  = ED2;
  SDataV2(1,8)  = size(ED2,1);
  SDataV2(1,9)  = size(PN2,1);
  SDataV2(1:nFaces,10) = bCounts;

  CoupleNodes2 = C;
end
