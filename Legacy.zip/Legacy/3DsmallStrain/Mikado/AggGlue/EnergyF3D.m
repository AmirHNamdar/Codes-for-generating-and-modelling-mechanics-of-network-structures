function Ed = EnergyF3D(PN,ED,U,e,g,NE,diam)

% this function calculates the energy stored in each fibre and each mode in 3D.
% to do so, we have first calculated the deformation of each node in local
% coordinate and then calculated the forces at boundary of each node and
% then the integration for calculating the overall energy is conducted.
% Ebending = 1/2 int_0^L(M^2/EI)dx and similar for others.

 % some predefined data 
% if tb == 1
    k = 9/10; % for circular bar
% elseif tb == 0
%     k = 5/6; % for rectangle bar
% end



Ar = pi*diam^2/4;
I = pi*diam^4/64;
J = 2*I;





%__________________________________________________________________________________________
% calculating the local deformations

% first step to calculate the length of each segment considereing which node
% of each segment is the the number one node

L=zeros(NE,1);
n1=ED(:,1);
n2=ED(:,2);
n1x=PN(n1,2);
n1y=PN(n1,3);
n1z = PN(n1,4);
n2x=PN(n2,2);
n2y=PN(n2,3);
n2z = PN(n2,4);
L(:,1)=sqrt((n1x-n2x).^2+(n1y-n2y).^2+(n1z-n2z).^2);  

    % we need transformation matrix T. 
    X1 = [n1x,n1y,n1z];
    X2 = [n2x,n2y,n2z];
    dX = X2 - X1;
    
    
    dc = dX ./ L;  % direction cosines (x direction)
    locx = dc;
    
    interZ0 = [zeros(size(dc,1),1),zeros(size(dc,1),1),ones(size(dc,1),1)];
    v = cross(dc, interZ0, 2);      % if l≈[0;0;1] we should choose another axis (but it never happens in reality of the code)
    locy = v ./ vecnorm(v, 2, 2); % local y
    
    locz = cross(dc, locy, 2); % local z

    
%     for i=1:NE
%   M = [ locx(i,:) ; locy(i,:) ; locz(i,:) ];
%   if norm(M*M' - eye(3)) > 1e-8
%     i
%   end
% end
% disp('All local axes OK')
    
    
    
    C = cell(1,4*NE);
    
    for i = 1:NE
    temT = [locx(i,:); locy(i,:); locz(i,:)];
    C{4*i-3} = ( temT );     % convert to sparse if you want zeros omitted
    C{4*i-2} = ( temT );     % convert to sparse if you want zeros omitted
    C{4*i-1} = ( temT );     % convert to sparse if you want zeros omitted
    C{4*i} = ( temT );     % convert to sparse if you want zeros omitted
    end
    T = blkdiag( C{:} ); % transformation matrix T
    
    % u_loc = T * u_global (here u is a vector)
    
        u_g = zeros(12*NE,1);
    
        n1 = ED(:,1);
        n2 = ED(:,2);
        u_g1 = U(n1,2:7); % is a NE by 6 
        u_g2 = U(n2,2:7); % is a NE by 6 
        
        % appending them to u_g
        
        u_g = [u_g1,u_g2];
        u_g = reshape(u_g',[12*NE,1]);
        


    u_loc = T * u_g;    % = 12*NE by 1 vector
    
    u_loc_temp = reshape(u_loc,[12,NE]);
    Ulocal = u_loc_temp' % [ux1,uy1,....]
%__________________________________________________________________________________________
% calculating the forces

% stretching part
Fstretch = (Ulocal(:,7)-Ulocal(:,1))./L.*Ar.*e

% torsion
Tor = (Ulocal(:,10)-Ulocal(:,4))./L.*J.*g

% bending and shear part
% in two plain we will have two indipendent deformation since we are in the
% infinitisimal deformation regime.

A1 = -L./(k.*Ar.*g) + L.^3./(6.*e.*I);
B1 = -L.^2./(2.*e.*I);
C1 = Ulocal(:,8)-Ulocal(:,2)-Ulocal(:,6).*L; % def in y and rotation in z
D1 = -L.^2./(2.*e.*I);
E1 = +L./(e.*I);
F1 = Ulocal(:,6)-Ulocal(:,12);

Fshear1 = (C1-(B1.*F1)./E1)./(A1-(B1.*D1)./E1);
M1 = (C1-A1.*Fshear1)./B1

A2 = -L./(k.*Ar.*g) + L.^3./(6.*e.*I);
B2 = -L.^2./(2.*e.*I);
C2 = Ulocal(:,9)-Ulocal(:,3)-Ulocal(:,5).*L; % def in z and rotation in y
D2 = -L.^2./(2.*e.*I);
E2 = +L./(e.*I);
F2 = Ulocal(:,5)-Ulocal(:,11);

Fshear2 = (C2-(B2.*F2)./E2)./(A2-(B2.*D2)./E2);
M2 = (C2-A2.*Fshear2)./B2

%__________________________________________________________________________________________
% calculating the energy


Estretch = 1./(2.*e.*Ar).*Fstretch.^2.*L ; % stretching energy
Etorsion = 1./(2.*g.*J).*Tor.^2.*L ;
Eshear1 = 1./(2.*k.*Ar.*g).* Fshear1.^2.*L;
Eshear2 = 1./(2.*k.*Ar.*g).* Fshear2.^2.*L;
Ebending1 = 1./(2.*e.*I).*(M1.^2.*L + Fshear1.^2.*L.^3./3 - 2.*Fshear1.*M1.*L.^2./2);
Ebending2 = 1./(2.*e.*I).*(M2.^2.*L + Fshear2.^2.*L.^3./3 - 2.*Fshear2.*M2.*L.^2./2);
Eshear = Eshear1 + Eshear2;
Ebending = Ebending1 + Ebending2;

Ed = zeros(NE,4);

Ed(:,1) = Ebending;
Ed(:,2) = Estretch;
Ed(:,3) = Eshear;
Ed(:,4) = Etorsion;
    

% EstreDef = e.*Ar ./ 2 ./ L .* (Ulocal(:,7)-Ulocal(:,1)) .^2;
% EtorDef = g.*J ./ 2 ./ L .* (Ulocal(:,10)-Ulocal(:,4)) .^2;
% Ebend1Def = e.*I ./ 2 ./ L .* (Ulocal(:,11)-Ulocal(:,5)) .^2;
% Ebend2Def = e.*I ./ 2 ./ L .* (Ulocal(:,12)-Ulocal(:,6)) .^2;
% EbendDef = Ebend1Def + Ebend2Def;
    


%     i = 4;   % pick element 1
%     for i = 1:NE
% idx = [ ED(i,1); ED(i,2) ];
% fprintf('Node-1 dofs: %g %g %g  %g %g %g\n', U(idx(2),2:7));
% fprintf('Ulocal row : %g %g %g  %g %g %g\n', Ulocal(i,7:12));
%     
%     
%     dot(U(idx(2),5:7),locx(i,:)) 
%     dot(U(idx(2),5:7),locz(i,:)) 
%     dc(1,:);
%     locy(1,:);
%     locz(1,:);
%     
%     
%     sqrt((U(idx(2),5)).^2+(U(idx(2),6)).^2+(U(idx(2),7)).^2)
%     sqrt((Ulocal(i,10)).^2+(Ulocal(i,11)).^2+(Ulocal(i,12)).^2)
%     end
end
    
    


