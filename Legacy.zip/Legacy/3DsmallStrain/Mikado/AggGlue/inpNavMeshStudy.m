clear
clc
close all
% in this code we generate the .inp file needed by abaqus in matlab for 3D
% small deformation case. All beams are in circular shape.
% this is for a simple mikado network.
% for this code we create a network in a volume with side length of L+2 and
% then cut the portion of fibres that are outside of the box with side length of L.



% The necessary input___________________________________________________________________________
% input for generating the network

meshl2 = [1,0.05,0.025,0.012,0.005,0.0025,0.001];  % for den = 40 and CD = L/5, mean length is 0.05425

outFolder = '/Users/Code/Abaqus/GeneratingInputFile/3D/MeshStudy'; % direction of where i want to write my .inp file
% make sure it exists (creates it if it doesn’t)
if ~exist(outFolder,'dir')
    mkdir(outFolder)
end


diam = 1e-5; % the diameter of a single fibre
density = 40; % number of fibre centre in a unit volume
lambda = 2; % side length of the box
N = (lambda+2)^3*density; % number of fibres data [initial nf, final nf, number of increase in each step]
x = [0 lambda]; % boundary of x direction
y = [0 lambda]; % boundary of y direction
z = [0 lambda];
L=1; % Length of fibers
flt = 10^(-4)*L; % fibre lenght treshold. Edges smaller than flt will be deleted.
ContactDistance = L/5; % the distance below which the contact occures
nnG = 1; % number of nodes in each group for BC matter
defH = [0 1 0;
        0 0 0;
        0 0 0]; % the appllied farfield BC
MatDen = 7800; % beam material density
Matnu = 0.5; % beam material poisson ratio
e = 100; % elastic modulus of beams
g = e/2/(1+Matnu);
% inpName = 'TestAll'; % name of the .inp file
CheckPlot = false; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = true; % to check the time of excution of each main function


% generating network___________________________________________________________________________
[SDataH,SDataV,Fiber,Per,SDatatest,CoupleNodes,DataRaw] = NetworkSemiRand(x,y,z,L,N,lambda,flt,density,ContactDistance,CheckPlot,timeCheck);
if Per == false % if the network not percoalted 
    disp('not percolated network')
else
NE = SDataV(1,8); % number of edges
NN = SDataV(1,9); % number of nodes 
PN = SDataV(1:NN,1:5); % position of nodes
ED = SDataV(1:NE,6:7); % position of edges
nrb = SDataV(1,10); % number of right boundary node (x +)
nlb = SDataV(2,10); % number of left boundary node (x -)
ntb = SDataV(3,10); % number of top boundary node (y +)
nbb = SDataV(4,10); % number of botttom boundary node (y -)
nfb = SDataV(5,10); % number of front boundary node (z +)
nreb = SDataV(6,10); % number of rear boundary node (z -)
nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes


% calculating the equation needed for BC___________________________________________________________________________
if timeCheck == true
    tic
end
[equations,errorArea] = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nfb,nreb,nnG,defH);
if timeCheck == true
    time_Equation = toc
end

% I also need to save the data to use in the PP section
% save(inpName)


for nm = 1:size(meshl2,2) % number of mesh studies
% writing the .inp file___________________________________________________________________________
if errorArea == false
    if timeCheck == true
        tic
    end
    
    meshl = meshl2 (1,nm); % mesh length
    inpName = strcat('MeshStudy-','Den',num2str(density),'diam',num2str(diam),'lambda',num2str(lambda),'MeshSize',num2str(meshl));
    
    [ToPrint,prp] = writeFunctionMesh(PN,ED,inpName,diam,MatDen,Matnu,e,equations,nbn,lambda,CoupleNodes,CheckPlot,meshl,outFolder);
    if timeCheck == true
        time_write = toc
    end
end
disp(ToPrint);
end


end