function [ip,Fiber,PI2,ED2,nrb,nlb,ntb,nbb,nfb,nreb] = NetIntersec(Fiber,x,y,PBN2,nf,density,ContactDistance,flt,lambda,L)

N=size(Fiber,1);
ip = 0;


nrb = 0; % number of right boundary node
nlb = 0;
ntb = 0; % in y direction with + normal vector
nbb = 0;
nfb = 0;
nreb = 0;

for i = 1:size(PBN2,1)
    if PBN2(i,3) == 1
        nrb = nrb + 1;
    elseif PBN2(i,3) == 2
        nlb = nlb + 1;
        elseif PBN2(i,3) == 3
          ntb = ntb + 1;
          elseif PBN2(i,3) == 4
            nbb = nbb + 1;
            elseif PBN2(i,3) == 5
                nfb = nfb + 1;
                elseif PBN2(i,3) == 6
                    nreb = nreb + 1;
    end
end


PN3(:,1:2) = PBN2(:,1:2); % x and y
PN3(:,3) = PBN2(:,5); % z


ED2 = [];
PI2 = zeros(1,5);
cou = size(PBN2,1)+1;

% for fibre connection
ca = [];
ica = [];
jca = [];





% for i=1:N
%     for j=i+1:N
%         if j~=i
%             % find its contact with fiber j (if yes, ec ==1, otherwise, ec ==0)
%             if Fiber(i,9) - Fiber(j,9) <= 1 && Fiber(i,9) - Fiber(j,9) >= -1 &&...
%                     Fiber(i,10) - Fiber(j,10) <= 1 && Fiber(i,10) - Fiber(j,10) >= -1 &&...
%                     Fiber(i,16) - Fiber(j,16) <= 1 && Fiber(i,16) - Fiber(j,16) >= -1
%             [ec,pi,pj] = intersection2(Fiber,i,j,ContactDistance,flt,lambda);
%             if ec == 1
%             PI2(cou,1) = cou; % the first point on the node one
%             PI2(cou,2:4) = pi;
%             PI2(cou,5) = cou + 1; % which node is its counterpart
%             ica(end+1) = i;
%             jca(end+1) = j;
%             ca(end+1) = cou;
%             
%             cou = cou+1;
%             PI2(cou,1) = cou; % the second point on the node two
%             PI2(cou,2:4) = pj;
%             PI2(cou,5) = cou - 1; % which node is its counterpart
%             ica(end+1) = j; % wehre the two node intersect is not the same
%             jca(end+1) = i;
%             ca(end+1) = cou;
%             
%             cou = cou+1;
%             end
%             end
%         end
%         
%     end
% end


% --- Build KD‐tree on true midpoints ---
midpts      = Fiber(:, [6 7 17]);  
searchRadius = L + ContactDistance;
MdlKD       = createns(midpts, 'NSMethod', 'kdtree');
neighborIdx = rangesearch(MdlKD, midpts, searchRadius);

% --- Loop only over candidate pairs ---
for i = 1:N
    neigh = neighborIdx{i};
    % only keep j>i (to avoid double‐counting and self)
    neigh = neigh(neigh > i);

    for j = neigh
        % exact intersection test
        [ec, pi, pj] = intersection4(Fiber, i, j, ContactDistance, flt, lambda);
%         [ec2, pi2, pj2] = intersection2newfast(Fiber, i, j, ContactDistance, flt, lambda);
%         assert( isequal(ec, ec2), 'Mismatch in ec');
%         pi;
%         pi2;
%         tol = 1e-10;  
%         assert( all(abs(pi - pi2) <= tol), 'Mismatch in pi: max abs diff = %g > tol = %g', max(abs(pi - pi2)), tol );
%         assert( all(abs(pj - pj2) <= tol), 'Mismatch in pj: max abs diff = %g > tol = %g', max(abs(pj - pj2)), tol );

        if ec == 1
            % record first intersection point
            PI2(cou, 1)   = cou;
            PI2(cou, 2:4) = pi;
            PI2(cou, 5)   = cou + 1;
            ica(end+1)    = i;
            jca(end+1)    = j;
            ca(end+1)     = cou;
            cou = cou + 1;

            % record second intersection point
            PI2(cou, 1)   = cou;
            PI2(cou, 2:4) = pj;
            PI2(cou, 5)   = cou - 1;
            ica(end+1)    = j;
            jca(end+1)    = i;
            ca(end+1)     = cou;
            cou = cou + 1;
        end
    end
end

ica';


API = sparse(ica,jca,ca,N,N); % connection of fibres 
size(API);
cou = size(PBN2,1)+1;

% %________________%________________%________________%________________%________________%________________
% 
% % API is your N×N sparse matrix
% % Find rows whose sum is zero
% zeroRows = find( sum(API,2) == 0 )
% 
% % Find columns whose sum is zero
% zeroCols = find( sum(API,1) == 0 );
% 
% for i = zeroRows(1,1)
%     neigh = neighborIdx{i};
%     % only keep j>i (to avoid double‐counting and self)
%     neigh = neigh(neigh > i);
% 
%     for j = neigh
%         % exact intersection test
%         [ec] = intersection2_2(Fiber, i, j, ContactDistance, flt, lambda);
%         if ec == 1
%             1111111111111
% 
% 
%         end
%     end
% end
% %________________%________________%________________%________________%________________%________________

% creating ED

ED2 = [];
for i=1:N
    xnodes = []; % the x position of nodes (i use this to guide the direction)
    pbn = [];
    
        if Fiber(i,11) ~= 7
            pbn = find(PBN2(:,4)==i);
            xnodes(end+1,1) = PBN2(pbn(1,1),1);
            xnodes(end,2) = pbn(1,1);
        end
        if Fiber(i,12) ~= 7
            pbn = find(PBN2(:,4)==i);
            xnodes(end+1,1) = PBN2(pbn(end,1),1);
            xnodes(end,2) = pbn(end,1);
        end
        
%     if Fiber(i,11) == 7 && Fiber(i,12) == 7 % no boundary nodes on the fibre
        nnode = size(nonzeros(API(i,:)),1); % number of nodes
        which_nodes = nonzeros(API(i,:))'; % which nodes
        for j=1:nnode
            w_node = which_nodes(1,j); % which node
            xnodes(end+1,1) = PI2(w_node,2);
            xnodes(end,2) = w_node;
        end
        nnode;
        xnodes = sortrows(xnodes,1);
        
        if size(xnodes,1)>1
            for k=1:size(xnodes,1)-1
                ED2(end+1,1) = xnodes(k,2);
                ED2(end,2) = xnodes(k+1,2);
                ED2(end,3) = Fiber(i,18); % thickness of the fibre
            end
        end
%     end % one side or two side of the fibre has boundary nodes

        
            

end

PI2(1:size(PBN2,1),2:4) = PN3;
PI2(1:size(PBN2,1),1) = [1:1:size(PBN2,1)];
end
















        
        
        
        