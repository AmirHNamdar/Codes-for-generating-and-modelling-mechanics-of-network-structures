function [nir,x1,x2,y1,y2,z1,z2,bp1,bp2,theta,phi] = portion(x1o,x2o,y1o,y2o,z1o,z2o,x,y,z,xm,ym,zm,theta,phi,lambda)

% nir 0 means there is no portion from the fibre in the study domain
nir = 0;
p1 = 0; % if the position of one end of the fibre is inside of the domain (1 = yes)
p2 = 0;

if x1o < x(2) && x1o > x(1) && y1o < y(2) && y1o > y(1) && z1o < z(2) && z1o > z(1)
    p1 = 1; % point 1 is in the range
end

if x2o < x(2) && x2o > x(1) && y2o < y(2) && y2o > y(1) && z2o < z(2) && z2o > z(1)
    p2 = 1; % point 2 is in the range
end

%____________________condition 1________________________
% if both point are in the range, then whole fibre is in the range
if p1 == 1 && p2 == 1
    str = 'condition 1';
    nir = 1;
    x1 = x1o;
    x2 = x2o;
    y1 = y1o;
    y2 = y2o;
    z1 = z1o;
    z2 = z2o;
    bp1 = 7;
    bp2 = 7;
    
    
% % % % % % % % % %     plot3([x1o x2o],[y1o y2o],[z1o z2o], 'LineWidth', 2,'color','g')
% % % % % % % % % % hold on
% % % % % % % % % % xlim([-1 3])
% % % % % % % % % % ylim([-1 3])
% % % % % % % % % % zlim([-1 3])


end

%____________________condition 2_________________________
% if one point is in the range and the other is outside then there is
% intersection with the boundary which should be find

if p1 == 0 && p2 == 1 % point 2 is in the range and the other outside
% in this condition we change some stuff to make it p1 == 1 && p2 == 0 (the code will be shorter)
    
    x1otemp = x1o;
    y1otemp = y1o;
    z1otemp = z1o;
    x1o = x2o;
    y1o = y2o;
    z1o = z2o;
    x2o = x1otemp;
    y2o = y1otemp;
    z2o = z1otemp;
    theta = pi - theta;
    phi = pi + phi;
    p1 = 1;
    p2 = 0;
    
end

if p1 == 1 && p2 == 0 % point 1 is in the range and the other outside
    str = 'condition 2';
    nir = 1; 
    x1 = x1o;
    y1 = y1o;
    z1 = z1o;
    bp1 = 7;
    
    
% % % % % % %     plot3([x1o x2o],[y1o y2o],[z1o z2o], 'LineWidth', 2,'color','r')
% % % % % % % hold on
% % % % % % % xlim([-1 3])
% % % % % % % ylim([-1 3])
% % % % % % % zlim([-1 3])
    
    
    
    if x2o > x(2)
        nL = (x(2) - xm)/(abs(cos(phi))*abs(sin(theta))); % the reduced size of the half fibre
        y2o = ym - nL*(sin(theta)*sin(phi)); 
        z2o = zm - nL*(cos(theta));
        x2o = x(2);
        bp2 = 1;
    elseif x2o < x(1)
        nL = (xm - x(1))/(abs(cos(phi))*abs(sin(theta)));
        y2o = ym - nL*(sin(theta)*sin(phi)); 
        z2o = zm - nL*(cos(theta));
        x2o = x(1);
        bp2 = 2;
    end
    
    if y2o > y(2)
        nL = (y(2) - ym)/(abs(sin(phi))*abs(sin(theta))); % the reduced size of the half fibre
        y2o = y(2); 
        z2o = zm - nL*(cos(theta));
        x2o = xm - nL*(sin(theta)*cos(phi));
        bp2 = 3;
    elseif y2o < y(1)
        nL = (ym - y(1))/(abs(sin(phi))*abs(sin(theta)));
        y2o = y(1); 
        z2o = zm - nL*(cos(theta));
        x2o = xm - nL*(sin(theta)*cos(phi));
        bp2 = 4;
    end
    
    if z2o > z(2)
        nL = (z(2) - zm)/(abs(cos(theta))); % the reduced size of the half fibre
        y2o = ym - nL*(sin(theta)*sin(phi)); 
        z2o = z(2);
        x2o = xm - nL*(sin(theta)*cos(phi));
        bp2 = 5;
    elseif z2o < z(1)
        nL = (zm - z(1))/(abs(cos(theta)));
        y2o = ym - nL*(sin(theta)*sin(phi)); 
        z2o = z(1);
        x2o = xm - nL*(sin(theta)*cos(phi));
        bp2 = 6;
    end
    
    x2 = x2o;
    y2 = y2o;
    z2 = z2o;
    
end
    
    
%_____________________condition 3_________________________
% there is two conditon for this. 1- all of the fibre is outside of the
% study region. 2- the fibre cut two boundaries.

if p1 == 0 && p2 == 0
    str = 'condition 3';
    fout = 1; % it means there is no contact with the boundaries
    
    % checking the possiblity of having contacts with each boundary
    % the parametric set of equation for line is x = (1-t)x1 + t * x2
    % for example to find the connection with boundary z(2), we put z=z(2)
    % and find t, after that we can find x and y.
    
%     ptemp = [x1o,x2o;y1o,y2o;z1o,z2o]; % fibre position temp
%     bptemp = [x(1),x(2);y(1),y(2);z(1),z(2)]; % boudnary position temp
        


% % % % % % % % % plot3([x1o x2o],[y1o y2o],[z1o z2o], 'LineWidth', 2,'color','b')
% % % % % % % % % hold on
% % % % % % % % % xlim([-1 lambda+1])
% % % % % % % % % ylim([-1 lambda+1])
% % % % % % % % % zlim([-1 lambda+1])
% % % % % % % % % 
% % % % % % % % % xxx = linspace(0, lambda, 20); % Range for x
% % % % % % % % % yyy = linspace(0, lambda, 20); % Range for y
% % % % % % % % % zzz = linspace(0, lambda, 20); % Range for z
% % % % % % % % % % Create grids for X and Y
% % % % % % % % % [X, Y] = meshgrid(xxx, yyy); % Grid for X and Y
% % % % % % % % % [~, Z] = meshgrid(xxx, zzz); % Grid for Z when x or y are fixed
% % % % % % % % % % Plot surfaces
% % % % % % % % % % Surface z = 0 (bottom face)
% % % % % % % % % surf(X, Y, zeros(size(X)), 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% % % % % % % % % % Surface z = 2 (top face)
% % % % % % % % % surf(X, Y, 2 * ones(size(X)), 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% % % % % % % % % % Surface x = 0 (left face)
% % % % % % % % % surf(zeros(size(X)), X, Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% % % % % % % % % % Surface x = 2 (right face)
% % % % % % % % % surf(2 * ones(size(X)), X, Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% % % % % % % % % % Surface y = 0 (front face)
% % % % % % % % % surf(X, zeros(size(X)), Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% % % % % % % % % % Surface y = 2 (back face)
% % % % % % % % % surf(X, 2 * ones(size(X)), Z, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% % % % % % % % % % Set axis properties
% % % % % % % % % plot3([0 lambda lambda 0 0 0 0 0 lambda lambda lambda lambda lambda 0 0 lambda],...
% % % % % % % % %     [0 0 0 0 0 lambda lambda 0 0 lambda lambda 0 lambda lambda lambda lambda],...
% % % % % % % % %     [0 0 lambda lambda 0 0 lambda lambda lambda lambda 0 0 0 0 lambda lambda], 'k-', 'LineWidth', 0.5); % Edge along x-axis
% % % % % % % % % hold on
% % % % % % % % % xlabel('X-axis');
% % % % % % % % % ylabel('Y-axis');
% % % % % % % % % zlabel('Z-axis');
% % % % % % % % % title('3D Transparent Box with 6 Surfaces');
% % % % % % % % % axis equal; % Make axes equal for better visualization
% % % % % % % % % grid on;
% % % % % % % % % axis equal; % Enforce 1:1:1 ratio for all axes
% % % % % % % % % view(3); % Set 3D view




        firstnode = true; % if the node we fibnd is the first one
        % right boundary (bp = 1)
        t = (x(2)-x1o)/(x2o-x1o);
        xc = (1-t)*x1o + t*x2o; % x contact with the surface
        yc = (1-t)*y1o + t*y2o;
        zc = (1-t)*z1o + t*z2o;
        
        if min(x1o,x2o) < xc && max(x1o,x2o) > xc && yc > y(1) && yc < y(2) ...
                && zc > z(1) && zc < z(2) % the fibre has a contact with right boundary
            bp1 = 1;
            x1 = xc;
            y1 = yc;
            z1 = zc;
            nir = 1;
            fout = 0;
            firstnode = false;
%             1
        end
        
        % left boundary (bp = 2)
        t = (x(1)-x1o)/(x2o-x1o);
        xc = (1-t)*x1o + t*x2o; % x contact with the surface
        yc = (1-t)*y1o + t*y2o;
        zc = (1-t)*z1o + t*z2o;

        if min(x1o,x2o) < xc && max(x1o,x2o) > xc && yc > y(1) && yc < y(2) ...
                && zc > z(1) && zc < z(2) % the fibre has a contact with right boundary
            if firstnode == true
            	bp1 = 2;
                x1 = xc;
                y1 = yc;
                z1 = zc;
                nir = 1;
                fout = 0;
                firstnode = false;
%                 2
            else
                bp2 = 2;
                x2 = xc;
                y2 = yc;
                z2 = zc;
%                 3
            end
        end
        
        % bp = 3
        t = (y(2)-y1o)/(y2o-y1o);
        xc = (1-t)*x1o + t*x2o; % x contact with the surface
        yc = (1-t)*y1o + t*y2o;
        zc = (1-t)*z1o + t*z2o;

        if min(y1o,y2o) < yc && max(y1o,y2o) > yc && xc > x(1) && xc < x(2) ...
                && zc > z(1) && zc < z(2) % the fibre has a contact with right boundary
            if firstnode == true
            	bp1 = 3;
                x1 = xc;
                y1 = yc;
                z1 = zc;
                nir = 1;
                fout = 0;
                firstnode = false;
%                 4
            else
                bp2 = 3;
                x2 = xc;
                y2 = yc;
                z2 = zc;
%                 5
            end
        end
        
        % bp = 4
        t = (y(1)-y1o)/(y2o-y1o);
        xc = (1-t)*x1o + t*x2o; % x contact with the surface
        yc = (1-t)*y1o + t*y2o;
        zc = (1-t)*z1o + t*z2o;

        if min(y1o,y2o) < yc && max(y1o,y2o) > yc && xc > x(1) && xc < x(2) ...
                && zc > z(1) && zc < z(2) % the fibre has a contact with right boundary
            if firstnode == true
            	bp1 = 4;
                x1 = xc;
                y1 = yc;
                z1 = zc;
                nir = 1;
                fout = 0;
                firstnode = false;
%                 6
            else
                bp2 = 4;
                x2 = xc;
                y2 = yc;
                z2 = zc;
%                 7
            end
        end

        % bp = 5
        t = (z(2)-z1o)/(z2o-z1o);
        xc = (1-t)*x1o + t*x2o; % x contact with the surface
        yc = (1-t)*y1o + t*y2o;
        zc = (1-t)*z1o + t*z2o;

        if min(z1o,z2o) < zc && max(z1o,z2o) > zc && xc > x(1) && xc < x(2) ...
                && yc > y(1) && yc < y(2) % the fibre has a contact with right boundary
            if firstnode == true
            	bp1 = 5;
                x1 = xc;
                y1 = yc;
                z1 = zc;
                nir = 1;
                fout = 0;
                firstnode = false;
%                 8
            else
                bp2 = 5;
                x2 = xc;
                y2 = yc;
                z2 = zc;
%                 9
            end
        end
        
        % bp = 6
        t = (z(1)-z1o)/(z2o-z1o);
        xc = (1-t)*x1o + t*x2o; % x contact with the surface
        yc = (1-t)*y1o + t*y2o;
        zc = (1-t)*z1o + t*z2o;

        if min(z1o,z2o) < zc && max(z1o,z2o) > zc && xc > x(1) && xc < x(2) ...
                && yc > y(1) && yc < y(2) % the fibre has a contact with right boundary
            if firstnode == true
            	bp1 = 6;
                x1 = xc;
                y1 = yc;
                z1 = zc;
                nir = 1;
                fout = 0;
                firstnode = false;
%                 10
            else
                bp2 = 6;
                x2 = xc;
                y2 = yc;
                z2 = zc;
%                 11
            end
        end
        
        if fout == 1
            nir = 0;
            x1 = 1;
            x2 = 1;
            z1 = 1;
            z2 = 1;
            y1 = 1;
            y2 = 1;
            bp1 = 7;
            bp2 = 7;
%             12
        end
        
% % % % % % % % % % % %         if fout == 0
% % % % % % % % % % % %             plot3([x1o x2o],[y1o y2o],[z1o z2o], 'LineWidth', 5,'color','k')
% % % % % % % % % % % %             [x1o x2o]
% % % % % % % % % % % %             [y1o y2o]
% % % % % % % % % % % %             [z1o z2o]
% % % % % % % % % % % %         end
%         firstnode
%         fout
%         p1
%         p2
end

end












