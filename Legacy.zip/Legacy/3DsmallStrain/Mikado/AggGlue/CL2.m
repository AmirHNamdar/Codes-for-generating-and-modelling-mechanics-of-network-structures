function CL = CL2(CL)



for i=1:size(CL,1)
    
    % find the first neighbors. There is most likely just one.
    nei = []; % is the node that are connected to ith node.
%     CL(i,1);
    if CL(i,1) ~= 0 % the list might have been deleted before reaching it
        a = CL(i,1) == CL(:,1);
        b = CL(i,1) == CL(:,2);
        nei_temp = CL(a,2);
        if ~isempty(CL(b,1))
            nei_temp = [nei_temp; CL(b,1)];
        end
        parent = CL(i,1);
        cycleNode = CL(i,1);
        nei = [nei_temp,parent*ones(size(nei_temp,1),1)];
    end
    if size(nei,1) > 1
        nei;
        k = 1;
        while k <= size(nei,1)
            
            nei2 = [];
            node = nei(k,1); 
            a = node == CL(:,1);
            b = node == CL(:,2);
            if ~isempty(CL(a,2))
                nei2 = CL(a,2);
                
            end
            if ~isempty(CL(b,1))
                nei2 = [nei2; CL(b,1)];
                
            end
            % deleting the parent node
            parent_node = nei(k,2);
            k;
            del_par = nei2 == parent_node;
            nei2(del_par,:) = [];
            % addin the new nei2 into nei (first deleting the similar
            % ones) - actually this is wrong since the parent of each of
            % them is different
%             nei3 = nei2;
%             del_nei3 = [];
%             for ll=1:size(nei3,1)
%                 if any(nei==nei3(ll,1))
%                     del_nei3(end+1,1) = ll ;
%                 end
%             end
%             nei3(del_nei3,:) = [];
            % cycleNode should not be added to the nei
            nei3 = nei2;
            del_nei3 = nei3 == cycleNode;
            nei3(del_nei3,:) = [];
            % if the direction is already exist in nei
            del_nei3_2 = [];
            for nn =1:size(nei3,1)
                if sum((nei3(nn,1) == nei(:,1)).*(node == nei(:,2))) >=1
                    del_nei3_2(end+1,1) = nn;
                end
            end
            nei3(del_nei3_2,:) = [];
            
            if ~isempty(nei3)
                nei = [nei ; nei3,node*ones(size(nei3,1),1)];
            end
            % test
            if any(nei2 == cycleNode)
                [cycleNode,node];
                % deleting node will be: (or its flip)
%                 delEdge = all([cycleNode,parent_node] == CL)'
                delEdge = nonzeros((cycleNode==CL(:,1)) .* (node==CL(:,2)) .*[1:size(CL,1)]');
                
                if sum(delEdge,1) == 0
%                     delEdge = all(flip([cycleNode,parent_node]) == CL)'
                    delEdge = nonzeros((cycleNode==CL(:,2)) .* (node==CL(:,1)) .*[1:size(CL,1)]');
                    
                end
                
                % before deleting the edge we should investigate if we
                % still can get to node from cycleNode. For 2 reason we
                % might fail. 1- we might delete all the edges going to the
                % cycle node. 2- the cycle node is outside of the cycle.
                % but connected to it.
                
                delEdgeTest = false;
                CLtemp = CL;
                CLtemp(delEdge,:) = [0,0];
                
%                 a2 = CLtemp(i,1) == CLtemp(:,1);
%                 b2 = CLtemp(i,1) == CLtemp(:,2);
                a2 = cycleNode == CLtemp(:,1);
                b2 = cycleNode == CLtemp(:,2);
                
                nei_tempn = [];
                if ~isempty(CLtemp(a2,2))
                    nei_tempn = CLtemp(a2,2);
                end
                if ~isempty(CLtemp(b2,1))
                    nei_tempn = [nei_tempn; CLtemp(b2,1)];
                end
%                 parentn = cycleNode;
%                 cycleNoden = cycleNode;
                nein = [nei_tempn];
                if ~isempty(nein)
                    k2 = 1;
                    while k2 <= size(nein,1) % new nei
                        nein2 = [];
                        node2 = nein(k2,1);
                        a2 = node2 == CLtemp(:,1);
                        b2 = node2 == CLtemp(:,2);
                        if ~isempty(CLtemp(a2,2))
                            nein2 = CLtemp(a2,2);
                        end
                        if ~isempty(CLtemp(b2,1))
                            nein2 = [nein2; CLtemp(b2,1)];

                        end
                        % deleting the nodes that already exist in nein
                        del_nein2 = [];
                        for zz =1:size(nein2,1)
                            if sum(nein==nein2(zz,1)) ~=0
                                del_nein2(end+1,1) = zz;
                            end
                        end
                        nein2(del_nein2,:)=[];
%                         nein;
%                         nein2
                        nein = [nein;nein2];
                        
                        k2 = k2+1;
%                         size(nein)
                    end
                end
%                 node
%                 nein
                if ~isempty(nein)
                    if find(nein(:,1)==node) % if we can go to node
                        delEdgeTest = true;
                    end
                end
%                 nein(:,1);
%                 delEdgeTest
                
%                 CL(delEdge,:);
%                 node
%                 cycleNode
                if delEdgeTest == true
%                     delEdge;
%                     CL(delEdge,:);
                    CL(delEdge,:) = [0,0];
                end
            end
            
            k = k+1;
        
        end
    end
end



CL = [nonzeros(CL(:,1)),nonzeros(CL(:,2))];

% CL(:,1) should not have repeated nodes for any reason abaqus doesnt like.

nrnode = 0;
for j=1:size(CL,1)
    if sum(CL(j,1) == CL(:,1)) > 1
        nrnode = nrnode +1;
    end
end

nrnode;

% SortedList = [];
% [UNodes,~,indices] = unique(CL);
% counts = accumarray(indices, 1); % number of repeated of each unique node
% % Create a matrix with counts corresponding to original values in A
% count_matrix = reshape(counts(indices), size(CL));



zzz = 0; % how deep I am in fixing CL function?
% tic
for i = 1:size(CL,1)
    
    conn = CL(i,:); % considered connection
    if sum(CL(:,1) == conn(1,1)) ~= 1 % if there is more than one incident
%         fixnodes = []; % nodes that needs to be fixed
%         fixnodes(end+1,1) = conn(1,2);
        nfixn = CL(:,1) == conn(1,2); % number of fixed nodes
        if size(nonzeros(nfixn),1) == 0
            CL(i,:) = flip(CL(i,:));
        else
            CL = fixingCL(CL,nfixn,i,zzz);
        end
    end
end
% toc    




% % --- after you’ve run your cycle-breaker CL2 ---
% % Ensure “column consistency” without recursion:
% 
% % 1) Identify nodes that must live in col 1,
% %    and those that must live in col 2:
% mustBeCol1 = unique(CL(:,1));
% allCol2     = unique(CL(:,2));
% mustBeCol2 = setdiff(allCol2, mustBeCol1);
% 
% % 2) One-pass swap:
% for i = 1:size(CL,1)
%     u = CL(i,1);
%     v = CL(i,2);
%     if ismember(u, mustBeCol2) || ismember(v, mustBeCol1)
%         CL(i,:) = [v, u];
%     end
% end



nrnode = 0;
for j=1:size(CL,1)
    if sum(CL(j,1) == CL(:,1)) > 1
        nrnode = nrnode +1;
    end
end

nrnode;




end