#!/usr/bin/env bash
set -euo pipefail
shopt -s nullglob

# how many cores?
CPUS=$(nproc)
echo "Using all $CPUS CPUs for each Abaqus job."

# gather all your inp files
files=(Size-*.inp)

if [ ${#files[@]} -eq 0 ]; then
  echo "No input files matching Size-*.inp found in $(pwd)." >&2
  exit 1
fi

# run them one by one
for inp in "${files[@]}"; do
  job="${inp%.inp}"
  echo "=== Running job '$job' (file: $inp) with $CPUS CPUs ==="
  abaqus job="$job" input="$inp" cpus="$CPUS" interactive
  echo "=== Job '$job' completed successfully ==="
done

echo "All jobs finished."
