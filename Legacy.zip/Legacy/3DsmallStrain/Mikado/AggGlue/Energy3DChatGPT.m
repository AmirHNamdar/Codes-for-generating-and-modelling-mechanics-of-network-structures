function Ed = Energy3DChatGPT(PN,ED,U,e,g,NE,diam)



%--- geometric & section properties (circular cross‐section) ---
A      = pi*diam^2/4;           % area
Izz    = pi*diam^4/64;          % 2nd moment about z (bending in y‐plane)
Iyy    = Izz;                   % equal for circular section
J      = pi*diam^4/32;          % polar moment (torsion)
kappa  = 6/7;                   % shear correction

%--- preallocate ---
% columns: [axial, torsion, shear_z, bend_z, shear_y, bend_y]
E_elem = zeros(NE,6);

for i = 1:NE
  %--- node indices & coords ---
  n1 = ED(i,1);  n2 = ED(i,2);
  x1 = PN(n1,2:4); x2 = PN(n2,2:4);
  
  %--- element length & axis ---
  L  = norm(x2-x1);
  dc = (x2-x1)/L;               % local x‐axis
  
  %--- build a stable local (y,z) frame ---
  up = [0 0 1];
  if abs(dot(dc,up))>0.9, up = [0 1 0]; end
  locy = cross(up, dc);    locy = locy/norm(locy);
  locz = cross(dc, locy);  % right‐handed
  
  %--- 12×12 transform from global→local ---
  Q = [dc; locy; locz];    % 3×3
  T = blkdiag(Q,Q,Q,Q);
  
  %--- extract and project the 12 global DOFs ---
  idx_g = [(n1*6-5):(n1*6), (n2*6-5):(n2*6)];
  ue_g  = U(idx_g);
  ue_l  = T * ue_g';        % local [u1;rot1;u2;rot2]
  
  %--- 1) Axial energy: ½·EA/L·(Δu_x)^2 ---
  dUax  = ue_l(7) - ue_l(1);
  E_ax  = 0.5 * e*A/L * dUax^2;

  %--- 2) Torsion energy: ½·GJ/L·(Δθ_x)^2 ---
  dThx  = ue_l(10) - ue_l(4);
  E_tr  = 0.5 * g*J/L * dThx^2;
  
  %--- 3) Flexural in z‐plane (deflection u_y, rotation θ_z) ---
  iz    = [2,6,8,12];       % [u1y, θ1z, u2y, θ2z]
  u_fz  = ue_l(iz);
  ks    = kappa*A*g/L;      % shear stiffness
  kbz   = e*Izz/L;          % bending stiffness
  % 4×4 Timoshenko block Kz:
  Kz = [ ...
     ks,       ks*L/2,   -ks,       ks*L/2;
     ks*L/2,   kbz+ks*L^2/4,  -ks*L/2,  kbz-ks*L^2/4;
    -ks,      -ks*L/2,    ks,      -ks*L/2;
     ks*L/2,   kbz-ks*L^2/4,  -ks*L/2,  kbz+ks*L^2/4 ];
  E_fz  = 0.5 * (u_fz' * Kz * u_fz);
  % split into bending vs shear:
  dThz  = ue_l(12) - ue_l(6);
  E_bz  = 0.5 * kbz * dThz^2;
  E_sz  = E_fz - E_bz;
  
  %--- 4) Flexural in y‐plane (deflection u_z, rotation θ_y) ---
  iy    = [3,5,9,11];       % [u1z, θ1y, u2z, θ2y]
  u_fy  = ue_l(iy);
  kby   = e*Iyy/L;
  % 4×4 block Ky:
  Ky = [ ...
     ks,       -ks*L/2,  -ks,      -ks*L/2;
    -ks*L/2,   kby+ks*L^2/4,  ks*L/2,  kby-ks*L^2/4;
    -ks,        ks*L/2,   ks,       ks*L/2;
    -ks*L/2,   kby-ks*L^2/4,  ks*L/2,  kby+ks*L^2/4 ];
  E_fy  = 0.5 * (u_fy' * Ky * u_fy);
  dThy  = ue_l(11) - ue_l(5);
  E_by  = 0.5 * kby * dThy^2;
  E_sy  = E_fy - E_by;
  
  %--- store per‐element energies ---
  E_elem(i,:) = [E_ax, E_tr, E_sz, E_bz, E_sy, E_by];
end

%--- total energies per mode ---
E_modes.axial   = sum(E_elem(:,1));
E_modes.torsion = sum(E_elem(:,2));
E_modes.shear_z = sum(E_elem(:,3));
E_modes.bend_z  = sum(E_elem(:,4));
E_modes.shear_y = sum(E_elem(:,5));
E_modes.bend_y  = sum(E_elem(:,6));
E_modes.total   = sum(E_elem(:));

%--- display summary ---
fprintf('Axial:   %g\nTorsion: %g\nShearZ:  %g\nBendZ:   %g\nShearY:  %g\nBendY:   %g\nTotal:   %g\n', ...
  E_modes.axial, E_modes.torsion, E_modes.shear_z, E_modes.bend_z, ...
  E_modes.shear_y, E_modes.bend_y,   E_modes.total);

end