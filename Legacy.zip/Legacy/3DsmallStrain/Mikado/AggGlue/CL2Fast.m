function CL2 = CL2Fast(CL)
    % CL2FAST  Fast cycle-breaking and orientation for coupling list
    %   Removes edges that form cycles while preserving connectivity,
    %   then orients the resulting spanning forest as parent->child.

    % Remove zero entries and self-loops
    CL = CL(all(CL~=0,2), :);
    CL(CL(:,1)==CL(:,2), :) = [];
    if isempty(CL)
        CL2 = zeros(0,2);
        return;
    end

    % Build undirected graph
    G = graph(CL(:,1), CL(:,2));

    % Prepare output
    CL2 = zeros(0,2);

    % Get connected components
    comps = conncomp(G);
    % For each component, build a BFS tree rooted at its smallest node
    for compID = unique(comps)
        nodes = find(comps == compID);
        root = min(nodes);
        % BFS tree edges (undirected) as edge indices
        [~, edgeIDs] = bfsearch(G, root, 'edgetonew');
        % Extract oriented edges: parent->child
        newEdges = G.Edges.EndNodes(edgeIDs, :);
        CL2 = [CL2; newEdges];
    end
end
