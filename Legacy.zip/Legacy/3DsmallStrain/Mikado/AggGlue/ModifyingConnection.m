function [PBN2,ED2,PI2] = ModifyingConnection(PBN2,ED2,PI2)

% note that since the boundary  nodes are designed in such a way that do
% not have couple node (they always connected to a closby node with 2flt distance) they do not
% be deleted.

nN = size(PI2,1); % number of ndoes
nE = size(ED2,1); % number of edges
nbn = size(PBN2,1) % number of boundary node

fN = zeros(nN,1); % free nodes (0 = free, 1 = connected)

for i=1:nE
    fN(ED2(i,1),1) = 1;
    fN(ED2(i,2),1) = 1;
end
delfI = find(fN == 0);

if any(delfI <= nbn)
    nonzeros(delfI)
    disp('A boundary node does not have a edge');
end
% nfN = size(fN,1) - size(nonzeros(fN),1); % number of free ndoes

% delfI = []; % the list of the nodes that should be deleted (not bouhdary)
% for i = 1:nN
%     if fN(i,1) == 0 % if the fibre is free
%         if i < nbn
%             disp('A boundary node does not have a edge');
%         else
%             delfI(end+1,1) = i;
%         end
%     end
% end


% the nodes should be deleted, and ED2 direction should be modified
% considereing which nodes have been deleted. the node couple number is
% also needs to be modified.

% first I modeify the number of couple nodes and then delete the rows of
% deleteing nodes. the order at which we modify the ED2 is not
% important.

% modifying ED2
for i=size(delfI,1):-1:1
    wEDsm1 = ED2(:,1) > delfI(i,1); % wich ED2 should be modified (subtract one)
    ED2(:,1) = ED2(:,1) - wEDsm1;
    wEDsm2 = ED2(:,2) > delfI(i,1); % wich ED2 should be modified (subtract one)
    ED2(:,2) = ED2(:,2) - wEDsm2;
end

% modifying couple node
for i=1:size(delfI,1)
    awnsm = find(PI2(:,5) == delfI(i,1)); % address of which node should be modified
    if size(awnsm,1) == 1 % the node is free
        PI2(awnsm,5) = 0;
    elseif size(awnsm,1) > 1 % the node is connected to more than one node (the other two should be considered to be in contact)
        PI2(awnsm(2:end,1),5) = awnsm(1,1);
    end
end

for i=size(delfI,1):-1:1
    wPIsm1 = PI2(:,5) >= delfI(i,1); % wich PI2 should be modified (subtract one)
    PI2(:,5) = PI2(:,5) - wPIsm1;
end

% deleting the free nodes
PI2(delfI,:) = [];

end