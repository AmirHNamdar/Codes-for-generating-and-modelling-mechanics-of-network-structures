function [ec, pi, pj] = intersection3(Fiber, i, j, ContactDistance)
    % Extract endpoints of the segments
    A = [Fiber(i,1); Fiber(i,2); Fiber(i,13)];
    B = [Fiber(i,3); Fiber(i,4); Fiber(i,14)];
    C = [Fiber(j,1); Fiber(j,2); Fiber(j,13)];
    D = [Fiber(j,3); Fiber(j,4); Fiber(j,14)];
    ec = 0;
    
    % Direction vectors of the segments
    u = B - A; % Direction vector of segment AB
    v = D - C; % Direction vector of segment CD
    w0 = A - C;
    
    % Compute dot products using manual computation for small vectors
    a = u(1)^2 + u(2)^2 + u(3)^2;       % Equivalent to dot(u, u)
    b = u(1)*v(1) + u(2)*v(2) + u(3)*v(3); % Equivalent to dot(u, v)
    c = v(1)^2 + v(2)^2 + v(3)^2;       % Equivalent to dot(v, v)
    d = u(1)*w0(1) + u(2)*w0(2) + u(3)*w0(3); % Equivalent to dot(u, w0)
    e = v(1)*w0(1) + v(2)*w0(2) + v(3)*w0(3); % Equivalent to dot(v, w0)
    
    % Compute the denominator
    denom = a * c - b^2;
    epsilon = 1e-8; % Small threshold to check for parallelism
    
    % Initialize s and t
    if denom > epsilon
        % Lines are not parallel, compute s and t
        s = (b * e - c * d) / denom;
        t = (a * e - b * d) / denom;
    else
        % Lines are nearly parallel
        s = 0;
        t = (b * s + e) / c;
    end
    
    % Clamp s and t to [0,1]
    s_clamped = max(0, min(1, s));
    t_clamped = max(0, min(1, t));
    
    % Compute the closest points
    P = A + s_clamped * u;
    Q = C + t_clamped * v;
    
    % Compute the distance between the closest points using manual computation
    diff_PQ = P - Q;
    distance_PQ = sqrt(diff_PQ(1)^2 + diff_PQ(2)^2 + diff_PQ(3)^2);
    
    % Early exit if the closest points lie within the segments
    if s_clamped == s && t_clamped == t
        min_distance = distance_PQ;
        if min_distance < ContactDistance
            ec = 1;
            pi = P; % Position on segment AB
            pj = Q; % Position on segment CD
        end
        return; % Exit the function early
    end
    
    % Compute distances from endpoints to opposite segments
    distances = zeros(4,1);
    
    % Distance from A to segment CD
    % Reuse w0 for A - C
    t_A = (v(1)*w0(1) + v(2)*w0(2) + v(3)*w0(3)) / c;
    t_A_clamped = max(0, min(1, t_A));
    Q_A = C + t_A_clamped * v;
    diff_A_QA = A - Q_A;
    distances(1) = sqrt(diff_A_QA(1)^2 + diff_A_QA(2)^2 + diff_A_QA(3)^2);
    
    % Distance from B to segment CD
    w1 = B - C;
    t_B = (v(1)*w1(1) + v(2)*w1(2) + v(3)*w1(3)) / c;
    t_B_clamped = max(0, min(1, t_B));
    Q_B = C + t_B_clamped * v;
    diff_B_QB = B - Q_B;
    distances(2) = sqrt(diff_B_QB(1)^2 + diff_B_QB(2)^2 + diff_B_QB(3)^2);
    
    % Distance from C to segment AB
    w0_neg = -w0; % C - A = -(A - C)
    s_C = (u(1)*w0_neg(1) + u(2)*w0_neg(2) + u(3)*w0_neg(3)) / a;
    s_C_clamped = max(0, min(1, s_C));
    P_C = A + s_C_clamped * u;
    diff_PC_C = P_C - C;
    distances(3) = sqrt(diff_PC_C(1)^2 + diff_PC_C(2)^2 + diff_PC_C(3)^2);
    
    % Distance from D to segment AB
    w2 = D - A;
    s_D = (u(1)*w2(1) + u(2)*w2(2) + u(3)*w2(3)) / a;
    s_D_clamped = max(0, min(1, s_D));
    P_D = A + s_D_clamped * u;
    diff_PD_D = P_D - D;
    distances(4) = sqrt(diff_PD_D(1)^2 + diff_PD_D(2)^2 + diff_PD_D(3)^2);
    
    % Find the minimal distance
    [min_distance, idx] = min([distance_PQ; distances]);
    
    % Assign the closest points based on idx
    switch idx
        case 1
            pP = P;
            pQ = Q;
        case 2
            pP = A;
            pQ = Q_A;
        case 3
            pP = B;
            pQ = Q_B;
        case 4
            pP = P_C;
            pQ = C;
        case 5
            pP = P_D;
            pQ = D;
    end
    
    % Check if the minimal distance is less than ContactDistance
    if min_distance < ContactDistance
        ec = 1;
        pi = pP; % Position on segment AB
        pj = pQ; % Position on segment CD
    end
    
    pi
end
