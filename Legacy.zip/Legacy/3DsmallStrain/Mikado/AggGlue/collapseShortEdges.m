function [PN2, ED2, couple2] = collapseShortEdges(PN, ED, couple, shortF, nbn, flt)
  % PN       : NN×5 node array [id x y z partner]
  % ED       : NE×2 edge list [nodeA nodeB]
  % couple   : K×2 partner list [node partner]
  % shortF   : NE×1 logical of “too-short” edges
  % nbn      : # of boundary nodes
  % flt      : your small‐edge threshold

  %–– A) Identify & drop duplicate short edges in one go
  E = sort(ED,2);                             % unordered pairs
  [U, ~, ic] = unique(E,'rows');             % group identical edges
  counts = accumarray(ic,1);
  isDupShort = shortF & counts(ic)>=2;
  ED(isDupShort,:)   = [];
  shortF(isDupShort) = [];

  %–– B) Handle boundary‐attached short edges (no merging, just nudge)
  bMask = shortF & (ED(:,1)<=nbn | ED(:,2)<=nbn);
  bIdx  = find(bMask);
  for k = bIdx.'
    fN = ED(k,1); sN = ED(k,2);
    if fN <= nbn
      PN(sN,2:4) = newPosition(PN, fN, sN, fN, flt);
    else
      PN(fN,2:4) = newPosition(PN, fN, sN, sN, flt);
    end
  end
  ED(bMask,:)   = []; 
  shortF(bMask) = [];

  %–– C) Merge remaining truly short interior edges via union‐find
  % Build disjoint‐set over nodes
  NN     = size(PN,1);
  parent = 1:NN;
  function r = findp(x)
    while parent(x)~=x, x=parent(x); end
    r=x;
  end
  function unite(a,b)
    ra = findp(a); rb = findp(b);
    if ra~=rb
      % keep boundary nodes as roots
      if ra<=nbn && rb>nbn, parent(rb)=ra;
      elseif rb<=nbn && ra>nbn, parent(ra)=rb;
      else parent(rb)=ra;
      end
    end
  end

  % union every remaining short edge’s endpoints
  toMerge = find(shortF);
  for e = toMerge.'
    unite(ED(e,1), ED(e,2));
  end

  % path‐compress
  for k=1:NN, parent(k)=findp(k); end
  parent(1:nbn) = 1:nbn;                % re-enforce boundary roots

  %–– D) Re-index nodes & rebuild PN, ED, couple, exactly as a cascade of deletions would
  [~,~,newIdx] = unique(parent,'stable');
  % remap PN
  PN2 = PN;
  PN2(:,1) = newIdx(PN(:,1));
  % remap partners only if >0
  tempP = PN(:,5);
  PN2(:,5) = 0;
  maskP = tempP>0;
  PN2(maskP,5) = newIdx(tempP(maskP));

  % remap edges, drop self-loops & duplicates
  ED2 = newIdx(ED);                    
  ED2(ED2(:,1)==ED2(:,2),:) = [];
  ED2 = unique(sort(ED2,2),'rows');

  % remap couple list
  C = couple;
  C(:,1) = newIdx(C(:,1));
  maskC2  = C(:,2)>0;
  C(maskC2,2) = newIdx(C(maskC2,2));
  % drop invalid rows
  C(C(:,2)==0 | C(:,1)==C(:,2),:) = [];
  couple2 = C;
end
