function [ec, pi, pj] = intersection2newfast(Fiber,i,j,ContactDistance,flt,lambda)
    % Unpack endpoints into local vectors
    A = [Fiber(i,1); Fiber(i,2); Fiber(i,13)];
    B = [Fiber(i,3); Fiber(i,4); Fiber(i,14)];
    C = [Fiber(j,1); Fiber(j,2); Fiber(j,13)];
    D = [Fiber(j,3); Fiber(j,4); Fiber(j,14)];

    % Direction vectors and delta
    u = B - A;
    v = D - C;
    w = A - C;

    % Precompute dot products
    a = u(1)*u(1) + u(2)*u(2) + u(3)*u(3);
    b = u(1)*v(1) + u(2)*v(2) + u(3)*v(3);
    c = v(1)*v(1) + v(2)*v(2) + v(3)*v(3);
    d = u(1)*w(1) + u(2)*w(2) + u(3)*w(3);
    e = v(1)*w(1) + v(2)*w(2) + v(3)*w(3);

    % Solve for (s,t)
    denom = a*c - b*b;
    if denom > lambda*1e-8
        s = (b*e - c*d) / denom;
        t = (a*e - b*d) / denom;
    else
        s = 0;           % nearly parallel
        t = e / c;
    end

    % Clamp to [0,1]
    if s < 0, s_cl = 0; elseif s > 1, s_cl = 1; else s_cl = s; end
    if t < 0, t_cl = 0; elseif t > 1, t_cl = 1; else t_cl = t; end

    % Compute the five candidate distances
    % 1) interior–interior
    P1  = A + s_cl*u;
    P2  = C + t_cl*v;
    dx  = P1 - P2;
    minD = dx(1)*dx(1) + dx(2)*dx(2) + dx(3)*dx(3);
    idx  = 1;

    % 2) A→CD
    tA = (v(1)*w(1) + v(2)*w(2) + v(3)*w(3)) / c;
    if tA < 0, tAcl = 0; elseif tA > 1, tAcl = 1; else tAcl = tA; end
    Q_A = C + tAcl*v;
    d2  = (A(1)-Q_A(1))^2 + (A(2)-Q_A(2))^2 + (A(3)-Q_A(3))^2;
    if d2 < minD, minD = d2; idx = 2; end

    % 3) B→CD
    wB = B - C;
    tB = (v(1)*wB(1) + v(2)*wB(2) + v(3)*wB(3)) / c;
    if tB < 0, tBcl = 0; elseif tB > 1, tBcl = 1; else tBcl = tB; end
    Q_B = C + tBcl*v;
    d3  = (B(1)-Q_B(1))^2 + (B(2)-Q_B(2))^2 + (B(3)-Q_B(3))^2;
    if d3 < minD, minD = d3; idx = 3; end

    % 4) C→AB
    wC = C - A;
    sC = (u(1)*wC(1) + u(2)*wC(2) + u(3)*wC(3)) / a;
    if sC < 0, sCcl = 0; elseif sC > 1, sCcl = 1; else sCcl = sC; end
    P_C = A + sCcl*u;
    d4   = (C(1)-P_C(1))^2 + (C(2)-P_C(2))^2 + (C(3)-P_C(3))^2;
    if d4 < minD, minD = d4; idx = 4; end

    % 5) D→AB
    wD = D - A;
    sD = (u(1)*wD(1) + u(2)*wD(2) + u(3)*wD(3)) / a;
    if sD < 0, sDcl = 0; elseif sD > 1, sDcl = 1; else sDcl = sD; end
    P_D = A + sDcl*u;
    d5   = (D(1)-P_D(1))^2 + (D(2)-P_D(2))^2 + (D(3)-P_D(3))^2;
    if d5 < minD, minD = d5; idx = 5; end

    % Determine ec
    ec = (minD <= ContactDistance^2);

    % Only if requested, set pi,pj
    if nargout>1
        switch idx
          case 1, pi = P1; pj = P2;
          case 2, pi = A;  pj = Q_A;
          case 3, pi = B;  pj = Q_B;
          case 4, pi = P_C;pj = C;
          case 5, pi = P_D;pj = D;
        end

        % optional boundary‐dislocation
        tol  = 1e-10;
        dis1 = 2*flt; dis2 = lambda - 2*flt;
        if abs(pi(1))<tol,       pi(1)=dis1;  end
        if abs(pi(1)-lambda)<tol,pi(1)=dis2;  end
        if abs(pi(2))<tol,       pi(2)=dis1;  end
        if abs(pi(2)-lambda)<tol,pi(2)=dis2;  end
        if abs(pi(3))<tol,       pi(3)=dis1;  end
        if abs(pi(3)-lambda)<tol,pi(3)=dis2;  end

        if abs(pj(1))<tol,       pj(1)=dis1;  end
        if abs(pj(1)-lambda)<tol,pj(1)=dis2;  end
        if abs(pj(2))<tol,       pj(2)=dis1;  end
        if abs(pj(2)-lambda)<tol,pj(2)=dis2;  end
        if abs(pj(3))<tol,       pj(3)=dis1;  end
        if abs(pj(3)-lambda)<tol,pj(3)=dis2;  end
    end
end
