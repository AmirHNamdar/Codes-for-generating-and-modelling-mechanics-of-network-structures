clear
clc
close all



% this script creates a series inp file to do a study of effect of density on poisson ratio of
% Mikado netowrks.



% The necessary input___________________________________________________________________________
% Specific input for generating the network
L=1e-2; % Length of fibers
density2 = [4,5,6,7,8]*1e6;
lambda2 = [4,4,4,3,3,2].*L; % side length of the box (Llc will be around 35)

ragg = L/4;
Pagg = 0.8;


% lambda2 = [2,3,4,5];
% lambda2 = [6,7];
consCD = 8; % ContactDistance = radius*consCD; % the distance below which the contact occures

flt = 10^(-4)*L; % fibre lenght treshold. Edges smaller than flt will be deleted.

nnG2 = 8; % number of nodes in each group for BC matter
NO2 = [12,12,12,12,12,12,12]; % number of observation
% NO2 = [48,36,24,12];
% NO2 = [12,12];
radius2 = 1e-4; %___________%%%%%%%%% only one radius is allowed %%%%%%%%___________
ContactDistance = radius2*consCD; % the distance below which the contact occures
outFolder = '/home/m60315an/abaqus/Abaqus/GeneratingInputFile/3D/Mikado/AggGlue/nustudy';
% outFolder = '/Users/Code/Abaqus/GeneratingInputFile/3D/Mikado/denStudy';


MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio
e = 100; % elastic modulus of beams
g = e/2/(1+Matnu);
CheckPlot = false; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = false; % to check the time of excution of each main function









% THE LOOP___________________________________________________________________________

% I will have two loops (the first one for the N and the other for the radius)





nS = size(density2,2);
tic
for i = 1:nS
    i
    lambda = lambda2(1,i);
    density = density2(1,i);
    N = (lambda+2*L).^3.*density/L; % number of fibres data [initial nf, final nf, number of increase in each step]
    x = [0 lambda]; % boundary of x direction
    y = [0 lambda]; % boundary of y direction
    z = [0 lambda];

    % number of observation for each case depending on the size
    NO = NO2(1,i);
    
    parfor j=1:NO
% create the netwrok
       [SDataH,SDataV,Fiber,Per,SDatatest,CoupleNodes,DataRaw] = NetworkSemiRand(x,y,z,L,N,lambda,flt,density,ContactDistance,CheckPlot,timeCheck,ragg,Pagg);
        
        if Per == false % if the network not percoalted 
            disp('not percolated network')
        else
            NE = SDataV(1,8); % number of edges
            NN = SDataV(1,9); % number of nodes 
            PN = SDataV(1:NN,1:5); % position of nodes
            ED = SDataV(1:NE,6:7); % position of edges
            nrb = SDataV(1,10); % number of right boundary node (x +)
            nlb = SDataV(2,10); % number of left boundary node (x -)
            ntb = SDataV(3,10); % number of top boundary node (y +)
            nbb = SDataV(4,10); % number of botttom boundary node (y -)
            nfb = SDataV(5,10); % number of front boundary node (z +)
            nreb = SDataV(6,10); % number of rear boundary node (z -)
            nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes
            naf = SDataV(1:NE,11);

                nradi = size(radius2,2);
                
                for l = 1:nradi
                    radius = radius2(1,l);
                    nnG = nnG2;
                    

                    % inpName should be specified here
                    inpName = strcat('nuAggGlue-','Pagg',num2str(Pagg),'Ragg',num2str(ragg),'Den',num2str(density),'radius',num2str(radius),'lambda',num2str(lambda),'CD',num2str(ContactDistance),'Observ',num2str(j));
                    i
                    j

                    % writing the .inp file___________________________________________________________________________

                        if timeCheck == true
                            tic
                        end
                    [ToPrint] = writeFunctionNu(PN,ED,inpName,radius,MatDen,Matnu,e,nbn,lambda,CoupleNodes,CheckPlot,outFolder,nrb,nlb,ntb,nbb,nfb,nreb,naf);
                        if timeCheck == true
                            time_write = toc
                        end

                end
        end
    end
end


timeAll = toc

















