function [U,URP,NF,NFRP] = datFileRead(fileName,NRP)


% Open the .dat file
fileName2 = [fileName, '.dat'];
fileID = fopen(fileName2, 'r');

% Initialize cell array to store displacement data
displacementData = {};
ReactiveForceData = {};

% Flag to start reading data once the section is reached
readingData = false;
readingDataRF = false;

% Loop through each line in the .dat file
while ~feof(fileID)
    line = fgetl(fileID);  % Read a line from the file
    
    % Check if the line contains the start of the displacement section
    if contains(line, 'N O D E   O U T P U T')  % Adjust based on your .dat structure
        % Skip lines to reach the actual data section
        for i = 1:5
            fgetl(fileID);
        end
        readingData = true;  % Set flag to start reading data
    end
    
    % Read and store displacement data until end of section
    if readingData
        if isempty(line) || contains(line, '***')  % End of the displacement section
%             break;
            readingData = false;
        end
        % Parse numeric data
        data = sscanf(line, '%f');
        displacementData = [displacementData; data'];  % Append to data array
    end
    
    if contains(line, 'RF1')  % Adjust based on your .dat structure
        % Skip lines to reach the actual data section
        for i = 1:2
            fgetl(fileID);
        end
        readingDataRF = true;  % Set flag to start reading data
    end
    
    % Read and store displacement data until end of section
    if readingDataRF
        if isempty(line) || contains(line, '***')  % End of the displacement section
            break;
        end
        % Parse numeric data
        data = sscanf(line, '%f');
        ReactiveForceData = [ReactiveForceData; data'];  % Append to data array
    end
    
    
end

% Close the file
fclose(fileID);

% Convert cell array to a matrix for easier access
URP = cell2mat(displacementData(1:NRP));
U = cell2mat(displacementData (NRP+1:end));

NFRP = cell2mat(ReactiveForceData(1:NRP));
NF = cell2mat(ReactiveForceData (NRP+1:end));


end