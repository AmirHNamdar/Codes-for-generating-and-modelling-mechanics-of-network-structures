function [Per, ip, pc, Fiber, timeIntersection2] = NetIntersecC_fast2(...
    Fiber, ~, ~, PBN, ~, ~, ContactDistance, timeIntersection2, ...
    flt, lambda, time_intersection_Check, L)

% --- 0) Setup
N  = size(Fiber,1);
ip = [];                     % you weren't computing points, so keep empty
Per = false;
pc  = 0;

% --- 1) KD-tree on true midpoints
midpts       = Fiber(:, [6 7 17]);           % xm, ym, zm
searchRadius = L + ContactDistance;
MdlKD        = createns(midpts, 'NSMethod', 'kdtree');
neighborIdx  = rangesearch(MdlKD, midpts, searchRadius);

% --- 2) PARALLEL: detect intersections, collect edges only
E = cell(N,1);                                % per-worker edge buckets
tAccum = zeros(N,1);                          % (optional) per-i timing

% You can switch this to parfor once it's stable:
% parfor i = 1:N
for i = 1:N
    neigh = neighborIdx{i};
    neigh(neigh <= i) = [];                   % enforce j>i and drop self

    localEdges = [];                           % [k x 2] list for this i
    tLocal = 0;

    for j = neigh(:).'
        if time_intersection_Check
            t0 = tic;
        end

        % Your intersection predicate (must be pure / no shared state)
        ec = intersection2_2new(Fiber, i, j, ContactDistance, flt, lambda);
%         [ec,~,~] = intersection2(Fiber, i, j, ContactDistance, flt, lambda);
%         if ec2 ~=ec
%             111111111
%         end
        if time_intersection_Check
            tLocal = tLocal + toc(t0);
        end

        if ec == 1
            localEdges(end+1, :) = [i, j];    %#ok<AGROW>
        end
    end

    E{i}     = localEdges;
    tAccum(i)= tLocal;
end

if time_intersection_Check
    timeIntersection2 = timeIntersection2 + sum(tAccum);
end

% --- 3) SERIAL: union-find on collected edges
edges = vertcat(E{:});                        % all (i,j) that intersect
parent = 1:N;                                 % disjoint-set parent
rank   = zeros(N,1);                          % union-by-rank (or size)

for k = 1:size(edges,1)
    a = edges(k,1); b = edges(k,2);
    [parent, rank] = uf_union(parent, rank, a, b);
end

% flatten labels into Fiber(:,8)
for k = 1:N
    [root, parent] = uf_find(parent, k);      % path compression
    Fiber(k,8) = root;
end

% --- 4) Percolation check (unchanged)
faceIDs       = PBN(:,3);
fiberIDs      = PBN(:,4);
clusterLabels = Fiber(fiberIDs,8);

cnf  = clusterLabels(faceIDs==5);
cnre = clusterLabels(faceIDs==6);
common = intersect(cnf, cnre);

if ~isempty(common)
    Per = true;
    pc  = common(1);
end

% (optional debug) save snapshot
% Fiber2 = Fiber; save('Fiber2Data.mat','Fiber2','neighborIdx');

end

% ======= subfunctions (no captured variables) ============================
function [root, parent] = uf_find(parent, x)
% Iterative find with path compression
px = x;
while parent(px) ~= px
    px = parent(px);
end
root = px;
% compress path
px = x;
while parent(px) ~= px
    nxt = parent(px);
    parent(px) = root;
    px = nxt;
end
end

function [parent, rank] = uf_union(parent, rank, a, b)
[aRoot, parent] = uf_find(parent, a);
[bRoot, parent] = uf_find(parent, b);
if aRoot == bRoot, return; end
ra = rank(aRoot); rb = rank(bRoot);
if ra < rb
    parent(aRoot) = bRoot;
elseif ra > rb
    parent(bRoot) = aRoot;
else
    parent(bRoot) = aRoot;
    rank(aRoot)   = ra + 1;
end
end
