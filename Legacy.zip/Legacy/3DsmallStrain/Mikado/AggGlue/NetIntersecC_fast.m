function [Per, ip, pc, Fiber, timeIntersection2] = NetIntersecC_fast(...
    Fiber, ~, ~, PBN, ~, ~, ContactDistance, timeIntersection2,...
    flt, lambda, time_intersection_Check,L)

% % 1) Set up
N = size(Fiber,1);
ip = [];        % we’re not computing intersection points here
Per = false;
% 
% % 2) Build a KD-tree on the 3D “bounding box” features [col9 col10 col16]
% coords = Fiber(:, [9 10 16]);
% MdlKD  = createns(coords, 'NSMethod', 'kdtree');
% 
% % 3) For each fiber, find neighbors within ±1 in all three dims
% neighborIdx = rangesearch(MdlKD, coords, 1);

% --- Build KD‐tree on true midpoints ---
midpts       = Fiber(:, [6 7 17]);                % [xm, ym, zm] from columns 6–8
searchRadius = L + ContactDistance;          % max midpoint separation
MdlKD        = createns(midpts, 'NSMethod', 'kdtree');
neighborIdx  = rangesearch(MdlKD, midpts, searchRadius);

% % 4) Loop over only the candidate pairs
% for i = 1:N
%     neigh = neighborIdx{i};
%     neigh(neigh==i) = [];  % drop self
% 
%     for j = neigh
%         % timing
%         if time_intersection_Check, t0 = tic; end
%         ec = intersection2_2(Fiber,i,j,ContactDistance,flt,lambda);
%         if time_intersection_Check
%             timeIntersection2 = timeIntersection2 + toc(t0);
%         end
% 
%         if ec == 1
%             oldLabel = Fiber(j,8);
%             % vectorized re-labelling:
%             Fiber(Fiber(:,8)==oldLabel,8) = i;
%         end
%     end
% end
parent = 1:N; 

% --- Loop only over candidate pairs ---
% for i = 1:N
%     neigh = neighborIdx{i};
%     neigh(neigh == i) = [];      % drop self
%     for j = neigh
%         if time_intersection_Check
%             t0 = tic;
%         end
%         ec = intersection2_2(Fiber, i, j, ContactDistance, flt, lambda);
%         if time_intersection_Check
%             timeIntersection2 = timeIntersection2 + toc(t0);
%         end
%         if ec == 1
%             oldLabel = Fiber(j,8);
%             Fiber(Fiber(:,8) == oldLabel, 8) = i;
%         end
%     end
% end

for i = 1:N
    neigh = neighborIdx{i};
    neigh(neigh <= i) = [];      % drop self
    for j = neigh
%         if time_intersection_Check
%             t0 = tic;
%         end
%         intBefore = [i,j]
        ec = intersection2_2new(Fiber, i, j, ContactDistance, flt, lambda);
%         ec = intersection2(Fiber, i, j, ContactDistance, flt, lambda);
        
%         if time_intersection_Check
%             timeIntersection2 = timeIntersection2 + toc(t0);
%         end

        if ec == 1
%             ec1 = [i,j]
            % merge the two sets
            union_set(i, j);
        end
    end
end

% --- after all intersections, flatten and write back into Fiber(:,8) ---
for k = 1:N
    Fiber(k,8) = find_set(k);
end




% 5) Vectorized boundary-cluster mapping
faceIDs = PBN(:,3);
fiberIDs = PBN(:,4);
clusterLabels = Fiber(fiberIDs,8);

cnr  = clusterLabels(faceIDs==1);
cnl  = clusterLabels(faceIDs==2);
cnt  = clusterLabels(faceIDs==3);
cnb  = clusterLabels(faceIDs==4);
cnf  = clusterLabels(faceIDs==5);
cnre = clusterLabels(faceIDs==6);

% 6) Check percolation via set intersection
common = intersect(cnf, cnre);

if ~isempty(common)
    Per = true;
    pc  = common(1);    % pick the first percolating cluster
else
    pc = 0;
end



% 
% 
% 
% % --- 1) Identify percolating-cluster fibres ---
% members  = find(Fiber(:,8) == pc);   % global indices of PC fibres
% nMembers = numel(members);
% 
% % --- 2) Build midpoints for only those fibres ---
% % xm_all = 0.5*(Fiber(:,1)  + Fiber(:,3));
% % ym_all = 0.5*(Fiber(:,2)  + Fiber(:,4));
% % zm_all = 0.5*(Fiber(:,13) + Fiber(:,14));
% 
% xm_all = Fiber(:,6);
% ym_all = Fiber(:,7);
% zm_all = Fiber(:,17);
% 
% midpts  = [xm_all(members), ym_all(members), zm_all(members)];
% 
% 
% % --- 3) KD‐tree & neighbor search among PC only ---
% searchRadius = L + ContactDistance;
% MdlKD        = createns(midpts, 'NSMethod','kdtree');
% neighborIdx  = rangesearch(MdlKD, midpts, searchRadius);
% 
% % --- 4) Initialize intersection tables (continuing from your PI2,ca,etc.) ---
% cou = size(PBN,1) + 1;
% ica = []; jca = []; ca = [];
% 
% % --- 5) Loop over PC fibres & record intersections ---
% for sub_i = 1:nMembers
%     i = members(sub_i);              % global fibre ID
%     neigh_local = neighborIdx{sub_i};
%     neigh_local(neigh_local == sub_i) = [];    % drop self
%     % map back to global IDs and enforce j>i
%     neigh = members(neigh_local);
%     neigh = neigh(neigh > i);
% 
%     for j = neigh'
%         [ec, pi, pj] = intersection2(Fiber, i, j, ContactDistance, flt, lambda);
%         if ec == 1
%             pi = pi(:)';  pj = pj(:)';   % force to 1×3
% 
%             % first intersection node
%             PI2(cou,   :) = [cou,   pi,   cou+1];
%             ica(end+1)    = i;
%             jca(end+1)    = j;
%             ca(end+1)     = cou;
%             cou = cou + 1;
% 
%             % second intersection node
%             PI2(cou,   :) = [cou,   pj,   cou-1];
%             ica(end+1)    = j;
%             jca(end+1)    = i;
%             ca(end+1)     = cou;
%             cou = cou + 1;
%         end
%     end
% end
% 
% % --- 6) Build adjacency & sanity‐check connectivity ---
% API = sparse(ica, jca, ca, N, N);
% isolated = members( sum(API(members,members), 2) == 0 );
% if ~isempty(isolated)
%     warning('These percolating‐cluster fibres have no fibre–fibre contacts: %s', mat2str(isolated'));
% else
%     disp('All fibres in the percolating cluster have at least one intersection.');
% end
% 
% 
% 

Fiber2 = Fiber;
save('Fiber2Data.mat','Fiber2','neighborIdx');
% Inputs you can tweak:

% if CheckPlot == true
% 
% lineW    = 2;    % line width
% fontSz   = 12;   % font size for labels
% 
% labels       = Fiber2(:,8);
% uniqueClusts = unique(labels);
% colors       = lines(length(uniqueClusts));
% 
% figure; hold on;
% for ci = 1:length(uniqueClusts)
%     c   = uniqueClusts(ci);
%     col = colors(ci,:);
%     idx = find(labels==c);
%     for k = idx'
%         x = [Fiber2(k,1), Fiber2(k,3)];
%         y = [Fiber2(k,2), Fiber2(k,4)];
%         z = [Fiber2(k,13),Fiber2(k,14)];
%         plot3(x,y,z,'LineWidth',lineW,'Color',col);
% 
%         % label at the midpoint:
%         xm = mean(x);
%         ym = mean(y);
%         zm = mean(z);
%         text(xm,ym,zm, sprintf('%d',k), ...
%              'FontSize',fontSz, ...
%              'HorizontalAlignment','center', ...
%              'VerticalAlignment','middle', ...
%              'Color','k');
%     end
% end
% 
% axis equal tight
% xlabel('X'); ylabel('Y'); zlabel('Z');
% view(3); grid on;
% title('Fiber Network: clusters & IDs');
% hold off;
% end




% --- before your intersection loop, initialize union-find ---
 

    function r = find_set(x)
        if parent(x) ~= x
            parent(x) = find_set(parent(x));
        end
        r = parent(x);
    end

    function union_set(a,b)
        ra = find_set(a);
        rb = find_set(b);
        if ra ~= rb
            parent(rb) = ra;
        end
    end


end
