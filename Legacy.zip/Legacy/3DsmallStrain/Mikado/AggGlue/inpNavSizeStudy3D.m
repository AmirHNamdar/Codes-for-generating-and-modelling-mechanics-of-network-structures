clear
clc
close all



% this script creates a series inp file to do a study of effect of size of
% lambda (Study box size) in small deformation of Mikado netowrks.

% The simulation happens to get bulk and shear modulus and then poisson
% ratio is extracted. We will have different box sizes and different nnG (as
% defined below).

% The necessary input___________________________________________________________________________
% Specific input for generating the network

% General input for generating the network
radius = 1e-4; % the diameter of a single fibre
density = 1e6; % number of fibre centre in a unit volume
L=1e-2; % Length of fibers
flt = 10^(-4)*L; % fibre lenght treshold. Edges smaller than flt will be deleted.
ContactDistance = radius*8; % the distance below which the contact occures
MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio
e = 100; % elastic modulus of beams
g = e/2/(1+Matnu);
% inpName = 'TestAll'; % name of the .inp file
CheckPlot = false; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = false; % to check the time of excution of each main function
outFolder = '/home/m60315an/abaqus/Abaqus/GeneratingInputFile/3D/Mikado/BCStudy';
% outFolder = '/Users/Code/Abaqus/GeneratingInputFile/3D/Mikado/BCStudy';

% I will have two loops (the first one for the density and the other for the nnG)


lambda2 = [2,3,4,5,6,7]*L; % side length of the box
% lambda2 = [2,3,4,5];
% lambda2 = [6,7];
nnG2 = [7,8,9,10,15]; % number of nodes in each group for BC matter
NO2 = [24,24,12,12,6,6]; % number of observation
% NO2 = [48,36,24,12];
% NO2 = [12,12];




nS = size(lambda2,2);
tic
for i = 5:5
    i
    lambda = lambda2(1,i);
%     N = (lambda+2).^3.*density; % number of fibres data [initial nf, final nf, number of increase in each step]
    N = floor((lambda+2*L)^3*density/L);
    x = [0 lambda]; % boundary of x direction
    y = [0 lambda]; % boundary of y direction
    z = [0 lambda];
    
    defHShear = [0 1/1000 0;
            0 0 0;
            0 0 0]; % the appllied farfield BC
        
%     defHBulk = [1/1000 0 0;
%             0 1/1000 0;
%             0 0 1/1000]; % the appllied farfield BC

    % number of observation for each case depending on the size
    NO = NO2(1,i);
    
    parfor j=1:NO
        % create the netwrok
        [SDataH,SDataV,Fiber,Per,SDatatest,CoupleNodes,DataRaw] = NetworkSemiRand(x,y,z,L,N,lambda,flt,density,ContactDistance,CheckPlot,timeCheck);
        
        if Per == false % if the network not percoalted 
            disp('not percolated network')
        else
            NE = SDataV(1,8); % number of edges
            NN = SDataV(1,9); % number of nodes 
            PN = SDataV(1:NN,1:5); % position of nodes
            ED = SDataV(1:NE,6:7); % position of edges
            nrb = SDataV(1,10); % number of right boundary node (x +)
            nlb = SDataV(2,10); % number of left boundary node (x -)
            ntb = SDataV(3,10); % number of top boundary node (y +)
            nbb = SDataV(4,10); % number of botttom boundary node (y -)
            nfb = SDataV(5,10); % number of front boundary node (z +)
            nreb = SDataV(6,10); % number of rear boundary node (z -)
            nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes

            % write various .inp file for different nnGs and BC.
            % in the nase it should be clear which shear/bulk are for the same
            % network and nnG so that the poisson ratio can be investigated.
            
            if sum(CoupleNodes(:,1) == CoupleNodes(:,2)) == 0 % there was a problem for one incident
                
            for k =1:1 
                if k == 1
                    defH = defHShear;
                else
                    defH = defHBulk;
                end

                nBCnnG = size(nnG2,2);
                for l = 1:nBCnnG
                    nnG = nnG2(1,l);

                    % inpName should be specified here
                    inpName = strcat('Size-','Den',num2str(density),'radius',num2str(radius),'ContactDistance',num2str(ContactDistance),'lambda',num2str(lambda),'L',num2str(L),'nnG',num2str(nnG),'Observ',num2str(j));

                    

                    % calculating the equation needed for BC___________________________________________________________________________
                    
                    [equations,errorArea] = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nfb,nreb,nnG,defH);
                    
                    % I also need to save the data to use in the PP section
%                     save(inpName)

                    % writing the .inp file___________________________________________________________________________
                    if errorArea == false
                        
                    [ToPrint,prp] = writeFunction(PN,ED,inpName,radius,MatDen,Matnu,e,equations,nbn,lambda,CoupleNodes,CheckPlot,outFolder);
                        
                    end
                end
            end
            end
        end
    end
end

timeAll = toc
        






