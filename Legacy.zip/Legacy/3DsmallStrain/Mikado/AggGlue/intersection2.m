function [ec,pii,pj] = intersection2(Fiber,i,j,ContactDistance,flt,lambda)
    % Inputs:
    % P1, Q1: Endpoints of the first line segment [x, y, z].
    % P2, Q2: Endpoints of the second line segment [x, y, z].
    % Output:
    % d_min: Minimum distance between the two segments.
    A = [Fiber(i,1); Fiber(i,2); Fiber(i,13)];
    B = [Fiber(i,3); Fiber(i,4); Fiber(i,14)];
    C = [Fiber(j,1); Fiber(j,2); Fiber(j,13)];
    D = [Fiber(j,3); Fiber(j,4); Fiber(j,14)];
    ec = 0;
    pii = [];
    pj = [];
    % Direction vectors of the segments
    
    % Direction vectors of the segments
    u = B - A;
    v = D - C;
    w0 = A - C;

   
    % Compute dot products
%     a = dot(u, u);
%     b = dot(u, v);
%     c = dot(v, v);
%     d = dot(u, w0);
%     e = dot(v, w0);
    a = u(1)^2+u(2)^2+u(3)^2;
    b = u(1)*v(1) + u(2)*v(2) + u(3)*v(3);
    c = v(1)^2+v(2)^2+v(3)^2;
    d = u(1)*w0(1) + u(2)*w0(2) + u(3)*w0(3);
    e = v(1)*w0(1) + v(2)*w0(2) + v(3)*w0(3);
    
    % Compute the denominator
    denom = a * c - b^2;
    epsilon = lambda*1e-8; % Small threshold to check for parallelism

    % Initialize s and t
    s = 0;
    t = 0;

    if denom > epsilon
        % Lines are not parallel, compute s and t
        s = (b * e - c * d) / denom;
        t = (a * e - b * d) / denom;

        % Clamp s and t to [0,1]
        s_clamped = max(0, min(1, s));
        t_clamped = max(0, min(1, t));
    else
        % Lines are nearly parallel
        s_clamped = 0;
        % Compute t for s = 0
%         t = (b * s_clamped + e) / c;
        t = e / c;
        t_clamped = max(0, min(1, t));
    end

    % Compute the closest points
    P = A + s_clamped * u;
    Q = C + t_clamped * v;

    % Compute the distance between the closest points
%     distance_PQ = norm(P - Q);
    diff_PQ = P - Q;
    distance_PQ = sqrt(diff_PQ(1)^2 + diff_PQ(2)^2 + diff_PQ(3)^2);
    
    if s_clamped == s && t_clamped == t
        pP = P;
        pQ = Q;
        min_distance = distance_PQ;
    else

    % Compute distances from endpoints to opposite segments
    distances = zeros(4,1);
%     PointOfDistanceP = zeros(4,3);
%     PointOfDistanceQ = zeros(4,3);
    
    % Distance from A to segment CD
%     t_A = dot(v, (A - C)) / c;
%     temp1 = A - C;
    temp1 = w0;
    t_A = (v(1)*temp1(1) + v(2)*temp1(2) + v(3)*temp1(3))/c;
    t_A_clamped = max(0, min(1, t_A));
    Q_A = C + t_A_clamped * v;
%     distances(1) = norm(A - Q_A);
    diff_A_QA = A - Q_A;
    distances(1) = sqrt(diff_A_QA(1)^2 + diff_A_QA(2)^2 + diff_A_QA(3)^2);
%     PointOfDistanceP(1,:) = A;
%     PointOfDistanceQ(1,:) = Q_A;

    % Distance from B to segment CD
%     t_B = dot(v, (B - C)) / c;
    temp1 = B - C;
    t_B = (v(1)*temp1(1) + v(2)*temp1(2) + v(3)*temp1(3))/c;
    t_B_clamped = max(0, min(1, t_B));
    Q_B = C + t_B_clamped * v;
%     distances(2) = norm(B - Q_B);
    diff_B_QB = B - Q_B;
    distances(2) = sqrt(diff_B_QB(1)^2 + diff_B_QB(2)^2 + diff_B_QB(3)^2);
%     PointOfDistanceP(2,:) = B;
%     PointOfDistanceQ(2,:) = Q_B;
    
    % Distance from C to segment AB
%     s_C = dot(u, (C - A)) / a;
%     temp1 = C - A;
    temp1 = -w0;
    s_C = (u(1)*temp1(1) + u(2)*temp1(2) + u(3)*temp1(3))/a;
    s_C_clamped = max(0, min(1, s_C));
    P_C = A + s_C_clamped * u;
%     distances(3) = norm(C - P_C);
    diff_PC_C = P_C - C;
    distances(3) = sqrt(diff_PC_C(1)^2 + diff_PC_C(2)^2 + diff_PC_C(3)^2);
%     PointOfDistanceP(3,:) = P_C;
%     PointOfDistanceQ(3,:) = C;
    
    % Distance from D to segment AB
%     s_D = dot(u, (D - A)) / a;
    temp1 = D - A;
    s_D = (u(1)*temp1(1) + u(2)*temp1(2) + u(3)*temp1(3))/a;
    s_D_clamped = max(0, min(1, s_D));
    P_D = A + s_D_clamped * u;
%     distances(4) = norm(D - P_D);
    diff_PD_D = P_D - D;
    distances(4) = sqrt(diff_PD_D(1)^2 + diff_PD_D(2)^2 + diff_PD_D(3)^2);
%     PointOfDistanceP(4,:) = P_D;
%     PointOfDistanceQ(4,:) = D;
    
    % Find the minimal distance
%     min_distance = min([distance_PQ; distances]);
    
%     [distance_PQ; distances];
    
%     temp = find([distance_PQ; distances]==min([distance_PQ; distances]));
%     if temp(1,1) == 1
%         pP = P;
%         pQ = Q;
%     elseif temp(1,1) == 2
%         pP = PointOfDistanceP(1,:);
%         pQ = PointOfDistanceQ(1,:);
%     elseif temp(1,1) == 3
%         pP = PointOfDistanceP(2,:);
%         pQ = PointOfDistanceQ(2,:);
%     elseif temp(1,1) == 4
%         pP = PointOfDistanceP(3,:);
%         pQ = PointOfDistanceQ(3,:);
%     elseif temp(1,1) == 5
%         pP = PointOfDistanceP(4,:);
%         pQ = PointOfDistanceQ(4,:);
%     end
    % Find the minimal distance
    [min_distance, idx] = min([distance_PQ; distances]);
    
    % Assign the closest points based on idx
    switch idx
        case 1
            pP = P;
            pQ = Q;
        case 2
            pP = A;
            pQ = Q_A;
        case 3
            pP = B;
            pQ = Q_B;
        case 4
            pP = P_C;
            pQ = C;
        case 5
            pP = P_D;
            pQ = D;
    end
    
    end
    
    if min_distance < ContactDistance
        ec = 1;
        pii = pP; % position of intersection in line i
        pj = pQ; % position of intersection in line j 
    end
    
    % i do not want the nodes to appear on the boundary
    dislocationN1 = flt*2; % how much the node should dislocate?
    dislocationN2 = lambda - flt*2;
    

%     indices1 = find(pii == 0);
%     if ~isempty(indices1)
%         switch indices1
%             case 1
%                 pii(1,1) = dislocationN1;
%             case 2
%                 pii(2,1) = dislocationN1;
%             case 3 
%                 pii(3,1) = dislocationN1;
%         end
%         pii
%     end
%     indices2 = find(pii == lambda);
%     if ~isempty(indices2)
%         switch indices2
%             case 1
%                 pii(1,1) = dislocationN2;
%             case 2
%                 pii(2,1) = dislocationN2;
%             case 3 
%                 pii(3,1) = dislocationN2;
%         end
%         pii
%     end
%     
%     indices3 = find(pj == 0);
%     if ~isempty(indices3)
%         switch indices3
%             case 1
%                 pj(1,1) = dislocationN1;
%             case 2
%                 pj(2,1) = dislocationN1;
%             case 3 
%                 pj(3,1) = dislocationN1;
%         end
%         pj
%     end
%     indices4 = find(pj == lambda);
%     if ~isempty(indices4)
%         switch indices4
%             case 1
%                 pj(1,1) = dislocationN2;
%             case 2
%                 pj(2,1) = dislocationN2;
%             case 3 
%                 pj(3,1) = dislocationN2;
%         end
%         pj
%     end
    
    
    
%     dislocationN1 = flt*2; % how much the node should dislocate?
%     dislocationN2 = lambda - flt*2;
%     
    x1i = A(1,1);
    x2i = B(1,1);
    y1i = A(2,1);
    y2i = B(2,1);
    z1i = A(3,1);
    z2i = B(3,1);
    
    x1j = C(1,1);
    x2j = D(1,1);
    y1j = C(2,1);
    y2j = D(2,1);
    z1j = C(3,1);
    z2j = D(3,1);
    
if ~isempty(pii)
%     indices1 = find(pii == 0);
    % if any of pii is zero (computational zero)
%     indices11 = find(pii < 1e-10 & pii > -1e-10 );
    indices1 = nonzeros((pii < 1e-10 & pii > -1e-10 ).*[1:3]');
%     if ~isempty(indices11)
%         indices1 == indices11
%     end
    if ~isempty(indices1)
        switch indices1
            case 1
                t = (dislocationN1 - x1i) / (x2i - x1i);
            case 2
                t = (dislocationN1 - y1i) / (y2i - y1i);
            case 3 
                t = (dislocationN1 - z1i) / (z2i - z1i);
        end
%         pii
        pii(1,1) = x1i + t*(x2i-x1i);
        pii(2,1) = y1i + t*(y2i-y1i);
        pii(3,1) = z1i + t*(z2i-z1i);
%         pii
%         t
    end
%     indices2 = find(pii == lambda);
%     indices2 = find(pii < lambda + 1e-10 & pii > lambda - 1e-10 );
    indices2 = nonzeros((pii < lambda + 1e-10 & pii > lambda - 1e-10 ).*[1:3]');
    if ~isempty(indices2)
        switch indices2
            case 1
                t = (dislocationN2 - x1i) / (x2i - x1i);
            case 2
                t = (dislocationN2 - y1i) / (y2i - y1i);
            case 3 
                t = (dislocationN2 - z1i) / (z2i - z1i);
        end
%         pii
        pii(1,1) = x1i + t*(x2i-x1i);
        pii(2,1) = y1i + t*(y2i-y1i);
        pii(3,1) = z1i + t*(z2i-z1i);
%         pii
%         t
    end
    
%     indices3 = find(pj == 0);
%     indices3 = find(pj < 1e-10 & pj > -1e-10 );
    indices3 = nonzeros((pj < 1e-10 & pj > -1e-10 ).*[1:3]');
    if ~isempty(indices3)
        switch indices3
            case 1
                t = (dislocationN1 - x1j) / (x2j - x1j);
            case 2
                t = (dislocationN1 - y1j) / (y2j - y1j);
            case 3 
                t = (dislocationN1 - z1j) / (z2j - z1j);
        end
%         pj
        pj(1,1) = x1j + t*(x2j-x1j);
        pj(2,1) = y1j + t*(y2j-y1j);
        pj(3,1) = z1j + t*(z2j-z1j);
%         pj
%         t
    end
%     indices4 = find(pj == lambda);
%     indices4 = find(pj < lambda + 1e-10 & pj > lambda - 1e-10 );
    indices4 = nonzeros((pj < lambda + 1e-10 & pj > lambda - 1e-10 ).*[1:3]');
    if ~isempty(indices4)
        switch indices4
            case 1
                t = (dislocationN2 - x1j) / (x2j - x1j);
            case 2
                t = (dislocationN2 - y1j) / (y2j - y1j);
            case 3 
                t = (dislocationN2 - z1j) / (z2j - z1j);
        end
%         pj
        pj(1,1) = x1j + t*(x2j-x1j);
        pj(2,1) = y1j + t*(y2j-y1j);
        pj(3,1) = z1j + t*(z2j-z1j);
%         pj
%         t
    end
end
    
    
    
end
