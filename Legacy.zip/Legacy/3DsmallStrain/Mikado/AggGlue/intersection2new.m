function [ec, pi, pj] = intersection2new(Fiber,i,j,ContactDistance,flt,lambda)
    % Unpack endpoints
    A = [Fiber(i,1);  Fiber(i,2);  Fiber(i,13)];
    B = [Fiber(i,3);  Fiber(i,4);  Fiber(i,14)];
    C = [Fiber(j,1);  Fiber(j,2);  Fiber(j,13)];
    D = [Fiber(j,3);  Fiber(j,4);  Fiber(j,14)];

    % Direction vectors
    u = B - A;
    v = D - C;
    w = A - C;

    % Dot‐products
    a = dot(u,u);
    b = dot(u,v);
    c = dot(v,v);
    d = dot(u,w);
    e = dot(v,w);

    % Solve for unconstrained (s,t)
    denom = a*c - b^2;
    epsD  = 1e-8;
    if denom > epsD
        s = ( b*e - c*d ) / denom;
        t = ( a*e - b*d ) / denom;
    else
        % nearly parallel: project A onto CD
        s = 0;
        t = e/c;
    end

    % Clamp into [0,1]
    s_cl = max(0, min(1, s));
    t_cl = max(0, min(1, t));

    % Compute the candidate closest points
    P  = A + s_cl*u;
    Q  = C + t_cl*v;
    d1 = norm(P - Q);

    % A→CD
    tA = max(0, min(1, dot(v, A-C)/c));
    QA = C + tA*v;
    d2 = norm(A - QA);

    % B→CD
    tB = max(0, min(1, dot(v, B-C)/c));
    QB = C + tB*v;
    d3 = norm(B - QB);

    % C→AB
    sC = max(0, min(1, dot(u, C-A)/a));
    PC = A + sC*u;
    d4 = norm(C - PC);

    % D→AB
    sD = max(0, min(1, dot(u, D-A)/a));
    PD = A + sD*u;
    d5 = norm(D - PD);

    % Pick the true minimum
    [minD, idx] = min([d1; d2; d3; d4; d5]);

    % Assign the corresponding closest‐point pair
    switch idx
      case 1, pP = P;  pQ = Q;
      case 2, pP = A;  pQ = QA;
      case 3, pP = B;  pQ = QB;
      case 4, pP = PC; pQ = C;
      case 5, pP = PD; pQ = D;
    end

    % Dislocate if exactly on the boundary planes (optional)
    tol = 1e-10;
    dis1 = 2*flt;
    dis2 = lambda - 2*flt;
    for point = {'pP','pQ'}
        pt = eval(point{1});
        % x‐boundary
        if abs(pt(1)-0)   < tol, pt(1) = dis1; end
        if abs(pt(1)-lambda) < tol, pt(1) = dis2; end
        % y‐boundary
        if abs(pt(2)-0)   < tol, pt(2) = dis1; end
        if abs(pt(2)-lambda) < tol, pt(2) = dis2; end
        % z‐boundary
        if abs(pt(3)-0)   < tol, pt(3) = dis1; end
        if abs(pt(3)-lambda) < tol, pt(3) = dis2; end
        eval([point{1} ' = pt;']);
    end

    % Intersection flag
    ec = (minD <= ContactDistance);

    % Outputs
    if nargout>1, pi = pP; end
    if nargout>2, pj = pQ; end
end
