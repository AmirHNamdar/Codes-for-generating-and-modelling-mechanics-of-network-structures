function [ec,pii,pj] = intersection4(Fiber,i,j,ContactDistance,flt,lambda)

    ec = 0;
    pii = [];
    pj = [];
    
    

  % Extract endpoints
  A = [Fiber(i,1); Fiber(i,2); Fiber(i,13)];
  B = [Fiber(i,3); Fiber(i,4); Fiber(i,14)];
  C = [Fiber(j,1); Fiber(j,2); Fiber(j,13)];
  D = [Fiber(j,3); Fiber(j,4); Fiber(j,14)];

  % Direction vectors
  u = B - A;
  v = D - C;
  w = A - C;

  % Dot products
  a = dot(u,u);  b = dot(u,v);  c = dot(v,v);
  d = dot(u,w);  e = dot(v,w);

  % Solve for the unconstrained parameters
  denom = a*c - b^2;
  epsD  = lambda*1e-8;
  if denom > epsD
    s = ( b*e - c*d ) / denom;
    t = ( a*e - b*d ) / denom;
  else
    % nearly parallel: project A onto CD
    s = 0;
    t = e / c;
  end

  % Always clamp into [0,1]
  s_cl = max(0, min(1, s));
  t_cl = max(0, min(1, t));

  % Compute the four “endpoint‐to‐opposite‐segment” distances
  % plus the interior–interior distance
  distances = zeros(5,1);
  P   = A + s_cl*u;
  Q   = C + t_cl*v;
  distances(1)  = norm(P - Q);
  % A→CD
  tA  = max(0, min(1, dot(v, (A-C))/c));
  QA  = C + tA*v;
  distances(2)  = norm(A - QA);
  % B→CD
  tB  = max(0, min(1, dot(v, (B-C))/c));
  QB  = C + tB*v;
  distances(3)  = norm(B - QB);
  % C→AB
  sC  = max(0, min(1, dot(u, (C-A))/a));
  PC  = A + sC*u;
  distances(4)  = norm(C - PC);
  % D→AB
  sD  = max(0, min(1, dot(u, (D-A))/a));
  PD  = A + sD*u;
  distances(5)  = norm(D - PD);
    
    
    
    
    [min_distance, idx] = min(distances);
    
    % Assign the closest points based on idx
    switch idx
        case 1
            pP = P;
            pQ = Q;
        case 2
            pP = A;
            pQ = QA;
        case 3
            pP = B;
            pQ = QB;
        case 4
            pP = PC;
            pQ = C;
        case 5
            pP = PD;
            pQ = D;
    end
    

    
    if min_distance < ContactDistance
        ec = 1;
        pii = pP; % position of intersection in line i
        pj = pQ; % position of intersection in line j 
    end
    
    % i do not want the nodes to appear on the boundary
    dislocationN1 = flt*2; % how much the node should dislocate?
    dislocationN2 = lambda - flt*2;
    

%     indices1 = find(pii == 0);
%     if ~isempty(indices1)
%         switch indices1
%             case 1
%                 pii(1,1) = dislocationN1;
%             case 2
%                 pii(2,1) = dislocationN1;
%             case 3 
%                 pii(3,1) = dislocationN1;
%         end
%         pii
%     end
%     indices2 = find(pii == lambda);
%     if ~isempty(indices2)
%         switch indices2
%             case 1
%                 pii(1,1) = dislocationN2;
%             case 2
%                 pii(2,1) = dislocationN2;
%             case 3 
%                 pii(3,1) = dislocationN2;
%         end
%         pii
%     end
%     
%     indices3 = find(pj == 0);
%     if ~isempty(indices3)
%         switch indices3
%             case 1
%                 pj(1,1) = dislocationN1;
%             case 2
%                 pj(2,1) = dislocationN1;
%             case 3 
%                 pj(3,1) = dislocationN1;
%         end
%         pj
%     end
%     indices4 = find(pj == lambda);
%     if ~isempty(indices4)
%         switch indices4
%             case 1
%                 pj(1,1) = dislocationN2;
%             case 2
%                 pj(2,1) = dislocationN2;
%             case 3 
%                 pj(3,1) = dislocationN2;
%         end
%         pj
%     end
    
    
    
%     dislocationN1 = flt*2; % how much the node should dislocate?
%     dislocationN2 = lambda - flt*2;
%     
    x1i = A(1,1);
    x2i = B(1,1);
    y1i = A(2,1);
    y2i = B(2,1);
    z1i = A(3,1);
    z2i = B(3,1);
    
    x1j = C(1,1);
    x2j = D(1,1);
    y1j = C(2,1);
    y2j = D(2,1);
    z1j = C(3,1);
    z2j = D(3,1);
    
if ~isempty(pii)
%     indices1 = find(pii == 0);
    % if any of pii is zero (computational zero)
%     indices11 = find(pii < 1e-10 & pii > -1e-10 );
    indices1 = nonzeros((pii < 1e-10 & pii > -1e-10 ).*[1:3]');
%     if ~isempty(indices11)
%         indices1 == indices11
%     end
    if ~isempty(indices1)
        switch indices1
            case 1
                t = (dislocationN1 - x1i) / (x2i - x1i);
            case 2
                t = (dislocationN1 - y1i) / (y2i - y1i);
            case 3 
                t = (dislocationN1 - z1i) / (z2i - z1i);
        end
%         pii
        pii(1,1) = x1i + t*(x2i-x1i);
        pii(2,1) = y1i + t*(y2i-y1i);
        pii(3,1) = z1i + t*(z2i-z1i);
%         pii
%         t
    end
%     indices2 = find(pii == lambda);
%     indices2 = find(pii < lambda + 1e-10 & pii > lambda - 1e-10 );
    indices2 = nonzeros((pii < lambda + 1e-10 & pii > lambda - 1e-10 ).*[1:3]');
    if ~isempty(indices2)
        switch indices2
            case 1
                t = (dislocationN2 - x1i) / (x2i - x1i);
            case 2
                t = (dislocationN2 - y1i) / (y2i - y1i);
            case 3 
                t = (dislocationN2 - z1i) / (z2i - z1i);
        end
%         pii
        pii(1,1) = x1i + t*(x2i-x1i);
        pii(2,1) = y1i + t*(y2i-y1i);
        pii(3,1) = z1i + t*(z2i-z1i);
%         pii
%         t
    end
    
%     indices3 = find(pj == 0);
%     indices3 = find(pj < 1e-10 & pj > -1e-10 );
    indices3 = nonzeros((pj < 1e-10 & pj > -1e-10 ).*[1:3]');
    if ~isempty(indices3)
        switch indices3
            case 1
                t = (dislocationN1 - x1j) / (x2j - x1j);
            case 2
                t = (dislocationN1 - y1j) / (y2j - y1j);
            case 3 
                t = (dislocationN1 - z1j) / (z2j - z1j);
        end
%         pj
        pj(1,1) = x1j + t*(x2j-x1j);
        pj(2,1) = y1j + t*(y2j-y1j);
        pj(3,1) = z1j + t*(z2j-z1j);
%         pj
%         t
    end
%     indices4 = find(pj == lambda);
%     indices4 = find(pj < lambda + 1e-10 & pj > lambda - 1e-10 );
    indices4 = nonzeros((pj < lambda + 1e-10 & pj > lambda - 1e-10 ).*[1:3]');
    if ~isempty(indices4)
        switch indices4
            case 1
                t = (dislocationN2 - x1j) / (x2j - x1j);
            case 2
                t = (dislocationN2 - y1j) / (y2j - y1j);
            case 3 
                t = (dislocationN2 - z1j) / (z2j - z1j);
        end
%         pj
        pj(1,1) = x1j + t*(x2j-x1j);
        pj(2,1) = y1j + t*(y2j-y1j);
        pj(3,1) = z1j + t*(z2j-z1j);
%         pj
%         t
    end
end
    
    
    
end
