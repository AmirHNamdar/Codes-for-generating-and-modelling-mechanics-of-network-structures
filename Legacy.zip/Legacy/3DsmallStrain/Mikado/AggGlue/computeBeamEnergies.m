function [E_modes, E_elem_modes] = computeBeamEnergies(inpFile, datFile)
% computeBeamEnergies - computes energy stored in each deformation mode
% of a 3D Timoshenko beam model from Abaqus .inp and .dat files.
% Modes: axial, torsion, flexural-z (split into bending+shear), flexural-y.
%
% Inputs:
%   inpFile - path to Abaqus input (.inp) file
%   datFile - path to Abaqus output (.dat) file with nodal displacements
%
% Outputs:
%   E_modes       - struct with total energies per mode:
%                   axial, torsion, shear_z, bend_z, shear_y, bend_y, total
%   E_elem_modes  - nElem x 6 array of element energies per mode

% --- 1) Parse .inp for nodes, elements, and section props ---
[nodes, elems, props] = parseInp(inpFile);

% --- 2) Read nodal displacements from .dat (global DOFs) ---
U = readDatU(datFile, nodes(:,1));  % size = nNodes*6 x 1

% --- 3) Loop over elements and compute energies ---
nElem = size(elems,1);
E_elem_modes = zeros(nElem,6);
for i = 1:nElem
    % node IDs and coords
    n1 = elems(i,2); n2 = elems(i,3);
    x1 = nodes(n1,2:4); x2 = nodes(n2,2:4);
    % element length and unit axis
    L = norm(x2-x1);
    dc = (x2-x1)/L;
    % build stable local frame
    up = [0 0 1]; if abs(dot(dc,up))>0.9, up=[0 1 0]; end
    locy = cross(up, dc); locy = locy/norm(locy);
    locz = cross(dc, locy);
    Q = [dc; locy; locz];  % 3x3
    T = blkdiag(Q,Q,Q,Q);  % 12x12
    % extract global element DOFs
    idx = [(n1*6-5):(n1*6), (n2*6-5):(n2*6)];
    ue_g = U(idx);
    % project to local coords
    ue_l = T * ue_g;
    % build full local stiffness
    Ke = beam3D_Timoshenko_K(props.E, props.G, props.A, props.Iyy, props.Izz, props.J, props.kappa, L);
    % axial energy
    ia = [1,7];
    E_ax = 0.5 * ue_l(ia)' * Ke(ia,ia) * ue_l(ia);
    % torsion energy
    it = [4,10];
    E_tor = 0.5 * ue_l(it)' * Ke(it,it) * ue_l(it);
    % flexural-z block (u_y, phi_z)
    iz = [2,6,8,12];
    E_flex_z = 0.5 * ue_l(iz)' * Ke(iz,iz) * ue_l(iz);
    % bending (phi_z2 - phi_z1)
    dphi_z = ue_l(12) - ue_l(6);
    E_bz = 0.5 * props.E * props.Izz / L * dphi_z^2;
    % shear_z energy = flex_z - bending_z
    E_sz = E_flex_z - E_bz;
    % flexural-y block (u_z, phi_y)
    iy = [3,5,9,11];
    E_flex_y = 0.5 * ue_l(iy)' * Ke(iy,iy) * ue_l(iy);
    % bending (phi_y2 - phi_y1)
    dphi_y = ue_l(11) - ue_l(5);
    E_by = 0.5 * props.E * props.Iyy / L * dphi_y^2;
    % shear_y energy
    E_sy = E_flex_y - E_by;
    % store
    E_elem_modes(i,:) = [E_ax, E_tor, E_sz, E_bz, E_sy, E_by];
end

% --- 4) Sum totals ---
E_modes.axial   = sum(E_elem_modes(:,1));
E_modes.torsion = sum(E_elem_modes(:,2));
E_modes.shear_z = sum(E_elem_modes(:,3));
E_modes.bend_z  = sum(E_elem_modes(:,4));
E_modes.shear_y = sum(E_elem_modes(:,5));
E_modes.bend_y  = sum(E_elem_modes(:,6));
E_modes.total   = sum(struct2array(E_modes));
end

%% --- subfunctions ---
function [nodes, elems, props] = parseInp(fname)
% Parses .inp for *Node, *Element (two-node beams), and section props E,G,A,Iyy,Izz,J,kappa
fid = fopen(fname,'r'); nodes=[]; elems=[];
props = struct('E',[],'G',[],'A',[],'Iyy',[],'Izz',[],'J',[],'kappa',[]);
while ~feof(fid)
    tline = strtrim(fgetl(fid));
    if startsWith(tline,'*Node','IgnoreCase',true)
        while true
            pos=ftell(fid); line= strtrim(fgetl(fid));
            if startsWith(line,'*'), fseek(fid,pos,'bof'); break; end
            data=sscanf(line,'%f,%f,%f,%f'); nodes(end+1,:)=data';
        end
    elseif startsWith(tline,'*Element','IgnoreCase',true)
        while true
            pos=ftell(fid); line= strtrim(fgetl(fid));
            if startsWith(line,'*'), fseek(fid,pos,'bof'); break; end
            data=sscanf(line,'%f,%f,%f'); elems(end+1,:)=data';
        end
    elseif startsWith(tline,'*Solid Section','IgnoreCase',true) || startsWith(tline,'*Beam Section','IgnoreCase',true)
        vals = sscanf(tline,'%*[^,], E=%f, G=%f, A=%f, Iyy=%f, Izz=%f, J=%f, kappa=%f');
        if numel(vals)==7
            props.E=vals(1); props.G=vals(2); props.A=vals(3);
            props.Iyy=vals(4); props.Izz=vals(5); props.J=vals(6);
            props.kappa=vals(7);
        end
    end
end
fclose(fid);
end

function U = readDatU(datFile, nodeIDs)
% Reads nodal U output (U1,U2,U3,UR1,UR2,UR3) from .dat
fid = fopen(datFile,'r'); Udata=[]; reading=false;
while ~feof(fid)
    line=fgetl(fid);
    if contains(line,'U =')
        reading=true; fgetl(fid); fgetl(fid); continue;
    end
    if reading
        if isempty(line)||startsWith(strtrim(line),'***'), break; end
        nums=sscanf(line,'%f'); Udata(end+1,:)=nums';
    end
end
fclose(fid);
% assemble global U vector
nNodes = numel(nodeIDs);
U=zeros(nNodes*6,1);
for i=1:size(Udata,1)
    nid=Udata(i,1);
    idx=(nid*6-5):(nid*6);
    U(idx)=Udata(i,2:7)';
end
end
