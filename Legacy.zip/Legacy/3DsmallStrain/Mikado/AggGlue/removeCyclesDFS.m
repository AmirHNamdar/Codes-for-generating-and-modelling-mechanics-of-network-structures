function edgesNoCycle = removeCyclesDFS(edges, nNodes)
% removeCyclesDFS Removes cycles from an undirected graph using DFS.
%
%   edgesNoCycle = removeCyclesDFS(edges, nNodes)
%
%   INPUT:
%       edges   - An Nx2 matrix of edges, with each row representing [u, v].
%       nNodes  - Total number of nodes (labelled 1 to nNodes).
%
%   OUTPUT:
%       edgesNoCycle - Subset of 'edges' forming an acyclic graph.

    %--- 1. Build adjacency list (cell array), since it's handy for DFS.
    adjacencyList = cell(nNodes, 1);
    for i = 1:size(edges, 1)
        u = edges(i, 1);
        v = edges(i, 2);
        adjacencyList{u} = [adjacencyList{u}, v];
        adjacencyList{v} = [adjacencyList{v}, u];
    end

    %--- 2. Prepare for DFS traversal.
    visited = false(1, nNodes);  % Tracks if a node has been visited
    parent  = zeros(1, nNodes);  % Tracks the parent of each node in DFS
    edgesNoCycle = [];           % Will store the edges of our acyclic graph

    % DFS function using nested definition so we can access variables directly.
    function dfs(u)
        visited(u) = true;
        for v = adjacencyList{u}
            if ~visited(v)
                % We've found a tree edge, so keep it.
                edgesNoCycle = [edgesNoCycle; u, v];
                parent(v) = u;
                dfs(v);
            else
                % If 'v' is visited but isn't the parent, that edge would form a cycle.
                % We simply skip it to avoid creating a cycle.
                if v ~= parent(u)
                    % This is a back edge - do nothing, effectively removing [u, v].
                end
            end
        end
    end

    %--- 3. Run DFS from each unvisited node (graph may be disconnected).
    for node = 1:nNodes
        if ~visited(node)
            dfs(node);
        end
    end
end
