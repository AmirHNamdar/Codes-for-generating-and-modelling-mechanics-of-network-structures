function [Per,ip,pc,Fiber,timeIntersection2] = NetIntersecC(Fiber,x,y,PBN,nf,density,ContactDistance,timeIntersection2,flt,lambda,time_intersection_Check,L)

N=size(Fiber,1);
ip = 0; % intersection position
Per = false;


for i=1:N
    for j=i+1:N
%         if j~=i
            % find its contact with fiber j (if yes, ec ==1, otherwise, ec ==0)
            Mi = Fiber(i,[6 7 17]);   % [xm, ym, zm]
            Mj = Fiber(j,[6 7 17]);
%             if Fiber(i,9) - Fiber(j,9) <= 1 && Fiber(i,9) - Fiber(j,9) >= -1 &&...
%                     Fiber(i,10) - Fiber(j,10) <= 1 && Fiber(i,10) - Fiber(j,10) >= -1 && ...
%                     Fiber(i,16) - Fiber(j,16) <= 1 && Fiber(i,16) - Fiber(j,16) >= -1
            if norm(Mi - Mj) <= (L + ContactDistance)
                if time_intersection_Check == true
                    tic
                end
                [ec] = intersection2_2new(Fiber,i,j,ContactDistance,flt,lambda);
                
                if time_intersection_Check == true
                    timeIntersection2temp = toc;
                    timeIntersection2 = timeIntersection2 + timeIntersection2temp;
                end
                if ec == 1
%             ip(i,2*j-1) = xi;
%             ip(i,2*j) = yi;
%                 lfj = Fiber(j,8); %  label of fiber j
%                 for k=1:N
%                     if Fiber(k,8) == lfj
%                         Fiber(k,8) = Fiber(i,8);
%                     end
%                 end
                    li       = Fiber(i,8);
                    lj       = Fiber(j,8);
                    newLabel = min(li, lj);                % pick a consistent representative
                    mask     = (Fiber(:,8)==li) | (Fiber(:,8)==lj);
                    Fiber(mask, 8) = newLabel;             % collapse both into newLabel
                end
            end
%         end
    end
end


% % --- 0) initialize union-find
% parent = 1:N;




% % --- 1) build KD-tree & pre-filter as before ---
% xm = Fiber(:,6);  ym = Fiber(:,7);  zm = Fiber(:,17);
% midpts       = [xm, ym, zm];
% searchRadius = L + ContactDistance;
% MdlKD        = createns(midpts, 'NSMethod','kdtree');
% neighborIdx  = rangesearch(MdlKD, midpts, searchRadius);
% 
% % --- 2) union everything that truly intersects ---
% for i = 1:N
%     neigh = neighborIdx{i};
%     neigh(neigh <= i) = [];
%     for j = neigh
%         [ec,~,~] = intersection2(Fiber,i,j,ContactDistance,flt,lambda);
%         if ec==1
%             union_set(i,j);
%         end
%     end
% end
% 
% % --- 3) finalize all fibre labels in Fiber(:,8) ---
% for k = 1:N
%     Fiber(k,8) = find_set(k);
% end



cnr = []; % cluster number of right boundary 1
cnl = []; % cluster number of left boundary 2
cnt = []; % cluster number of y + boundary 3
cnb = []; % cluster number of y - boundary 4
cnf = []; % cluster number of z + boundary 5
cnre = []; % cluster number of y - boundary 6

for i = 1 : size(PBN,1)
    nf = PBN(i,4); % number of fibre
    if PBN(i,3) == 1
        cnr(end+1) = Fiber(nf,8);
    elseif PBN(i,3) == 2
        cnl(end+1) = Fiber(nf,8);
    elseif PBN(i,3) == 3
        cnt(end+1) = Fiber(nf,8);
    elseif PBN(i,3) == 4
        cnb(end+1) = Fiber(nf,8);
    elseif PBN(i,3) == 5
        cnf(end+1) = Fiber(nf,8);
    elseif PBN(i,3) == 6
        cnre(end+1) = Fiber(nf,8);
    end
end

VPer = false;
for i=1:size(cnf,2)
    for j=1:size(cnre,2)
        if cnf(1,i) == cnre(1,j)
            VPer = true;
            pc = cnf(1,i); % percolated cluster 
        end
    end
end
% % % % % % % % VPer
if VPer == true % && HPer == true
    Per = true;
end

if Per ==false
    pc = 0;
end

% 
% % 
% % --- 1) Identify percolating-cluster fibres ---
% members  = find(Fiber(:,8) == pc);   % global indices of PC fibres
% nMembers = numel(members);
% 
% % --- 2) Build midpoints for only those fibres ---
% % xm_all = 0.5*(Fiber(:,1)  + Fiber(:,3));
% % ym_all = 0.5*(Fiber(:,2)  + Fiber(:,4));
% % zm_all = 0.5*(Fiber(:,13) + Fiber(:,14));
% 
% xm_all = Fiber(:,6);
% ym_all = Fiber(:,7);
% zm_all = Fiber(:,17);
% 
% midpts  = [xm_all(members), ym_all(members), zm_all(members)];
% 
% 
% % --- 3) KD‐tree & neighbor search among PC only ---
% searchRadius = L + ContactDistance;
% MdlKD        = createns(midpts, 'NSMethod','kdtree');
% neighborIdx  = rangesearch(MdlKD, midpts, searchRadius);
% 
% % --- 4) Initialize intersection tables (continuing from your PI2,ca,etc.) ---
% cou = size(PBN,1) + 1;
% ica = []; jca = []; ca = [];
% 
% % --- 5) Loop over PC fibres & record intersections ---
% for sub_i = 1:nMembers
%     i = members(sub_i);              % global fibre ID
%     neigh_local = neighborIdx{sub_i};
%     neigh_local(neigh_local == sub_i) = [];    % drop self
%     % map back to global IDs and enforce j>i
%     neigh = members(neigh_local);
%     neigh = neigh(neigh > i);
% 
%     for j = neigh'
%         [ec, pi, pj] = intersection2(Fiber, i, j, ContactDistance, flt, lambda);
%         if ec == 1
%             pi = pi(:)';  pj = pj(:)';   % force to 1×3
% 
%             % first intersection node
%             PI2(cou,   :) = [cou,   pi,   cou+1];
%             ica(end+1)    = i;
%             jca(end+1)    = j;
%             ca(end+1)     = cou;
%             cou = cou + 1;
% 
%             % second intersection node
%             PI2(cou,   :) = [cou,   pj,   cou-1];
%             ica(end+1)    = j;
%             jca(end+1)    = i;
%             ca(end+1)     = cou;
%             cou = cou + 1;
%         end
%     end
% end
% 
% % --- 6) Build adjacency & sanity‐check connectivity ---
% API = sparse(ica, jca, ca, N, N);
% isolated = members( sum(API(members,members), 2) == 0 );
% if ~isempty(isolated)
%     warning('These percolating‐cluster fibres have no fibre–fibre contacts: %s', mat2str(isolated'));
% else
%     disp('All fibres in the percolating cluster have at least one intersection.');
% end
% 
% 





end




