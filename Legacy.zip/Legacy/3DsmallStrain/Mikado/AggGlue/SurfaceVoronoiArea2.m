function [areas, errorArea] = SurfaceVoronoiArea2(lambda, points)
% SurfaceVoronoiArea  Compute the area of Voronoi cells inside a square
%
%   [areas, errorArea] = SurfaceVoronoiArea(lambda, points)
%
%   Inputs:
%     lambda : side length of the square [0,lambda] x [0,lambda]
%     points : N×2 array of (x,y) coordinates, all within (0,0)-(lambda,lambda)
%
%   Outputs:
%     areas     : N×1 vector, area of the clipped Voronoi cell for each point
%     errorArea : logical flag, true if sum(areas) differs from lambda^2

    % Number of original points
    N = size(points,1);
    
    % Create the 8 mirror-image sets around the square
    Xx = points(:,1);
    Yy = points(:,2);
    mirrors = [
        -Xx,  Yy;
        2*lambda - Xx,  Yy;
         Xx, -Yy;
         Xx, 2*lambda - Yy;
        -Xx, -Yy;
        -Xx, 2*lambda - Yy;
        2*lambda - Xx, -Yy;
        2*lambda - Xx, 2*lambda - Yy
    ];
    
    % Combine original + mirrors
    allPts = [points; mirrors];
    
    % Compute unbounded Voronoi diagram over allPts
    
    [V, C] = voronoin(allPts);
    
    % Define the square as a polyshape for clipping
    square = polyshape([0,lambda,lambda,0], [0,0,lambda,lambda]);
    
    % Preallocate
    areas = zeros(N,1);
    
    % For each original point, clip its Voronoi cell to the square
    for i = 1:N
        cellIdx = C{i};        % indices of vertices
        vert   = V(cellIdx, :);% coordinates
        
        % Build the (possibly unbounded) polygon
        pg = polyshape(vert);
        
        % Clip to the square
        pgClip = intersect(pg, square);
        
        % Compute area
        areas(i) = area(pgClip);
    end
    errorArea = false;
    % Check that total area matches lambda^2 (within tolerance)
    if abs((sum(areas) - lambda^2)/lambda^2) > 1e-9
    disp('sum area is not close to lambda square.')
    errorArea = true;
    end
end
