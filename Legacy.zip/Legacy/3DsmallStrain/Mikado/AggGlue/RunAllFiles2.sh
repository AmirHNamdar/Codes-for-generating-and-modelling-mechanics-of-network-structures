#!/usr/bin/env bash
set -uo pipefail
shopt -s nullglob

# Portable CPU count
if command -v nproc &>/dev/null; then
  CPUS=$(nproc)
else
  CPUS=$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)
fi
echo "Using all $CPUS CPUs for each Abaqus job."

# Gather .inp files
files=(Size-*.inp)
if [ ${#files[@]} -eq 0 ]; then
  echo "No input files matching Size-*.inp found in $(pwd)." >&2
  exit 1
fi

# Arrays to track status
failed_jobs=()
skipped_jobs=()

for inp in "${files[@]}"; do
  job="${inp%.inp}"

  # 1) Skip if output already exists
  if [ -f "${job}.odb" ]; then
    echo ">>> Skipping '$job': '${job}.odb' already exists."
    skipped_jobs+=("$job")
    continue
  fi

  # 2) Run the job
  echo "=== Running job '$job' (file: $inp) with $CPUS CPUs ==="
  if abaqus job="$job" input="$inp" cpus="$CPUS" interactive; then
    echo "+++ Job '$job' completed successfully +++"
  else
    echo "!!! Job '$job' FAILED with exit code $? !!!" >&2
    failed_jobs+=("$job")
  fi
done

# Summary & write to files
echo
if [ ${#skipped_jobs[@]} -gt 0 ]; then
  echo "Skipped ${#skipped_jobs[@]} job(s) because outputs existed:"
  printf '  - %s\n' "${skipped_jobs[@]}"
  printf '%s\n' "${skipped_jobs[@]}" > skipped_jobs.txt
  echo "Names of skipped jobs have been written to skipped_jobs.txt"
fi

if [ ${#failed_jobs[@]} -gt 0 ]; then
  echo
  echo "The following ${#failed_jobs[@]} job(s) failed:"
  printf '  - %s\n' "${failed_jobs[@]}"
  printf '%s\n' "${failed_jobs[@]}" > failed_jobs.txt
  echo "Names of failed jobs have been written to failed_jobs.txt"
else
  echo
  echo "All remaining jobs finished successfully."
fi
