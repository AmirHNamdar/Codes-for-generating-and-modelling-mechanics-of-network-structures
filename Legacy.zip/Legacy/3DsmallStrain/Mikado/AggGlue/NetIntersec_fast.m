function [ip, Fiber, PI2, ED2, nrb,nlb,ntb,nbb,nfb,nreb] = NetIntersec_fast( ...
    Fiber, x, y, PBN2, nf, density, ContactDistance, flt, lambda)

  %% 1) INITIALIZE + BOUNDARY COUNTS
  N = size(Fiber,1);
  % placeholder for intersection‐points per fiber (unused here)
  ip = zeros(N, 2*N);
  % count how many PBN2 entries lie on each of the six faces
  faces = PBN2(:,3);
  cnts  = histcounts(faces, 1:7);
  [nrb,nlb,ntb,nbb,nfb,nreb] = deal( cnts(1),cnts(2),cnts(3),...
                                     cnts(4),cnts(5),cnts(6) );

  %% 2) PRE-ALLOCATE NODE & EDGE LISTS
  B = size(PBN2,1);           % number of boundary-nodes
  guessI = 10*N;              % rough upper bound on internal intersections
  PI2 = zeros(B+guessI, 5);   % [nodeID, x, y, flag_or_counterpart]
  ED2 = zeros(B+guessI, 2);   % edge list: pairs of nodeIDs

  % 2a) fill in the boundary nodes (first B rows)
  PI2(1:B,1)   = (1:B)';            
  PI2(1:B,2:4) = PBN2(:, [1 2 5]);  % x, y, boundary-flag
  nextIdx = B + 1;                  % next free row in PI2

  %% 3) BUILD KD-TREE FOR COARSE FILTER
  % use the same ±1 bounding-box test on cols 9,10,16
  coords     = Fiber(:, [9,10,16]);
  MdlKD      = createns(coords,'NSMethod','kdtree');
  neighbors  = rangesearch(MdlKD, coords, 1);

  %% 4) COLLECT INTERSECTIONS & ADJACENCY
  contacts = false(N,N);  % to feed Union-Find later
  ica = []; jca = []; ca = [];  % for sparse‐matrix API

  for i = 1:N
    nbrs = neighbors{i};
    nbrs(nbrs <= i) = [];    % only j>i

    for j = nbrs
      [ec, pi, pj] = intersection2(Fiber, i, j, ContactDistance, flt, lambda);
      if ec == 1
        % mark contact for Union-Find
        contacts(i,j) = true;
        contacts(j,i) = true;

        % ensure row-vectors
        pi = pi(:).';  
        pj = pj(:).';

        % append two new intersection nodes
        PI2(nextIdx,   :) = [ nextIdx,    pi, nextIdx+1 ];
        PI2(nextIdx+1, :) = [ nextIdx+1,  pj, nextIdx   ];

        % record for sparse adjacency (if needed for ED2)
        ica(end+1:end+2) = [ i,   j   ];
        jca(end+1:end+2) = [ j,   i   ];
        ca (end+1:end+2) = [ nextIdx, nextIdx+1 ];

        nextIdx = nextIdx + 2;
      end
    end
  end

  % trim PI2 to used rows
  PI2 = PI2(1:nextIdx-1, :);

  %% 5) UNION-FIND TO ASSIGN CLUSTER LABELS (order-independent)
  parent = 1:N;
  % helper to find root with path-compression
  function r = findp(u)
    while parent(u) ~= u
      parent(u) = parent(parent(u));
      u = parent(u);
    end
    r = u;
  end

  % perform unions for every contacting pair
  [I,J] = find(triu(contacts,1));
  for k = 1:numel(I)
    ri = findp(I(k));
    rj = findp(J(k));
    if ri~=rj
      parent(rj) = ri;
    end
  end

  % flatten all paths
  for i = 1:N
    parent(i) = findp(i);
  end

  % relabel to 1,2,3… in order of first appearance
  [~, ~, newLab] = unique(parent, 'stable');
  Fiber(:,8) = newLab;

  %% 6) BUILD EDGE LIST ED2 ALONG EACH FIBER
  API = sparse(ica, jca, ca, N, N);
  ptr = 1;
  for i = 1:N
    % 6a) boundary nodes on fiber i
    bsel    = find(PBN2(:,4)==i);
    bd_x    = PBN2(bsel,1);
    bd_idx  = bsel;

    % 6b) internal nodes (from sparse API)
    int_rows = find(API(i,:))';
    int_pts  = PI2(int_rows, 2:3);  % [x,y]

    % 6c) merge & sort by x
    pts = [ bd_x, zeros(numel(bd_x),1) ];
    idx = bd_idx;
    if ~isempty(int_pts)
      pts = [pts; int_pts];
      idx = [idx; int_rows];
    end

    if size(pts,1) > 1
      [~, ord] = sort(pts(:,1));
      seq = idx(ord);
      m   = numel(seq)-1;
      ED2(ptr:ptr+m-1, :) = [ seq(1:m), seq(2:m+1) ];
      ptr = ptr + m;
    end
  end

  % trim ED2
  ED2 = ED2(1:ptr-1, :);
end
