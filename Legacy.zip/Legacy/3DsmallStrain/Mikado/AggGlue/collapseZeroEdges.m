function [PN2, ED2, couple2] = collapseZeroEdges(PN,ED2,couple,azdE,nbn)
  % PN      : NN×5 = [ x y z  ?  partnerID ]
  % ED2     : NE×2 = [node1 node2]
  % couple  : K×2 = [node partner]
  % azdE    : M×1 = indices of zero-length edges
  % nbn     : number of boundary nodes

  NN = size(PN,1);

  %% 1) union–find merges
  parent = 1:NN;
  function r = findp(u)
    while parent(u)~=u
      u = parent(u);
    end
    r = u;
  end
  function unite(a,b)
    ra = findp(a); rb = findp(b);
    if ra~=rb
      % preserve boundary nodes as roots
      if ra<=nbn && rb>nbn
        parent(rb) = ra;
      elseif rb<=nbn && ra>nbn
        parent(ra) = rb;
      else
        parent(rb) = ra;
      end
    end
  end

  for e = azdE.'          % perform each zero-edge merge
    unite( ED2(e,1), ED2(e,2) );
  end
  % path-compress
  for k=1:NN
    parent(k) = findp(k);
  end
  parent(1:nbn) = 1:nbn;   % ensure boundary nodes stay their own parent

  %% 2) build new contiguous indices
  [uniqueReps, ~, newIdx] = unique(parent, 'stable');
  nNew = numel(uniqueReps);

  %% 3) collapse PN
  coords   = PN(:,1:3);
  partner  = PN(:,5);
  PN2      = zeros(nNew,5);
  for k = 1:nNew
    repID = uniqueReps(k);
    members = find(parent==repID);
    % if any member is boundary pick its coords, else centroid
    bnd = members(members<=nbn);
    if ~isempty(bnd)
      pick = bnd(1);
    else
      pick = members(1);
      coords(pick,:) = mean(coords(members,:),1);
    end
    PN2(k,1:3) = coords(pick,:);
    oldP = partner(members(1));
    if oldP>0
      PN2(k,5) = newIdx(oldP);
    else
      PN2(k,5) = 0;
    end
  end

  %% 4) remap ED2, drop loops & duplicates
  ED2 = newIdx(ED2);                       % apply to both columns
  ED2(ED2(:,1)==ED2(:,2),:) = [];          % drop self‐loops
  ED2 = unique(sort(ED2,2), 'rows');       % drop duplicates

  %% 5) remap couple list
  C = couple;
  m1 = C(:,1)>0;   C(m1,1) = newIdx(C(m1,1));
  m2 = C(:,2)>0;   C(m2,2) = newIdx(C(m2,2));
  C(C(:,2)==0 | C(:,1)==C(:,2),:) = [];     % remove invalid
  couple2 = C;
end
