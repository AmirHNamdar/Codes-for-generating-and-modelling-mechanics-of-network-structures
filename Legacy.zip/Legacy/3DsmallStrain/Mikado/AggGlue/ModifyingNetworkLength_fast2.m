function [SDataV,CoupleNodes] = ModifyingNetworkLength_fast2(SDataV,flt,Lf,shortF,lambda,PBN2,CheckPlot,CoupleNodes,L)




% getting data from SData
NE = SDataV(1,8); % number of edges
NN = SDataV(1,9); % number of nodes
PN = SDataV(1:NN,1:5); % position of nodes
ED2 = SDataV(1:NE,6:7); % edge direction (node 1 to node 2)
nrb = SDataV(1,10); % number of boundary nodes on right side
nlb = SDataV(2,10); % number of boundary nodes on left side
ntb = SDataV(3,10); % number of boundary nodes on top side
nbb = SDataV(4,10); % number of boundary nodes on bottom side
nfb = SDataV(5,10); % number of front boundary node
nreb = SDataV(6,10); % number of rear boundary node
nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes


L;
azdE_temp = Lf < L*1e-13;
azdE = find(azdE_temp == 1); % address of zeros distance edges
n0E = size(azdE,1); % number of zeros distance nodes
% for i=1:n0E
%     wE = azdE(i,1); % wihch edge?
%     wn1 = ED2(wE,1); % wich node?
%     wn2 = ED2(wE,2);
% %     if wn1<nbn || wn2<nbn
% %         wn1
% %         wn2
% %     end
% end

% size(azdE)
% sum(Lf(azdE,1))

if isempty(CoupleNodes)
% creating a matrix to store the couple information
couple = zeros(size(PN,1),2);
couple(1:end,1) = [1:size(PN,1)]';
couple(1:end,2) = PN(:,5);
% deleting the rows with couple(i,2) == 0

del_c = ((couple(:,2) == 0)); %.*[1:size(couple,1)]');
couple(del_c,:) = [];
else
    couple = CoupleNodes;
end



te= false;

[PN, ED2, couple] = collapseZeroEdges(PN,ED2,couple,azdE,nbn);




% sometimes we create a node that is connected to itself. we should delete
% it. The reason is stuff in hE. It is easier to do it like this.
delC = [];
for i=1:size(couple,1)
    if couple(i,1) == couple(i,2)
        delC(end+1) = i;
        
    end
end
couple(delC,:) = [];

% checking again teh size of the fibres
    
    Lf=zeros(NE,1);
for i=1:NE
    e1=ED2(i,1); % first end
    e2=ED2(i,2); % second end
    xe1 = PN(e1,2);
    ye1 = PN(e1,3);
    ze1 = PN(e1,4);
    xe2 = PN(e2,2);
    ye2 = PN(e2,3);
    ze2 = PN(e2,4);
    
    Lf(i,1) = sqrt((xe1 - xe2)^2 + (ye1 - ye2)^2 + (ze1 - ze2)^2);
end 
    shortF = Lf < flt; % is it a short fibre? (1 = yes, 0 = no)
nsF = sum(shortF(:) == 1); % number of short fibres


i = 1; % the edge that is under study
ED = ED2;
EDs = size(ED,1);

[PN, ED, couple] = collapseShortEdges(PN, ED, couple, shortF, nbn, flt);




SDataV = zeros(max(size(ED,1),size(PN,1)),10);
SDataV(1:size(PN,1),1:5) = PN;
SDataV(1:size(ED,1),6:7) = ED;
SDataV(1,8) = size(ED,1);
SDataV(1,9) = size(PN,1);
SDataV(1,10) = nrb; % in + x direction
SDataV(2,10) = nlb; % in - x direction
SDataV(3,10) = ntb; % in + y direction
SDataV(4,10) = nbb; % in - y direction
SDataV(5,10) = nfb; % in + z direction
SDataV(6,10) = nreb; % in - z direction

CoupleNodes = couple; % this still needs to be trimed since there are many instances with similar connections

del_zero1 = CoupleNodes(:,1) == 0;
CoupleNodes(del_zero1,:) = [];
del_zero2 = CoupleNodes(:,2) == 0;
CoupleNodes(del_zero2,:) = [];

for i=1:size(CoupleNodes,1)
    if CoupleNodes(i,1) == CoupleNodes(i,2)
        CoupleNodes(i,:)
        3
    end
end

 % calculating the new length and calling this fuction again if
    % neccesary
    
    NE = size(ED,1);
    NN = size(PN,1);
    

Lf=zeros(NE,1);
for i=1:NE
    e1=ED(i,1); % first end
    e2=ED(i,2); % second end
%     if e1>NN || e2 > NN
%         e1
%         e2
%         NN
%     end
    xe1 = PN(e1,2);
    ye1 = PN(e1,3);
    ze1 = PN(e1,4);
    xe2 = PN(e2,2);
    ye2 = PN(e2,3);
    ze2 = PN(e2,4);
    
    Lf(i,1) = sqrt((xe1 - xe2)^2 + (ye1 - ye2)^2 + (ze1 - ze2)^2);
end 
Lf;

    shortF = Lf < flt; % is it a short fibre? (1 = yes, 0 = no)
nsF = sum(shortF(:) == 1); % number of short fibres
    
if nsF ~=0
    SDatatest = SDataV;
    [SDataV,CoupleNodes] = ModifyingNetworkLength_fast2(SDataV,flt,Lf,shortF,lambda,PBN2,CheckPlot,CoupleNodes,L);
end














