function [SDataV,CoupleNodes] = ModifyingNetworkLength(SDataV,flt,Lf,shortF,lambda,PBN2,CheckPlot,CoupleNodes,L)

% getting data from SData
NE = SDataV(1,8); % number of edges
NN = SDataV(1,9); % number of nodes
PN = SDataV(1:NN,1:5); % position of nodes
ED2(:,1:2) = SDataV(1:NE,6:7); % edge direction (node 1 to node 2)
ED2(:,3) = SDataV(1:NE,11);
nrb = SDataV(1,10); % number of boundary nodes on right side
nlb = SDataV(2,10); % number of boundary nodes on left side
ntb = SDataV(3,10); % number of boundary nodes on top side
nbb = SDataV(4,10); % number of boundary nodes on bottom side
nfb = SDataV(5,10); % number of front boundary node
nreb = SDataV(6,10); % number of rear boundary node
nbn = nrb+nlb+ntb+nbb+nfb+nreb; % number of boundary nodes


for i=1:size(CoupleNodes,1)
    if CoupleNodes(i,1) == CoupleNodes(i,2)
        CoupleNodes(i,:)
        disp('Look at ModifyingNetworkLength 20');
    end
end


L;
azdE_temp = Lf < L*1e-13;
azdE = find(azdE_temp == 1); % address of zeros distance edges
n0E = size(azdE,1); % number of zeros distance nodes
% for i=1:n0E
%     wE = azdE(i,1); % wihch edge?
%     wn1 = ED2(wE,1); % wich node?
%     wn2 = ED2(wE,2);
% %     if wn1<nbn || wn2<nbn
% %         wn1
% %         wn2
% %     end
% end

% size(azdE)
% sum(Lf(azdE,1))

if isempty(CoupleNodes)
% creating a matrix to store the couple information
couple = zeros(size(PN,1),2);
couple(1:end,1) = [1:size(PN,1)]';
couple(1:end,2) = PN(:,5);
% deleting the rows with couple(i,2) == 0

del_c = ((couple(:,2) == 0)); %.*[1:size(couple,1)]');
couple(del_c,:) = [];
else
    couple = CoupleNodes;
end



te= false;


for i=1:n0E
    NN = size(PN,1);
    NE = size(ED2,1);
    wE = azdE(i,1); % wihch edge?
    wn1 = ED2(wE,1); % wich node?
    wn2 = ED2(wE,2);
%     if wn1<nbn || wn2<nbn
%         wn1
%         wn2
%     end

    % I delete wn1 node and change the couple
    
    % Updating the couple

    upd_c1 = nonzeros((couple(:,1) == wn1).*[1:size(couple,1)]');
    upd_c2 = nonzeros((couple(:,2) == wn1).*[1:size(couple,1)]');
    couple(upd_c1,1) = wn2;
    couple(upd_c2,2) = wn2;
    % updating the number of nodes
    upd_cn1 = (couple(:,1) > wn1);
    upd_cn2 = (couple(:,2) > wn1);
    couple(:,1) = couple(:,1) - upd_cn1;
    couple(:,2) = couple(:,2) - upd_cn2;
    

    
    % before we delete the edge we update the couple node in PN
    wnc1 = nonzeros((PN(:,5) == wn1).*[1:NN]'); % which node is the couple of the wn1
    PN(wnc1,5) = wn2; % I delete wn1 node and change the couple of its couple
    % before we delete the edge we update the ED
    wein2 = nonzeros((ED2(:,1) == wn2).*[1:NE]'); % which edge includes node 2?
    wein2_2 = nonzeros((ED2(:,2) == wn2).*[1:NE]'); % which edge includes node 2?
    wein1 = nonzeros((ED2(:,1) == wn1).*[1:NE]'); % which edge includes node 1?
    if ~isempty(wein1)
        ED2(wein1,1) = wn2;
    end
    wein1_2 = nonzeros((ED2(:,2) == wn1).*[1:NE]'); % which edge includes node 1?
    if ~isempty(wein1_2)
        ED2(wein1_2,2) = wn2;
    end
    % hE = how many times two nodes are appear in edges? it at least two
    % (for the same edge).
    hE = sum(size(wein1,1)) + sum(size(wein1_2,1)) + sum(size(wein2,1)) + sum(size(wein2_2,1));
    % deleting the node
    PN(wn1,:) = [];
    % address of couple node
    red_temp = PN(:,5) > wn1;
    PN(:,5) = PN(:,5) - red_temp;
    % address of ED
    red1_temp2 = ED2(:,1) > wn1;
    ED2(:,1) = ED2(:,1) - red1_temp2;
    red2_temp2 = ED2(:,2) >  wn1;
    ED2(:,2) = ED2(:,2) - red2_temp2;
    % deleting the ED
    ED2(wE,:) = [];
    red_temp2 = azdE(:,1) > wE;
    azdE(:,1) = azdE(:,1) - red_temp2;
    
    if hE == 2 % there was only one edge so the wn2 is also need to be deleted
        % first updating wn2
        
        if wn2 > wn1
            wn2 = wn2-1;
        end
%         disp('hE = 2')
%         wn1
%         wn2
        % connections of the wn2
        NN = size(PN,1);
        % =====================================================================
        wn2c1 = PN(wn2,5); % first connection of wn2
        % i think this can create a 0 in CoupleNodes (it is harmless as long as we delete the 0 row at the end)
        % =====================================================================
        wn2c2 = nonzeros((PN(:,5)==wn2).*[1:NN]');
%         wn2
        for l=1:size(wn2c2,1)
            PN(wn2c2(l,1),5) = wn2c1;
        end
        
            % Updating the couple
        upd_c1 = nonzeros((couple(:,1) == wn2).*[1:size(couple,1)]');
        upd_c2 = nonzeros((couple(:,2) == wn2).*[1:size(couple,1)]');
        couple(upd_c1,1) = wn2c1;
        couple(upd_c2,2) = wn2c1;
        % updating the number of nodes
        upd_cn1 = (couple(:,1) > wn2);
        upd_cn2 = (couple(:,2) > wn2);
        couple(:,1) = couple(:,1) - upd_cn1;
        couple(:,2) = couple(:,2) - upd_cn2;
        
        % deleting the node
        PN(wn2,:) = [];
        % address of couple node
        red_temp = PN(:,5) > wn2;
        PN(:,5) = PN(:,5) - red_temp;
        % address of ED
        red1_temp2 = ED2(:,1) > wn2;
        ED2(:,1) = ED2(:,1) - red1_temp2;
        red2_temp2 = ED2(:,2) >  wn2;
        ED2(:,2) = ED2(:,2) - red2_temp2;
    end
        


%     for kk =1:NE
%     if sum(ED2(:,1)==kk) == 0
%         if sum(ED2(:,2)==kk) == 0 
%             if te==false
%             kk
%             sum(size(wein1,1)) + sum(size(wein1_2,1)) + sum(size(wein2,1)) + sum(size(wein2_2,1)) 
%             te = true;
%             wn1
%             wn2
% %             wnc1
%             wein1
%             wein1_2
%             wein2
%             wein2_2
%             end
% %             sum(delN(:,1) < kk)
%         end
%     end
%     end
end



% sometimes we create a node that is connected to itself. we should delete
% it. The reason is stuff in hE. It is easier to do it like this.
delC = [];
for i=1:size(couple,1)
    if couple(i,1) == couple(i,2)
        delC(end+1) = i;
        
    end
end
couple(delC,:) = [];
% CoupleNodes = couple;
% if CheckPlot == true
%     TopTitle = '1';
%     plot3D(ED2,PN,lambda,PBN2,TopTitle,[],CoupleNodes)
% end
%     NN = size(PN,1);
% for kk =1:NN
%     if sum(ED2(:,1)==kk) == 0 && sum(ED2(:,2)==kk) == 0 
%             kk
%     end
% end

% _____________________________________________________________________________________
% delN = []; % deleting nodes
% for i=1:n0E
%     wE = azdE(i,1); % wihch edge?
%     wn1 = ED2(wE,1); % wich node?
%     wn2 = ED2(wE,2);
%     % before we delete the edge we update the couple node in PN
%     wnc1 = nonzeros((PN(:,5) == wn1).*[1:NN]'); % which node is the couple of the wn1
%     PN(wnc1,5) = wn2; % I delete wn1 node and change the couple of its couple
%     % before we delete the edge we update the ED
%     wein1 = nonzeros((ED2(:,1) == wn1).*[1:NE]'); % which edge includes node 1?
%     ED2(wein1,1) = wn2;
%     wein1_2 = nonzeros((ED2(:,2) == wn1).*[1:NE]'); % which edge includes node 1?
%     ED2(wein1_2,2) = wn2;
%     
%     delN(end+1,1) = wn1;
% end
% 
% % the ED and couple node in PN must be modified since some nodes are
% % being deleted
% size(delN)
% delN = sort(delN,'descend');
% 
% for k=1:size(delN,1)
%     red_temp = PN(:,5) >= delN(k,1);
%     PN(:,5) = PN(:,5) - red_temp;
%     
%     red1_temp2 = ED2(:,1) >= delN(k,1);
%     ED2(:,1) = ED2(:,1) - red1_temp2;
%     red2_temp2 = ED2(:,2) >= delN(k,1);
%     ED2(:,2) = ED2(:,2) - red2_temp2;
% end
% 
% % deleting the edges with zeros distance and nodes
% ED2(azdE,:) = [];
% PN(delN,:) = [];
% _____________________________________________________________________________________
for i=1:size(CoupleNodes,1)
    if CoupleNodes(i,1) == CoupleNodes(i,2)
        CoupleNodes(i,:)
        disp('Look at ModifyingNetworkLength 250');
    end
end


NE = size(ED2,1);
NN = size(PN,1);



% for kk =1:NE
%     if sum(ED2(:,1)==kk) == 0
%         if sum(ED2(:,2)==kk) == 0 
%             kk
% %             sum(delN(:,1) < kk)
%         end
%     end
% end
% % % PI2 = PN;
% % % Lf2=zeros(NE,1);
% % % for i=1:NE
% % %     e1=ED2(i,1); % first end
% % %     e2=ED2(i,2); % second end
% % %     xe1 = PI2(e1,2);
% % %     ye1 = PI2(e1,3);
% % %     ze1 = PI2(e1,4);
% % %     xe2 = PI2(e2,2);
% % %     ye2 = PI2(e2,3);
% % %     ze2 = PI2(e2,4);
% % %     
% % %     Lf2(i,1) = sqrt((xe1 - xe2)^2 + (ye1 - ye2)^2 + (ze1 - ze2)^2);
% % % end 
% % % Lf2;
% % %     shortF2 = Lf2 < flt; % is it a short fibre? (1 = yes, 0 = no)
% % % nsF2 = sum(shortF2(:) == 1); % number of short fibres
% % % 
% % % Lf2(find(shortF2 == 1),1)
% % % 
% % % NN
% % % NE


% checking again teh size of the fibres
    
    Lf=zeros(NE,1);
for i=1:NE
    e1=ED2(i,1); % first end
    e2=ED2(i,2); % second end
    xe1 = PN(e1,2);
    ye1 = PN(e1,3);
    ze1 = PN(e1,4);
    xe2 = PN(e2,2);
    ye2 = PN(e2,3);
    ze2 = PN(e2,4);
    
    Lf(i,1) = sqrt((xe1 - xe2)^2 + (ye1 - ye2)^2 + (ze1 - ze2)^2);
end 
    shortF = Lf < flt; % is it a short fibre? (1 = yes, 0 = no)
nsF = sum(shortF(:) == 1); % number of short fibres


i = 1; % the edge that is under study
ED = ED2;
EDs = size(ED,1);

while i <= EDs
    if shortF(i,1) == 1
%         cou=cou+1;
        fN = ED(i,1); % first node number
        sN = ED(i,2); % second node number
        intE = 0; % edges on top of eachother (yes: intE >= 2, no: intE = 1)
        intE = sum(ED(:,1) == fN & ED(:,2) == sN);
        intE = intE + sum(ED(:,2) == fN & ED(:,1) == sN);
        
        if intE == 1 % if there is only one edge involved between two nodes
            
        % note that I do not create a couple node for the boundary nodes
        % and do not want to create them here as well. So when a short edge
        % is connecte to the boundary node, I keep both ndoes and just
        % slightly replace the other node (a random displacement between flt and 2*flt).

        if fN <= nbn % first node is a boundary node
            % we update the position of the sN and nothing will change
            wnb = fN; % which node is hte first node. I want to look from first node (which is the boundary node) to the second
            PN(sN,2:4) = newPosition(PN,fN,sN,wnb,flt);
        elseif sN <= nbn % second node is a boundary node
            % we update the position of the fN and nothing else will change
            wnb = sN; % which node is hte first node. I want to look from first node (which is the boundary node) to the second
            PN(fN,2:4) = newPosition(PN,fN,sN,wnb,flt);
        else % there is no boundary node
            % we delete one of the nodes (sN) and update everything
            % else
            npn (1,1) = PN(fN,1); % I keep the first node and delete the second
            npn (1,2) = (PN(fN,2) + PN(sN,2))/2;
            npn (1,3) = (PN(fN,3) + PN(sN,3))/2;
            npn (1,4) = (PN(fN,4) + PN(sN,4))/2;
            npn (1,5) = PN(fN,5);
            
            % which node was connected to the deleted node?
            cdn = [];
            cdn = nonzeros((PN(:,5) == sN).*[1:size(PN,1)]'); % connection of the deleted node
            
            if PN(sN,5) ~=0
            cdn(end+1,1) = PN(sN,5);
            end
            
            if ~isempty(cdn)
                PN(cdn,5) = fN; % updating the connection
            end
            CNode = fN; % chosed node
            DNode = sN; % deleted node
            
            % updating couple

            upd_c1 = nonzeros((couple(:,1) == DNode).*[1:size(couple,1)]');
            upd_c2 = nonzeros((couple(:,2) == DNode).*[1:size(couple,1)]');
            couple(upd_c1,1) = CNode;
            couple(upd_c2,2) = CNode;
            % updating the number of nodes
            upd_cn1 = (couple(:,1) > DNode);
            upd_cn2 = (couple(:,2) > DNode);
            couple(:,1) = couple(:,1) - upd_cn1;
            couple(:,2) = couple(:,2) - upd_cn2;
            
        	PN(CNode,:) = npn;
            PN(DNode,:) = [];
            
            fNn = fN;  % fN new (since sN is deleted)
            if fN > sN
                fNn = fNn - 1;
            end
                
        % dealing with ED (updating ED) with 2 step:
        % 1- changing the direction of edges that were connected to DNode
        % 2- since we have deleted some node, we should update the number
        % of nodes in ED.
        % 3- the couple node is also need to be corrected.
        % Note: in some conditions 2 side of a triangle are below the limit
        % but the other side is above. In this condition we will end up
        % with a zero length edge that both ED(i,1) and ED(i,2) are the
        % same node. This edge must be deleted.
        
        % 1st stage:
        ED(i,:) = [];
        [rD,cD] = find(ED==DNode); % row deleted, column deleted 
        nce = size(rD,1); % number of connected edge to the deleted node
        for j = 1:nce
            ED(rD(j,1),cD(j,1)) = CNode;
        end
        
        % please note that since we have deleted some row in PN the
        % address in ED doesn't mach the correct point. It is dealt with 
        % in the coming lines.
        
        % 2nd stage:
        red1_temp2 = ED(:,1) > DNode;
        ED(:,1) = ED(:,1) - red1_temp2;
        red2_temp2 = ED(:,2) >  DNode;
        ED(:,2) = ED(:,2) - red2_temp2;
            
%         for k = 1:size(ED,1)
%             for kk = 1:2
%                 if ED(k,kk) > DNode
%                     ED(k,kk) = ED(k,kk)-1;
%                 end
%             end
%         end
        
        % 3rd stage:
        red_temp = PN(:,5) > DNode;
        PN(:,5) = PN(:,5) - red_temp;
%         for k = 1:size(PN,1)
%             if PN(k,5) > DNode
%                 PN(k,5) = PN(k,5)-1;
%             end
%         end
        
        
        %_________
        % check if deleting the second node creates a free node or not
        esN = sum(ED(:,1) == fNn);
        esN = esN + sum(ED(:,2) == fNn);
        % deleting the other node if it is a free node
        if esN == 0
            esN;
%             fNn;
            % connections of the fNn
            NN = size(PN,1);
            %======================================================================
            wn2c1 = PN(fNn,5); % first connection of wn2
            % this also can create a 0 in CoupleNodes
            %======================================================================
            wn2c2 = nonzeros((PN(:,5)==fNn).*[1:NN]');
            for l=1:size(wn2c2,1)
                PN(wn2c2(l,1),5) = wn2c1;
            end
            % deleting the node
            PN(fNn,:) = [];
            % address of couple node
            red_temp = PN(:,5) > fNn;
            PN(:,5) = PN(:,5) - red_temp;
            
            % Updating the couple
            
            upd_c1 = nonzeros((couple(:,1) == fNn).*[1:size(couple,1)]');
            upd_c2 = nonzeros((couple(:,2) == fNn).*[1:size(couple,1)]');
            couple(upd_c1,1) = wn2c1;
            couple(upd_c2,2) = wn2c1;
            % updating the number of nodes
            upd_cn1 = (couple(:,1) > fNn);
            upd_cn2 = (couple(:,2) > fNn);
            couple(:,1) = couple(:,1) - upd_cn1;
            couple(:,2) = couple(:,2) - upd_cn2;
            
            % address of ED
%             max(max(ED(:,1)),max(ED(:,2)))
            red1_temp2 = ED(:,1) > fNn;
            ED(:,1) = ED(:,1) - red1_temp2;
            red2_temp2 = ED(:,2) >  fNn;
            ED(:,2) = ED(:,2) - red2_temp2;
%             max(max(ED(:,1)),max(ED(:,2)))
        end
        %________
        
        
           
           shortF(i,:) = [];% in order to investigate the ED that is dropped to the 
                 % position of the resently deleted ED
           i = i-1;
        end
            
        elseif intE >=2 % if there exist more than one edge between two nodes
           ED (i,:) = []; 
           
           shortF(i,:) = []; % in order to investigate the ED that is dropped to the 
                 % position of the resently deleted ED
           i = i-1;
        end

    end
    i = i+1;
    EDs = size(ED,1);
end


% sometimes we create a node that is connected to itself. we should delete
% it. The reason is stuff in hE. It is easier to do it like this.
delC = [];
for i=1:size(couple,1)
    if couple(i,1) == couple(i,2)
        delC(end+1) = i;
    end
end
couple(delC,:) = [];



SDataV = zeros(max(size(ED,1),size(PN,1)),10);
SDataV(1:size(PN,1),1:5) = PN;
SDataV(1:size(ED,1),6:7) = ED(:,1:2);
SDataV(1,8) = size(ED,1);
SDataV(1,9) = size(PN,1);
SDataV(1,10) = nrb; % in + x direction
SDataV(2,10) = nlb; % in - x direction
SDataV(3,10) = ntb; % in + y direction
SDataV(4,10) = nbb; % in - y direction
SDataV(5,10) = nfb; % in + z direction
SDataV(6,10) = nreb; % in - z direction
SDataV(1:size(ED,1),11) = ED(:,3);

CoupleNodes = couple; % this still needs to be trimed since there are many instances with similar connections

del_zero1 = CoupleNodes(:,1) == 0;
CoupleNodes(del_zero1,:) = [];
del_zero2 = CoupleNodes(:,2) == 0;
CoupleNodes(del_zero2,:) = [];

for i=1:size(CoupleNodes,1)
    if CoupleNodes(i,1) == CoupleNodes(i,2)
        CoupleNodes(i,:)
        size(CoupleNodes,1)
        disp('Look at ModifyingNetworkLength 504');
    end
end

 % calculating the new length and calling this fuction again if
    % neccesary
    
    NE = size(ED,1);
    NN = size(PN,1);
    
    
    if size(nonzeros(ED(:,1) > NN)) > 0 | size(nonzeros(ED(:,2) > NN)) > 0
        disp('Look at ModifyingNetworkLength 544');
    end
    max(ED(:,1))
max(ED(:,2))
    

Lf=zeros(NE,1);
for i=1:NE
    e1=ED(i,1); % first end
    e2=ED(i,2); % second end
%     if e1>NN || e2 > NN
%         e1
%         e2
%         NN
%     end
    xe1 = PN(e1,2);
    ye1 = PN(e1,3);
    ze1 = PN(e1,4);
    xe2 = PN(e2,2);
    ye2 = PN(e2,3);
    ze2 = PN(e2,4);
    
    Lf(i,1) = sqrt((xe1 - xe2)^2 + (ye1 - ye2)^2 + (ze1 - ze2)^2);
end 
Lf;

    shortF = Lf < flt; % is it a short fibre? (1 = yes, 0 = no)
nsF = sum(shortF(:) == 1); % number of short fibres
    
if nsF ~=0
    SDatatest = SDataV;
    [SDataV,CoupleNodes] = ModifyingNetworkLength(SDataV,flt,Lf,shortF,lambda,PBN2,CheckPlot,CoupleNodes,L);
end




end