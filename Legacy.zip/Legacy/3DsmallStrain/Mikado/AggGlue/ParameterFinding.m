clear
clc
close all

% this is for parameter finding 




%% parameters
radius = 1e-4;  % fibre radius [m]
ContactDistance = radius*8; %L/5; % the distance below which the contact occures


% define ranges for L and density
L_vals       = logspace(-3, -2, 100);    % fibre lengths 
density_vals = logspace( 4, 6, 100);    % line density

% create 2D mesh
[ L_grid, rho_grid ] = meshgrid( L_vals, density_vals );

%% compute fields
phiC_c      = 0.56 * ( L_grid ./ (ContactDistance) ).^(-0.95);           % percolation threshold
phiC        = rho_grid .* (ContactDistance^2*pi/4);                         % volume fraction
phi        = rho_grid .* (radius^2*pi);                         % volume fraction
phiphi_c   = phiC ./ phiC_c;                                       % normalized phi
w          = log10( (rho_grid.*L_grid.^2).^2 .* (radius./L_grid./4).^2 );

%% plot
figure('Renderer','opengl','Position',[100 100 1200 800]);

% phi
subplot(2,2,1);
% Plot phi
h3 = surf( L_grid, rho_grid, phi, 'EdgeColor', 'none' );
% Switch X and Y axes to log scale
set(gca, 'XScale', 'log', 'YScale', 'log');
% Relabel axes
xlabel('L [m]');
ylabel('\rho_{line} [m^{-2}]');
zlabel('\phi');
title('\phi on a log–log base');
view(45,30);
colorbar;


% phi/phi_c
subplot(2,2,2);
h1 = surf( L_grid, rho_grid, phiphi_c, 'EdgeColor','none' );
set(gca, 'XScale', 'log', 'YScale', 'log');
xlabel('L [m]');
ylabel('\rho_{line} [m^{-2}]');
zlabel('\phi/\phi_c');
title('\phi / \phi_c on a log–log base');
view(45,30);
colormap('jet');
colorbar;

% w
subplot(2,2,3);
h2 = surf( L_grid, rho_grid, w, 'EdgeColor', 'none' );
% Make both horizontal axes log‑scale
set(gca, 'XScale', 'log', 'YScale', 'log');
% Relabel axes
xlabel('L [m]');
ylabel('\rho_{line} [m^{-2}]');
zlabel('w');
title('w on a log–log base');
view(45,30);
colorbar;







% 
% 
% 
% %% parameters (as before)
% radius          = 1e-5;             % fibre radius [m]
% ContactDistance = radius*2;         % contact distance
% L_vals       = logspace(-7, -3, 400);  % L grid
% density_vals = logspace( 6,  8, 400);  % rho_line grid
% [ L_grid, rho_grid ] = meshgrid( L_vals, density_vals );
% 
% %% fields (as before)
% phiC_c    = 0.56 * ( L_grid./(2*ContactDistance) ).^(-0.95);
% phiC      = rho_grid .* (ContactDistance^2*pi);
% phi       = rho_grid .* (radius^2*pi);
% phiphi_c  = phiC ./ phiC_c;
% w         = log10( (rho_grid.*L_grid.^2).^2 .* (radius./L_grid./4).^2 );
% 
% %% 1) analytic relation for w = -4
% %    w = log10( (rho*L^2)^2 * (radius/(4 L))^2 )
% %  ⇒ rho = 10^(-1.39794) / (L*radius)
% const = 10^(-1.39794);
% rho_w_line = const ./ (L_vals * radius);
% 
% %% 2) compute phiphi_c along that analytic curve
% phiC_line   = rho_w_line .* (ContactDistance^2*pi);
% phiC_c_line = 0.56 * ( L_vals./(2*ContactDistance) ).^(-0.95);
% phiphi_c_line = phiC_line ./ phiC_c_line;
% 
% %% 3) pick out the segment where phiphi_c > 5
% keep = phiphi_c_line > 5;
% L_keep   = L_vals(keep);
% rho_keep = rho_w_line(keep);
% 
% %% 4) Plot the background w-contours and overlay the feasible segment
% figure; 
% % -- background: contour of w
% contourf(L_grid, rho_grid, w, -8:0.5:0, 'LineStyle','none');
% set(gca,'XScale','log','YScale','log');
% hold on;
% 
% % -- overlay the w=-4 contour
% [C4,h4] = contour(L_grid, rho_grid, w, [-4 -4], 'LineColor','w','LineWidth',2);
% 
% % -- highlight the region of that contour where phiphi_c > 5
% plot(L_keep, rho_keep, 'r.-','MarkerSize',12);
% 
% xlabel('L [m]');
% ylabel('\rho_{line} [m^{-2}]');
% title('Region satisfying w=-4 and \phi/\phi_c>5');
% colorbar
% colormap jet
% legend([h4, NaN], 'w = -4 contour','Location','SouthWest');
