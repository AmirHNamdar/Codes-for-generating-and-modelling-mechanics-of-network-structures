function P_new = newPosition(PN,fN,sN,wnb,flt)
    
    if wnb == fN % which node is hte first node. I want to look from first node (which is the boundary node) to the second

    x1 = PN(fN,2);
    x2 = PN(sN,2);
    y1 = PN(fN,3);
    y2 = PN(sN,3);
    z1 = PN(fN,4);
    z2 = PN(sN,4);
    BP = [x1,y1,z1]; % boundary point
    NBP = [x2,y2,z2]; % non boundary point
    
    elseif wnb == sN
        
    x2 = PN(fN,2);
    x1 = PN(sN,2);
    y2 = PN(fN,3);
    y1 = PN(sN,3);
    z2 = PN(fN,4);
    z1 = PN(sN,4);
    BP = [x1,y1,z1]; % boundary point
    NBP = [x2,y2,z2]; % non boundary point
    end
    
    dislocation = flt * rand(1) + flt;
    
    direction = BP - NBP;
    unit_direction = direction/norm(direction);
    
    P_new = BP + dislocation * unit_direction;

end