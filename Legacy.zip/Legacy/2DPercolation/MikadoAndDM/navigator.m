clear
clc
close all
% in this code, the dependancy of shear modulus to direction will be
% investigated. 0.5 2.0 15 40


Pr = 0.0;
tb = 0; % type of bar 0 for rectangular bar and 1 for circular bar
thickness = 1e-4;
diam = 1e-3;
density = 5.63726; %5.63726;
wm = 2;
% =-§12e[p[ network? perfect squares = 1, random network wm = 2.
TM = true; % if timoshenko beam then true


np = 0; % number of percolated system


N2s = 1; % number of study for each Nf
Nf2 = 20000;
Nf = [Nf2,Nf2,1]; % number of fibres data [initial nf, final nf, number of increase in each step]
Ns = (Nf(1,2) - Nf(1,1))/ Nf(1,3) + 1; % number of considered density

% lambda = sqrt(Nf2/density); % ++++++++++++ ********* ---------------
lamh = sqrt(Nf2/density);
laml = 1;
er = 1;

while er>1e-12
    test = (lamh+laml)/2;
    er = abs(sqrt(Nf2/density)-test*(1+2/floor(test)));
    if sqrt(Nf2/density)-test*(1+2/floor(test))<0
        lamh = test;
    else 
        laml = test;
    end
    
end
lambda = test;

W = zeros(N2s,1); % realisations with warning (Rcond small) - 1 indicats warning.


% tCN = zeros(Ns,1); % time allocated to create the network
% tSN = zeros(Ns,1); % time allocated to solve the network

Gs = zeros(N2s,Ns);
Ge = zeros(N2s,Ns);
% mu = zeros(N2s,Ns);
tic
for j = 1:Ns


% input:
% Network generation
% lambda = 5;

% density = Nf(1,1)/(lambda+2)^2;

x=[0 lambda]; % boundary of x direction
y=[0 lambda]; % boundary of y direction
if wm == 1
N = 2 + 2*(ns); % for square beams
L = 300;
elseif wm == 2
N = Nf(1,1); % Number of fibers
L=1; % Length of fibers
end
    Gv = zeros(N2s,1);
    GvE = zeros(N2s,1);
%     mu1 = zeros(N2s,1);
for ns = 1:N2s
ns
j
flt = 10^(-3)*L/density; % fibre lenght treshold. Edges smaller than flt will be deleted.


% tic % to record time


% e = 100; % elastic modulus of beams
% Ar = 1; % cross section of beams
% I = 1; % second moment


e = 100; % elastic modulus of beams
g = e/3; % for incompressible fibres
if tb == 1
    Ar = pi*diam^2/4; % cross section of circular beams
    I = pi*diam^4/64; % second moment of circular bars 
elseif tb == 0
   Ar = thickness^2; % cross section of square beams    
   I = (thickness)^4/12; % second moment of square bars 
end

% Ar = 1;
% I = 1;
BM = (x(2)-x(1))/1000; % Boundary movement

% using function NetworkRand to generate the random network and get the data
if wm == 1
[NN,NE,ED,PN,nrb,nlb,ntb,nbb,Fiber] = SquareBeams(x,y,L,N,lambda);
elseif wm == 2
[SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRand(x,y,L,N,lambda,flt,Pr,density);
end
% toc
if Per == true
    np = np+1;
end
np
% tCN(ns,1) = toc;
if Per == false
    continue
end



NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);


% BB
% M = 0;
% sM = false;
% [fov,C3v,FFv,UUv,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);
% 
% BC(7,1) = 0;
% BC(8,1) = BM; % to investigate E
% sM = true;
% [fovE,C3vE,FFvE,UUvE,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);

% initializing BC for calculating shear modulus
BC = zeros(12,2);

% deformations
% deformations
BC(1,1) = nan; % right x (will be modified inside the code)
BC(2,1) = nan; % right y (will be modified inside the code)
BC(3,1) = nan; % right theta 
BC(4,1) = nan;  % left x (will be modified inside the code)
BC(5,1) = nan; % left y (will be modified inside the code)
BC(6,1) = nan;  % left theta
BC(7,1) = BM; % top x (will be modified inside the code)
BC(8,1) = 0; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = 0;
BC(2,2) = 0;
BC(3,2) = 0;
BC(4,2) = 0;
BC(5,2) = 0;
BC(6,2) = 0;
BC(7,2) = nan;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = nan;
BC(11,2) = nan;
BC(12,2) = nan;



% % % TB

M = 0;
M2 =0;
sM = false;
BCvx = BM; 
BCvy = 0;
% [fov,C3v,FFv,UUv,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy);

BC = zeros(12,2);
% deformations
BC(1,1) = nan; % right x (will be modified inside the code)
BC(2,1) = nan; % right y (will be modified inside the code)
BC(3,1) = 0; % right theta 
BC(4,1) = nan;  % left x (will be modified inside the code)
BC(5,1) = nan; % left y (will be modified inside the code)
BC(6,1) = 0;  % left theta
BC(7,1) = nan; % top x (will be modified inside the code)
BC(8,1) = BM; % top y (will be modified inside the code)
BC(9,1) = nan; % top theta
BC(10,1) = nan; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = nan; % bottom theta
% forces
BC(1,2) = 0;
BC(2,2) = 0;
BC(3,2) = nan;
BC(4,2) = 0;
BC(5,2) = 0;
BC(6,2) = nan;
BC(7,2) = 0;
BC(8,2) = nan;
BC(9,2) = 0;
BC(10,2) = 0;
BC(11,2) = nan;
BC(12,2) = 0;

BCvx = 0;
BCvy = BM;

sM = false;
% tic
[fovE,C3vE,FFvE,UUvE,M,w] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy,tb);
W(ns,1) = w;
% toc
% shear modulus------------------------------------------------------------
% aggregation of forces in x direction devided by rotation

% sfv = 0; % shear force on the boundary V
% for i = (nlb+nrb)+1:(nlb+nrb+ntb)
%     sfv = FFv(i*3-2,1)+sfv;
% end
% sfv2 = 0; % the force on bottom boundary (to check the equilibrium)
% for i = (nlb+nrb+ntb)+1:(nlb+nrb+ntb+nbb)
%     sfv2 = FFv(i*3-2,1)+sfv2;
% end
% 
% Gv(ns,1) = sfv/lambda / tan(BM / (y(2)-y(1)));
% UT = transpose(UUv);
% Energy = UT*M*UUv;
% shear = Energy/(BM)^2;

sfvE = 0; % shear force on the boundary V
for i = (nlb+nrb)+1:(nlb+nrb+ntb)
    sfvE = FFvE(i*3-1,1)+sfvE;
end
sfvE2 = 0; % the force on bottom boundary (to check the equilibrium)
for i = (nlb+nrb+ntb)+1:(nlb+nrb+ntb+nbb)
    sfvE2 = FFvE(i*3-1,1)+sfvE2;
end
sfvEr = 0; % right
for i = 1:(nrb)
    sfvEr = FFvE(i*3-2,1)+sfvEr;
end
sfvE;
sfvEr;
% GvE(ns,1) = sfvE/lambda / (BM/lambda);
UTE = transpose(UUvE);
Energy = UTE*M*UUvE;
young2 = Energy/(BM)^2;
GvE(ns,1) = young2;

% finding mu and then E
% mu = 1-2*shear/young2;
% young = 2*shear*(1+mu);



mu1(ns,1) = GvE(ns,1)/Gv(ns,1)/2-1;
denN(ns,1) = N;

end

% Gs(:,j) = Gv;
Ge(:,j) = GvE;
% mu(:,j) = mu1;
% GE(:,3) = Gh;
% GE(:,4) = GhE;

end


% MGs = zeros(1,Ns); % Mean of Gs 
MGe = zeros(1,Ns); % Mean of Ge



for i = 1: Ns
%     Gs2 = Gs(:,i);
    Ge2 = Ge(:,i);
    
    k=1;
    for j = 1:N2s
        if Ge2(k,1) == 0
%             Gs2(k,:)=[];
            Ge2(k,:)=[];
            k=k-1;
        end
        k=k+1;
    end
%     MGs(1,i) = mean(Gs2);
    MGe(1,i) = mean(Ge2);
end
toc
% plot(MGs)


% if wm ==1
%     save('SSdata')      %-------------------*********************
% elseif wm==2
%                                 %-------------------*********************
%     nameS = strcat('SSdensity',num2str(density),'diam',num2str(diam),'Pr',num2str(Pr*100),'lambda',num2str(lambda),'-ConvStudy');
%     save(nameS)
% end

% poly = polyfit(den,G,4);
% x1 = linspace(min(denN),max(denN));
% y1 = polyval(poly,x1);

% subplot(2,2,1)
% plot(den,G,'o')
% hold on
% plot(x1,y1)
% hold on
% subplot(2,2,2)
% plot(denN,G,'o')
% hold on
% subplot(2,2,3)
% plot(denf,G,'o')





