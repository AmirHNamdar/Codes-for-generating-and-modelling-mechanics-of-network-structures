clear
clc
close all

load Per_ConvZero_test2_Pr0Th0-1

Ms = Mslambda(7:end,:);
Me = Melambda(7:end,:);
Mg = Mglambda(7:end,:);

load Per_ConvZero_test2_Pr0Th0-2
close all
Ms = [Ms,Mslambda];
Me = [Me,Melambda];
Mg = [Mg,Mglambda];


load Per_ConvZero_test2_Pr0Th0-3
close all
Ms = [Ms,Mslambda];
Me = [Me,Melambda];
Mg = [Mg,Mglambda];

Mslambda = Ms;
Melambda = Me;
Mglambda = Mg;
N2s1 = size(Mglambda,2);

% for i = 1:size(Melambda,1)
%     Gs2 = Mslambda(i,:);
%     Ge2 = Melambda(i,:);
%     Gg2 = Mglambda(i,:);
% %     mu2 = Mmulambda(i,:);
% %     mu2v = Mmuvlambda(i,:);
%     k=1;
%     for j = 1:N2s1
%         j
%         if Ge2(1,k) == 0
%             Gs2(:,k)=[];
%             Ge2(:,k)=[];
%             Gg2(:,k)=[];
% %             mu2(:,k)=[];
% %             mu2v(:,k)=[];
%             k=k-1;
%         end
%         k=k+1;
%     end
%     MMslambda(i,1) = mean(Gs2);
%     MMelambda(i,1) = mean(Ge2);
%     MMglambda(i,1) = mean(Gg2);
% %     MMmulambda(i,1) =  mean(mu2);
% %     MMmuvlambda(i,1) =  mean(mu2v);
% end

for i = 1:size(Mslambda,1)
MMslambda(i,1) = mean(nonzeros(Mslambda(i,:)));
MMelambda(i,1) = mean(nonzeros(Melambda(i,:)));
MMglambda(i,1) = mean(nonzeros(Mglambda(i,:)));
end


















% stuff for analysing convergance to f/v

% y axis is equivalent to -log(E)/log(lambda)
% YaxisE1 = -log(MMslambda)./log(lambda2');  % higher E
% YaxisE2 = -log(MMelambda)./log(lambda2'); % lower E
% YaxisG = -log(MMglambda)./log(lambda2'); % shear

Xaxis = 1./log(lambda2');

% to evaluate error bar
% kk=0;
% for i=1:size(lambda2,2)
%     for j=1:N2s1
%         if WV(i,j) == 1
%             Mslambda(i,j) = 0;
%         end
%         if WVE(i,j) == 1
%             Melambda(i,j) = 0;
%         end
%         if WVG(i,j) == 1
%             Mglambda(i,j) = 0;
%         end
%     end
% end
% 
% for i=1:size(lambda2,2)
%     for j=1:N2s1
%         if Mslambda(i,j) <0
%             Mslambda(i,j)=0;
%         end
%         if Melambda(i,j) <0
%             Melambda(i,j)=0;
%         end       
%         if Mglambda(i,j) <0
%             Mglambda(i,j)=0;
%         end
%     end
% end


yE1_data = zeros(Nslambda,N2s1);
yE2_data = zeros(Nslambda,N2s1);
yG_data = zeros(Nslambda,N2s1);
yE1_mean = zeros(Nslambda,1);
yE2_mean = zeros(Nslambda,1);
yG_mean = zeros(Nslambda,1);
SEE1 = zeros(Nslambda,1);
SEE2 = zeros(Nslambda,1);
SEG = zeros(Nslambda,1);

for i =1:size(lambda2,2)
    for j = 1:N2s1
        if Mslambda(i,j) ~=0
            yE1_data(i,j) = -log((Mslambda(i,j)))/log(lambda2(1,i));  % higher E
        end
        if Melambda(i,j) ~=0
            yE2_data(i,j) = -log(Melambda(i,j))/log(lambda2(1,i));  % lower E
        end
        if Mglambda(i,j) ~=0
            yG_data(i,j) = -log(Mglambda(i,j))/log(lambda2(1,i));  % higher G
        end
    end
SEE1(i,1) = sqrt(var(nonzeros(yE1_data(i,:))))/sqrt(size(nonzeros(yE1_data(i,:)),1)); % standard error
SEE2(i,1) = sqrt(var(nonzeros(yE2_data(i,:))))/sqrt(size(nonzeros(yE2_data(i,:)),1));
SEG(i,1) = sqrt(var(nonzeros(yG_data(i,:))))/sqrt(size(nonzeros(yG_data(i,:)),1));

sigE1(i,1) = sqrt(var(nonzeros(yE1_data(i,:))));
sigE2(i,1) = sqrt(var(nonzeros(yE2_data(i,:))));
sigG(i,1) = sqrt(var(nonzeros(yG_data(i,:))));

% arithmatic mean
yE1_mean(i,1) = mean(nonzeros(yE1_data(i,:)));
yE2_mean(i,1) = mean(nonzeros(yE2_data(i,:)));
yG_mean(i,1) = mean(nonzeros(yG_data(i,:)));

% geometric mean
yE1_geomean(i,1) = geomean(nonzeros(yE1_data(i,:)));
yE2_geomean(i,1) = geomean(nonzeros(yE2_data(i,:)));
yG_geomean(i,1) = geomean(nonzeros(yG_data(i,:)));

% harmonic mean
yE1_harmean(i,1) = size(nonzeros(yE1_data(i,:)),1)/sum(1./(nonzeros(yE1_data(i,:))));
yE2_harmean(i,1) = size(nonzeros(yE2_data(i,:)),1)/sum(1./(nonzeros(yE2_data(i,:))));
yG_harmean(i,1) = size(nonzeros(yG_data(i,:)),1)/sum(1./(nonzeros(yG_data(i,:))));

end


fiE1 = polyfit(Xaxis,yE1_mean,1)
fiE2 = polyfit(Xaxis,yE2_mean,1)
fiG = polyfit(Xaxis,yG_mean,1)

% fiE1axis = polyfit(Xaxis,YaxisE1,1);
% fiE2axis = polyfit(Xaxis,YaxisE2,1);
% fiGaxis = polyfit(Xaxis,YaxisG,1);


% finding chi squre value
expE1 = fiE1(1).*Xaxis+fiE1(2);
expE2 = fiE2(1).*Xaxis+fiE2(2);
expG = fiG(1).*Xaxis+fiG(2);

chisquareE1 = sum(((yE1_mean - expE1) ./ sigE1).^2);
chisquareE2 = sum(((yE2_mean - expE2) ./ sigE2).^2);
chisquareG = sum(((yG_mean - expG) ./ sigG).^2);






% plot

fiE1 = polyfit(Xaxis,yE1_mean,1);
fiE2 = polyfit(Xaxis,yE2_mean,1);
fiG = polyfit(Xaxis,yG_mean,1);


xplot = linspace(0,max(1./log(lambda2'))*1.1,10000);
yplotE1 = fiE1(1).*xplot+fiE1(2);
yplotE2 = fiE2(1).*xplot+fiE2(2);
yplotG = fiG(1).*xplot+fiG(2);

% yaxisE1 = fiE1axis(1).*xplot+fiE1axis(2);
% yaxisE2 = fiE2axis(1).*xplot+fiE2axis(2);
% yaxisG = fiGaxis(1).*xplot+fiGaxis(2);


figure2 = figure;
errorbar(Xaxis,yE1_mean,SEE1,'r')
hold on
errorbar(Xaxis,yE2_mean,SEE2,'b')
hold on
errorbar(Xaxis,yG_mean,SEG,'k')
hold on
plot(xplot,yplotE1,'r')
hold on
plot(xplot,yplotE2,'b')
hold on
plot(xplot,yplotG,'k')





fiE1
fiE1geo = polyfit(Xaxis,yE1_geomean,1)
fiE1har = polyfit(Xaxis,yE1_harmean,1)
fiE2
fiE2geo = polyfit(Xaxis,yE2_geomean,1)
fiE2har = polyfit(Xaxis,yE2_harmean,1)
fiG
fiGgeo = polyfit(Xaxis,yG_geomean,1)
fiGhar = polyfit(Xaxis,yG_harmean,1)


yplotE1geo = fiE1geo(1).*xplot+fiE1geo(2);
yplotE1har = fiE1har(1).*xplot+fiE1har(2);




figure1 = figure;
plot(Xaxis,yE1_mean,'o')
hold on
plot(Xaxis,yE1_geomean,'o')
hold on
plot(Xaxis,yE1_harmean,'o')
hold on
plot(xplot,yplotE1,'r')
hold on
plot(xplot,yplotE1geo,'b')
hold on
plot(xplot,yplotE1har,'k')

% errorbar(Xaxis,yE2_geomean,'b')
% hold on
% errorbar(Xaxis,yG_geomean,'k')



% 
% figure2 = figure;
% errorbar(Xaxis,YaxisE1,SEE1,'r')
% hold on
% errorbar(Xaxis,YaxisE2,SEE2,'b')
% hold on
% errorbar(Xaxis,YaxisG,SEG,'k')
% hold on
% plot(xplot,yaxisE1,'r')
% hold on
% plot(xplot,yaxisE2,'b')
% hold on
% plot(xplot,yaxisG,'k')

% fit_function = @(params, x) params(1) + x.*(log(params(2) + exp(-params(3)./x)));
% 
% initial_params = [1, 1, 1]; % Example initial guesses: [c1, c2, w, f]
% y_data = yE2_mean;
% x_data = Xaxis;
% 
% % Fit the function to the data
% [fitted_params, resnorm, residual, exitflag, output, lambda, jacobian] = ...
%     lsqcurvefit(fit_function, initial_params, x_data, y_data);
% 
% % Display fitted parameters
% disp(['Fitted parameters: f = ' num2str(fitted_params(1)) ...
%       ', c1 = ' num2str(fitted_params(2)) ...
%       ', w = ' num2str(fitted_params(3))]);
% 
% % Generate x values for the fitted curve
% x_fit = linspace(min(x_data), max(x_data), 100);
% y_fit = fit_function(fitted_params, x_fit);
% 
% % Plot the data and the fit
% figure;
% plot(x_data, y_data, 'o', 'DisplayName', 'Data');
% hold on;
% plot(x_fit, y_fit, 'r-', 'DisplayName', 'Fit');
% xlabel('x');
% ylabel('y');
% legend;
% title('Data and Fit');
% hold off;
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 










