clear
clc
close all

load Per_ConvZero_test2_Pr80Th0-1

Ms = Mslambda(7:end);
Me = Melambda(7:end);
Mg = Mglambda(7:end);

load Per_ConvZero_test2_Pr80Th0-2

Ms = [Ms,Mslambda];
Me = [Me,Melambda];
Mg = [Mg,Mglambda];


load Per_ConvZero_test2_Pr80Th0-3

Ms = [Ms,Mslambda];
Me = [Me,Melambda];
Mg = [Mg,Mglambda];



for i = 1:size(Melambda,1)
    Gs2 = Mslambda(i,:);
    Ge2 = Melambda(i,:);
    Gg2 = Mglambda(i,:);
    mu2 = Mmulambda(i,:);
%     mu2v = Mmuvlambda(i,:);
    k=1;
    for j = 1:N2s1
        if Ge2(1,k) == 0
            Gs2(:,k)=[];
            Ge2(:,k)=[];
            Gg2(:,k)=[];
            mu2(:,k)=[];
%             mu2v(:,k)=[];
            k=k-1;
        end
        k=k+1;
    end
    MMslambda(i,1) = mean(Gs2);
    MMelambda(i,1) = mean(Ge2);
    MMglambda(i,1) = mean(Gg2);
    MMmulambda(i,1) =  mean(mu2);
%     MMmuvlambda(i,1) =  mean(mu2v);
end



% stuff for analysing convergance to f/v

% y axis is equivalent to -log(E)/log(lambda)
YaxisE1 = -log(MMslambda)./log(lambda2');  % higher E
YaxisE2 = -log(MMelambda)./log(lambda2'); % lower E
YaxisG = -log(MMglambda)./log(lambda2'); % shear

Xaxis = 1./log(lambda2');

% to evaluate error bar
kk=0;
for i=1:size(lambda2,2)
    for j=1:N2s1
        if WV(i,j) == 1
            Mslambda(i,j) = 0;
        end
        if WVE(i,j) == 1
            Melambda(i,j) = 0;
        end
        if WVG(i,j) == 1
            Mglambda(i,j) = 0;
        end
    end
end
% 
% for i=1:size(lambda2,2)
%     for j=1:N2s1
%         if Mslambda(i,j) <0
%             Mslambda(i,j)=0;
%         end
%         if Melambda(i,j) <0
%             Melambda(i,j)=0;
%         end       
%         if Mglambda(i,j) <0
%             Mglambda(i,j)=0;
%         end
%     end
% end


yE1_data = zeros(Nslambda,N2s1);
yE2_data = zeros(Nslambda,N2s1);
yG_data = zeros(Nslambda,N2s1);
yE1_mean = zeros(Nslambda,1);
yE2_mean = zeros(Nslambda,1);
yG_mean = zeros(Nslambda,1);
SEE1 = zeros(Nslambda,1);
SEE2 = zeros(Nslambda,1);
SEG = zeros(Nslambda,1);

for i =1:size(lambda2,2)
    for j = 1:N2s1
        if Mslambda(i,j) ~=0
            yE1_data(i,j) = -log((Mslambda(i,j)))/log(lambda2(1,i));  % higher E
        end
        if Melambda(i,j) ~=0
            yE2_data(i,j) = -log(Melambda(i,j))/log(lambda2(1,i));  % lower E
        end
        if Mglambda(i,j) ~=0
            yG_data(i,j) = -log(Mglambda(i,j))/log(lambda2(1,i));  % higher G
        end
    end
SEE1(i,1) = sqrt(var(nonzeros(yE1_data(i,:))))/sqrt(size(nonzeros(yE1_data(i,:)),1)); % standard error
SEE2(i,1) = sqrt(var(nonzeros(yE2_data(i,:))))/sqrt(size(nonzeros(yE2_data(i,:)),1));
SEG(i,1) = sqrt(var(nonzeros(yG_data(i,:))))/sqrt(size(nonzeros(yG_data(i,:)),1));

sigE1(i,1) = sqrt(var(nonzeros(yE1_data(i,:))));
sigE2(i,1) = sqrt(var(nonzeros(yE2_data(i,:))));
sigG(i,1) = sqrt(var(nonzeros(yG_data(i,:))));

yE1_mean(i,1) = mean(nonzeros(yE1_data(i,:)));
yE2_mean(i,1) = mean(nonzeros(yE2_data(i,:)));
yG_mean(i,1) = mean(nonzeros(yG_data(i,:)));
end


fiE1 = polyfit(Xaxis,yE1_mean,1)
fiE2 = polyfit(Xaxis,yE2_mean,1)
fiG = polyfit(Xaxis,yG_mean,1)

fiE1axis = polyfit(Xaxis,YaxisE1,1);
fiE2axis = polyfit(Xaxis,YaxisE2,1);
fiGaxis = polyfit(Xaxis,YaxisG,1);


% finding chi squre value
expE1 = fiE1(1).*Xaxis+fiE1(2);
expE2 = fiE2(1).*Xaxis+fiE2(2);
expG = fiG(1).*Xaxis+fiG(2);

chisquareE1 = sum(((yE1_mean - expE1) ./ sigE1).^2);
chisquareE2 = sum(((yE2_mean - expE2) ./ sigE2).^2);
chisquareG = sum(((yG_mean - expG) ./ sigG).^2);






% plot

fiE1 = polyfit(Xaxis,yE1_mean,1)
fiE2 = polyfit(Xaxis,yE2_mean,1)
fiG = polyfit(Xaxis,yG_mean,1)


xplot = linspace(0,max(1./log(lambda2'))*1.1,10000);
yplotE1 = fiE1(1).*xplot+fiE1(2);
yplotE2 = fiE2(1).*xplot+fiE2(2);
yplotG = fiG(1).*xplot+fiG(2);

yaxisE1 = fiE1axis(1).*xplot+fiE1axis(2);
yaxisE2 = fiE2axis(1).*xplot+fiE2axis(2);
yaxisG = fiGaxis(1).*xplot+fiGaxis(2);


figure2 = figure;
errorbar(Xaxis,yE1_mean,SEE1,'r')
hold on
errorbar(Xaxis,yE2_mean,SEE2,'b')
hold on
errorbar(Xaxis,yG_mean,SEG,'k')
hold on
plot(xplot,yplotE1,'r')
hold on
plot(xplot,yplotE2,'b')
hold on
plot(xplot,yplotG,'k')
% 
% figure2 = figure;
% errorbar(Xaxis,YaxisE1,SEE1,'r')
% hold on
% errorbar(Xaxis,YaxisE2,SEE2,'b')
% hold on
% errorbar(Xaxis,YaxisG,SEG,'k')
% hold on
% plot(xplot,yaxisE1,'r')
% hold on
% plot(xplot,yaxisE2,'b')
% hold on
% plot(xplot,yaxisG,'k')












