function [ec,xi,yi] = intersection2(Fiber,i,j)

% it finds intesrction of two straight fibre in 2D space

ec = 0;

if Fiber(j,3)>Fiber(j,1)
    xj2 = Fiber(j,3);
    xj1 = Fiber(j,1);
    yj2 = Fiber(j,4);
    yj1 = Fiber(j,2);
else
    xj2 = Fiber(j,1);
    xj1 = Fiber(j,3);
    yj2 = Fiber(j,2);
    yj1 = Fiber(j,4);
end
if Fiber(i,3)>Fiber(i,1)
    xi2 = Fiber(i,3);
    xi1 = Fiber(i,1);
    yi2 = Fiber(i,4);
    yi1 = Fiber(i,2);
else
    xi2 = Fiber(i,1);
    xi1 = Fiber(i,3);
    yi2 = Fiber(i,2);
    yi1 = Fiber(i,4);
end



% for j: y = ax + b
a = (yj2-yj1)/(xj2-xj1);
b = yj2 - a*(xj2);

% for i: y = cx + d
c = (yi2-yi1)/(xi2-xi1);
d = yi2 - c*(xi2);

xi = (d-b)/(a-c); % x position of intersection 
yi = a*xi + b; % y position of intersection

if xi < xj2 && xi > xj1
    if xi < xi2 && xi > xi1
        ec = 1;
    end
end

end











