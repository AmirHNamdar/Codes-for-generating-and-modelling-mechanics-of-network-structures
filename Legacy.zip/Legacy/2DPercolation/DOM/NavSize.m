
clear
clc
close all
% in this code, the dependancy of shear modulus to direction will be
% investigated.

Pr = 0.8;
ptheta = 0;

tb = 0; % type of bar 0 for rectangular bar and 1 for circular bar
thickness = 1e-3;
diam = 1e-3;
density = 7.6905;  % DM = 4.9917; % 5.63726;
wm = 2;
% =-§12e[p[ network? perfect squares = 1, random network wm = 2.
TM = true; % if timoshenko beam then true

N2s1 = 25600*8; % number of study for each Nf


% tCN = zeros(Ns,1); % time allocated to create the network
% tSN = zeros(Ns,1); % time allocated to solve the network
Nf2 = [1000,1300,1600,2000,2700,3500,4300,5000,7000,10000];
% Nf2 = [3000 5000 10000];
% Nlambda = [2,10,2];
% Nslambda = (Nlambda(1,2) - Nlambda(1,1))/ Nlambda(1,3) + 1;
Nslambda = size(Nf2,2);
% lambda = sqrt(Nf2/density); % ++++++++++++ ********* ---------------
lamh = sqrt(Nf2/density);
laml = 1;

lambda2 = zeros(1,size(Nf2,2));
for i =1:size(Nf2,2)
    laml = 1;
    er = 1;
while er>1e-12
    test = (lamh(1,i)+laml)/2;
    er = abs(sqrt(Nf2(1,i)/density)-test*(1+2/floor(test)));
    if sqrt(Nf2(1,i)/density)-test*(1+2/floor(test))<0
        lamh(1,i) = test;
    else 
        laml = test;
    end
    
end
lambda2(1,i) = test;
end





Mslambda = zeros(Nslambda,N2s1); % young modulus relating to a given lambda;
Melambda = zeros(Nslambda,N2s1); % young2 modulus relating to a given lambda;
Mglambda = zeros(Nslambda,N2s1); % shear ...
Mmulambda = zeros(Nslambda,N2s1);
Mmuvlambda = zeros(Nslambda,N2s1);
WV = zeros(Nslambda,N2s1); % which simulation encountered error
WVE = zeros(Nslambda,N2s1);
WVG = zeros(Nslambda,N2s1);

MMslambda = zeros(Nslambda,1); % mean ...
MMelambda = zeros(Nslambda,1); % mean ...
MMglambda = zeros(Nslambda,1);
MMmulambda = zeros(Nslambda,1);
MMmuvlambda = zeros(Nslambda,1);

tic
for l = 1:Nslambda
    lambda = lambda2(1,l);
    Nf = Nf2(1,l);
    
    if Nf < 751
        N2s = N2s1;
    elseif Nf < 1501
        N2s = N2s1/2;
    elseif Nf < 2701
        N2s = N2s1/8;
    elseif Nf < 5001
        N2s = N2s1/16;
    else
        N2s = N2s1/32;
    end
    
%     Nf = [(lambda+2)^2*density,(lambda+2)^2*density,10]; % number of fibres data [initial nf, final nf, number of increase in each step]
% Nf = Nf2(1,i);
%     Ns = (Nf(1,2) - Nf(1,1))/ Nf(1,3) + 1; % number of considered density 
Ns = 1; 
    Gs = zeros(N2s1,Ns);
    Ge = zeros(N2s1,Ns);
    Gg = zeros(N2s1,Ns);
    mu = zeros(N2s1,Ns);
    muv = zeros(N2s1,Ns);
for j = 1:Ns


% input:
% Network generation
% lambda = 5;

% density = Nf(1,1)/(lambda+2)^2;

x=[0 lambda]; % boundary of x direction
y=[0 lambda]; % boundary of y direction
if wm == 1
N = 2 + 2*(ns); % for square beams
L = 300;
elseif wm == 2
N = Nf; % Number of fibers
L=1; % Length of fibers
end
    Gv = zeros(N2s1,1);
    GvE = zeros(N2s1,1);
    GvG = zeros(N2s1,1);
    mu1 = zeros(N2s1,1);
    mu1v = zeros(N2s1,1);
parfor ns = 1:N2s
l
ns
j
flt = 10^(-3)*L/density; % fibre lenght treshold. Edges smaller than flt will be deleted.


% tic % to record time


% e = 100; % elastic modulus of beams
% Ar = 1; % cross section of beams
% I = 1; % second moment


e = 100; % elastic modulus of beams
g = e/3; % for incompressible fibres
if tb == 1
    Ar = pi*diam^2/4; % cross section of circular beams
    I = pi*diam^4/64; % second moment of circular bars 
elseif tb == 0
   Ar = thickness^2; % cross section of square beams    
   I = (thickness)^4/12; % second moment of square bars 
end
BM = (x(2)-x(1))/1000; % Boundary movement


% using function NetworkRand to generate the random network and get the data
if wm == 1
[NN,NE,ED,PN,nrb,nlb,ntb,nbb,Fiber] = SquareBeams(x,y,L,N,lambda);
elseif wm == 2
[SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRand(x,y,L,N,lambda,flt,Pr,density,ptheta);
end
% tCN(ns,1) = toc;
if Per == false
    continue
end


NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);



BC = zeros(12,2);
% deformations
BC(1,1) = nan; % right x (will be modified inside the code)
BC(2,1) = nan; % right y (will be modified inside the code)
BC(3,1) = nan; % right theta 
BC(4,1) = nan;  % left x (will be modified inside the code)
BC(5,1) = nan; % left y (will be modified inside the code)
BC(6,1) = nan;  % left theta
BC(7,1) = 0; % top x (will be modified inside the code)
BC(8,1) = BM; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = 0;
BC(2,2) = 0;
BC(3,2) = 0;
BC(4,2) = 0;
BC(5,2) = 0;
BC(6,2) = 0;
BC(7,2) = nan;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = nan;
BC(11,2) = nan;
BC(12,2) = nan;

% BB
% % M = 0;
% % sM = false;
% % [fov,C3v,FFv,UUv,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);
% % 
% % BC(7,1) = 0;
% % BC(8,1) = BM; % to investigate E
% % sM = true;
% % [fovE,C3vE,FFvE,UUvE,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);

% TB
M = 0;
M2 = 0;
sM = false;
BCvx = 0; 
BCvy = BM;
[fov,C3v,FFv,UUv,M,wv] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy,tb);
WV(l,ns) = wv;


BC = zeros(12,2);
% deformations
BC(1,1) = nan; % right x (will be modified inside the code)
BC(2,1) = nan; % right y (will be modified inside the code)
BC(3,1) = nan; % right theta 
BC(4,1) = nan;  % left x (will be modified inside the code)
BC(5,1) = nan; % left y (will be modified inside the code)
BC(6,1) = nan;  % left theta
BC(7,1) = nan; % top x (will be modified inside the code)
BC(8,1) = BM; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = nan; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = 0;
BC(2,2) = 0;
BC(3,2) = 0;
BC(4,2) = 0;
BC(5,2) = 0;
BC(6,2) = 0;
BC(7,2) = 0;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = 0;
BC(11,2) = nan;
BC(12,2) = nan;

BCvx = nan;
BCvy = BM;

sM = true;

[fovE,C3vE,FFvE,UUvE,M,wvE] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy,tb);
WVE(l,ns) = wvE;


BC = zeros(12,2);
% deformations
BC(1,1) = nan; % right x (will be modified inside the code)
BC(2,1) = nan; % right y (will be modified inside the code)
BC(3,1) = nan; % right theta 
BC(4,1) = nan;  % left x (will be modified inside the code)
BC(5,1) = nan; % left y (will be modified inside the code)
BC(6,1) = nan;  % left theta
BC(7,1) = BM; % top x (will be modified inside the code)
BC(8,1) = 0; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = 0;
BC(2,2) = 0;
BC(3,2) = 0;
BC(4,2) = 0;
BC(5,2) = 0;
BC(6,2) = 0;
BC(7,2) = nan;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = nan;
BC(11,2) = nan;
BC(12,2) = nan;

BCvx = BM;
BCvy = 0;

sM = true;

[fovG,C3vG,FFvG,UUvG,M,wvG] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy,tb);
WVG(l,ns) = wvG;
% shear modulus------------------------------------------------------------
% aggregation of forces in x direction devided by rotation

UTg = transpose(UUvG);
Energyg = UTg*M*UUvG;
GvG(ns,1) = Energyg/(BM)^2;



% sfv = 0; % shear force on the boundary V
% for i = nlb+nrb+1:nlb+nrb+ntb
%     sfv = FFv(i*3-1,1)+sfv;
% end
% sfv2 = 0; % the force on bottom boundary (to check the equilibrium)
% for i = nlb+nrb+ntb+1:nlb+nrb+ntb+nbb
%     sfv2 = FFv(i*3-1,1)+sfv2;
% end

UT = transpose(UUv);
Energy = UT*M*UUv;
Gv(ns,1) = Energy/(BM)^2;
% sfv/BM;
% sfv2/BM;

% eerv = 0; % the force on bottom boundary (to check the equilibrium)
% for i = 1:nrb
%     eerv = UUv(i*3-2,1)+eerv;
% end
% eerv = eerv/nrb;
% eelv = 0; % the force on bottom boundary (to check the equilibrium)
% for i = nrb+1:nrb+nlb
%     eelv = UUv(i*3-2,1)+eelv;
% end
% eelv = eelv/nlb;
% mu1v(ns,1) = -(eerv-eelv)/BM;

sfvE = 0; % shear force on the boundary V
for i = nlb+nrb+1:nlb+nrb+ntb
    sfvE = FFvE(i*3-1,1)+sfvE;
end
sfvE2 = 0; % the force on bottom boundary (to check the equilibrium)
for i = nlb+nrb+ntb+1:nlb+nrb+ntb+nbb
    sfvE2 = FFvE(i*3-1,1)+sfvE2;
end

eer = 0; % the force on bottom boundary (to check the equilibrium)
for i = 1:nrb
    eer = UUvE(i*3-2,1)+eer;
end
eer = eer/nrb;
eel = 0; % the force on bottom boundary (to check the equilibrium)
for i = nrb+1:nrb+nlb
    eel = UUvE(i*3-2,1)+eel;
end
eel = eel/nlb;
mu1(ns,1) = -(eer-eel)/BM;


UTE = transpose(UUvE);
EnergyE = UTE*M*UUvE;
young2 = EnergyE/(BM)^2;

% finding mu and then E
% mu = 1-2*Gv(ns,1)/young2;
GvE(ns,1) = young2;
sfvE/BM;
sfvE2/BM;

% GvE(ns,1) = sfvE/lambda / (BM/lambda);


denN(ns,1) = N;

end
mu(:,j) = mu1;
% muv(:,j) = mu1v;
Gs(:,j) = Gv;
Ge(:,j) = GvE;
Gg(:,j) = GvG;
% GE(:,3) = Gh;
% GE(:,4) = GhE;

end

Mslambda(l,:) = Gs(:,1);
Melambda(l,:) = Ge(:,1);
Mglambda(l,:) = Gg(:,1);
Mmulambda(l,:) = mu(:,1);
% Mmuvlambda(l,:) = muv(:,1);

Mmu = zeros(1,Ns);
% Mmuv = zeros(1,Ns);
MGs = zeros(1,Ns); % Mean of Gs 
MGe = zeros(1,Ns); % Mean of Ge
MGg = zeros(1,Ns); % Mean of Gg


for i = 1: Ns
    Gs2 = Gs(:,i);
    Ge2 = Ge(:,i);
    Gg2 = Gg(:,i);
    mu2 = mu(:,i);
%     mu2v = muv(:,i);
    k=1;
    for j = 1:N2s
        if Ge2(k,1) == 0
            Gs2(k,:)=[];
            Ge2(k,:)=[];
            Gg2(k,:) = [];
            mu2(k,:)=[];
%             mu2v(k,:)=[];
            k=k-1;
        end
        k=k+1;
    end
    MGs(1,i) = mean(Gs2);
    MGe(1,i) = mean(Ge2);
    MGg(1,i) = mean(Gg2);
    Mmu(1,i) = mean(mu2);
%     Mmuv(1,i) = mean(mu2v);
end

MMslambda(l,1) = MGs;
MMelambda(l,1) = MGe;
MMglambda(l,1) = MGg;
MMmulambda(l,1) = Mmu;
% MMmuvlambda(l,1) = Mmuv;
end

for i = 1:size(Melambda,1)
    Gs2 = Mslambda(i,:);
    Ge2 = Melambda(i,:);
    Gg2 = Mglambda(i,:);
    mu2 = Mmulambda(i,:);
%     mu2v = Mmuvlambda(i,:);
    k=1;
    for j = 1:N2s1
        if Ge2(1,k) == 0
            Gs2(:,k)=[];
            Ge2(:,k)=[];
            Gg2(:,k)=[];
            mu2(:,k)=[];
%             mu2v(:,k)=[];
            k=k-1;
        end
        k=k+1;
    end
    MMslambda(i,1) = mean(Gs2);
    MMelambda(i,1) = mean(Ge2);
    MMglambda(i,1) = mean(Gg2);
    MMmulambda(i,1) =  mean(mu2);
%     MMmuvlambda(i,1) =  mean(mu2v);
end



% stuff for analysing convergance to f/v

% y axis is equivalent to -log(E)/log(lambda)
YaxisE1 = -log(MMslambda)./log(lambda2');  % higher E
YaxisE2 = -log(MMelambda)./log(lambda2'); % lower E
YaxisG = -log(MMglambda)./log(lambda2'); % shear

Xaxis = 1./log(lambda2');

% to evaluate error bar
kk=0;
for i=1:size(lambda2,2)
    for j=1:N2s1
        if WV(i,j) == 1
            Mslambda(i,j) = 0;
        end
        if WVE(i,j) == 1
            Melambda(i,j) = 0;
        end
        if WVG(i,j) == 1
            Mglambda(i,j) = 0;
        end
    end
end
% 
% for i=1:size(lambda2,2)
%     for j=1:N2s1
%         if Mslambda(i,j) <0
%             Mslambda(i,j)=0;
%         end
%         if Melambda(i,j) <0
%             Melambda(i,j)=0;
%         end       
%         if Mglambda(i,j) <0
%             Mglambda(i,j)=0;
%         end
%     end
% end


yE1_data = zeros(Nslambda,N2s1);
yE2_data = zeros(Nslambda,N2s1);
yG_data = zeros(Nslambda,N2s1);
yE1_mean = zeros(Nslambda,1);
yE2_mean = zeros(Nslambda,1);
yG_mean = zeros(Nslambda,1);
SEE1 = zeros(Nslambda,1);
SEE2 = zeros(Nslambda,1);
SEG = zeros(Nslambda,1);

for i =1:size(lambda2,2)
    for j = 1:N2s1
        if Mslambda(i,j) ~=0
            yE1_data(i,j) = -log((Mslambda(i,j)))/log(lambda2(1,i));  % higher E
        end
        if Melambda(i,j) ~=0
            yE2_data(i,j) = -log(Melambda(i,j))/log(lambda2(1,i));  % lower E
        end
        if Mglambda(i,j) ~=0
            yG_data(i,j) = -log(Mglambda(i,j))/log(lambda2(1,i));  % higher G
        end
    end
SEE1(i,1) = sqrt(var(nonzeros(yE1_data(i,:))))/sqrt(size(nonzeros(yE1_data(i,:)),1)); % standard error
SEE2(i,1) = sqrt(var(nonzeros(yE2_data(i,:))))/sqrt(size(nonzeros(yE2_data(i,:)),1));
SEG(i,1) = sqrt(var(nonzeros(yG_data(i,:))))/sqrt(size(nonzeros(yG_data(i,:)),1));

sigE1(i,1) = sqrt(var(nonzeros(yE1_data(i,:))));
sigE2(i,1) = sqrt(var(nonzeros(yE2_data(i,:))));
sigG(i,1) = sqrt(var(nonzeros(yG_data(i,:))));

yE1_mean(i,1) = mean(nonzeros(yE1_data(i,:)));
yE2_mean(i,1) = mean(nonzeros(yE2_data(i,:)));
yG_mean(i,1) = mean(nonzeros(yG_data(i,:)));
end


fiE1 = polyfit(Xaxis,yE1_mean,1)
fiE2 = polyfit(Xaxis,yE2_mean,1)
fiG = polyfit(Xaxis,yG_mean,1)

fiE1axis = polyfit(Xaxis,YaxisE1,1);
fiE2axis = polyfit(Xaxis,YaxisE2,1);
fiGaxis = polyfit(Xaxis,YaxisG,1);


% finding chi squre value
expE1 = fiE1(1).*Xaxis+fiE1(2);
expE2 = fiE2(1).*Xaxis+fiE2(2);
expG = fiG(1).*Xaxis+fiG(2);

chisquareE1 = sum(((yE1_mean - expE1) ./ sigE1).^2);
chisquareE2 = sum(((yE2_mean - expE2) ./ sigE2).^2);
chisquareG = sum(((yG_mean - expG) ./ sigG).^2);






% plot

fiE1 = polyfit(Xaxis,yE1_mean,1)
fiE2 = polyfit(Xaxis,yE2_mean,1)
fiG = polyfit(Xaxis,yG_mean,1)


xplot = linspace(0,max(1./log(lambda2'))*1.1,10000);
yplotE1 = fiE1(1).*xplot+fiE1(2);
yplotE2 = fiE2(1).*xplot+fiE2(2);
yplotG = fiG(1).*xplot+fiG(2);

yaxisE1 = fiE1axis(1).*xplot+fiE1axis(2);
yaxisE2 = fiE2axis(1).*xplot+fiE2axis(2);
yaxisG = fiGaxis(1).*xplot+fiGaxis(2);


figure2 = figure;
errorbar(Xaxis,yE1_mean,SEE1,'r')
hold on
errorbar(Xaxis,yE2_mean,SEE2,'b')
hold on
errorbar(Xaxis,yG_mean,SEG,'k')
hold on
plot(xplot,yplotE1,'r')
hold on
plot(xplot,yplotE2,'b')
hold on
plot(xplot,yplotG,'k')
% 
% figure2 = figure;
% errorbar(Xaxis,YaxisE1,SEE1,'r')
% hold on
% errorbar(Xaxis,YaxisE2,SEE2,'b')
% hold on
% errorbar(Xaxis,YaxisG,SEG,'k')
% hold on
% plot(xplot,yaxisE1,'r')
% hold on
% plot(xplot,yaxisE2,'b')
% hold on
% plot(xplot,yaxisG,'k')


% 
% figure1 = figure;
% plot(MMelambda,'r')
% hold on
% plot(MMslambda,'b')
% figure1 = figure;
% plot(MMmulambda,'o','color','r')
% hold on
% plot(MMmuvlambda,'o','color','b')



timeTottal = toc









if wm ==1
    save('SSdata')      %-------------------*********************
elseif wm==2
                                %-------------------*********************
%     nameS = strcat('NEW-Size',num2str(density),'Pr',num2str(Pr*100));
    nameS = strcat('Per_ConvZero_test2_','Pr',num2str(Pr*100),'Th',num2str(ptheta),'-3');
    save(nameS)
end

% poly = polyfit(den,G,4);
% x1 = linspace(min(denN),max(denN));
% y1 = polyval(poly,x1);

% subplot(2,2,1)
% plot(den,G,'o')
% hold on
% plot(x1,y1)
% hold on
% subplot(2,2,2)
% plot(denN,G,'o')
% hold on
% subplot(2,2,3)
% plot(denf,G,'o')





