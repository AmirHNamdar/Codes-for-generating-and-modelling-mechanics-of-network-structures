%% Plot network: deleted fibres (red) vs intact fibres (blue)
clear; clc; close all;

% ---------------- User files ----------------
matFile = 'Test1.mat';
csvFile = 'Test1_deletion_history.csv';   % your deletion history CSV

% ---------------- Load network data ----------------
S = load(matFile);

% Expecting ED and PN in the .mat file
ED = S.ED;   % [nElem x 2] node connectivity
PN = S.PN;   % likely [nNode x 3] = [nodeID, x, y]

% ---------------- Extract node coordinates ----------------
% Your PN appears to be [ID, x, y]
if size(PN,2) >= 3
    % Check if first column looks like node IDs (1:N)
    idCol = PN(:,1);
    if all(abs(idCol - round(idCol)) < 1e-12) && ...
       min(idCol) >= 1 && max(idCol) <= size(PN,1)
        x = PN(:,2);
        y = PN(:,3);
    else
        % If PN is already [x,y,...]
        x = PN(:,1);
        y = PN(:,2);
    end
elseif size(PN,2) == 2
    x = PN(:,1);
    y = PN(:,2);
else
    error('PN has unexpected size.');
end

nElem = size(ED,1);

% ---------------- Read deletion history ----------------
Tdel = readtable(csvFile);

if ~ismember('element_label', Tdel.Properties.VariableNames)
    error('CSV must contain column "element_label".');
end

deletedLabels = unique(Tdel.element_label);
deletedLabels = deletedLabels(~isnan(deletedLabels));

% Make sure labels are integers
deletedLabels = round(deletedLabels);

% ---------------- Map Abaqus element labels -> ED row indices ----------------
% Assumption (your note): Abaqus element ID ~= row number in ED
% Usually element labels are 1-based. We handle a possible 0-based case too.
if min(deletedLabels) == 0 && max(deletedLabels) <= nElem-1
    idxDeleted = deletedLabels + 1;  % 0-based -> MATLAB 1-based
else
    idxDeleted = deletedLabels;      % already 1-based
end

% Keep only valid indices
idxDeleted = idxDeleted(idxDeleted >= 1 & idxDeleted <= nElem);
idxDeleted = unique(idxDeleted);

% Create logical mask
isDeleted = false(nElem,1);
isDeleted(idxDeleted) = true;

fprintf('Total ED elements: %d\n', nElem);
fprintf('Deleted elements found in CSV (valid): %d\n', nnz(isDeleted));

% ---------------- Plot ----------------
figure('Color','w'); hold on; box on;

% Plot intact (blue) first
idxIntact = find(~isDeleted);
for k = 1:numel(idxIntact)
    e = idxIntact(k);
    n1 = ED(e,1);
    n2 = ED(e,2);
    plot([x(n1) x(n2)], [y(n1) y(n2)], '-', ...
        'Color', [0 0.35 0.9], 'LineWidth', 0.8);  % blue
end

% Plot deleted (red) on top
idxDel = find(isDeleted);
for k = 1:numel(idxDel)
    e = idxDel(k);
    n1 = ED(e,1);
    n2 = ED(e,2);
    plot([x(n1) x(n2)], [y(n1) y(n2)], '-', ...
        'Color', [0.9 0.1 0.1], 'LineWidth', 1.5); % red
end

axis equal;
xlabel('x');
ylabel('y');
title(sprintf('Network deletion map: %d deleted / %d total', nnz(isDeleted), nElem));

% Optional legend (dummy lines)
h1 = plot(nan,nan,'-','Color',[0 0.35 0.9],'LineWidth',1.2);
h2 = plot(nan,nan,'-','Color',[0.9 0.1 0.1],'LineWidth',1.8);
legend([h1 h2], {'Not deleted','Deleted'}, 'Location','best');

set(gca,'FontSize',11);