function [nodes, edges, bndIdx, bndCounts] = generateVoronoi2D_prunedFirst2(N, L)
%GENERATEVORONOI2D_PRUNEDFIRST2  Build 2D Voronoi in [0,L]^2, prune to main component,
% then reorder so boundary nodes occupy the first rows.
%
% [nodes, edges, bndIdx, bndCounts] = generateVoronoi2D_prunedFirst2(N, L)
%   nodes       — P×2 coords (boundary nodes first)
%   edges       — Q×2 node-index pairs
%   bndIdx      — indices of boundary nodes (1:length(boundary))
%   bndCounts   — 4×1 counts per box edge [x=L; x=0; y=L; y=0]
%
% Notes:
% - Uses circumcenters of Delaunay triangles as Voronoi vertices.
% - Clips edges to the [0,L]^2 box.
% - Prunes to the largest connected component.
% - Reorders nodes so boundary nodes come first (stable, no duplicates).

  %% 1) Scatter seeds, Delaunay + circumcenters (pad with margin to reduce truncation)
  N      = floor((3*L)^2 * N);
  margin = L;
  P      = rand(N,2) * (L + 2*margin) - margin;  % seeds in padded box
  dt     = delaunayTriangulation(P);
  V      = circumcenter(dt);                     % Voronoi vertices (circumcenters)
  nbr    = dt.neighbors;                         % triangle neighbors (size: T×3)

  %% 2) Build raw edge list between neighboring triangles (each shared edge → Voronoi edge)
  T    = size(nbr,1);
  Eall = zeros(T*2,2);
  ec   = 0;
  for i = 1:T
    for f = 1:3
      j = nbr(i,f);
      if j > i    % add each undirected edge once
        ec = ec + 1;
        Eall(ec,:) = [i j];
      end
    end
  end
  Eall = Eall(1:ec,:);

  %% 3) Clip edges to [0,L]^2 and collect nodes
  inside = all(V >= 0 & V <= L, 2);     % vertices inside the box
  inIdx  = find(inside);
  nodes0 = V(inIdx, :);

  newIdx = zeros(size(V,1),1);
  newIdx(inIdx) = 1:numel(inIdx);

  edges0 = zeros(ec,2);
  ec2    = 0;

  for k = 1:ec
    i  = Eall(k,1);  j  = Eall(k,2);
    v1 = V(i,:);     v2 = V(j,:);
    in1 = inside(i); in2 = inside(j);

    if in1 && in2
      % both endpoints inside
      ec2 = ec2 + 1;
      edges0(ec2,:) = [newIdx(i), newIdx(j)];

    elseif xor(in1, in2)
      % segment crosses the boundary once → add intersection point
      if in1
        vi = v1; vo = v2; idx_in = newIdx(i);
      else
        vi = v2; vo = v1; idx_in = newIdx(j);
      end
      d = vo - vi;
      tmin = Inf;

      % Intersections with x=0 and x=L
      if d(1) > 0
        t = (L - vi(1)) / d(1); if t > 0 && t < 1 && t < tmin, tmin = t; end
      elseif d(1) < 0
        t = (0 - vi(1)) / d(1); if t > 0 && t < 1 && t < tmin, tmin = t; end
      end

      % Intersections with y=0 and y=L
      if d(2) > 0
        t = (L - vi(2)) / d(2); if t > 0 && t < 1 && t < tmin, tmin = t; end
      elseif d(2) < 0
        t = (0 - vi(2)) / d(2); if t > 0 && t < 1 && t < tmin, tmin = t; end
      end

      if isfinite(tmin)
        Pint = vi + tmin * d;
        nodes0(end+1, :) = Pint;            % append new boundary node
        ec2 = ec2 + 1;
        edges0(ec2, :) = [idx_in, size(nodes0,1)];
      end
    end
  end
  edges0 = edges0(1:ec2, :);

  %% 4) Prune to main connected component
  if isempty(edges0)
    nodes   = zeros(0,2);
    edges   = zeros(0,2);
    bndIdx  = zeros(0,1);
    bndCounts = zeros(4,1);
    return;
  end

  G     = graph(edges0(:,1), edges0(:,2));
  comp  = conncomp(G);
  mainC = mode(comp);
  keepV = find(comp == mainC);

  nodes_pruned = nodes0(keepV, :);
  maskE = ismember(edges0(:,1), keepV) & ismember(edges0(:,2), keepV);
  e_sub = edges0(maskE, :);

  mapV = zeros(size(nodes0,1),1);
  mapV(keepV) = 1:numel(keepV);
  edges_pruned = [mapV(e_sub(:,1)), mapV(e_sub(:,2))];

  %% 5) Identify & count boundary nodes
  tol = 1e-10*L;    % tight tolerance for box hits
  X = nodes_pruned(:,1);
  Y = nodes_pruned(:,2);

  faceMasks = { abs(X - L) < tol, ...  % x = L
                abs(X - 0) < tol, ...  % x = 0
                abs(Y - L) < tol, ...  % y = L
                abs(Y - 0) < tol };    % y = 0
  bndCounts = cellfun(@nnz, faceMasks);

  %% 6) Reorder so boundary nodes are first (stable & de-duplicated)
  bndIdxList = [];
  for f = 1:4
    bndIdxList = [bndIdxList; find(faceMasks{f})]; %#ok<AGROW>
  end
  bndIdxList = unique(bndIdxList, 'stable');

  allIdx = (1:size(nodes_pruned,1))';
  intIdx = setdiff(allIdx, bndIdxList, 'stable');
  newOrder = [bndIdxList; intIdx];

  nodes = nodes_pruned(newOrder, :);
  remap = zeros(size(nodes,1),1);
  remap(newOrder) = 1:numel(newOrder);
  edges = [remap(edges_pruned(:,1)), remap(edges_pruned(:,2))];

  bndIdx = (1:numel(bndIdxList))';
end
