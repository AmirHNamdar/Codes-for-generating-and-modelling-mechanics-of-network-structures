
clear
clc
close all


exctime = 15 /100; % used to be 0.1


N = 20e6; % density of number of initial seeds
lambda = 0.03; % size of the study box
nnG = 1; % number of nodes in each group for BC
% defH = [0 0.5*lambda; 0 0]; % pure longitudinal
stretch = 1.5*lambda; % used to be 0.5




MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio
e = 2e9; % elastic modulus of beams

% fracture parameters
sigCrack = e * 0.8; % e*failure strain  % used to be 0.2
crackStrain = 1e-4 * lambda;
shearRetention1 = 1.0;
failStrain = 1e-4 * lambda ;




g = e/2/(1+Matnu);

inpName = 'TestVL'; % name of the .inp file
CheckPlot = false; % to plot a series of graphs at various steps to check if anything is wrong
timeCheck = true; % to check the time of excution of each main function
radius = 1e-3;

outFolder = '/Users/Code/Abaqus/Fracture/2DVoronoi/inp';

% creating the newtork
[nodes, edges, bndIdx, bndCounts] = generateVoronoi2D_prunedFirst2(N, lambda);

% analysing some data
G    = graph(edges(:,1), edges(:,2));
comp = conncomp(G); 
NumberofClusters = max(comp) % the number of clusters in the network (it should be one)

% compute differences for each edge
diffs = nodes(edges(:,1), :) - nodes(edges(:,2), :);

% Euclidean length of each edge
edgeLengths = sqrt( sum( diffs.^2, 2 ) );
aveL = mean(edgeLengths);
lcradi = aveL/radius
density = sum(edgeLengths)/lambda^2
Llc = lambda/mean(edgeLengths)
w = log10(density*(radius)^2)
polymerRatio = density*radius^2*pi


NE = size(edges,1) % number of edges
NN = size(nodes,1); % number of nodes
PN = nodes; % position of nodes
ED = edges; % position of edges
nrb = bndCounts(1,1); % number of right boundary node (x +)
nlb = bndCounts(1,2); % number of left boundary node (x -)
ntb = bndCounts(1,3); % number of top boundary node (y +)
nbb = bndCounts(1,4); % number of botttom boundary node (y -)
nbn = nrb+nlb+ntb+nbb; % number of boundary nodes
nbn


% deleting the short fibres 
flt = aveL/50;
[NE,NN,PN,ED,nrb,nlb,ntb,nbb,nbn] = ModifyingNetworkLengthVor(NE,NN,PN,ED,nrb,nlb,ntb,nbb,nbn,edgeLengths,flt);


% writing the .inp file ()first getting the equations
% equations = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nnG,defH);

PN2 = zeros(NN,3);
PN2(1:end,1) = [1:NN]';
PN2(1:end,2:3) = PN;
PN = PN2;
ToPrint = writeFunctionStretch(PN,ED,inpName,radius,MatDen,Matnu,e,stretch,nbn,lambda,nrb,nlb,exctime,sigCrack,crackStrain,shearRetention1,failStrain)






save(inpName)



% plot if ...
if CheckPlot == true
    
    % the netwokr before trimming
figure1 = figure('Position', [500, 500, 500, 500]); hold on; axis equal tight; box on;
plot([0 lambda lambda 0 0],[0 0 lambda lambda 0],'k-'); % box
for e = 1:size(edges,1)
  p = nodes(edges(e,1),:); q = nodes(edges(e,2),:);
  plot([p(1) q(1)], [p(2) q(2)], '-', 'LineWidth', 1);
end
scatter(nodes(bndIdx,1), nodes(bndIdx,2), 15, 'r', 'filled'); % boundary nodes
title(sprintf('Boundary counts [x=L; x=0; y=L; y=0] = [%d %d %d %d]', bndCounts));

    % the network after trimming
figure2 = figure('Position', [1200, 500, 500, 500]); hold on; axis equal tight; box on;
plot([0 lambda lambda 0 0],[0 0 lambda lambda 0],'k-'); % box
for e = 1:NE
  p = PN(ED(e,1),2:3); q = PN(ED(e,2),2:3);
  plot([p(1) q(1)], [p(2) q(2)], '-', 'LineWidth', 1);
end
scatter(nodes(bndIdx,1), nodes(bndIdx,2), 15, 'r', 'filled'); % boundary nodes
title(sprintf('Boundary counts [x=L; x=0; y=L; y=0] = [%d %d %d %d]', [nrb nlb ntb nbb]));

end





