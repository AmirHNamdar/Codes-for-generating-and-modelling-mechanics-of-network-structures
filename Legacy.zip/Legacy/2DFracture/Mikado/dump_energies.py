# Usage: abaqus python dump_energies.py MyRun.odb > energies.csv
from odbAccess import openOdb
import sys, csv

if len(sys.argv) < 2:
    sys.stderr.write("Usage: abaqus python dump_energies.py <file.odb>\n")
    sys.exit(1)

odb_path = sys.argv[1]
odb = openOdb(odb_path, readOnly=True)
w = csv.writer(sys.stdout)
w.writerow(["step","region","variable","description","time","value"])

def is_whole_model(name):
    u = name.upper()
    return ("WHOLE MODEL" in u) or u.endswith(" ASSEMBLY") or u == "ASSEMBLY"

for step_name, step in odb.steps.items():
    for reg_name, region in step.historyRegions.items():
        if not is_whole_model(reg_name):
            continue
        for var_name, ho in region.historyOutputs.items():
            desc = getattr(ho, "description", "")
            # Keep variables that are energies (catch ALLIE, ALLKE, ALLSE, ALLAE, ALLVD, etc.)
            if ("energy" in desc.lower()) or var_name.upper().startswith("ALL") or var_name.upper() in ("ETOTAL","TOTAL ENERGY"):
                for t, v in ho.data:
                    w.writerow([step_name, reg_name, var_name, desc, t, v])

odb.close()
