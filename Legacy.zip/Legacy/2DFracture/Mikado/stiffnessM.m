function [M,Me] = stiffnessM(ED,PN)

I = 1;
e = 100;
Ar = 1;
NN = size(PN,1);
NE = size(ED,1);

% edges lenghts and angles_________________________________________________
L=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    L(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end   

TETA=zeros(NE,1);
for i=1:NE
    q=ED(i,1);
    w=ED(i,2);
    qs=PN(q,2);
    qg=PN(q,3);
    ws=PN(w,2);
    wg=PN(w,3);
    TETA1=asin((wg-qg)/L(i,1));
    TETA2=acos((ws-qs)/L(i,1));
    
    if TETA1 >= 0
        if TETA2 <= pi/2
            TETA(i,1) = TETA1;
        else TETA(i,1) = TETA2;
        end
    else 
        if TETA2 <= pi/2
            TETA(i,1) = 2*pi + TETA1;
        else TETA(i,1) = 2*pi - TETA2;
        end
    end
    
end


% stifness matrix






M=zeros(3*NN); % M is the stiffness amtrix of the network
Me=zeros(6*NE); % Me is the stiffness matrix of each elemetn individualy
for i=1:NE
    ll=L(i,1);
    t=TETA(i,1);
    C = cos(t);
    S = sin(t);
    
    % for Euler beam
    K = zeros(6);
    K(1,1) = Ar*(C^2)+12*I*(S^2)/(ll^2);
    K(1,2) = (Ar-12*I/(ll^2))*C*S;
    K(1,3) = -6*I*S/ll;
    K(1,4) = -Ar*C^2-12*I*(S^2)/(ll^2);
    K(1,5) = -(Ar-12*I/(ll^2))*C*S;
    K(1,6) = -6*I*S/ll;
    
    K(2,1) = K(1,2);
    K(2,2) = Ar*(S^2)+12*I*(C^2)/(ll^2);
    K(2,3) = 6*I*C/ll;
    K(2,4) = -K(1,2);
    K(2,5) = -K(2,2);
    K(2,6) = K(2,3);
    
    K(3,1) = K(1,3);
    K(3,2) = K(2,3);
    K(3,3) = 4*I;
    K(3,4) = 6*I*S/ll;
    K(3,5) = -6*I*C/ll;
    K(3,6) = 2*I;
    
    K(4,1) = K(1,4);
    K(4,2) = K(2,4);
    K(4,3) = K(3,4);
    K(4,4) = K(1,1);
    K(4,5) = K(1,2);
    K(4,6) = 6*I*S/ll;
    
    K(5,1) = K(1,5);
    K(5,2) = K(2,5);
    K(5,3) = K(3,5);
    K(5,4) = K(4,5);
    K(5,5) = K(2,2);
    K(5,6) = -6*I*C/ll;
    
    K(6,1) = K(1,6);
    K(6,2) = K(2,6);
    K(6,3) = K(3,6);
    K(6,4) = K(4,6);
    K(6,5) = K(5,6);
    K(6,6) = 4*I;
    
    K = e/ll*K;
    Me(i*6-5:i*6,i*6-5:i*6) = K;
    
    KK = zeros(3*NN);
    KK(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(1:3,1:3);
    KK(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(1:3,4:6);
    KK(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(4:6,1:3);
    KK(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(4:6,4:6);
    
    M = M + KK; 
end






end