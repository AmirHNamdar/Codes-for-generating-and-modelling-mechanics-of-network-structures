clear 
clc
close all

load SSPr0lambda4-ConvStudy

histogram(Gs)


























