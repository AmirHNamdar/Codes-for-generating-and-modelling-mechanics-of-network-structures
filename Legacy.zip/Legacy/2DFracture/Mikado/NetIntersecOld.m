function [Per,ip,pc,Fiber] = NetIntersecOld(Fiber,x,y,PBN,nf,density)

N=size(Fiber,1);
% the mean size of segment is lc=pi/(2*density), therefore the number of
% intersections per fibre is 2*density/pi
% ninter = floor(2*2*density/pi*N) % number of expected intersections
% ip = spalloc (N,2*N,ninter); % intersection position
ip = zeros(N,2*N);
Per = false;
tic
for i=1:N
    for j=1:N
        if j~=i
            % find its contact with fiber j (if yes, ec ==1, otherwise, ec ==0)
            if Fiber(i,9) - Fiber(j,9) <= 1 && Fiber(i,9) - Fiber(j,9) >= -1 && Fiber(i,10) - Fiber(j,10) <= 1 && Fiber(i,10) - Fiber(j,10) >= -1
            [ec,xi,yi] = intersection2(Fiber,i,j);
            if ec == 1
            ip(i,2*j-1) = xi;
            ip(i,2*j) = yi;
                lfj = Fiber(j,8); %  label of fiber j
                for k=1:N
                    if Fiber(k,8) == lfj
                        Fiber(k,8) = i;
                    end
                end
            end
            end
        end
    end
end
inttoc = toc
% tic
% I = [];
% J = [];
% K2 = [];
% for i=1:N
%     for j=1:N
%         if j~=i
%             % find its contact with fiber j (if yes, ec ==1, otherwise, ec ==0)
%             if Fiber(i,9) - Fiber(j,9) <= 1 && Fiber(i,9) - Fiber(j,9) >= -1 && Fiber(i,10) - Fiber(j,10) <= 1 && Fiber(i,10) - Fiber(j,10) >= -1
%             [ec,xi,yi] = intersection2(Fiber,i,j);
%             if ec == 1
% %             ip(i,2*j-1) = xi;
% %             ip(i,2*j) = yi;
%             I(end+1) = i;
%             I(end+1) = i;
%             J(end+1) = 2*j-1;
%             J(end+1) = 2*j;
%             K2(end+1) = xi;
%             K2(end+1) = yi;
%                 lfj = Fiber(j,8); %  label of fiber j
%                 for k=1:N
%                     if Fiber(k,8) == lfj
%                         Fiber(k,8) = i;
%                     end
%                 end
%             end
%             end
%         end
%     end
% end
% ipsparse = sparse(I,J,K2,N,2*N);
% % ipsparse2 = full(ipsparse);
% int2toc = toc

cnr = []; % cluster number of right boundary
cnl = []; % cluster number of left boundary
cnt = []; % cluster number of top boundary
cnb = []; % cluster number of bottom boundary


for i = 1 : size(PBN,1)
    nf = PBN(i,4); % number of fibre
    if PBN(i,3) == 1
        cnr(end+1) = Fiber(nf,8);
    elseif PBN(i,3) == 2
        cnl(end+1) = Fiber(nf,8);
    elseif PBN(i,3) == 3
        cnt(end+1) = Fiber(nf,8);
    elseif PBN(i,3) == 4
        cnb(end+1) = Fiber(nf,8);
    end
end
% % % % % % % % % % cnr
% % % % % % % % % % cnl
% % % % % % % % % % cnt
% % % % % % % % % % cnb

% HPer = false;
% for i=1:size(cnr,2)
%     for j=1:size(cnl,2)
%         if cnr(1,i) == cnl(1,j)
%             HPer = true;
%         end
%     end
% end
% % % % % % % % HPer
VPer = false;
for i=1:size(cnt,2)
    for j=1:size(cnb,2)
        if cnt(1,i) == cnb(1,j)
            VPer = true;
            pc = cnt(1,i); % percolated cluster 
        end
    end
end
% % % % % % % % VPer
if VPer == true % && HPer == true
    Per = true;
end

if Per ==false
    pc = 0;
end
% % % % % % % % % pc

end