function k = seventeenPreferOdd(k)
  if mod(k,2)==0, k = k+1; end
end