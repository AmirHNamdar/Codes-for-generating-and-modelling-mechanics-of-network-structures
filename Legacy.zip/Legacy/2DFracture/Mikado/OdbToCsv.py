# -*- coding: utf-8 -*-
# Abaqus Python (usually Python 2.7) compatible script
# Exports:
#   1) Global energies history -> <job>_energies.csv
#   2) Element deletion history from STATUS -> <job>_deletion_history.csv

from odbAccess import openOdb
import sys
import os
import csv


def get_total_time_map(odb):
    """
    Return cumulative start time for each step:
    offsets[stepName] = total elapsed time before this step starts
    """
    step_names = list(odb.steps.keys())
    offsets = {}
    cum = 0.0

    for sname in step_names:
        offsets[sname] = cum
        step = odb.steps[sname]
        if len(step.frames) > 0:
            # frameValue is step-local time
            cum += step.frames[-1].frameValue

    return offsets


def export_energies(odb, out_csv):
    """
    Export global energy history variables (ALL*, ETOTAL) from history output.
    Output columns:
      step, step_time, total_time, <energy variables...>
    """
    step_offsets = get_total_time_map(odb)
    rows = []

    all_vars = set()
    step_region_data = {}

    for sname, step in odb.steps.items():
        # Prefer assembly-level history region
        assembly_regions = []
        for hr_name, hr in step.historyRegions.items():
            if "ASSEMBLY" in hr_name.upper():
                assembly_regions.append((hr_name, hr))

        if len(assembly_regions) == 0:
            candidates = list(step.historyRegions.items())
        else:
            candidates = assembly_regions

        chosen = None
        for hr_name, hr in candidates:
            vars_here = []
            for k in hr.historyOutputs.keys():
                ku = k.upper()
                if ku.startswith("ALL") or ku == "ETOTAL":
                    vars_here.append(k)

            if len(vars_here) > 0:
                chosen = (hr_name, hr, vars_here)
                break

        if chosen is None:
            step_region_data[sname] = None
            continue

        hr_name, hr, vars_here = chosen

        for v in vars_here:
            all_vars.add(v)

        # Build time-indexed dict for this step
        time_map = {}  # step_time -> {var:value}
        for v in vars_here:
            data_list = hr.historyOutputs[v].data  # list of (time, value)
            for pair in data_list:
                t = pair[0]
                val = pair[1]
                if t not in time_map:
                    time_map[t] = {}
                time_map[t][v] = val

        step_region_data[sname] = time_map

    all_vars = sorted(list(all_vars))

    for sname, time_map in step_region_data.items():
        if not time_map:
            continue

        for t in sorted(time_map.keys()):
            d = time_map[t]
            row = {
                "step": sname,
                "step_time": t,
                "total_time": step_offsets[sname] + t
            }
            for v in all_vars:
                if v in d:
                    row[v] = d[v]
                else:
                    row[v] = ""
            rows.append(row)

    # Python 2 csv module expects binary mode on Windows
    f = open(out_csv, "wb")
    try:
        writer = csv.DictWriter(f, fieldnames=["step", "step_time", "total_time"] + all_vars)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
    finally:
        f.close()

    print("Wrote energies: %s" % out_csv)


def export_deletion_history(odb, out_csv, instance_name=None, elset_name=None,
                            status_var_candidates=("STATUS", "STATUSMP")):
    """
    Export first deletion event per element based on STATUS-like field output.

    Deletion criterion used here:
      status < 0.5  => treated as deleted/failed

    Output columns:
      element_label, instance, step, frame_id, step_time, total_time, status_value
    """
    step_offsets = get_total_time_map(odb)

    # Track first deletion only
    deleted_first = {}

    f = open(out_csv, "wb")
    try:
        writer = csv.writer(f)
        writer.writerow(["element_label", "instance", "step", "frame_id",
                         "step_time", "total_time", "status_value"])

        for sname, step in odb.steps.items():
            for i_frame, frame in enumerate(step.frames):

                # Find STATUS-like variable in this frame
                field = None
                used_var = None
                for cand in status_var_candidates:
                    if cand in frame.fieldOutputs.keys():
                        field = frame.fieldOutputs[cand]
                        used_var = cand
                        break

                if field is None:
                    continue

                subset = field

                # Optional filter by instance
                if instance_name is not None:
                    try:
                        inst = odb.rootAssembly.instances[instance_name]
                        subset = subset.getSubset(region=inst)
                    except Exception:
                        # Ignore and continue with unfiltered subset if instance not found
                        pass

                # Optional filter by element set
                if elset_name is not None:
                    try:
                        # Try assembly-level elset first
                        if elset_name in odb.rootAssembly.elementSets.keys():
                            eset = odb.rootAssembly.elementSets[elset_name]
                            subset = subset.getSubset(region=eset)
                        elif (instance_name is not None and
                              instance_name in odb.rootAssembly.instances.keys() and
                              elset_name in odb.rootAssembly.instances[instance_name].elementSets.keys()):
                            eset = odb.rootAssembly.instances[instance_name].elementSets[elset_name]
                            subset = subset.getSubset(region=eset)
                    except Exception:
                        pass

                for v in subset.values:
                    label = getattr(v, "elementLabel", None)
                    if label is None:
                        continue

                    if hasattr(v, "instance") and hasattr(v.instance, "name"):
                        inst_name = v.instance.name
                    else:
                        inst_name = ""

                    data = v.data
                    if isinstance(data, (tuple, list)):
                        sval = float(data[0])
                    else:
                        sval = float(data)

                    key = (inst_name, label)

                    # first time detected deleted
                    if sval < 0.5 and key not in deleted_first:
                        deleted_first[key] = (sname, i_frame, frame.frameValue,
                                              step_offsets[sname] + frame.frameValue, sval, used_var)
                        writer.writerow([label, inst_name, sname, i_frame,
                                         frame.frameValue,
                                         step_offsets[sname] + frame.frameValue,
                                         sval])
    finally:
        f.close()

    print("Wrote deletion history: %s" % out_csv)
    print("Note: deletion time is resolved only at output frame times (not exact increment unless output every increment).")


def main():
    if len(sys.argv) < 2:
        print("Usage: abaqus python OdbToCsv.py Job-1.odb [INSTANCE_NAME] [ELSET_NAME]")
        sys.exit(1)

    odb_path = sys.argv[1]

    instance_name = None
    elset_name = None
    if len(sys.argv) >= 3 and sys.argv[2] != "None":
        instance_name = sys.argv[2]
    if len(sys.argv) >= 4 and sys.argv[3] != "None":
        elset_name = sys.argv[3]

    if not os.path.isfile(odb_path):
        print("ODB not found: %s" % odb_path)
        sys.exit(1)

    odb = openOdb(path=odb_path, readOnly=True)

    try:
        base = os.path.splitext(os.path.basename(odb_path))[0]
        out1 = base + "_energies.csv"
        out2 = base + "_deletion_history.csv"

        export_energies(odb, out1)
        export_deletion_history(odb, out2,
                                instance_name=instance_name,
                                elset_name=elset_name)
    finally:
        odb.close()


if __name__ == "__main__":
    main()