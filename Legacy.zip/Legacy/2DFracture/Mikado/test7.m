clear all
clc
close all


x=[0 100];
y=[0 100];
L=100; % Length of fibers
N=1000; % Number of fibers

xc = [x(1)-L , x(2)+L]; % x to create the network
yc = [y(1)-L , y(2)+L];


for i=1:1:N
% while 1
xm=min(xc)+(max(xc)-min(xc))*rand(1);
ym=min(yc)+(max(yc)-min(yc))*rand(1);
theta=2*pi*rand(1);
x1=xm-cos(theta)*L/2;
y1=ym-sin(theta)*L/2;
x2=xm+cos(theta)*L/2;
y2=ym+sin(theta)*L/2;
% if x2<=x(2) && x2>=x(1) && y2<=y(2) && y2>=y(1) 
% break;
% end    

% end
Fiber(i,1)=x1;
Fiber(i,2)=y1;
Fiber(i,3)=x2;
Fiber(i,4)=y2;
Fiber(i,5)=theta;
Fiber(i,6)=xm;
Fiber(i,7)=ym;
end

% plot
% the fibers on top of each other
for i = 1:N
subplot(2,2,1)
plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
axis([xc(1),xc(2),yc(1),yc(2)])
hold on
end
plot([x(1) x(1)],[y(1) y(2)],'b');
hold on
plot([x(2) x(2)],[y(1) y(2)],'b');
hold on
plot([x(1) x(2)],[y(1) y(1)],'b');
hold on
plot([x(1) x(2)],[y(2) y(2)],'b');

i = 1;
while i <= N % for all of the fibres
    
    it = 0; % if there is intersection this will be 1, otherwise 0
    if Fiber(i,1) < Fiber(i,3)
        xs = Fiber(i,1):(Fiber(i,3)-Fiber(i,1))/3:Fiber(i,3); % = x limit of the fiber
        xi1 = Fiber(i,1);
        yil = Fiber(i,2);
%         tg = (Fiber(i,4)-Fiber(i,2))/(Fiber(i,3)-Fiber(i,1));
    else
        xs = Fiber(i,3):(Fiber(i,1)-Fiber(i,3))/3:Fiber(i,1);
        xi1 = Fiber(i,3);
        yil = Fiber(i,4);
%         tg = -(Fiber(i,4)-Fiber(i,2))/(Fiber(i,3)-Fiber(i,1));
    end
    ys = tan(Fiber(i,5))*xs + yil - tan(Fiber(i,5))*xi1; % = y of the fiber 1
    
        xss = x(1):x(2)-x(1):x(2);
        yss = (0)*xss + y(1) - (0)*x(1);
        [xout1,yout1] = intersections(xs,ys,xss,yss,1); % finds the intersection of fiber and bottom line
            if ~isempty(xout1)
            it = 1;
            end
        xss = x(1):x(2)-x(1):x(2);
        yss = (0)*xss + y(2) - (0)*x(1);
        [xout2,yout2] = intersections(xs,ys,xss,yss,1); % finds the intersection of fiber and top line
            if ~isempty(xout2)
            it = 1;
            end
        xss = x(1):(x(2)-x(1))/100000:x(1)+(x(2)-x(1))/100000;
        yss = ((x(2)-x(1))/100000)/(y(2)-y(1))*xss + y(1) - ((x(2)-x(1))/100000)/(y(2)-y(1))*x(1);
        [xout3,yout3] = intersections(xs,ys,xss,yss,1); % finds the intersection of fiber and left line
            if ~isempty(xout3)
            it = 1;
            end
        xss = x(2)-(x(2)-x(1))/100000:(x(2)-x(1))/100000:x(2);
        yss = (y(2)-y(1))/((x(2)-x(1))/100000)*xss + y(2) - (y(2)-y(1))/((x(2)-x(1))/100000)*x(1);
        [xout4,yout4] = intersections(xs,ys,xss,yss,1); % finds the intersection of fiber and left line
            if ~isempty(xout4)
            it = 1;
            end
            
            if Fiber(i,6)>x(1) && Fiber(i,6)<x(2) && Fiber(i,7)>y(1) && Fiber(i,7)<y(2)
                it = 1;
            end
            
            
            if it == 0
                Fiber(i,:) = [];
            else
                i=i+1;
            end
            
            N = size(Fiber,1);
end


% cutting the out-of-range portion of the fibers and creating the boundary
% nodes

PBN = zeros(1,4); % position of boundary nodes - third column represents which boundary - 4th represents the number of the fiber
k = 1;
for i = 1:N
    % cutting x
    if Fiber(i,3) > x(2)
        Fiber(i,4) = tan(Fiber(i,5))*x(2) + Fiber(i,2) - tan(Fiber(i,5))*Fiber(i,1); 
        Fiber(i,3) = x(2);
%         if Fiber(i,4) < y(2) && Fiber(i,4) > y(1)
%             PBN(k,1) = x(2);
%             PBN(k,2) = Fiber(i,4);
%             PBN(k,3) = 5; % right
%             PBN(k,4) = i;
%             k = k+1;
%         end
    end
    
    if Fiber(i,1) > x(2)
        Fiber(i,2) = tan(Fiber(i,5))*x(2) + Fiber(i,4) - tan(Fiber(i,5))*Fiber(i,3); 
        Fiber(i,1) = x(2);
%         if Fiber(i,2) < y(2) && Fiber(i,2) > y(1)
%             PBN(k,1) = x(2);
%             PBN(k,2) = Fiber(i,2);
%             PBN(k,3) = 1; % right
%             PBN(k,4) = i;
%             k = k+1;
%         end
    end
    
    if Fiber(i,3) < x(1)
        Fiber(i,4) = tan(Fiber(i,5))*x(1) + Fiber(i,4) - tan(Fiber(i,5))*Fiber(i,3); 
        Fiber(i,3) = x(1);
%         if Fiber(i,4) < y(2) && Fiber(i,4) > y(1)
%             PBN(k,1) = x(1);
%             PBN(k,2) = Fiber(i,4);
%             PBN(k,3) = 2; % left
%             PBN(k,4) = i;
%             k = k+1;
%         end
    end
    
    if Fiber(i,1) < x(1)
        Fiber(i,2) = tan(Fiber(i,5))*x(1) + Fiber(i,2) - tan(Fiber(i,5))*Fiber(i,1); 
        Fiber(i,1) = x(1);
%         if Fiber(i,2) < y(2) && Fiber(i,2) > y(1)
%             PBN(k,1) = x(1);
%             PBN(k,2) = Fiber(i,2);
%             PBN(k,3) = 2; % left
%             PBN(k,4) = i;
%             k = k+1;
%         end
    end
    
    % cutting y
    if Fiber(i,4) > y(2)
        Fiber(i,3) = (y(2)-Fiber(i,2))/(Fiber(i,4)-Fiber(i,2))*(Fiber(i,3)-Fiber(i,1)) + Fiber(i,1);
        Fiber(i,4) = y(2);
        if Fiber(i,3) < x(2) && Fiber(i,3) > x(1)
            PBN(k,1) = Fiber(i,3);
            PBN(k,2) = y(2); 
            PBN(k,3) = 3; % top
            PBN(k,4) = i;
            k = k+1;
        end
    end
    
    if Fiber(i,2) > y(2)
        Fiber(i,1) = (y(2)-Fiber(i,4))/(Fiber(i,2)-Fiber(i,4))*(Fiber(i,1)-Fiber(i,3)) + Fiber(i,3);
        Fiber(i,2) = y(2);
        if Fiber(i,1) < x(2) && Fiber(i,1) > x(1)
            PBN(k,1) = Fiber(i,1);
            PBN(k,2) = y(2); 
            PBN(k,3) = 3; % top
            PBN(k,4) = i;
            k = k+1;
        end
    end
    
    if Fiber(i,4) < y(1)
        Fiber(i,3) = (y(1)-Fiber(i,2))/(Fiber(i,4)-Fiber(i,2))*(Fiber(i,3)-Fiber(i,1)) + Fiber(i,1);
        Fiber(i,4) = y(1);
        if Fiber(i,3) < x(2) && Fiber(i,3) > x(1)
            PBN(k,1) = Fiber(i,3);
            PBN(k,2) = y(1);
            PBN(k,3) = 4; % bottom 
            PBN(k,4) = i;
            k = k+1;
        end
    end
    
    if Fiber(i,2) < y(1)
        Fiber(i,1) = (y(1)-Fiber(i,2))/(Fiber(i,4)-Fiber(i,2))*(Fiber(i,3)-Fiber(i,1)) + Fiber(i,1);
        Fiber(i,2) = y(1);
        if Fiber(i,1) < x(2) && Fiber(i,1) > x(1)
            PBN(k,1) = Fiber(i,1);
            PBN(k,2) = y(1);
            PBN(k,3) = 4; % bottom 
            PBN(k,4) = i;
            k = k+1;
        end
    end
end


% finding the intersection of fibers---------------------------------------

 ip = zeros (N,2*N); % intersection position
 
for i = 1:N % for all of the fibres
    if Fiber(i,1) < Fiber(i,3)
        xs = Fiber(i,1):(Fiber(i,3)-Fiber(i,1))/3:Fiber(i,3); % = x limit of the fiber
        xi1 = Fiber(i,1);
        yil = Fiber(i,2);
%         tg = (Fiber(i,4)-Fiber(i,2))/(Fiber(i,3)-Fiber(i,1));
    else
        xs = Fiber(i,3):(Fiber(i,1)-Fiber(i,3))/3:Fiber(i,1);
        xi1 = Fiber(i,3);
        yil = Fiber(i,4);
%         tg = -(Fiber(i,4)-Fiber(i,2))/(Fiber(i,3)-Fiber(i,1));
    end
    ys = tan(Fiber(i,5))*xs + yil - tan(Fiber(i,5))*xi1; % = y of the fiber 1
    for j =1:N
        if i~=j
            if Fiber(j,1) < Fiber(j,3)
            xss = Fiber(j,1):(Fiber(j,3)-Fiber(j,1))/3:Fiber(j,3);
            xj1 = Fiber(j,1);
            yjl = Fiber(j,2);
%             tgg = (Fiber(j,4)-Fiber(j,2))/(Fiber(j,3)-Fiber(j,1));
            else
                xss = Fiber(j,3):(Fiber(j,1)-Fiber(j,3))/3:Fiber(j,1);
                xj1 = Fiber(j,3);
                yjl = Fiber(j,4);
%                 tgg = -(Fiber(j,4)-Fiber(j,2))/(Fiber(j,3)-Fiber(j,1));
            end
            yss = tan(Fiber(j,5))*xss + yjl - tan(Fiber(j,5))*xj1;
            
            [xout,yout] = intersections(xs,ys,xss,yss,1); % finds the intersection of fiber i and j
            
            if ~isempty(xout)
            ip(i,2*j-1) = xout;
            ip(i,2*j) = yout;
            end
        end
    end
end

% creating the PN----------------------------------------------------------
% first sorting the boundary nodes
PBN2 = sortrows(PBN,3);

nrb = 0; % number of right boundary
nlb = 0;
ntb = 0;
nbb = 0;

for i = 1:size(PBN2,1)
    if PBN2(i,3) == 1
        nrb = nrb + 1;
    elseif PBN2(i,3) == 2
        nlb = nlb + 1;
        elseif PBN2(i,3) == 3
          ntb = ntb + 1;
          elseif PBN2(i,3) == 4
            nbb = nbb + 1;
    end
end

PN(:,1:2) = PBN2(:,1:2);

% secondly sorting the fiber intersections considering the fact that the ip
% is diogonal matrix (i mean...u know!)

PI = zeros(1,3); % position of intersections [number of nodes,x ,y]
k = size(PBN2,1) + 1;
mip = ip; % modified ip - data below the diogonal line is deleted
for i = 1:N
    for j = 1 : 2*i-1
        mip(i,j) = 0;
    end
end

for i = 1:N
    if nnz(mip(i,:)) ~= 0 % if any node that is not labled exist
        for j = 1 : nnz(mip(i,:))/2
            PI(k,1) = k;
            pon = find(mip(i,:)); % pon = position of nodes in the mip
            xn = mip(i,pon(2*j-1));
            yn = mip(i,pon(2*j));
            PI(k,2) = xn;
            PI(k,3) = yn;
            k=k+1;
        end
    end
end

PN = PI;
PN(1:nrb+nlb+ntb+nbb,2) = PBN2(:,1);
PN(1:nrb+nlb+ntb+nbb,3) = PBN2(:,2);
k = 1;
for i = 1:nrb+nlb+ntb+nbb
PN(i,1) = k;
k=k+1;
end


%  since the left and right boundaries do not effect the shear modulus (due
%  the the lack of resistence to force) and that they cause problem in
%  numerical prosedure, it seems logical to delet the fibres that are
%  attached to these boundaries.











% creating the edge direction----------------------------------------------
% we end up with two situation:1- the fibers has connection with the
% boundary. 2- it doesnt.

mmip = zeros(N); % modified ip that includes the number of nodes that each fiber is connected to
k = nrb+nlb+ntb+nbb + 1;
for i = 1:N
    for j = 2*i:2*N
        if rem(j,2)==0
            if ip(i,j)~=0
                mmip(i,j/2) = k;
                k = k+1;
            end
        end
    end
end

for i = 1:N
    for j = 1:i
        mmip(i,j) = mmip(j,i);
    end
end

k = 1;
ED = zeros(1,2);
for i =1:N
    drp = zeros(1,2); % distance to reference point which is the first point of the fiber
    pon = find(mmip(i,:));
    nnf = mmip(i,pon); % address of the nodes that exist on the fiber
    lf = sqrt((Fiber(i,1)-Fiber(i,3))^2 + (Fiber(i,2)-Fiber(i,4))^2); % length of each fiber
    if lf == L % the fiber doesn't have connection with the boundary
        if nnz(mmip(i,:)) ~=0
            for j = 1:nnz(mmip(i,:))
                drp(j,2) = sqrt((Fiber(i,1)-PN(nnf(1,j),2))^2 + (Fiber(i,2)-PN(nnf(1,j),3))^2); 
                drp(j,1) = nnf(1,j);
            end
            ged = sortrows(drp,2); % guide to create ED
            if size(ged,1) > 1
                for l = 1:size(ged,1)-1
                    ED(k,1) = ged(l+1,1);
                    ED(k,2) = ged(l,1);
                    k = k+1;
                end
            end
        end
    else
        [sb,ggf] = size(find(PBN2(:,4)==i)); % sb =  number of nodes at the boundary 
        [nnb, jfdth] = find(PBN2(:,4)==i); % = address of node of the boundary
        for h = 1:sb
            sizel = size(nnf,2);
            nnf(1,sizel+1) = nnb(h,1);
        end
        if nnz(mmip(i,:)) + sb ~=0
            for j = 1:nnz(mmip(i,:)) + sb
                drp(j,2) = sqrt((Fiber(i,1)-PN(nnf(1,j),2))^2 + (Fiber(i,2)-PN(nnf(1,j),3))^2); 
                drp(j,1) = nnf(1,j);
            end
            ged = sortrows(drp,2); % guide to create ED
            if size(ged,1) > 1
                for l = 1:size(ged,1)-1
                    ED(k,1) = ged(l+1,1);
                    ED(k,2) = ged(l,1);
                    k = k+1;
                end
            end
        end
    end
end






NE = size(ED,1);
NN = size(PN,1);


% plot
% the fibers on top of each other
for i = 1:N
subplot(2,2,2)
plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
hold on
plot(PN(:,2), PN(:,3),'o');
end
% 
% % the fiber network
for j=1:NE
    subplot(2,2,3)
    n=ED(j,1);
    m=ED(j,2);
    plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)])
    hold on
end
% 
% 
% 
N
