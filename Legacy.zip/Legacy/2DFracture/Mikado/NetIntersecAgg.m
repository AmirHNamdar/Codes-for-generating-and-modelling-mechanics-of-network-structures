function [ip,Fiber,PI2,ED2] = NetIntersecAgg(Fiber,x,y,PBN2,nf,density)

N=size(Fiber,1);
% the mean size of segment is lc=pi/(2*density), therefore the number of
% intersections per fibre is 2*density/pi
% ninter = floor(2*2*density/pi*N) % number of expected intersections
% ip = spalloc (N,2*N,ninter); % intersection position
% ip = zeros(N,2*N);
% Per = false;
ip = 0;
% tic
% for i=1:N
%     for j=1:N
%         if j~=i
%             % find its contact with fiber j (if yes, ec ==1, otherwise, ec ==0)
%             if Fiber(i,9) - Fiber(j,9) <= 1 && Fiber(i,9) - Fiber(j,9) >= -1 && Fiber(i,10) - Fiber(j,10) <= 1 && Fiber(i,10) - Fiber(j,10) >= -1
%             [ec,xi,yi] = intersection2(Fiber,i,j);
%             if ec == 1
%             ip(i,2*j-1) = xi;
%             ip(i,2*j) = yi;
%                 lfj = Fiber(j,8); %  label of fiber j
%                 for k=1:N
%                     if Fiber(k,8) == lfj
%                         Fiber(k,8) = i;
%                     end
%                 end
%             end
%             end
%         end
%     end
% end
% inttoc = toc
% tic

nrb = 0; % number of right boundary node
nlb = 0;
ntb = 0;
nbb = 0;

for i = 1:size(PBN2,1)
    if PBN2(i,3) == 1
        nrb = nrb + 1;
    elseif PBN2(i,3) == 2
        nlb = nlb + 1;
        elseif PBN2(i,3) == 3
          ntb = ntb + 1;
          elseif PBN2(i,3) == 4
            nbb = nbb + 1;
    end
end


PN3(:,1:2) = PBN2(:,1:2);

 



I = [];
J = [];
K2 = [];
ED2 = [];
PI2 = zeros(1,3);
cou = size(PBN2,1)+1;

% for fibre connection
ca = [];
ica = [];
jca = [];

for i=1:N
    for j=i+1:N
        if j~=i
            % find its contact with fiber j (if yes, ec ==1, otherwise, ec ==0)
            if Fiber(i,9) - Fiber(j,9) <= 1 && Fiber(i,9) - Fiber(j,9) >= -1 && Fiber(i,10) - Fiber(j,10) <= 1 && Fiber(i,10) - Fiber(j,10) >= -1
            [ec,xi,yi] = intersection2(Fiber,i,j);
            if ec == 1
%             ip(i,2*j-1) = xi;
%             ip(i,2*j) = yi;
%             I(end+1) = i;
%             I(end+1) = i;
%             J(end+1) = 2*j-1;
%             J(end+1) = 2*j;
%             K2(end+1) = xi;
%             K2(end+1) = yi;
            PI2(cou,1) = cou;
            PI2(cou,2) = xi;
            PI2(cou,3) = yi;  
%             API(i,j) = cou; % adddress of PI (which two fibres are connected)
            ica(end+1) = i;
            jca(end+1) = j;
            ca(end+1) = cou;
            
            cou = cou+1;
%                 lfj = Fiber(j,8); %  label of fiber j
%                 for k=1:N
%                     if Fiber(k,8) == lfj
%                         Fiber(k,8) = i;
%                     end
%                 end
            end
            end
        end
        
    end
end

API = sparse(ica,jca,ca,N,N); % connection of fibres 

cou = size(PBN2,1)+1;

for i=1:N
    xside = Fiber(i,1); % one side position
    yside = Fiber(i,2);
    disx = [];
    for j=1:N
        if j~=i
            % find its contact with fiber j (if yes, ec ==1, otherwise, ec ==0)
            if Fiber(i,9) - Fiber(j,9) <= 1 && Fiber(i,9) - Fiber(j,9) >= -1 && Fiber(i,10) - Fiber(j,10) <= 1 && Fiber(i,10) - Fiber(j,10) >= -1
            [ec,xi,yi] = intersection2(Fiber,i,j);
            if ec == 1
                if j>i
            disx(end+1,1) = (xi-xside); % x distance to the side point
            disx(end,2) = cou; % the number of the node that is there   
            cou = cou+1;
                end
                if i>j
                    disx(end+1,1) = (xi-xside); % x distance to the side point
                    disx(end,2) = API(j,i); % the number of the node that is there   
                end
%                 lfj = Fiber(j,8); %  label of fiber j
%                 for k=1:N
%                     if Fiber(k,8) == lfj
%                         Fiber(k,8) = i;
%                     end
%                 end
            end
            end
        end
        
    end
    

     if Fiber(i,11) ~=5
         pbn = find(PBN2(:,4)==i); % position of the boundary node
         disx(end+1,1) = (PBN2(pbn(1,1),1)-xside); % x distance to the side point
         disx(end,2) = pbn(1,1); % the number of the node that is there   
     end
     if Fiber(i,12) ~=5
         pbn = find(PBN2(:,4)==i); % position of the boundary node
         disx(end+1,1) = (PBN2(pbn(end),1)-xside); % x distance to the side point
         disx(end,2) = pbn(end); % the number of the node that is there   
     end
      % to create the ED
      if ~isempty(disx)
        disx = sortrows(disx,1);
        for k = 1:size(disx,1)-1
            ED2(end+1,1) = disx(k,2); 
            ED2(end,2) = disx(k+1,2);
            ED2(end,3) = Fiber(i,13); % thickness of the fibre
        end
      end
    
end
% ipsparse = sparse(I,J,K2,N,2*N);
% nnz(ipsparse)
% nnz(ip);
% ip = full(ipsparse);
% int2toc = toc

% cnr = []; % cluster number of right boundary
% cnl = []; % cluster number of left boundary
% cnt = []; % cluster number of top boundary
% cnb = []; % cluster number of bottom boundary


% for i = 1 : size(PBN,1)
%     nf = PBN(i,4); % number of fibre
%     if PBN(i,3) == 1
%         cnr(end+1) = Fiber(nf,8);
%     elseif PBN(i,3) == 2
%         cnl(end+1) = Fiber(nf,8);
%     elseif PBN(i,3) == 3
%         cnt(end+1) = Fiber(nf,8);
%     elseif PBN(i,3) == 4
%         cnb(end+1) = Fiber(nf,8);
%     end
% end
% % % % % % % % % % cnr
% % % % % % % % % % cnl
% % % % % % % % % % cnt
% % % % % % % % % % cnb

% HPer = false;
% for i=1:size(cnr,2)
%     for j=1:size(cnl,2)
%         if cnr(1,i) == cnl(1,j)
%             HPer = true;
%         end
%     end
% end
% % % % % % % % HPer
% VPer = false;
% for i=1:size(cnt,2)
%     for j=1:size(cnb,2)
%         if cnt(1,i) == cnb(1,j)
%             VPer = true;
%             pc = cnt(1,i); % percolated cluster 
%         end
%     end
% end
% % % % % % % % % VPer
% if VPer == true % && HPer == true
%     Per = true;
% end
% 
% if Per ==false
%     pc = 0;
% end
% % % % % % % % % pc

end