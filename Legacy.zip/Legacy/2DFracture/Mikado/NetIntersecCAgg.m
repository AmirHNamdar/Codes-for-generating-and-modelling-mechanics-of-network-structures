function [Per,ip,pc,Fiber] = NetIntersecCAgg(Fiber,x,y,PBN,nf,density)

N=size(Fiber,1);
ip = 0; % intersection position
Per = false;

% tic
for i=1:N
    for j=1:N
        if j~=i
            % find its contact with fiber j (if yes, ec ==1, otherwise, ec ==0)
            
            if Fiber(i,9) - Fiber(j,9) <= 1 && Fiber(i,9) - Fiber(j,9) >= -1 && Fiber(i,10) - Fiber(j,10) <= 1 && Fiber(i,10) - Fiber(j,10) >= -1
                [ec] = intersection2(Fiber,i,j);
            if ec == 1
%             ip(i,2*j-1) = xi;
%             ip(i,2*j) = yi;
                lfj = Fiber(j,8); %  label of fiber j
                for k=1:N
                    if Fiber(k,8) == lfj
                        Fiber(k,8) = i;
                    end
                end
            end
            end
        end
    end
end
% toc
% tic


% to investigate percolation of the system

pc = [];
VPer = false;

for i = 1:size(PBN,1)
    if PBN(i,3) == 4 % we are just interested in vertical percolation
    nf = PBN(i,4); %  fibre number 
    cnf = Fiber(nf,8); % cluster number of the fibre
    ncf = PBN(PBN(i,5),4); % fibre numebr of the couple
    cncf = Fiber(ncf,8); % cluster number of the couple fibre
    if cnf == cncf
        VPer = true;
        if isempty(pc)
            pc(end+1,1) = cnf;
        else
            for kk=1:size(pc,1)
                if cnf~=pc(kk,1)
                    pc(end+1,1) = cnf;
                end
            end
        end
    end
    end
end
    
if VPer == true % && HPer == true
    Per = true;
end

if Per ==false
    pc = 0;
end
        
        

% toc






% figure1 = figure;
%     for i =1:size(Fiber,1)
%         co = [0 0 1];
%         for j = 1:size(pc,1)
%             if Fiber(i,8) == pc(j,1)
%                 co = [1 0 0];
%             end
%         end
%             
%     plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'color',co);
%     hold on
% %     plot(Fiber(i,6),Fiber(i,7),'o')
%     end
%     cbn = rand(size(PBN,1),3); % color of the boundary node
% %     PBN
%     for j =1:size(PBN,1)
%         l=1;
%         for k=1:j-1
%             if PBN(k,5)==j
%                 l=k;
%                 break
%             else
%                 l = j;
%             end
%         end
% %         PBN(j,3)/4
%         plot([PBN(j,1)],[PBN(j,2)],'o','color',cbn(l,:),'MarkerSize',10,'MarkerFaceColor',cbn(l,:))
%     end
%           pbaspect([1 1 1])
     
     
     
     
     pc;
     
     









% cnr = []; % cluster number of right boundary
% cnl = []; % cluster number of left boundary
% cnt = []; % cluster number of top boundary
% cnb = []; % cluster number of bottom boundary
% 
% for i = 1 : size(PBN,1)
%     nf = PBN(i,4); % number of fibre
%     if PBN(i,3) == 1
%         cnr(end+1) = Fiber(nf,8);
%     elseif PBN(i,3) == 2
%         cnl(end+1) = Fiber(nf,8);
%     elseif PBN(i,3) == 3
%         cnt(end+1) = Fiber(nf,8);
%     elseif PBN(i,3) == 4
%         cnb(end+1) = Fiber(nf,8);
%     end
% end
% 
% % % % % % % % % % % cnr
% % % % % % % % % % % cnl
% % % % % % % % % % % cnt
% % % % % % % % % % % cnb
% 
% % HPer = false;
% % for i=1:size(cnr,2)
% %     for j=1:size(cnl,2)
% %         if cnr(1,i) == cnl(1,j)
% %             HPer = true;
% %         end
% %     end
% % end
% % % % % % % % % HPer
% VPer = false;
% for i=1:size(cnt,2)
%     for j=1:size(cnb,2)
%         if cnt(1,i) == cnb(1,j)
%             VPer = true;
%             pc = cnt(1,i); % percolated cluster 
%         end
%     end
% end
% % % % % % % % % VPer
% if VPer == true % && HPer == true
%     Per = true;
% end
% 
% if Per ==false
%     pc = 0;
% end
% % % % % % % % % pc

end