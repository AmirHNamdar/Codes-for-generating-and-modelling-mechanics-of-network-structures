function out = smooth_second_derivative(lambda, W, opts)
% Toolbox-free robust second derivative for noisy data.
% Steps:
%   1) sort & dedup, scale lambda to [0,1] (improves conditioning)
%   2) resample to uniform grid (PCHIP, no toolbox)
%   3) moving Savitzky–Golay (hand-rolled) with symmetric padding
%   4) map derivatives back to original lambda scale
%
% Inputs:
%   lambda (Nx1), W (Nx1)
%   opts.win   : odd window length (default ≈ 7% of N, min 11)
%   opts.order : poly degree for SG (default 3; use 3–4 for curvature)
%   opts.Mu    : uniform resample length (default = N)
%
% Outputs (struct):
%   out.lambda      : original lambda (sorted, unique)
%   out.Ws          : smoothed W at out.lambda
%   out.dW          : first derivative dW/dλ at out.lambda
%   out.d2W         : second derivative d²W/dλ² at out.lambda
%   out.diag        : diagnostics (scales, window, etc.)

lambda = lambda(:);  W = W(:);

% --- 0) sort & de-duplicate
[lambda, ia] = unique(lambda,'stable');  W = W(ia);
N = numel(lambda);
if N < 7, error('Too few points for stable second derivatives.'); end

% --- 1) scale lambda -> s in [0,1] to stabilise the fit
Lmin = lambda(1);
Lmax = lambda(end);
Lrng = Lmax - Lmin;
if ~isfinite(Lrng) || Lrng <= 0
    error('lambda must span a positive range.');
end
s = (lambda - Lmin) / Lrng;

% --- defaults
if nargin < 3, opts = struct; end
if ~isfield(opts,'Mu')    || isempty(opts.Mu),    opts.Mu    = N; end           % uniform resample count
if ~isfield(opts,'order') || isempty(opts.order), opts.order = 3; end           % 3 or 4 recommended
% window ≈ 7% of N_u, must be odd and >= order+2
if ~isfield(opts,'win')   || isempty(opts.win)
    win = 2*floor(0.07*opts.Mu/2)+1;
    opts.win = max([11, opts.order+2, win]);
end
win   = opts.win;
order = opts.order;
Mu    = max(opts.Mu, N);

% --- 2) resample W onto a UNIFORM grid in s
su = linspace(0,1,Mu).';
Wu = interp1(s, W, su, 'pchip');  % shape-preserving, base MATLAB

% --- 3) SG coefficients (about 0) on uniform spacing Δs
half = (win-1)/2;
if mod(win,2)==0, error('opts.win must be odd.'); end
if win < order+2, error('opts.win must be >= order+2.'); end

ds = mean(diff(su));
t = (-half:half).' * ds;                 % local coordinates around center

% Vandermonde for local poly y ≈ Σ a_k t^k, k=0..order
A = zeros(win, order+1);
for k = 0:order
    A(:,k+1) = t.^k;
end
% Least-squares projection
G = (A.'*A) \ (A.');   % (order+1 x win)

% Convolution weights for smooth/1st/2nd derivatives at t=0:
h0 = G(1,:);                         % a0
h1 = (1 * G(2,:)) / ds;              % 1!*a1 / ds
h2 = (2 * G(3,:)) / (ds^2);          % 2!*a2 / ds^2

% Symmetric reflection padding to keep length
Wpad = reflect_pad(Wu, half);
Ws_u = conv(Wpad, h0, 'valid');
d1_u = conv(Wpad, h1, 'valid');
d2_u = conv(Wpad, h2, 'valid');

% --- 4) Map back from s-grid to original lambda with correct unit scaling
% Chain rule: d/dλ = (1/Lrng) d/ds;  d²/dλ² = (1/Lrng²) d²/ds²
Ws  = interp1(su, Ws_u, s, 'pchip');
dW  = interp1(su, d1_u, s, 'pchip') / Lrng;
d2W = interp1(su, d2_u, s, 'pchip') / (Lrng^2);

% --- pack
out.lambda = lambda;
out.Ws     = Ws;
out.dW     = dW;
out.d2W    = d2W;
out.diag   = struct('win',win,'order',order,'Mu',Mu,'Lmin',Lmin,'Lmax',Lmax,'Lrng',Lrng);
end

function ypad = reflect_pad(y, m)
% Symmetric (odd) reflection: y[m+1:-1:2], y, y[end-1:-1:end-m]
n = numel(y);
if m<1, ypad = y; return; end
ypre  = y((m+1):-1:2);
ypost = y((n-1):-1:(n-m));
ypad  = [ypre; y; ypost];
end
