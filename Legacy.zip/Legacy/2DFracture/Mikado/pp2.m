close all
clear 
clc

dth = 5.2517; % Threshold density pr40=5.2517

load SSPr0lambda5-2
% load SSPr40lambda5
% load SSPr80lambda5
% load TestPr0
nd = Ns; % number of density studied
area = lambda^2+lambda*4+4;
% considering 0 zeros
% MGe = mean(Ge);
% MGs = mean(Gs);


MGeg = zeros(nd,1);
MGsg = zeros(nd,1);
den = zeros(nd,1);
for i=1:nd
    den(i,1) = (Nf(1,1)+i*Nf(1,3));
end

den = den/area;
den = den;
MGeg(1:nd,1) = MGe;
MGsg(1:nd,1) = MGs;

% load SRSA1I1L1Nf150-200-data
% % 
%  MGeg2(1:6,1) = MGe;
%  MGsg2(1:6,1) = MGs;
% 
% load SRSA1I1L1Pr0Nf150-200-data
%  
%  MGeg3(1:6,1) = MGe;
%  MGsg3(1:6,1) = MGs;


loge = log10(MGeg);
logs = log10(MGsg);
logden = log10(den);
% loge2 = log10(MGeg2);
% logs2 = log10(MGsg2);
% loge3 = log10(MGeg3);
% logs3 = log10(MGsg3);


pole = polyfit(logden,loge,1)
pols = polyfit(logden,logs,1)

figure1 = figure;
plot(logden,loge)
% hold on
% plot(logden,loge2)
% hold on
% plot(logden,loge3)

figure2 = figure;
plot(logden,logs)
% hold on
% plot(logden,logs2)
% hold on
% plot(logden,logs3)
% 
% figure3 = figure
% plot(den,MGeg)
% hold on
% plot(den,MGeg2)
% hold on
% plot(den,MGeg3)

% figure4 = figure
% plot(den,MGsg)
% hold on
% plot(den,MGsg2)
% hold on
% plot(den,MGsg3)


% (loge(end,1)-loge(1,1))/(logden(end,1)-logden(1,1))
% (loge2(end,1)-loge2(1,1))/(logden(end,1)-logden(1,1))
% (loge3(end,1)-loge3(1,1))/(logden(end,1)-logden(1,1))
% 
% (logs(end,1)-logs(1,1))/(logden(end,1)-logden(1,1))
% (logs2(end,1)-logs2(1,1))/(logden(end,1)-logden(1,1))
% (logs3(end,1)-logs3(1,1))/(logden(end,1)-logden(1,1))
% 
%  load SSdata
%  denG = zeros(25,1);
%  for i = 1: 25
%      denG(i,1) = i*4-2;
%  end
%  
%  figure5 = figure
%  plot(log10(denG),log10(G))
%  
 
%  error

erGe = zeros(1,nd);
for i=1:nd
    ff=(Ge(:,i)-MGe(1,i)).^2;
    erGe(1,i)= sqrt(sum(ff)/size(Ge,1))/sqrt(size(Ge,1));
end
 erGe
 
 
 
 
 
 