%%%%%%%% things to test 

% the network graph with number of nodes and edges __________________________


figure1=figure;
for i=1:NE
    n=ED(i,1);
    m=ED(i,2);
    plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)])
    texte = strcat(num2str(i));
    texth1 = strcat(num2str(PN(n,1)));
    texth2 = strcat(num2str(PN(m,1)));
    text((PN(n,2)+PN(m,2))/2,(PN(n,3)+PN(m,3))/2,texte,'Color','green','FontSize',14)
    text(PN(n,2)+1*lambda/100,PN(n,3),texth1,'Color','red','FontSize',14)
    text(PN(m,2)-1*lambda/100,PN(m,3),texth2,'Color','black','FontSize',14)
%     plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)])
    hold on
    plot(PN(:,2), PN(:,3),'o');
end 

% to see what edges are on top of each other__________________________

tnoe = [];% the number of edge
for i = 1:NE
    fN = ED(i,1); % first node number
    sN = ED(i,2); % second node number
            intE = 0; % edges on top of eachother (yes: intE >= 2, no: intE = 1) 
        for l = 1:size(ED,1)
            if ED(l,1) == fN && ED(l,2) == sN
                intE = intE + 1;
            end
            if ED(l,2) == fN && ED(l,1) == sN
                intE = intE + 1;
            end
        end
        
        if intE>1
            tnoe(end+1) = i;
        end
end
   

% the data that is not saved__________________________
NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);

% loading the data __________________________
load RSA1I1L1j3-96v

% testing the size of fibres__________________________
Lf=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    Lf(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end   

% which edges are shorter than the treshold?

shortF = zeros(NE,1); % is it a short fibre? (1 = yes, 0 = no)
for i = 1:NE
    if Lf(i,1) < flt
        shortF(i,1) = 1;
    end
end
shF = shortF; % the shortF is manipulated and changed in the loop below.
% size(shortF);
nsF = sum(shortF(:) == 1); % number of short fibres

% deleting the suspesiios data from Ge___________________________

for j = 1:Ns
    for i = 1:N2s
        if Ge(i,j)>5e4
            Ge(i,j) = 0;
        end
        if Gs(i,j)>5e4
            Gs(i,j) = 0;
        end
    end
end











