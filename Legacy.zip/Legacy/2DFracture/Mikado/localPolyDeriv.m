function [dW, d2W, Wfit] = localPolyDeriv(lambda, W, n, winPts)
%LOCALPOLYDERIV  Local polynomial (order n) regression on a sliding window,
% then evaluate 1st and 2nd derivatives at each lambda_i.
%
% Inputs
%   lambda : Nx1 vector (not necessarily uniform). Repeats allowed but discouraged.
%   W      : Nx1 vector, same length as lambda
%   n      : polynomial order (e.g., 2..5). Must be >= 1
%   winPts : number of points in the local window (odd recommended, >= n+1)
%
% Outputs
%   dW   : Nx1, first derivative dW/dλ
%   d2W  : Nx1, second derivative d²W/dλ²
%   Wfit : Nx1, locally-fitted value at each λ (useful for denoised curve)
%
% Notes
%   - Works with non-uniform spacing by fitting in local coordinates t = λ - λ_i.
%   - Near the boundaries it uses an asymmetric window.
%   - No toolboxes required.

  arguments
    lambda (:,1) double
    W      (:,1) double
    n (1,1) {mustBeInteger, mustBeNonnegative} = 3
    winPts (1,1) {mustBeInteger, mustBePositive} =  nineOrNplus3(n)
  end

  % --- sort & unique (keep first occurrence)
  [lambda, idx] = sort(lambda(:));  W = W(idx);
  [lambda, ia] = unique(lambda, 'stable');  W = W(ia);
  N = numel(lambda);

  if winPts < n+1
    error('winPts must be at least n+1. Got winPts=%d, n=%d.', winPts, n);
  end
  if winPts > N
    winPts = N;   % clamp if dataset is tiny
  end

  dW   = NaN(N,1);
  d2W  = NaN(N,1);
  Wfit = NaN(N,1);

  half = floor((winPts-1)/2);

  for i = 1:N
    % Choose window [iL..iR] centered on i where possible
    iL = max(1, i - half);
    iR = min(N, i + half);
    % If window too small at edges, slide it
    cur = iR - iL + 1;
    if cur < winPts
      short = winPts - cur;
      % try extend left
      iL = max(1, iL - short);
      iR = min(N, iL + winPts - 1);
      cur = iR - iL + 1;
      if cur < winPts
        % extend right if still short
        iR = min(N, iR + (winPts - cur));
        iL = max(1, iR - winPts + 1);
      end
    end

    Lw = lambda(iL:iR);
    Ww = W(iL:iR);

    % Local coordinates around λ_i for better conditioning
    lam0 = lambda(i);
    t = Lw - lam0; % so derivative at t=0 equals polynomial coefficients
    % Build Vandermonde: [1, t, t^2, ... t^n]
    V = ones(numel(t), n+1);
    for k = 2:n+1
      V(:,k) = t.^(k-1);
    end

    % Optional: small Tikhonov regularization for stability if window is ill-conditioned
    % (set tiny alpha; can be zero normally)
    alpha = 0;  % 1e-12 is a safe tiny value if needed
    if alpha > 0
      A = [V; sqrt(alpha)*eye(n+1)];
      b = [Ww; zeros(n+1,1)];
      p = A\b;
    else
      % Least squares via QR
      p = V \ Ww;
    end

    % p(1) is value at t=0; p(2) is 1st deriv at 0; p(3) relates to 2nd deriv /2!, etc.
    Wfit(i) = p(1);
    if n >= 1
      dW(i)  = p(2);             % dW/dλ at λ_i
    end
    if n >= 2
      d2W(i) = 2*p(3);           % because term is p3 * t^2, derivative twice -> 2*p3
    end
  end
end

function x = nineOrNplus3(n)
  % a sensible default for winPts: max(9, n+3), and prefer odd
  x = max(9, n+3);
  if mod(x,2)==0, x = x+1; end
end
