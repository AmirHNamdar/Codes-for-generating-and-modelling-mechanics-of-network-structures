function [SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRand(x,y,L,N,lambda,flt,Pr,density)
% clear all
% clc
% close all

% for kl = 1:10000

% lambda = 1;
% x = [0 lambda];
% y = [0 lambda];
% L = 1;
% N = 300;
% flt = 10^(-2)*lambda;

% tic
% creating the Fiber-----------------------------------------------------

[Fiber,xc,yc,nf,PBN] =  FiberC(x,y,L,N,lambda,Pr);
N = nf;
% figure1 = figure;
% plot(PBN(:,1),PBN(:,2),'o')
% fibercT = toc
% the fibre network inside the squre box is created and the boundary
% nodes are found and put in the PBN

% figure to test


% tic
    [Per,ip,pc,Fiber] = NetIntersecC(Fiber,x,y,PBN,nf,density);
    
% intersecT = toc
% intersection of fibres (with BC and eachother)...
% ... and allocating the cluster code
% pc represents the percolated cluster number (other...
% ...fibres should be deleted)
% % % % % % % % % figure1 = figure;
% % % % % % % % % for i = 1:size(Fiber)
% % % % % % % % %     if Fiber(i,8)==pc
% % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'r');
% % % % % % % % %     else
% % % % % % % % %         plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'b');
% % % % % % % % %     end
% % % % % % % % % hold on
% % % % % % % % % plot(PBN(:,1),PBN(:,2),'o')
% % % % % % % % % end
% % % % % % PBN
% % % % % % % % % % % % % % % % figure3 = figure;
% % % % % % % % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % % % % % % % hold on
% % % % % % % % % % % % % % % % plot(PBN(:,1), PBN(:,2),'o');
% % % % % % % % % % % % % % % % end

% Per represent the percolation (in both direction)

if Per == false
    SDataH = 0;
    SDataV = 0;
    Fiber = 0;
    SDatatest = 0;
else % if the system is percolated then do the rest of the code
  



% deleting the boundary nodes that are not connected to the main cluster

% tic 

spb2 = size(PBN,1);
kkk =1;
while kkk <= spb2
    if Fiber(PBN(kkk,4),8) ~= pc
        PBN (kkk,:) = [];
        kkk=kkk-1;
        spb2 = spb2-1;
    end
    kkk=kkk+1;
end

% figure1 = figure;
% for i = 1:size(Fiber)
%     if Fiber(i,8)==pc
% plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'r');
%     else
%         plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)],'b');
%     end
% hold on
% plot(PBN(:,1),PBN(:,2),'o')
% end


% figure to test
% % % % % % % % % % % % % figure2 = figure;
% % % % % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % % % % hold on
% % % % % % % % % % % % % end

 
% deleting the fibers that are not in the main cluster (fibres are either in the same cluster or are freely moving in the space which should be deleted)  
k=1;
nfd = 1; % to count the number of fibers
ndf = []; % deleted fibers
while k <= nf
    if Fiber(k,8)~=pc
        Fiber(k,:) =[];
%         ip(k,:) = []; % deleting the intersection of these fibers
%         ip(:,2*k-1:2*k) = [];
        nf = nf-1;
        k=k-1;
        ndf(end+1) = nfd; % to correct the address of fibres in the PBN
    end
    k=k+1;
    nfd = nfd+1;
end




% correcting the address of PBN (since some fibres are deleted)
PBN(:,5) = 0;
if ~isempty(ndf)
    for i=1:size(ndf,2)
        for j=1:size(PBN,1)
            if PBN(j,4)>ndf(1,i)
                PBN(j,5) = PBN(j,5)+1;
            end
        end
    end
end
PBN(:,4) = PBN(:,4)-PBN(:,5);
N = nf;
% stuffT = toc
% finding the ip for the new network
PBN2 = sortrows(PBN,3);

% tic
[ip,Fiber,PI2,ED2] = NetIntersec(Fiber,x,y,PBN2,nf,density);
% [Per,ip,pc,Fiber] = NetIntersecOld(Fiber,x,y,PBN,nf,density);
% netintersec2T = toc



% Deleting the right and left boundaries and creating the vertical data.


% spbn2 = size(PBN2,1); % size of PBN2
% kk=1;
% while kk <= spbn2
%     if PBN2 (kk,3) == 1 || PBN2 (kk,3) == 2
%         PBN2(kk,:) = [];
%         spbn2 = spbn2-1;
%         kk=kk-1;
%     end
%     kk=kk+1;
% end

% % % % % % % % % % % % % % % % figure1 = figure;
% % % % % % % % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % % % % % % % hold on
% % % % % % % % % % % % % % % % plot(PBN2(:,1), PBN2(:,2),'o');
% % % % % % % % % % % % % % % % end
% tic
    [SData] = SortData(Fiber,N,PBN,PBN2,ip,L,lambda,density,PI2,ED2);
%     [SData] = SortDataOld(Fiber,N,PBN,PBN2,ip,L,lambda,density);
% sortdT = toc
    % this function gets raw data and changes it to the type that is ...
    % ...possible for the solver to understand. SDataH = Sorted data
    % horizental and V = vertical.
    % they include NN,NE,ED,PN, and data of boundaries.
    
NE = SData(1,6);
NN = SData(1,7);
PN = SData(1:NN,1:3);
ED = SData(1:NE,4:5);
nrb = SData(1,8);
nlb = SData(2,8);
ntb = SData(3,8);
nbb = SData(4,8);
nbn = nrb+nlb+ntb+nbb; % number of boundary nodes

% fogure1 = figure;
% for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'b')
%     hold on
% end
    
    Lf=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    Lf(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end 
    shortF = zeros(NE,1); % is it a short fibre? (1 = yes, 0 = no)
for i = 1:NE
    if Lf(i,1) < flt
        shortF(i,1) = 1;
    end
end
shF = shortF; % the shortF is manipulated and changed in the loop below.
% size(shortF);
nsF = sum(shortF(:) == 1); % number of short fibres

    



%     tic
    SDatatest = SData;
    SData = ModifyingNetworkLength(SData,flt);
    SDataV = SData;
%     lengthT = toc
% % % % % % % %     figure3 = figure;
% % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % hold on
% % % % % % % % end
    
    % Deleting the right and left boundaries and creating the vertical data.
% PBN2 = sortrows(PBN,3);
% 
% spbn2 = size(PBN2,1); % size of PBN2
% kk=1;
% while kk <= spbn2
%     if PBN2 (kk,3) == 3 || PBN2 (kk,3) == 4
%         PBN2(kk,:) = [];
%         spbn2 = spbn2-1;
%         kk=kk-1;
%     end
%     kk=kk+1;
% end


% % % % % % % % % % % % % % figure2 = figure;
% % % % % % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % % % % % hold on
% % % % % % % % % % % % % % plot(PBN2(:,1), PBN2(:,2),'o');
% % % % % % % % % % % % % % end

%     [SData] = SortData(Fiber,N,PBN,PBN2,ip,L);
%     SDataH = SData;

% deleting the dangling clusters using electrical current analysis (finding backbone)

NE = SDataV(1,6); % number of edges
NN = SDataV(1,7); % number of nodes
PN = SDataV(1:NN,1:3); % position of nodes
ED = SDataV(1:NE,4:5); % edge direction (node 1 to node 2)
nrb = SDataV(1,8); % number of boundary nodes on right side
nlb = SDataV(2,8); % number of boundary nodes on left side
ntb = SDataV(3,8); % number of boundary nodes on top side
nbb = SDataV(4,8); % number of boundary nodes on bottom side
nbn = nrb+nlb+ntb+nbb; % number of tottal boundary nodes

% fogure1 = figure;
% for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)])
%     hold on
%     pbaspect([1 1 1])
% end
% xlim([0 10])
%
% fogure2 = figure;
% 
% for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'b')
%     hold on
%     pbaspect([1 1 1])
% end
% size(ED)
% size(ED2)

% tic
% % % % % % % % % % % SDataV = BackboneCA(SDataV);
% bbT = toc


SDataH = 0;
% % % % % % % % % %     figure4 = figure;
% % % % % % % % % % for i = 1:size(Fiber,1)
% % % % % % % % % % plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% % % % % % % % % % hold on
% % % % % % % % % % end




end
% end
end





