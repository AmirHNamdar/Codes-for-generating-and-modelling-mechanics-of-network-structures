function [nir,x1,x2,y1,y2,bp1,bp2] = portion(x1o,x2o,y1o,y2o,x,y,theta)

% nir 0 means there is no portion from the fibre in the study domain
nir = 0;
p1 = 0; % position of one end of the fibre
p2 = 0; % position of the other end of the fibre
if x1o < x(2) && x1o > x(1) && y1o < y(2) && y1o > y(1)
    p1 = 1; % point 1 is in the range
end

if x2o < x(2) && x2o > x(1) && y2o < y(2) && y2o > y(1)
    p2 = 1; % point 1 is in the range
end

%____________________condition 1________________________
% if both point are in the range, then whole fibre is in the range
if p1 == 1 && p2 == 1
    str = 'condition 1';
    nir = 1;
    x1 = x1o;
    x2 = x2o;
    y1 = y1o;
    y2 = y2o;
    bp1 = 5;
    bp2 = 5;
end
%____________________condition 2_________________________
% if one point is in the range and the other is outside then there is
% intersection with the boundary which should be find
if p1 == 1 && p2 == 0 % point 1 is in the range and the other outside
    str = 'condition 2';
    nir = 1; 
    x1 = x1o;
    y1 = y1o;
    bp1 = 5;
    
    
    if x2o > x(2)
        y2o = tan(theta)*x(2) + y1o - tan(theta)*x1o; 
        x2o = x(2);
        bp2 = 1;
    elseif x2o < x(1)
        y2o = tan(theta)*x(1) + y2o - tan(theta)*x2o; 
        x2o = x(1);
        bp2 = 2;
    end
    
    if y2o > y(2)
        x2o = (y(2)-y1o)/(y2o-y1o)*(x2o-x1o) + x1o;
        y2o = y(2);
        bp2 = 3;
    elseif y2o < y(1)
        x2o = (y(1)-y1o)/(y2o-y1o)*(x2o-x1o) + x1o;
        y2o = y(1);
        bp2 = 4;
    end
    
    x2 = x2o;
    y2 = y2o;
    
end

if p1 == 0 && p2 == 1 % point 2 is in the range and the other outside
    str = 'condition 2';
    nir = 1; 
    x2 = x2o;
    y2 = y2o;
    bp2 = 5;
    
    if x1o > x(2)
        y1o = tan(theta)*x(2) + y2o - tan(theta)*x2o; 
        x1o = x(2);
        bp1 = 1;
    elseif x1o < x(1)
        y1o = tan(theta)*x(1) + y1o - tan(theta)*x1o; 
        x1o = x(1);
        bp1 = 2;
    end
    
    if y1o > y(2)
        x1o = (y(2)-y2o)/(y1o-y2o)*(x1o-x2o) + x2o;
        y1o = y(2);
        bp1 = 3;
    elseif y1o < y(1)
        x1o = (y(1)-y1o)/(y2o-y1o)*(x2o-x1o) + x1o;
        y1o = y(1);
        bp1 = 4;
    end
    
    x1 = x1o;
    y1 = y1o;
end

%_____________________condition 3_________________________
% there is two conditon for this. 1- all of the fibre is outside of the
% study region. 2- the fibre cut two boundaries.

if p1 == 0 && p2 == 0
    str = 'condition 3';
    fout = 1; % it means htere is no contact with the boundaries
    
    % checking the possiblity of having contacts with each boundary
    % y(2) = ax+b (u know what i mean?)
    a = (y2o-y1o)/(x2o-x1o); 
    b = y2o-a*x2o;
    
    % first, top one. 
    xt = (y(2)-b)/a; % x test: the position of contact
    % to check if it is in the range of both of them:
    if xt < x(2) && xt > x(1) && xt < max(x1o,x2o) && xt > min(x1o,x2o)
        x1 = xt;
        y1 = y(2);
        bp1 = 3;
        nir = 1;
        fout = 0;
    end
    %  bottom one. 
    xt = (y(1)-b)/a; % x test: the position of contact
    % to check if it is in the range of both of them:
    if xt < x(2) && xt > x(1) && xt < max(x1o,x2o) && xt > min(x1o,x2o)
        x1 = xt;
        y1 = y(1);
        bp1 = 4;
        nir = 1;
        fout = 0;
    end
    % left boundary
    yt = a*x(1)+b;
    if yt < y(2) && yt > y(1) && yt < max(y1o,y2o) && yt > min(y1o,y2o)
        x2 = x(1);
        y2 = yt;
        bp2 = 2;
        nir = 1;
        fout = 0;
    end
    % right boundary
    yt = a*x(2)+b;
    if yt < y(2) && yt > y(1) && yt < max(y1o,y2o) && yt > min(y1o,y2o)
        x2 = x(2);
        y2 = yt;
        bp2 = 1;
        nir = 1;
        fout = 0;
    end
    
    if fout == 1
        nir = 0;
        x1 = 1;
        x2 = 1;
        y1 = 1;
        y2 = 1;
        bp1 = 5;
        bp2 = 5;
    end
end


end