clear
clc
close all
% in this code, the dependancy of shear modulus to direction will be
% investigated. 0.5 2.0 15 40


Pr = 0.0;
thickness = 1e-6;
tb = 0; % type of bar 0 for rectangular bar and 1 for circular bar

% diam = 1e-3;
density = 75;
wm = 2; % which method of creating the network? perfect squares = 1, random network wm = 2.
TM = true; % if timoshenko beam then true
lambda = 10;

N2s = 1; % number of study for each Nf

Nf = [(lambda+2)^2*density,(lambda+2)^2*density,1]; % number of fibres data [initial nf, final nf, number of increase in each step]
Ns = (Nf(1,2) - Nf(1,1))/ Nf(1,3) + 1; % number of considered density 

% tCN = zeros(Ns,1); % time allocated to create the network
% tSN = zeros(Ns,1); % time allocated to solve the network

Gs = zeros(N2s,Ns);
Ge = zeros(N2s,Ns);
% mu = zeros(N2s,Ns);
tic
for j = 1:Ns


% input:
% Network generation
% lambda = 5;

density = Nf(1,1)/(lambda+2)^2;

x=[0 lambda]; % boundary of x direction
y=[0 lambda]; % boundary of y direction
if wm == 1
N = 2 + 2*(ns); % for square beams
L = 300;
elseif wm == 2
N = (j-1) * Nf(1,3) + Nf(1,1); % Number of fibers
L=1; % Length of fibers
end
    Gv = zeros(N2s,1);
    GvE = zeros(N2s,1);
%     mu1 = zeros(N2s,1);
for ns = 1:N2s
ns
j
flt = 10^(-4)*L; % fibre lenght treshold. Edges smaller than flt will be deleted.


% tic % to record time


% e = 100; % elastic modulus of beams
% Ar = 1; % cross section of beams
% I = 1; % second moment


e = 100; % elastic modulus of beams
g = e/3; % for incompressible fibres
% Ar = pi*diam^2/4; % cross section of circular beams
Ar = thickness^2; % cross section of square beams
% I = pi*diam^4/64; % second moment of circular bars
I = (thickness)^4/12; % second moment of square bars


% Ar = 1;
% I = 1;
BM = (x(2)-x(1))/1000; % Boundary movement

% using function NetworkRand to generate the random network and get the data
if wm == 1
[NN,NE,ED,PN,nrb,nlb,ntb,nbb,Fiber] = SquareBeams(x,y,L,N,lambda);
elseif wm == 2
[SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRand(x,y,L,N,lambda,flt,Pr,density);
end
% toc
% tCN(ns,1) = toc;
if Per == false
    continue
end


NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);


% BB
% M = 0;
% sM = false;
% [fov,C3v,FFv,UUv,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);
% 
% BC(7,1) = 0;
% BC(8,1) = BM; % to investigate E
% sM = true;
% [fovE,C3vE,FFvE,UUvE,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);

% initializing BC for calculating shear modulus
BC = zeros(12,2);

% deformations
% deformations
BC(1,1) = nan; % right x (will be modified inside the code)
BC(2,1) = nan; % right y (will be modified inside the code)
BC(3,1) = nan; % right theta 
BC(4,1) = nan;  % left x (will be modified inside the code)
BC(5,1) = nan; % left y (will be modified inside the code)
BC(6,1) = nan;  % left theta
BC(7,1) = BM; % top x (will be modified inside the code)
BC(8,1) = 0; % top y (will be modified inside the code)
BC(9,1) = 0; % top theta
BC(10,1) = 0; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = 0; % bottom theta
% forces
BC(1,2) = 0;
BC(2,2) = 0;
BC(3,2) = 0;
BC(4,2) = 0;
BC(5,2) = 0;
BC(6,2) = 0;
BC(7,2) = nan;
BC(8,2) = nan;
BC(9,2) = nan;
BC(10,2) = nan;
BC(11,2) = nan;
BC(12,2) = nan;



% % % TB

M = 0;
M2 =0;
sM = false;
BCvx = BM; 
BCvy = 0;
% [fov,C3v,FFv,UUv,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy);

BC = zeros(12,2);
% deformations
BC(1,1) = nan; % right x (will be modified inside the code)
BC(2,1) = nan; % right y (will be modified inside the code)
BC(3,1) = nan; % right theta 
BC(4,1) = nan;  % left x (will be modified inside the code)
BC(5,1) = nan; % left y (will be modified inside the code)
BC(6,1) = nan;  % left theta
BC(7,1) = nan; % top x (will be modified inside the code)
BC(8,1) = BM; % top y (will be modified inside the code)
BC(9,1) = nan; % top theta
BC(10,1) = nan; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = nan; % bottom theta
% forces
BC(1,2) = 0;
BC(2,2) = 0;
BC(3,2) = 0;
BC(4,2) = 0;
BC(5,2) = 0;
BC(6,2) = 0;
BC(7,2) = 0;
BC(8,2) = nan;
BC(9,2) = 0;
BC(10,2) = 0;
BC(11,2) = nan;
BC(12,2) = 0;

BCvx = 0;
BCvy = BM;

sM = false;
% tic
[fovE,C3vE,FFvE,UUvE,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy);
% toc


% finding eneregy distribution:
Ed = EnergyF2(PN,ED,I,Ar,UUvE,e,g,tb,NE); % Ed = energy distribution (each fibre and each mode)
bEN = sum(Ed(:,1)); % bending portion of the network
sEN = sum(Ed(:,2)); % stretching //
shEN = sum(Ed(:,3)); % shear //
bEN+ sEN + shEN;

Esegment = Ed(:,1) + Ed(:,2) + Ed(:,3);


% shear modulus------------------------------------------------------------
% aggregation of forces in x direction devided by rotation

% sfv = 0; % shear force on the boundary V
% for i = (nlb+nrb)+1:(nlb+nrb+ntb)
%     sfv = FFv(i*3-2,1)+sfv;
% end
% sfv2 = 0; % the force on bottom boundary (to check the equilibrium)
% for i = (nlb+nrb+ntb)+1:(nlb+nrb+ntb+nbb)
%     sfv2 = FFv(i*3-2,1)+sfv2;
% end
% 
% Gv(ns,1) = sfv/lambda / tan(BM / (y(2)-y(1)));
% UT = transpose(UUv);
% Energy = UT*M*UUv;
% shear = Energy/(BM)^2;

sfvE = 0; % shear force on the boundary V
for i = (nlb+nrb)+1:(nlb+nrb+ntb)
    sfvE = FFvE(i*3-1,1)+sfvE;
end
sfvE2 = 0; % the force on bottom boundary (to check the equilibrium)
for i = (nlb+nrb+ntb)+1:(nlb+nrb+ntb+nbb)
    sfvE2 = FFvE(i*3-1,1)+sfvE2;
end
sfvEr = 0; % right
for i = 1:(nrb)
    sfvEr = FFvE(i*3-2,1)+sfvEr;
end
sfvE;
sfvEr;
% GvE(ns,1) = sfvE/lambda / (BM/lambda);
UTE = transpose(UUvE);
Energy = UTE*M*UUvE;
young2 = Energy/(BM)^2;
GvE(ns,1) = young2;

% finding mu and then E
% mu = 1-2*shear/young2;
% young = 2*shear*(1+mu);



mu1(ns,1) = GvE(ns,1)/Gv(ns,1)/2-1;
denN(ns,1) = N;

end

% Gs(:,j) = Gv;
Ge(:,j) = GvE;
% mu(:,j) = mu1;
% GE(:,3) = Gh;
% GE(:,4) = GhE;

end


% MGs = zeros(1,Ns); % Mean of Gs 
MGe = zeros(1,Ns); % Mean of Ge



for i = 1: Ns
%     Gs2 = Gs(:,i);
    Ge2 = Ge(:,i);
    
    k=1;
    for j = 1:N2s
        if Ge2(k,1) == 0
%             Gs2(k,:)=[];
            Ge2(k,:)=[];
            k=k-1;
        end
        k=k+1;
    end
%     MGs(1,i) = mean(Gs2);
    MGe(1,i) = mean(Ge2);
end
toc
% plot(MGs)


% if wm ==1
%     save('SSdata')      %-------------------*********************
% elseif wm==2
%                                 %-------------------*********************
%     nameS = strcat('SSdensity',num2str(density),'diam',num2str(diam),'Pr',num2str(Pr*100),'lambda',num2str(lambda),'-ConvStudy');
%     save(nameS)
% end
% edges lenghts and angles_________________________________________________
L=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    L(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end   

TETA=zeros(NE,1);
for i=1:NE
    q=ED(i,1);
    w=ED(i,2);
    qs=PN(q,2);
    qg=PN(q,3);
    ws=PN(w,2);
    wg=PN(w,3);
    TETA1=asin((wg-qg)/L(i,1));
    TETA2=acos((ws-qs)/L(i,1));
    
    if TETA1 >= 0
        if TETA2 <= pi/2
            TETA(i,1) = TETA1;
        else TETA(i,1) = TETA2 - pi ;
            
        end
    else 
        if TETA2 <= pi/2
            TETA(i,1) = TETA1; %  2*pi +
        else TETA(i,1) = TETA2 - pi ;
        end
    end
    
end


% plotting (elements which store n% of energy are red)
Etottal = sum(Esegment); 
tes = 0.50; % tottal energy storage
nof = [1:NE]; % number of fibres
Esegment2 = [nof;Esegment']';
Esegment2 = sortrows(Esegment2,2,'descend');

Estored = 0;
i=0;
while Estored <= tes % Estored = energy stored 
    i = i+1;
    Estored = Esegment2(i,2)/Etottal+Estored;
end

netes = Esegment2(1:i,1); % nodes that store tes

nntes = size(netes,1)/NE % how many nodes store tes


% plotting

% figure1 = figure;
% EsegMax = max(Esegment);
% 
% n = ED(1:NE,1);
% m = ED(1:NE,2);
% xxx = [PN(n,2)';PN(m,2)'];
% yyy = [PN(n,3)';PN(m,3)'];
% plot(xxx,yyy,'color',[0 0 0],'LineWidth',1.5)
% hold on
%     n=ED(netes(1:size(netes,1),1),1);
%     m=ED(netes(1:size(netes,1),1),2);
%     xxx = [PN(n,2)';PN(m,2)'];
%     yyy = [PN(n,3)';PN(m,3)'];
%     plot(xxx,yyy,'color',[0 1 0],'LineWidth',3)
%     pbaspect([1 1 1])
    

    figure1 = figure;
histogram(TETA,20)
hold on
histogram(TETA(netes,1),20)

figure1 = figure;
histogram(TETA(netes,1),20)

    
% poly = polyfit(den,G,4);
% x1 = linspace(min(denN),max(denN));
% y1 = polyval(poly,x1);

% subplot(2,2,1)
% plot(den,G,'o')
% hold on
% plot(x1,y1)
% hold on
% subplot(2,2,2)
% plot(denN,G,'o')
% hold on
% subplot(2,2,3)
% plot(denf,G,'o')





