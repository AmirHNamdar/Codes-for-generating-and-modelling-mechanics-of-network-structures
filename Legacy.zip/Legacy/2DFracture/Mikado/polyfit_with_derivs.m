function [p, dW_dlambda, d2W_dlambda2, Wfit] = polyfit_with_derivs(lambda, W, n, ridge)
%POLYFIT_WITH_DERIVS  Fit an order-n polynomial to W(lambda) and return
% Wfit, dW/dlambda, and d2W/dlambda2 evaluated at the given lambda points.
%
% INPUTS
%   lambda : Nx1 vector (not necessarily sorted; duplicates ok)
%   W      : Nx1 vector, same length as lambda
%   n      : polynomial order (nonnegative integer)
%   ridge  : optional nonnegative regularization (Tikhonov). Default 0.
%
% OUTPUTS
%   p              : (n+1)x1 polynomial coefficients in *scaled* variable x
%                    s.t. W ≈ polyval(p, x), where x = (lambda - mu)/sigma
%   dW_dlambda     : Nx1 first derivative at each lambda
%   d2W_dlambda2   : Nx1 second derivative at each lambda
%   Wfit           : Nx1 fitted values at each lambda
%
% NOTES
%   We scale lambda -> x = (lambda - mu)/sigma to improve conditioning.
%   Chain rule: d/dlambda = (1/sigma) d/dx; d2/dlambda2 = (1/sigma^2) d2/dx2.

    if nargin < 4 || isempty(ridge), ridge = 0; end

    % --- 0) Shape, sort, and de-dup (keep last occurrence) ---
    lambda = lambda(:);  W = W(:);
    [lambda, idx] = sort(lambda, 'ascend');  W = W(idx);
    [lambda, ia] = unique(lambda, 'stable'); W = W(ia);

    N = numel(lambda);
    if N < n+1
        error('Not enough unique points (%d) for order-%d polynomial.', N, n);
    end

    % --- 1) Scale the independent variable for numerical stability ---
    mu    = mean(lambda);
    sigma = std(lambda);
    if sigma == 0
        error('All lambda values are identical. Cannot fit a polynomial.');
    end
    x = (lambda - mu)/sigma;

    % --- 2) Build Vandermonde in x (descending powers) ---
    % V(i,k) = x(i)^(n-k+1), so that V*p = W with p = [a_n; ...; a_0]
    V = zeros(N, n+1);
    for k = 0:n
        V(:, k+1) = x.^(n-k);
    end

    % --- 3) Ridge-regularized least squares (ridge >= 0) ---
    if ridge > 0
        % Scale-invariant ridge on coefficients (tiny bias, big stability)
        % Solve (V'V + ridge*I)p = V'W
        A = V.'*V + ridge*eye(n+1);
        b = V.'*W;
        p = A \ b;
    else
        % Ordinary least squares
        p = V \ W;   % same as pinv(V)*W for full rank
    end

    % --- 4) Evaluate fit in x, then map derivatives back to lambda ---
    % Poly in x: W ≈ P(x) with coefficient vector p (descending powers).
    Wfit_x = V * p;   % same as polyval(p, x)
    Wfit   = Wfit_x;

    % First derivative wrt x: P'(x)
    dp1 = polyder(p.');              % row vector
    dp1 = dp1.';                     % column
    dWdx = polyval(dp1, x);

    % Second derivative wrt x: P''(x)
    dp2 = polyder(dp1.');            % row
    dp2 = dp2.';                     % col
    d2Wdx2 = polyval(dp2, x);

    % Chain rule back to lambda
    dW_dlambda   = (1/sigma)   * dWdx;
    d2W_dlambda2 = (1/sigma^2) * d2Wdx2;
end
