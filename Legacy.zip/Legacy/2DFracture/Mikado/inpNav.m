clear
clc
close all
% in this code we generate the .inp file needed for matlab.



UdH = false; % using defH for deformation or simple stretch

Pr = 0.0;

tb = 1; % type of bar 0 for rectangular bar and 1 for circular bar
nnG = 1; % number of nodes in each group
% deformation gradient
% defH = [0 0.1; 0.1 0]; % pure shear

% inpName = 'testLsmall5'; % name of the .inp file

L = 1e-3; % length of fibres
exctime = 10*L; % step time in abaqus
% inpNameS = 'Test9';


radius = 1e-6;
density = 17000;

wm = 2; % which method of creating the network? perfect squares = 1, random network wm = 2.
TM = true; % if timoshenko beam then true
lambda = 30*L;



defval1 = [0.5];

% defH = [defval 0; 0 0];
stretch1 = defval1*lambda;

Nf = (lambda+2*L)^2*density/L; % number of fibres data [initial nf, final nf, number of increase in each step]

% tCN = zeros(Ns,1); % time allocated to create the network
% tSN = zeros(Ns,1); % time allocated to solve the network

w = log10((density*L)^7 * (radius/2/L)^2)
phi = density*radius*2

% mu = zeros(N2s,Ns);

% input:
% Network generation
% lambda = 5;

x=[0 lambda]; % boundary of x direction
y=[0 lambda]; % boundary of y direction
N = Nf; % Number of fibers


flt = 10^(-3)*L; % fibre lenght treshold. Edges smaller than flt will be deleted.
meshl = 10*radius;


e = 2e9; % elastic modulus of beams
MatDen = 7800; % beam material density
Matnu = 0.49; % beam material poisson ratio

g = e/3; % for incompressible fibres
Ar = pi*radius^2; % cross section of circular beams
% Ar = thickness^2; % cross section of square beams
I = pi*radius^4/4; % second moment of circular bars
% I = (thickness)^4/12; % second moment of square bars


% fracture parameters
sigCrack = e * 0.2; % e*failure strain 
crackStrain = 1e-4 * L;
shearRetention1 = 1.0;
failStrain = 1e-4 * L ;



for j =1:1
[SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRand(x,y,L,N,lambda,flt,Pr,density);

if Per == false
    disp('not percolated network')
else


NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);
nbn = nrb+nlb+ntb+nbb; % number of boundary nodes

    Lf=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    Lf(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end 
LrRatio = mean(Lf)/radius

% % plotting
% figure1 = figure
% fn = ED(:,1);
% sn = ED(:,2);
% 
% for i =1:NE
%     fnn = fn(i,1);
%     snn = sn(i,1);
%     x1 = PN(fnn,2);
%     x2 = PN(snn,2);
%     y1 = PN(fnn,3);
%     y2 = PN(snn,3);
%     
%    plot([x1 x2], [y1 y2], '-b') 
%    hold on
% end



for i = 1: 1
    stretch = stretch1(1,i);
    defval = defval1(1,i);
%     inpName = strcat('Mik2D-','Den',num2str(density),'radius',num2str(radius),'lambda',num2str(lambda),'L',num2str(L),'ExcTime',num2str(exctime),'DefVal',num2str(defval),'Obs',num2str(j));
%     inpNameRamp = strcat('Mik2DRamp-','Den',num2str(density),'radius',num2str(radius),'lambda',num2str(lambda),'L',num2str(L),'ExcTime',num2str(exctime),'DefVal',num2str(defval),'Obs',num2str(j));
    inpNameS = strcat('Mik2DFracture-','Den',num2str(density),'radius',num2str(radius),'lambda',num2str(lambda),'L',num2str(L),'ExcTime',num2str(exctime),'DefVal',num2str(defval),'Obs',num2str(j));
%     inpNameM = strcat('Mik2DMesh-','Den',num2str(density),'radius',num2str(radius),'lambda',num2str(lambda),'L',num2str(L),'ExcTime',num2str(exctime),'DefVal',num2str(defval),'Obs',num2str(j));

if UdH == true
    equations = EquationsFunction(PN,lambda,nbn,nrb,nlb,ntb,nbb,nnG,defH);
    % ToPrint = writeFunction(PN,ED,inpName,radius,MatDen,Matnu,e,equations,nbn,lambda,exctime);
    % ToPrint2 = writeFunctionRamp(PN,ED,inpNameRamp,radius,MatDen,Matnu,e,equations,nbn,lambda,exctime);

    ToPrintM = writeFunctionM(PN,ED,inpNameM,radius,MatDen,Matnu,e,equations,nbn,lambda,exctime,meshl);
else
%     inpNameS = 'TestDangBCyesDefV03';
    ToPrintS = writeFunctionStretch(PN,ED,inpNameS,radius,MatDen,Matnu,e,stretch,nbn,lambda,nrb,nlb,exctime,sigCrack,crackStrain,shearRetention1,failStrain);
%     inpNameS = 'TestDangBCnoDefV03';
%     NE
%     [PN,ED,nbn,nrb,nlb,ntb,nbb] = DelBF(PN,ED,nbn,nrb,nlb,ntb,nbb); % boundary segments that are connected to the edge should be deleted for better convergance
%     % plotting
% 
% fn = ED(:,1);
% sn = ED(:,2);
% NE = size(ED,1);
% NE
% for i =1:NE
%     fnn = fn(i,1);
%     snn = sn(i,1);
%     x1 = PN(fnn,2);
%     x2 = PN(snn,2);
%     y1 = PN(fnn,3);
%     y2 = PN(snn,3);
%     
%    plot([x1 x2], [y1 y2], '-r') 
%    hold on
% end
%     ToPrintS = writeFunctionStretch(PN,ED,inpNameS,radius,MatDen,Matnu,e,stretch,nbn,lambda,nrb,nlb,exctime,meshl);
end
end
end
end


save(inpNameS)
