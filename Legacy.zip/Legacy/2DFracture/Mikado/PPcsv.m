% plot_energies_from_csv.m
% Reads energies CSV (columns: step,region,variable,description,time,value)
% and plots whole-model energies vs global time. Saves a PNG beside the CSV.
clear
clc
close all

%% --- User input ---
csvPath = 'VorTest3';   % <- change if needed
% csvPath = 'Mik2DstretchAggGlue-Den17000radius1e-06lambda0.005L0.001ExcTime0.01DefVal0.25Obs1.csv';
defVal = 0.1;
ExeTime = 0.2;
%% --- Load & tidy ---
T = readtable(csvPath);
T.Properties.VariableNames = matlab.lang.makeValidName(T.Properties.VariableNames);

% Ensure types
if ~iscell(T.step), T.step = cellstr(string(T.step)); end
if ~iscell(T.region), T.region = cellstr(string(T.region)); end
if ~iscell(T.variable), T.variable = cellstr(string(T.variable)); end

% Keep whole model / assembly history only
isWhole = contains(upper(string(T.region)),"WHOLE MODEL") | ...
          endsWith(upper(string(T.region)),"ASSEMBLY") | ...
          strcmpi(string(T.region),"ASSEMBLY");
TT = T(isWhole,:);

% Uppercase variable names (ALLIE, ALLKE, ...)
TT.variable = upper(string(TT.variable));

% (Optional) keep only energy-like variables
keepVars = ["ALLIE","ALLKE","ALLSE","ALLAE","ALLVD","ETOTAL","ALLMD","ALLFD","ALLWK","ALLHC","ALLPD"];
TT = TT(ismember(TT.variable, keepVars), :);

%% --- Build "global time" across steps (time accumulates over steps) ---
TT.step = string(TT.step);
TT.time = double(TT.time);
TT.value = double(TT.value);

steps = unique(TT.step,'stable');
TT.time_global = zeros(height(TT),1);
offset = 0;
for s = steps.'
    idx = (TT.step == s);
    tlocal = TT.time(idx);
    TT.time_global(idx) = tlocal + offset;
    if ~isempty(tlocal)
        offset = offset + max(tlocal);
    end
end

%% --- Plot: all energies vs global time ---
vars = unique(TT.variable,'stable');
figure('Color','w'); hold on; grid on; box on;
for k = 1:numel(vars)
    vk = vars(k);
    rows = TT.variable == vk;
    % sort by global time within this variable
    [tg, ord] = sort(TT.time_global(rows));
    vg = TT.value(rows);
    plot(tg, vg(ord), 'LineWidth', 1.4, 'DisplayName', char(vk));
end
xlabel('Global analysis time'); ylabel('Energy (J)');
title('Whole model energies vs time');
legend('Location','best','Interpreter','none');

% % Save beside the CSV
% [outDir, base, ~] = fileparts(csvPath);
% if isempty(outDir), outDir = pwd; end
% saveas(gcf, fullfile(outDir, base + "_energies.png"));

%% --- (Optional) Wide table + KE/IE ratio plot ---
% Unstack to one column per energy (handles duplicate times via mean)
W = unstack(TT(:,{'time_global','variable','value'}), 'value', 'variable', ...
            'AggregationFunction', @mean);

% KE/IE ratio if both exist
if all(ismember({'ALLKE','ALLIE'}, W.Properties.VariableNames))
    figure('Color','w','Position', [100, 800, 500, 500]); grid on; box on; hold on;
    plot(W.time_global, W.ALLKE ./ W.ALLIE, 'LineWidth', 1.4);
    xlabel('Global analysis time'); ylabel('KE / IE');
    title('Kinetic-to-Internal Energy Ratio (whole model)');
end
ylim([0 0.05])
xlim([0 ExeTime])

%% --- Build matrices for each energy (global time vs value) ---
% Result: energyMats.<ENERGY> is an N×2 double: [time_global, value]
vars = unique(TT.variable,'stable');
energyMats = struct();

for k = 1:numel(vars)
    vname = string(vars(k));
    rows  = (TT.variable == vname);

    % sort by global time
    [tg, ord] = sort(TT.time_global(rows));
    vg = TT.value(rows);
    M  = [double(tg), double(vg(ord))];   % ensure double, time first

    % safe field name (e.g., ALLIE -> energyMats.ALLIE)
    fld = matlab.lang.makeValidName(vname);
    energyMats.(fld) = M;
end

% Example: access matrices
% energyMats.ALLIE   % -> [t, value] for Internal Energy
% energyMats.ALLKE   % -> [t, value] for Kinetic Energy


WEnergy = energyMats.ALLWK; % work done
% WEnergy = energyMats.ALLSE; % strain energy
stretch = WEnergy(:,1).*defVal./(WEnergy(end,1)) +1;


% Inputs: vectors lambda, W (same length)
lambda = stretch(:);  W = WEnergy(:,2);
lambda = lambda(1:end); W = W(1:end);

% sort & de-dup just in case
[lambda, idx] = sort(lambda);  W = W(idx);
[lambda, ia] = unique(lambda,'stable');  W = W(ia);

% first & second derivatives using non-uniform spacing
dW_dlambda   = gradient(W, lambda);             % dW/dλ
d2W_dlambda2 = gradient(dW_dlambda, lambda);    % d²W/dλ²

% second way is to get derivative by first fitting a polynomial of order n
% to the W.
n = 7;
[p, S, mu] = polyfit(lambda, W, n);         % mu = [mean, std] of lambda
Wfit       = polyval(p, lambda, [], mu);    % fitted W(λ)
dp  = polyder(p);
d2p = polyder(dp);
dW   = polyval(dp,  lambda, [], mu) / mu(2);
d2W  = polyval(d2p, lambda, [], mu) / (mu(2)^2);      % d²W/dλ²

m = 6;
[p2, S2, mu2] = polyfit(lambda, dW_dlambda, m);
dp2  = polyder(p2);
d2W_2 = polyval(dp2,  lambda, [], mu2) / mu2(2);


% (optional) quick plot
figure3 = figure('Position', [1200, 500, 500, 500]); 
subplot(3,1,1); plot(lambda,W,'-'); ylabel('W(\lambda)');
subplot(3,1,2); plot(lambda,dW_dlambda,'-'); hold on;
plot(lambda,dW,'-');ylabel('dW/d\lambda');
subplot(3,1,3); plot((lambda),(d2W_dlambda2),'-');hold on;
plot((lambda),(d2W),'-'); hold on;
plot((lambda),(d2W_2),'-');ylabel('d^2W/d\lambda^2'); xlabel('\lambda');


figure4 = figure('Position', [100, 5, 500, 500]);
plot(log10(dW_dlambda),log10(d2W_dlambda2),'-')
hold on
plot(log10(dW),log10(d2W),'-')
hold on
plot(log10(dW),log10(d2W_2),'-')

figure5 = figure('Position', [700, 5, 500, 500]);
plot(log10(lambda-1),log10(d2W_dlambda2),'-')
hold on
plot(log10(lambda-1),log10(d2W),'-')
hold on
plot(log10(lambda-1),log10(d2W_2),'-')




%% --- (Optional) Per-step plots (uncomment to use) ---
%{
for s = steps.'
    idx = (TT.step == s);
    if nnz(idx) == 0, continue; end
    figure('Color','w'); hold on; grid on; box on;
    sv = unique(TT.variable(idx),'stable');
    for k = 1:numel(sv)
        rows = idx & TT.variable == sv(k);
        [tg, ord] = sort(TT.time(rows));   % local time within step
        vg = TT.value(rows);
        plot(tg, vg(ord), 'LineWidth', 1.3, 'DisplayName', char(sv(k)));
    end
    xlabel(sprintf('Step time (%s)', s));
    ylabel('Energy (J)');
    title(sprintf('Energies in %s (whole model)', s));
    legend('Location','best','Interpreter','none');
end
%}
