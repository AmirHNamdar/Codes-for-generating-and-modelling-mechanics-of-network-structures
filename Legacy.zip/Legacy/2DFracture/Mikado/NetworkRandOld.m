function [NN,NE,ED,PN,Fiber] = NetworkRand(x,y,L,N,lambda)


% it doesn't consider the intersection of fibres and boundaries


xc = [x(1)-L , x(2)+L]; % x to create the network
yc = [y(1)-L , y(2)+L];


% plot
% the fibers on top of each other
% for i = 1:N
% subplot(2,2,1)
% plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% axis([xc(1),xc(2),yc(1),yc(2)])
% hold on
% end
% plot([x(1) x(1)],[y(1) y(2)],'b');
% hold on
% plot([x(2) x(2)],[y(1) y(2)],'b');
% hold on
% plot([x(1) x(2)],[y(1) y(1)],'b');
% hold on
% plot([x(1) x(2)],[y(2) y(2)],'b');

% finding the fibres that have a portion within the network

ip = zeros (N,2*N); % intersection position
 
nobf = 0; % number of out of the box fiber
for i=1:N
    % finding a centre for a fibre to be addded to the network
    xm=min(xc)+(max(xc)-min(xc))*rand(1);
    ym=min(yc)+(max(yc)-min(yc))*rand(1);
    theta=2*pi*rand(1);
    x1o=xm-cos(theta)*L/2;
    y1o=ym-sin(theta)*L/2;
    x2o=xm+cos(theta)*L/2;
    y2o=ym+sin(theta)*L/2;
    % finding Acode = address code - where is its centre?
        ssms = L; % small square mesh size
        xma = xm + ssms;
        yma = ym + ssms;
        Acode (1,1) = floor(xma/ssms)+1;
        Acode (1,2) = floor(yma/ssms)+1;
    
    % deleting out of bound portion
    if Acode(1,1) < 3 || Acode(1,1) > lambda/L || Acode (1,2) <3 || Acode(1,2) > lambda/L
    [nir,x1,x2,y1,y2] = portion(x1o,x2o,y1o,y2o,x,y,theta); 
    % nir==> if not in the range nir =0, otherwise = 1;
    % o stands for old version
    if nir == 0
        nobf = nobf+1;
        continue % goes to the next iteration
    end
    else
        x1 = x1o;
        x2 = x2o;
        y1 = y1o;
        y2 = y2o;
    end
    
    % adding its information into fiber matrix
    Fiber(i-nobf,1)=x1;
    Fiber(i-nobf,2)=y1;
    Fiber(i-nobf,3)=x2;
    Fiber(i-nobf,4)=y2;
    Fiber(i-nobf,5)=theta;
    Fiber(i-nobf,6)=xm;
    Fiber(i-nobf,7)=ym;
    Fiber(i-nobf,8) = i;
    Fiber(i-nobf,9) = Acode(1,1);
    Fiber(i-nobf,10) = Acode(1,2);
    
    nf = size(Fiber,1);
    

end

N = nf;

    % investigating the intesection with other fibres
for i=1:N
    for j=1:N
        if j~=i
            % find its contact with fiber j (if yes, ec ==1, otherwise, ec ==0)
            if Fiber(i,9) - Fiber(j,9) <= 1 && Fiber(i,9) - Fiber(j,9) >= -1 && Fiber(i,10) - Fiber(j,10) <= 1 && Fiber(i,10) - Fiber(j,10) >= -1
            [ec,xi,yi] = intersection2(Fiber,i,j);
            if ec == 1
            ip(i,2*j-1) = xi;
            ip(i,2*j) = yi;
                lfj = Fiber(j,8); %  label of fiber j
                for k=1:nf
                    if Fiber(k,8) == lfj
                        Fiber(k,8) = i;
                    end
                end
            end
            end
        end
    end
end






% creating the PN----------------------------------------------------------
% first sorting the boundary nodes
% PBN2 = sortrows(PBN,3);
% 
% nrb = 0; % number of right boundary
% nlb = 0;
% ntb = 0;
% nbb = 0;

% for i = 1:size(PBN2,1)
%     if PBN2(i,3) == 1
%         nrb = nrb + 1;
%     elseif PBN2(i,3) == 2
%         nlb = nlb + 1;
%         elseif PBN2(i,3) == 3
%           ntb = ntb + 1;
%           elseif PBN2(i,3) == 4
%             nbb = nbb + 1;
%     end
% end

% PN(:,1:2) = PBN2(:,1:2);

% secondly sorting the fiber intersections considering the fact that the ip
% is diogonal matrix (i mean...u know!)

PI = zeros(1,3); % position of intersections [number of nodes,x ,y]
k =  1;
mip = ip; % modified ip - data below the diogonal line is deleted
for i = 1:N
    for j = 1 : 2*i-1
        mip(i,j) = 0;
    end
end

for i = 1:N
    if nnz(mip(i,:)) ~= 0 % if any node that is not labled exist
        for j = 1 : nnz(mip(i,:))/2
            PI(k,1) = k;
            pon = find(mip(i,:)); % pon = position of nodes in the mip
            xn = mip(i,pon(2*j-1));
            yn = mip(i,pon(2*j));
            PI(k,2) = xn;
            PI(k,3) = yn;
            k=k+1;
        end
    end
end

PN = PI;
% PN(1:nrb+nlb+ntb+nbb,2) = PBN2(:,1);
% PN(1:nrb+nlb+ntb+nbb,3) = PBN2(:,2);
% k = 1;
% for i = 1:nrb+nlb+ntb+nbb
% PN(i,1) = k;
% k=k+1;
% end


%  since the left and right boundaries do not effect the shear modulus (due
%  the the lack of resistence to force) and that they cause problem in
%  numerical prosedure, it seems logical to delet the fibres that are
%  attached to these boundaries.











% creating the edge direction----------------------------------------------
% we end up with two situation:1- the fibers has connection with the
% boundary. 2- it doesnt.

mmip = zeros(N); % modified ip that includes the number of nodes that each fiber is connected to
k = 1;
for i = 1:N
    for j = 2*i:2*N
        if rem(j,2)==0
            if ip(i,j)~=0
                mmip(i,j/2) = k;
                k = k+1;
            end
        end
    end
end

for i = 1:N
    for j = 1:i
        mmip(i,j) = mmip(j,i);
    end
end

k = 1;
ED = zeros(1,2);
for i =1:N
    drp = zeros(1,2); % distance to reference point which is the first point of the fiber
    pon = find(mmip(i,:));
    nnf = mmip(i,pon); % address of the nodes that exist on the fiber
    lf = sqrt((Fiber(i,1)-Fiber(i,3))^2 + (Fiber(i,2)-Fiber(i,4))^2); % length of each fiber
    if lf == L % the fiber doesn't have connection with the boundary
        if nnz(mmip(i,:)) ~=0
            for j = 1:nnz(mmip(i,:))
                drp(j,2) = sqrt((Fiber(i,1)-PN(nnf(1,j),2))^2 + (Fiber(i,2)-PN(nnf(1,j),3))^2); 
                drp(j,1) = nnf(1,j);
            end
            ged = sortrows(drp,2); % guide to create ED
            if size(ged,1) > 1
                for l = 1:size(ged,1)-1
                    ED(k,1) = ged(l+1,1);
                    ED(k,2) = ged(l,1);
                    k = k+1;
                end
            end
        end
    else
        sb = 0; % sb =  number of nodes at the boundary 
%         [nnb, jfdth] = find(PBN2(:,4)==i); % = address of node of the boundary
%         for h = 1:sb
%             sizel = size(nnf,2);
%             nnf(1,sizel+1) = nnb(h,1);
%         end
        if nnz(mmip(i,:)) + sb ~=0
            for j = 1:nnz(mmip(i,:)) + sb
                drp(j,2) = sqrt((Fiber(i,1)-PN(nnf(1,j),2))^2 + (Fiber(i,2)-PN(nnf(1,j),3))^2); 
                drp(j,1) = nnf(1,j);
            end
            ged = sortrows(drp,2); % guide to create ED
            if size(ged,1) > 1
                for l = 1:size(ged,1)-1
                    ED(k,1) = ged(l+1,1);
                    ED(k,2) = ged(l,1);
                    k = k+1;
                end
            end
        end
    end
end






NE = size(ED,1);
NN = size(PN,1);


% plot
% the fibers on top of each other
% for i = 1:N
% subplot(2,2,2)
% plot([Fiber(i,1) Fiber(i,3)],[Fiber(i,2) Fiber(i,4)]);
% hold on
% plot(PN(:,2), PN(:,3),'o');
% end
% % 
% % % the fiber network
% for j=1:NE
%     subplot(2,2,3)
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)])
%     hold on
% end
% 
% 
% 
end
