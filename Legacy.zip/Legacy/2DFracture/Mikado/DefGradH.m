
PN = [1 5 1
    2 5 3
    3 5 4
    4 0 2
    5 0 3
    6 1 5
    7 2 5
    8 3 5
    9 1 0
    10 2 0
    11 3 0
    12 4 0];

% size of the box
lambda = 5;

% number of boundary conditions
nbn = 12;
nrb = 3;
nlb = 2;
ntb = 3;
nbb = 4;

% number of nodes in each group
nnG = 2; 

% matrix of deformation gradient
defH = [0 0.1; 0.1 0];

% normal vector in right, left, top, and bottom side of the boundary
nr = [1; 0];
nl = [-1; 0];
nt = [0; 1];
nb = [0; -1];

% area associated with each boundary node
snr = zeros(nrb,2);
snr(:,1) = [1:nrb];
snr(:,2) = [PN(1:nrb,3)];
snr = sortrows(snr,2); % sorted nodes
if nrb > 2
    for i=2:nrb-1
        A1(snr(i,1),1) = (snr(i+1,2)-snr(i-1,2))/2;
    end
end
A1(snr(1,1),1) = snr(1,2) + (snr(2,2)-snr(1,2))/2;
A1(snr(nrb,1),1) = lambda-snr(nrb,2) + (snr(nrb,2)-snr(nrb-1,2))/2;

snl = zeros(nlb,2);
snl(:,1) = [1:nlb];
snl(:,2) = [PN(nrb+1:nrb+nlb,3)];
snl = sortrows(snl,2); % sorted nodes
if nlb > 2
    for i=2:nlb-1
        A2(snl(i,1),1) = (snl(i+1,2)-snl(i-1,2))/2;
    end
end
A2(snl(1,1),1) = snl(1,2) + (snl(2,2)-snl(1,2))/2;
A2(snl(nlb,1),1) = lambda-snl(nlb,2) +(snl(nlb,2)-snl(nlb-1,2))/2;

snt = zeros(ntb,2);
snt(:,1) = [1:ntb];
snt(:,2) = [PN(nrb+nlb+1:nrb+nlb+ntb,2)];
snt = sortrows(snt,2); % sorted nodes
if ntb > 2
    for i=2:ntb-1
        A3(snt(i,1),1) = (snt(i+1,2)-snt(i-1,2))/2;
    end
end
A3(snt(1,1),1) = snt(1,2) + (snt(2,2)-snt(1,2))/2;
A3(snt(ntb,1),1) = lambda-snt(ntb,2) + (snt(ntb,2)-snt(ntb-1,2))/2;

snb = zeros(nbb,2);
snb(:,1) = [1:nbb];
snb(:,2) = [PN(nrb+nlb+ntb+1:nrb+nlb+ntb+nbb,2)];
snb = sortrows(snb,2); % sorted nodes
if nbb > 2
    for i=2:nbb-1
        A4(snb(i,1),1) = (snb(i+1,2)-snb(i-1,2))/2;
    end
end
A4(snb(1,1),1) = snb(1,2) + (snb(2,2)-snb(1,2))/2;
A4(snb(nbb,1),1) = lambda-snb(nbb,2) + (snb(nbb,2)-snb(nbb-1,2))/2;

A = [A1;A2;A3;A4];

% node info [x, y, A, nx, ny]
Ninf = zeros(nbn,5);
Ninf = [PN(1:nbn,2),PN(1:nbn,3),A];
Ninf(1:nrb,4) = 1;
Ninf(1+nrb:nrb+nlb,4) = -1;
Ninf(1+nrb+nlb:nrb+nlb+ntb,5) = 1;
Ninf(1+nrb+nlb+ntb:nrb+nlb+ntb+nbb,5) = -1;

% total number of groups exist in the boundary
if floor(nbn/nnG) == nbn/nnG
    tG = floor(nbn/nnG);
else
    tG = floor(nbn/nnG) + 1;
end

% grouped nodes
Gn = zeros(tG,nnG);
random_indices = randperm(nbn, nbn);
for i=1:tG-1
    Gn(i,:) = random_indices((i-1)*nnG+1:i*nnG);
end
Gn(tG,1:size(random_indices((tG-1)*nnG+1:end),2)) = random_indices((tG-1)*nnG+1:end);



% Hi = Hi of each group after one another
Hi = zeros(2*tG,2);

for i = 1:tG
    
    Hnode2 = zeros(2,2);
    
    for j=1:size(nonzeros(Gn(i,:)),1) % nonzeros gives a vertical vector
        
        % the node under consideration
        node = Gn(i,j); 
        
        % normal vector
        norm = [Ninf(node,4); Ninf(node,5)];
        
        % position vector
        posv = [Ninf(node,1);Ninf(node,2)];
        
        % to calculate pos*norm'*A of each groups node (note that diadic product is [a;b]*[c,d])
        Hnode = (posv*norm')*A(node,1);
        
        % // of the group
        Hnode2 = Hnode2 + Hnode;
    end
    Hig = defH*(Hnode2);
    
    Hi((i-1)*2+1:i*2,1:2) = Hig;
end



% To get the set of equations. [node number 1, related DOF, A1; 
%                               node number 2, related DOF, A2;
%                               ...                           ;
%                               0            , 0          , -H]

Equations = {};

for i =1:tG
    
    % the corrosponding Hi to the group
    Hinode = Hi(2*i-1:2*i,:);
    
    % 4 possible equations (some of them might be 0=0)
    eq1 = [];
    eq2 = [];
    eq3 = [];
    eq4 = [];
    
    % calculating the node, dof and constant taht appears in the equation
    nniG = size(nonzeros(Gn(i,:)),1); %(number of nodes in the group)
    for j=1:nniG
        node = Gn(i,j);
        eq1(end+1,:) = [node,1,A(node)*Ninf(node,4)];
        eq2(end+1,:) = [node,1,A(node)*Ninf(node,5)];
        eq3(end+1,:) = [node,2,A(node)*Ninf(node,4)];
        eq4(end+1,:) = [node,2,A(node)*Ninf(node,5)];
    end
    
    % the last term of each eqution which is a constant
    eq1(end+1,:) = [0,0,-Hinode(1,1)];
    eq2(end+1,:) = [0,0,-Hinode(1,2)];
    eq3(end+1,:) = [0,0,-Hinode(2,1)];
    eq4(end+1,:) = [0,0,-Hinode(2,2)];
    
    % checking and deleting the 0=0 equations
    deleq1 = []; % the rows that needs to be deleted
    deleq2 = []; % the rows that needs to be deleted
    deleq3 = []; % the rows that needs to be deleted
    deleq4 = []; % the rows that needs to be deleted
    for j=1:nniG+1
        if eq1(j,end) == 0
            deleq1(end+1,1) = j;
        end
        if eq2(j,end) == 0
            deleq2(end+1,1) = j;
        end
        if eq3(j,end) == 0
            deleq3(end+1,1) = j;
        end
        if eq4(j,end) == 0
            deleq4(end+1,1) = j;
        end
    end
    eq1(deleq1,:) = [];
    eq2(deleq2,:) = [];
    eq3(deleq3,:) = [];
    eq4(deleq4,:) = [];
    
    % adding the equation in the main set
    if ~isempty(eq1)
        Equations{end+1} = eq1;
    end
    if ~isempty(eq2)
        Equations{end+1} = eq2;
    end
    if ~isempty(eq3)
        Equations{end+1} = eq3;
    end
    if ~isempty(eq4)
        Equations{end+1} = eq4;
    end
end



% % writing in a .inp file
% 
% % Specify the output filename
% filename = 'multiple_constraints.inp';
% 
% % Generate the .inp file content
% fileID = fopen(filename, 'w'); % Automatically creates and opens file
% 
% % Loop through each equation
% for i = 1:length(Equations)
%     eq = Equations{i};                % Select the current equation
%     num_terms = size(eq, 1);          % Number of terms in this equation
%     
%     % Write the *Equation header for ABAQUS
%     fprintf(fileID, '*Equation\n');
%     fprintf(fileID, '%d\n', num_terms); % Number of terms
%     
%     % Write each term in the format: node, dof, coefficient
%     for j = 1:num_terms
%         fprintf(fileID, '%d, %d, %.1f\n', eq(j, 1), eq(j, 2), eq(j, 3));
%     end
% end
% 
% % Close the file
% fclose(fileID);




