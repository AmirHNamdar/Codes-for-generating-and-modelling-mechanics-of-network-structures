% The first code := Network theory with infnitisimle deformation in 2D
% Developed by Amir Hossein Namdar
clear
clc
close all
% function [fo,C3,FF,UU,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M)


% inputs___________________________________________________________________
% e = 100;
% g = e/3;
% Ar = 1e4; % area of the beam
% I = 1e+4; % Area Moment of Inertia
sM = false;
% E=e;
% G=g;
% thth = pi/4;
% PN = [1 0 0;2 cos(thth) sin(thth)];
% ED = [1 2];
% NN = 2;
% NE = 1;
% FF = [nan; nan; nan;-sin(thth)/100;cos(thth)/100;0];
% UU = [0; 0; 0;nan;nan;nan];

%NN = input('please input the number of nodes \n');   
%NE = input('please input the number of edges \n');   
%e = input('Elasticity of edges \n'); 
diam = 1e-2;
e = 100; % elastic modulus of beams
g = e/4; % for incompressible fibres
Ar = pi*diam^2/4; % cross section of beams
I = pi*diam^4/64; % second moment
E=e;
G=g;
% SDataV = [1,0.0677331667401147,1,4,3,12,10,0;
%     2,0.319477432747998,0,5,6,0,0,0;
%     3,0.289816702292690,0.646023263010243,6,7,0,0,1;
%     4,0.224093361209958,0.596220897800458,5,8,0,0,1;
%     5,0.858242838906462,0.954864309537292,3,6,0,0,0;
%     6,0.224722588895504,0.749776122492806,6,10,0,0,0;
%     7,0.200768042589641,0.742021367260818,10,9,0,0,0;
%     8,0.0881983878391175,0.967380687774201,9,8,0,0,0;
%     9,0.189117683493422,0.806526426848774,8,1,0,0,0;
%     10,0.190903932203429,0.803679342807865,2,4,0,0,0;
%     0,0,0,7,4,0,0,0;0,0,0,7,10,0,0,0];

SDataV = [1,0.0677,1,3,4,12,10,0;
    2,0.319,0,6,5,0,0,0;
    3,0.2898,0.6460,7,6,0,0,1;
    4,0.2241,0.5962,5,8,0,0,1;
    5,0.8582,0.9549,3,6,0,0,0;
    6,0.2247,0.7498,6,10,0,0,0;
    7,0.2008,0.7420,10,9,0,0,0;
    8,0.0882,0.9674,9,8,0,0,0;
    9,0.1491,0.8565,8,1,0,0,0;
    10,0.1909,0.8037,2,4,0,0,0;
    0,0,0,4,7,0,0,0;
    0,0,0,7,10,0,0,0];

NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);

%PN = input('nodes coordinates from node number 1 to the last one [ x, y] \n');   
%ED=input('Edge direction from edge number 1 to last one [where it starts, where it ends] \n');

% FF=input('nodal forces by respect to the number of nodes (if it's Unknown use nan) [force in x direction; force in y direction;] \n');
% UU=input('nodal displacement by respect to the number of nodes (if it's Unknown use nan)[displacement in x, displacement in y;] \n');


% NN = 6;
% NE = 5;
% e = 100;
% Ar = 1; % area of the beam
% I = 1; % Area Moment of Inertia
% 
% PN = [-0.2 3.65 0; 2.8 3.65 0; 0.8 0.65 0; 2.35 2.7 0; 1.8 -0.35 0; 2.3 -0.35 0];
% ED = [1 3; 3 4; 4 2; 3 5; 4 6];
% 
% FF = [nan; nan; nan; nan; nan; nan; 0; 0; 0; 0; 0; 0; nan; nan; nan; nan; nan; nan];
% UU = [0; 0.0001; 0; 0; 0.0001; 0; nan; nan; nan; nan; nan; nan; 0; 0; 0; 0; 0; 0];
% Initialazing Boundary condition:
BCrux = 0; % right deformation x direction
BCruy = 0; % right deformation y direction
BCruph = 0; % right rotation
BClux = 0; % left deformation x direction
BCluy = 0; % left deformation y direction
BCluph = 0; % left rotation
BCtux = 0; % top deformation x direction
BCtuy = 1/10; % top deformation y direction
BCtuph = 0; % top rotation
BCbux = 0; % bottom deformation x direction
BCbuy = 0; % bottom deformation y direction
BCbuph = 0; % bottom rotation

BCrfx = nan; % right force x direction
BCrfy = nan; % right force y direction
BCrfph = nan; % right moment
BClfx = nan; % left force x direction
BClfy = nan; % left force y direction
BClfph = nan; % left moment
BCtfx = nan; % top force x direction
BCtfy = nan; % top force y direction
BCtfph = nan; % top moment
BCbfx = nan; % bottom force x direction
BCbfy = nan; % bottom force y direction
BCbfph = nan; % bottom moment

BC = zeros(12,2);
BC(1,1) = BCrux;
BC(2,1) = BCruy;
BC(3,1) = BCruph;
BC(4,1) = BClux;
BC(5,1) = BCluy;
BC(6,1) = BCluph;
BC(7,1) = BCtux;
BC(8,1) = BCtuy;
BC(9,1) = BCtuph;
BC(10,1) = BCbux;
BC(11,1) = BCbuy;
BC(12,1) = BCbuph;

BC(1,2) = BCrfx;
BC(2,2) = BCrfy;
BC(3,2) = BCrfph;
BC(4,2) = BClfx;
BC(5,2) = BClfy;
BC(6,2) = BClfph;
BC(7,2) = BCtfx;
BC(8,2) = BCtfy;
BC(9,2) = BCtfph;
BC(10,2) = BCbfx;
BC(11,2) = BCbfy;
BC(12,2) = BCbfph;

PN222 = PN;
PN = zeros(NN,2);
PN(:,1) = PN222(:,2);
PN(:,2) = PN222(:,3);
% 
FF = zeros(3*NN,1);
UU = nan(3*NN,1);

% BC(8,1) = 1/10; % to investigate the shear



FF(1:3:3*nrb) = BC(1,2);
FF(2:3:3*nrb) = BC(2,2);
FF(3:3:3*nrb) = BC(3,2);
FF(3*nrb+1:3:3*(nlb+nrb)) = BC(4,2);
FF(3*nrb+2:3:3*(nlb+nrb)) = BC(5,2);
FF(3*nrb+3:3:3*(nlb+nrb)) = BC(6,2);
FF(3*(nlb+nrb)+1:3:3*(nlb+nrb+ntb)) = BC(7,2);
FF(3*(nlb+nrb)+2:3:3*(nlb+nrb+ntb)) = BC(8,2);
FF(3*(nlb+nrb)+3:3:3*(nlb+nrb+ntb)) = BC(9,2);
FF(3*(nlb+nrb+ntb)+1:3:3*(nlb+nrb+ntb+nbb)) = BC(10,2);
FF(3*(nlb+nrb+ntb)+2:3:3*(nlb+nrb+ntb+nbb)) = BC(11,2);
FF(3*(nlb+nrb+ntb)+3:3:3*(nlb+nrb+ntb+nbb)) = BC(12,2);

UU(1:3:3*nrb) = BC(1,1);
UU(2:3:3*nrb) = BC(2,1);
UU(3:3:3*nrb) = BC(3,1);
UU(3*nrb+1:3:3*(nlb+nrb)) = BC(4,1);
UU(3*nrb+2:3:3*(nlb+nrb)) = BC(5,1);
UU(3*nrb+3:3:3*(nlb+nrb)) = BC(6,1);
UU(3*(nlb+nrb)+1:3:3*(nlb+nrb+ntb)) = BC(7,1);
UU(3*(nlb+nrb)+2:3:3*(nlb+nrb+ntb)) = BC(8,1);
UU(3*(nlb+nrb)+3:3:3*(nlb+nrb+ntb)) = BC(9,1);
UU(3*(nlb+nrb+ntb)+1:3:3*(nlb+nrb+ntb+nbb)) = BC(10,1);
UU(3*(nlb+nrb+ntb)+2:3:3*(nlb+nrb+ntb+nbb)) = BC(11,1);
UU(3*(nlb+nrb+ntb)+3:3:3*(nlb+nrb+ntb+nbb)) = BC(12,1);



% edges lenghts and angles_________________________________________________
L=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,1);
    dg=PN(d,2);
    cs=PN(c,1);
    cg=PN(c,2);
    L(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end   

TETA=zeros(NE,1);
for i=1:NE
    q=ED(i,1);
    w=ED(i,2);
    qs=PN(q,1);
    qg=PN(q,2);
    ws=PN(w,1);
    wg=PN(w,2);
    TETA1=asin((wg-qg)/L(i,1))
    TETA2=acos((ws-qs)/L(i,1))
    
    if TETA1 >= 0
        if TETA2 <= pi/2
            TETA(i,1) = TETA1;
        else
            TETA(i,1) = TETA2;
        end
    else 
        if TETA2 <= pi/2
            TETA(i,1) = 2*pi + TETA1;
        else
            TETA(i,1) = 2*pi - TETA2;
        end
    end
    
end

% stiffness matrix_________________________________________________________________

if sM == false

M=spalloc(3*NN,3*NN,36*NE);
% M = (zeros(3*NN));
for i=1:NE
%     i
%     NE
    ll=L(i,1);
    t=TETA(i,1);
    C = cos(t);
    S = sin(t);
    
    % for Euler beam
    K = zeros(6);
    
    K(1,1) = Ar*(C^2)+12*I*(S^2)/(ll^2);
    K(1,2) = (Ar-12*I/(ll^2))*C*S;
    K(1,3) = -6*I*S/ll;
    K(1,4) = -Ar*C^2-12*I*(S^2)/(ll^2);
    K(1,5) = -(Ar-12*I/(ll^2))*C*S;
    K(1,6) = -6*I*S/ll;
    
    K(2,1) = K(1,2);
    K(2,2) = Ar*(S^2)+12*I*(C^2)/(ll^2);
    K(2,3) = 6*I*C/ll;
    K(2,4) = -K(1,2);
    K(2,5) = -K(2,2);
    K(2,6) = K(2,3);
    
    K(3,1) = K(1,3);
    K(3,2) = K(2,3);
    K(3,3) = 4*I;
    K(3,4) = 6*I*S/ll;
    K(3,5) = -6*I*C/ll;
    K(3,6) = 2*I;
    
    K(4,1) = K(1,4);
    K(4,2) = K(2,4);
    K(4,3) = K(3,4);
    K(4,4) = K(1,1);
    K(4,5) = K(1,2);
    K(4,6) = 6*I*S/ll;
    
    K(5,1) = K(1,5);
    K(5,2) = K(2,5);
    K(5,3) = K(3,5);
    K(5,4) = K(4,5);
    K(5,5) = K(2,2);
    K(5,6) = -6*I*C/ll;
    
    K(6,1) = K(1,6);
    K(6,2) = K(2,6);
    K(6,3) = K(3,6);
    K(6,4) = K(4,6);
    K(6,5) = K(5,6);
    K(6,6) = 4*I;
    
    K = e/ll*K;
    
%     KK = zeros(3*NN);
%     KK(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(1:3,1:3);
%     KK(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(1:3,4:6);
%     KK(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(4:6,1:3);
%     KK(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(4:6,4:6);
    
%     KK = sparse (KK);

%     M = sparse(M);

    M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(1:3,1:3) + M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3);
    M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(1:3,4:6) + M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3);
    M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(4:6,1:3) + M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3);
    M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(4:6,4:6) + M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3);



end
end

% M = sparse(M);
% Solving__________________________________________________________________

AtMA = M;

F = FF;
U = UU;
AtMa2 = AtMA;

% Solve
for i=1:3*NN
    if ~isnan(U(i,1))
        F=-AtMA(:,i)*U(i,1)+F;
    end
end
j=1;
for i=1:3*NN
    if ~isnan(U(j,1))
        U(j,:)=[];
        AtMa2(:,j)=[];
        AtMa2(j,:)=[];
        F(j,:)=[];
    else
        j=j+1;
    end
end
U=AtMa2\F;
k=1;
for i=1:3*NN
    if isnan(UU(i,1))
        UU(i,1)=U(k,1);
        k=k+1;
    end
end
UU;
FF=AtMA*UU;

% Result___________________________________________________________________
% elements elongations
dis = zeros(NN,3);
for i = 1:NN
    n = 3*i-2;
    dis(i,1) = UU(n,1);
    m = 3*i-1;
    dis(i,2) = UU(m,1);
    k = 3*i;
    dis(i,3) = UU(k,1);
end
% C2= coordiantes after deformation 
C2=PN+dis(:,1:2);
% L2= after elongation lenght of elements
L2=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=C2(d,1);
    dg=C2(d,2);
    cs=C2(c,1);
    cg=C2(c,2);
    L2(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end

% dL=elements elongations
dL=L2-L;
% ddL= elements strains
ddL=zeros(NE,1);
for i=1:NE
    ddL(i,1)=dL(i,1)/L(i,1);
end
ddL;
% fo: elements forces
fo=zeros(NE,1);
for i=1:NE
    fo(i,1)=ddL(i,1)*e;
end
fo;
S = full(M);

% plot:
C3=PN+dis(:,1:2);

figure1 = figure;
for j=1:NE
    n=ED(j,1);
    m=ED(j,2);
    plot([PN(n,1) PN(m,1)],[PN(n,2) PN(m,2)],'k--','LineWidth',2)
    texte = strcat(num2str(j));
    texth1 = strcat(num2str(SDataV(n,1)));
    texth2 = strcat(num2str(SDataV(m,1)));
    text((PN(n,1)+PN(m,1))/2,(PN(n,2)+PN(m,2))/2,texte,'Color','green','FontSize',14)
    text(PN(n,1)+1*1/100,PN(n,2),texth1,'Color','red','FontSize',14)
    text(PN(m,1)-1*1/100,PN(m,2),texth2,'Color','black','FontSize',14)
    hold on
    plot([C3(n,1) C3(m,1)],[C3(n,2) C3(m,2)],'b','LineWidth',2)
    pbaspect([1 1 1])
    hold on
end


% end





