% timoshenko beam code := Network theory with infnitisimle deformation in
% 2D using direct stiffness method
% Developed by Amir Hossein Namdar


function [fo,C3,FF,UU,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy)

ks = 9/10; % for circular bar


% inputs___________________________________________________________________

% NN = input('please input the number of nodes \n');   
% NE = input('please input the number of edges \n');   
% e = input('Elasticity of edges \n'); 
% 
% PN = input('nodes coordinates from node number 1 to the last one [ x, y] \n');   
% ED=input('Edge direction from edge number 1 to last one [where it starts, where it ends] \n');
% 
% FF=input('nodal forces by respect to the number of nodes (if it's Unknown use nan) [force in x direction; force in y direction;] \n');
% UU=input('nodal displacement by respect to the number of nodes (if it's Unknown use nan)[displacement in x, displacement in y;] \n');


% NN = 6;
% NE = 5;
% % % % % % % e = 100;
% % % % % % % g = e/3;
% % % % % % % A = 1; % area of the beam
% % % % % % % I = 1; % Area Moment of Inertia
% % % % % % % sM = false;
% % % % % % % E=e;
% % % % % % % G=g;
% % % % % % % PN = [1 0 0;2 1 0];
% % % % % % % ED = [1 2];
% % % % % % % NN = 2;
% % % % % % % NE = 1;
% % % % % % % FF = [nan; nan; nan;0;10;0];
% % % % % % % UU = [0; 0; 0;nan;nan;nan];
% PN = [-0.2 3.65 0; 2.8 3.65 0; 0.8 0.65 0; 2.35 2.7 0; 1.8 -0.35 0; 2.3 -0.35 0];
% ED = [1 3; 3 4; 4 2; 3 5; 4 6];

% FF = [nan; nan; nan; nan; nan; nan; 0; 0; 0; 0; 0; 0; nan; nan; nan; nan; nan; nan];
% UU = [0; 0.0001; 0; 0; 0.0001; 0; nan; nan; nan; nan; nan; nan; 0; 0; 0; 0; 0; 0];

PN222 = PN;
PN = zeros(NN,2);
PN(:,1) = PN222(:,2);
PN(:,2) = PN222(:,3);

FF = zeros(3*NN,1);
UU = nan(3*NN,1);
% 

FF(1:3:3*nrb) = BC(1,2);
FF(2:3:3*nrb) = BC(2,2);
FF(3:3:3*nrb) = BC(3,2);
FF(3*nrb+1:3:3*(nlb+nrb)) = BC(4,2);
FF(3*nrb+2:3:3*(nlb+nrb)) = BC(5,2);
FF(3*nrb+3:3:3*(nlb+nrb)) = BC(6,2);
FF(3*(nlb+nrb)+1:3:3*(nlb+nrb+ntb)) = BC(7,2);
FF(3*(nlb+nrb)+2:3:3*(nlb+nrb+ntb)) = BC(8,2);
FF(3*(nlb+nrb)+3:3:3*(nlb+nrb+ntb)) = BC(9,2);
FF(3*(nlb+nrb+ntb)+1:3:3*(nlb+nrb+ntb+nbb)) = BC(10,2);
FF(3*(nlb+nrb+ntb)+2:3:3*(nlb+nrb+ntb+nbb)) = BC(11,2);
FF(3*(nlb+nrb+ntb)+3:3:3*(nlb+nrb+ntb+nbb)) = BC(12,2);

if sM == false
for i = 1:nrb
UU(3*i-2,1) = BCvx*(PN(i,2))/lambda; %%%%
UU(3*i-1,1) = BCvy*(PN(i,2))/lambda; %%%%
end
UU(3:3:3*nrb) = BC(3,1);
for i = nrb+1:nrb+nlb
UU(3*i-2,1) = BCvx*(PN(i,2))/lambda; %%%%
UU(3*i-1,1) = BCvy*(PN(i,2))/lambda; %%%%
end
UU(3*nrb+3:3:3*(nlb+nrb)) = BC(6,1);
UU(3*(nlb+nrb)+1:3:3*(nlb+nrb+ntb)) = BC(7,1);
UU(3*(nlb+nrb)+2:3:3*(nlb+nrb+ntb)) = BC(8,1);
UU(3*(nlb+nrb)+3:3:3*(nlb+nrb+ntb)) = BC(9,1);
UU(3*(nlb+nrb+ntb)+1:3:3*(nlb+nrb+ntb+nbb)) = BC(10,1);
UU(3*(nlb+nrb+ntb)+2:3:3*(nlb+nrb+ntb+nbb)) = BC(11,1);
UU(3*(nlb+nrb+ntb)+3:3:3*(nlb+nrb+ntb+nbb)) = BC(12,1);
else
for i = 1:nrb
UU(3*i-2,1) = BCvx; %%%%
UU(3*i-1,1) = BCvy*(PN(i,2))/lambda; %%%%
end
UU(3:3:3*nrb) = BC(3,1);
for i = nrb+1:nrb+nlb
UU(3*i-2,1) = 0; %%%%
UU(3*i-1,1) = BCvy*(PN(i,2))/lambda; %%%%
end
UU(3*nrb+3:3:3*(nlb+nrb)) = BC(6,1);
for i = nrb+nlb+1:nlb+nrb+ntb
UU(3*i-2,1) = BCvx*(PN(i,1))/lambda;
UU(3*i-1,1) = BCvy;
end
UU(3*(nlb+nrb)+3:3:3*(nlb+nrb+ntb)) = BC(9,1);
for i = nlb+nrb+ntb+1:nlb+nrb+ntb+nbb
UU(3*i-2,1) = BCvx*(PN(i,1))/lambda;
UU(3*i-1,1) = 0;
end
UU(3*(nlb+nrb+ntb)+3:3:3*(nlb+nrb+ntb+nbb)) = BC(12,1);
end


% edges lenghts and angles_________________________________________________
L=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=PN(d,1);
    dg=PN(d,2);
    cs=PN(c,1);
    cg=PN(c,2);
    L(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end   

TETA=zeros(NE,1);
for i=1:NE
    q=ED(i,1);
    w=ED(i,2);
    qs=PN(q,1);
    qg=PN(q,2);
    ws=PN(w,1);
    wg=PN(w,2);
    TETA1=asin((wg-qg)/L(i,1));
    TETA2=acos((ws-qs)/L(i,1));
    
    if TETA1 >= 0
        if TETA2 <= pi/2
            TETA(i,1) = TETA1;
        else TETA(i,1) = TETA2;
        end
    else 
        if TETA2 <= pi/2
            TETA(i,1) = 2*pi + TETA1;
        else TETA(i,1) = 2*pi - TETA2;
        end
    end
    
end

% stiffness matrix_________________________________________________________________

if sM == false

% M=(zeros(3*NN));
tic
M=spalloc(3*NN,3*NN,36*NE);

for i=1:NE
%     i
%     NE
    ll=L(i,1);
    t=TETA(i,1);
    C = cos(t);
    S = sin(t);
    phi = 12*e*I/(ks*Ar*g*ll^2) ;
    
    % for Euler beam
    K = zeros(6);
    K(1,1) = (1+phi)*Ar*(C^2)+12*I*(S^2)/(ll^2);
    K(1,2) = ((1+phi)*Ar-12*I/(ll^2))*C*S;
    K(1,3) = -6*I*S/ll;
    K(1,4) = -(1+phi)*Ar*C^2-12*I*(S^2)/(ll^2);
    K(1,5) = -((1+phi)*Ar-12*I/(ll^2))*C*S;
    K(1,6) = -6*I*S/ll;
    
    K(2,1) = K(1,2);
    K(2,2) = (1+phi)*Ar*(S^2)+12*I*(C^2)/(ll^2);
    K(2,3) = 6*I*C/ll;
    K(2,4) = -K(1,2);
    K(2,5) = -K(2,2);
    K(2,6) = K(2,3);
    
    K(3,1) = K(1,3);
    K(3,2) = K(2,3);
    K(3,3) = (4+phi)*I;
    K(3,4) = 6*I*S/ll;
    K(3,5) = -6*I*C/ll;
    K(3,6) = (2-phi)*I;
    
    K(4,1) = K(1,4);
    K(4,2) = K(2,4);
    K(4,3) = K(3,4);
    K(4,4) = K(1,1);
    K(4,5) = K(1,2);
    K(4,6) = 6*I*S/ll;
    
    K(5,1) = K(1,5);
    K(5,2) = K(2,5);
    K(5,3) = K(3,5);
    K(5,4) = K(4,5);
    K(5,5) = K(2,2);
    K(5,6) = -6*I*C/ll;
    
    K(6,1) = K(1,6);
    K(6,2) = K(2,6);
    K(6,3) = K(3,6);
    K(6,4) = K(4,6);
    K(6,5) = K(5,6);
    K(6,6) = (4+phi)*I;
    
    K = e/(ll*(1+phi))*K;
    
% % %     KK = zeros(3*NN);
% % %     KK(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(1:3,1:3);
% % %     KK(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(1:3,4:6);
% % %     KK(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(4:6,1:3);
% % %     KK(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(4:6,4:6);
% % %     
% % % %     KK = sparse (KK);
% % %     M = M + KK; 
% % % %     M = sparse(M);

    M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(1:3,1:3) + M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,1)*3-2 : ED(i,1)*3);
    M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(1:3,4:6) + M(ED(i,1)*3-2 : ED(i,1)*3 , ED(i,2)*3-2 : ED(i,2)*3);
    M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3) = K(4:6,1:3) + M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,1)*3-2 : ED(i,1)*3);
    M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3) = K(4:6,4:6) + M(ED(i,2)*3-2 : ED(i,2)*3 , ED(i,2)*3-2 : ED(i,2)*3);



end
Mtoc = toc
end

% M = sparse(M);
% Solving__________________________________________________________________

AtMA = M;

F = FF;
U = UU;
AtMa2 = AtMA;

% Solve
for i=1:3*NN
    if ~isnan(U(i,1))
        F=-AtMA(:,i)*U(i,1)+F;
    end
end
j=1;
for i=1:3*NN
    if ~isnan(U(j,1))
        U(j,:)=[];
        AtMa2(:,j)=[];
        AtMa2(j,:)=[];
        F(j,:)=[];
    else
        j=j+1;
    end
end
tic
U=AtMa2\F;
Utoc = toc
k=1;
for i=1:3*NN
    if isnan(UU(i,1))
        UU(i,1)=U(k,1);
        k=k+1;
    end
end
UU;
tic
FF=AtMA*UU;
Ftoc = toc
% Result___________________________________________________________________
% elements elongations
dis = zeros(NN,3);
for i = 1:NN
    n = 3*i-2;
    dis(i,1) = UU(n,1);
    m = 3*i-1;
    dis(i,2) = UU(m,1);
    k = 3*i;
    dis(i,3) = UU(k,1);
end
% C2= coordiantes after deformation 
C2=PN+dis(:,1:2);
% L2= after elongation lenght of elements
L2=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=C2(d,1);
    dg=C2(d,2);
    cs=C2(c,1);
    cg=C2(c,2);
    L2(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end

% dL=elements elongations
dL=L2-L;
% ddL= elements strains
ddL=zeros(NE,1);
for i=1:NE
    ddL(i,1)=dL(i,1)/L(i,1);
end
ddL;
% fo: elements forces
fo=zeros(NE,1);
for i=1:NE
    fo(i,1)=ddL(i,1)*e;
end
fo;


% plot:
C3=PN+dis(:,1:2);

% for k=1:


% figure1 = figure;
% for j=1:NE
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([PN(n,1) PN(m,1)],[PN(n,2) PN(m,2)],'r--','LineWidth',2)
%     hold on
%     plot([C3(n,1) C3(m,1)],[C3(n,2) C3(m,2)],'b','LineWidth',2)
%     pbaspect([1 1 1])
%     hold on
% end


end





