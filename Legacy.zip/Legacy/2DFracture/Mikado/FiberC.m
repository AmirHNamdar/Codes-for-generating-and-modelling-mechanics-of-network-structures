function [Fiber,xc,yc,nf,PBN] = FiberC(x,y,L,N,lambda,Pr)

    xc = [x(1)-L , x(2)+L]; % x to create the network
    yc = [y(1)-L , y(2)+L];

rr = 4/3*(sqrt(((x(2)+2*L)*(y(2)+2*L))/N/pi)) ; % the radius of the effect of the nodes
ife = false; % if a fibre exist

nobf = 0; % number of out of the box fiber
mobn  = []; % midlle of out of boundary nodes.
PBN = []; % data for on the boundary nodes | x-intersection | y-intersection | which bondary? | Which fiber? |
for i=1:N
    % finding a centre for a fibre to be be addded to the network
shsh = 0;
while shsh == 0
    xm=min(xc)+(max(xc)-min(xc))*rand(1);
    ym=min(yc)+(max(yc)-min(yc))*rand(1);
    theta=2*pi*rand(1);
    x1o=xm-cos(theta)*L/2;
    y1o=ym-sin(theta)*L/2;
    x2o=xm+cos(theta)*L/2;
    y2o=ym+sin(theta)*L/2;
if i>1 && ife == true %ife = if fibre exist
%     desn = zeros(size(Fiber,1),1); % distance of the new centre with other nodes
%     for j=1:size(Fiber,1)
%         desn(j,1) = sqrt((xm-Fiber(j,6))^2 + (ym-Fiber(j,7))^2);
%     end
    desn = zeros(size(Fiber,1),1); % distance of the new centre with other nodes
    desn(:,1) = sqrt((xm-Fiber(:,6)).^2 + (ym-Fiber(:,7)).^2);

end
 % to take into account the fibres that are deleted but effect the
 % boundary sections.
 
if size(mobn,1)>0
%     desn2 = zeros(size(mobn,1),1);
%     for j=1:size(mobn,1)
%         desn2(j,1) = sqrt((xm-mobn(j,1))^2 + (ym-mobn(j,2))^2);
%     end
    desn2 = zeros(size(mobn,1),1);
    desn2(:,1) = sqrt((xm-mobn(:,1)).^2 + (ym-mobn(:,2)).^2);
end

nrr=0; % nrr = number of nodes within the effective circle
if i>1 && ife == true
% for j=1:size(desn,1)
%     if desn(j,1)<rr
%         nrr=nrr+1;
%     end
% end
nsd = desn(:,1)<rr;
nrr = nrr+sum(nsd);
end
if size(mobn,1)>0
%     for j = 1:size(mobn,1)
%         if desn2(j,1)<rr
%             nrr = nrr+1;
%         end
%     end
nsd2 = desn2(:,1)<rr;
nrr = nrr+sum(nsd2);
end
% allocating the chance
Pa = (1-Pr)^nrr; % Pa is the chance of appearance

if rand(1)<Pa
    shsh = 1;
end
end

    % finding Acode = address code - where is its centre?
        ssms = L; % small square mesh size
        xma = xm + ssms;
        yma = ym + ssms;
        Acode (1,1) = floor(xma/ssms)+1;
        Acode (1,2) = floor(yma/ssms)+1;
    
    % deleting out of bound portion
    bp1 = 5;
    bp2 = 5;
%     if Acode(1,1) < 3 || Acode(1,1) > lambda/L || Acode (1,2) <3 || Acode(1,2) > lambda/L
    if any([x1o,x2o] < x(1)) || any([x1o,x2o] > x(2)) ...
       || any([y1o,y2o] < y(1)) || any([y1o,y2o] > y(2))
   
        [nir,x1,x2,y1,y2,bp1,bp2] = portion(x1o,x2o,y1o,y2o,x,y,theta); 
    % nir==> if not in the range nir =0, otherwise = 1;
    % bp1: boundary position 1 (right 1, left 2, top 3, bottom 4, not 5)
    % bp2: boundary position 2 (right 1, left 2, top 3, bottom 4, not 5)
    % o stands for old version
    
    % creating a double for a node that is out of the range of the study
    % box:
    
    if Acode(1,1) == 1 && Acode(1,2) == 1 % bottom left - requires 3 new node
        mobn(end+1,:) = [xm,ym+(lambda+2*L)]; % top one
        mobn(end+1,:) = [xm + (lambda+2*L),ym + (lambda+2*L)]; % top right one
        mobn(end+1,:) = [xm + (lambda+2*L),ym]; % right one
    end
    if Acode(1,1) == lambda/L+2 && Acode(1,2) == 1 % bottom right - requires 3 new node
        mobn(end+1,:) = [xm,ym+(lambda+2*L)]; % top one
        mobn(end+1,:) = [xm-(lambda+2*L),ym+(lambda+2*L)]; % top left one
        mobn(end+1,:) = [xm-(lambda+2*L),ym]; % left one
    end    
    if Acode(1,1) == lambda/L+2 && Acode(1,2) == lambda/L+2 % top right - requires 3 new node
        mobn(end+1,:) = [xm,ym-(lambda+2*L)]; % bottom one
        mobn(end+1,:) = [xm - (lambda+2*L),ym - (lambda+2*L)]; % bottom left one
        mobn(end+1,:) = [xm - (lambda+2*L),ym]; % left one
    end
    if Acode(1,1) == 1 && Acode(1,2) == lambda/L+2 % top left - requires 3 new node
        mobn(end+1,:) = [xm,ym-(lambda+2*L)]; % bottom one
        mobn(end+1,:) = [xm+(lambda+2*L),ym-(lambda+2*L)]; % bottom right one
        mobn(end+1,:) = [xm+(lambda+2*L),ym]; % right one
    end     
    if Acode(1,1) == 1 && Acode(1,2) ~= 1 && Acode(1,2) ~= lambda/L+2 % left - requires 1 node
        mobn(end+1,:) = [xm + (lambda+2*L),ym];
    end
    if Acode(1,1) == lambda/L+2 && Acode(1,2) ~= 1 && Acode(1,2) ~= lambda/L+2 % right - requires 1 node
        mobn(end+1,:) = [xm - (lambda+2*L),ym];
    end    
    if Acode(1,2) == 1 && Acode(1,1) ~= 1 && Acode(1,1) ~= lambda/L+2 % bottom - requires 1 node
        mobn(end+1,:) = [xm ,ym + (lambda+2*L)];
    end      
    if Acode(1,2) == lambda/L+2 && Acode(1,1) ~= 1 && Acode(1,1) ~= lambda/L+2 % top - requires 1 node
        mobn(end+1,:) = [xm ,ym - (lambda+2*L)];
    end 
    
    
    
    
    
    if nir == 0
        mobn (end+1,:) = [xm,ym]; % midle of out of boundary nodes.
        nobf = nobf+1;
        continue % goes to the next iteration
    end
    else
        x1 = x1o;
        x2 = x2o;
        y1 = y1o;
        y2 = y2o;
    end
    
    if bp1 == 1 || bp1 == 2 || bp1 == 3 || bp1 == 4
        PBN(end+1,1) = x1;
        PBN(end,2) = y1;
        PBN(end,3) = bp1;
        PBN(end,4) = i-nobf;
    end
    if bp2 == 1 || bp2 == 2 || bp2 == 3 || bp2 == 4
        PBN(end+1,1) = x2;
        PBN(end,2) = y2;
        PBN(end,3) = bp2;
        PBN(end,4) = i-nobf;
    end
    
    % adding its information into fiber matrix
    Fiber(i-nobf,1)=x1;
    Fiber(i-nobf,2)=y1;
    Fiber(i-nobf,3)=x2;
    Fiber(i-nobf,4)=y2;
    Fiber(i-nobf,5)=theta;
    Fiber(i-nobf,6)=xm;
    Fiber(i-nobf,7)=ym;
    Fiber(i-nobf,8) = i-nobf;
    Fiber(i-nobf,9) = Acode(1,1);
    Fiber(i-nobf,10) = Acode(1,2);
    Fiber(i-nobf,11) = bp1;
    Fiber(i-nobf,12) = bp2;
    ife = true;
    
    

end
    nf = size(Fiber,1);
        

% % % % % % 
% % % % % %     
% % % % % %     figure1 = figure
% % % % % %     plot(Fiber(:,6), Fiber(:,7),'o')
% % % % % %     hold on
% % % % % %     plot(mobn(:,1), mobn(:,2),'o')

end 