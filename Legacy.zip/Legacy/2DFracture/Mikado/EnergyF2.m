function Ed = EnergyF2(PN,ED,I,Ar,UUvE,e,g,tb,NE,NN)

% this function calculates the energy stored in each fibre and each mode.
% to do so, we have first calculated the deformation of each node in local
% coordinate and then calculated the forces at voundary of each node and
% then the integration for calculating the overall energy is conducted.
% Ebending = 1/2 int_0^L(M^2/EI)dx and similar for others.

% tic

 % some predefined data 
if tb == 1
    k = 9/10; % for circular bar
elseif tb == 0
    k = 5/6; % for rectangle bar
end


%__________________________________________________________________________________________
% first step to calculate the angle and length of each segment considereing which node
% of each segment is the the number one node

L=zeros(NE,1);
    d=ED(:,1);
    c=ED(:,2);
    ds=PN(d,2);
    dg=PN(d,3);
    cs=PN(c,2);
    cg=PN(c,3);
    L(:,1)=sqrt((ds-cs).^2+(dg-cg).^2);  

TETA=zeros(NE,1);

for i=1:NE
    q=ED(i,1);
    w=ED(i,2);
    qs=PN(q,2);
    qg=PN(q,3);
    ws=PN(w,2);
    wg=PN(w,3);
    TETA1=asin((wg-qg)/L(i,1));
    TETA2=acos((ws-qs)/L(i,1));
    
    if TETA1 >= 0
        if TETA2 <= pi/2
            TETA(i,1) = TETA1;
        else TETA(i,1) = TETA2;
        end
    else 
        if TETA2 <= pi/2
            TETA(i,1) = 2*pi + TETA1;
        else TETA(i,1) = 2*pi - TETA2;
        end
    end
    
end

%__________________________________________________________________________________________
% finding deformation of each segment in local coordinate:
% the rotation is the same
%  ux = uXcos + uYsin
%  uy = - uXsin + uYcos

Ulocal = zeros(NE,6); % [ux1,uy1,u_theta1, ux2,...] note that ux is only for stretching

% for i = 1:NE
    n1 = ED(:,1); % node 1
    n2 = ED(:,2); % node 2
    theta = TETA(:,1); % angle
    uX1 = UUvE(3*n1-2,1);
    uY1 = UUvE(3*n1-1,1);
    uT1 = UUvE(3*n1,1); % rotation
    uX2 = UUvE(3*n2-2,1);
    uY2 = UUvE(3*n2-1,1);
    uT2 = UUvE(3*n2,1); % rotation
    
    % doing the calculation
    ux1 = uX1.*cos(theta) + uY1.*sin(theta);
    uy1 = -uX1.*sin(theta) + uY1.*cos(theta);
    ut1 = uT1;
    ux2 = uX2.*cos(theta) + uY2.*sin(theta);
    uy2 = -uX2.*sin(theta) + uY2.*cos(theta);
    ut2 = uT2;
    
    % filling the matrix
    Ulocal =[ux1,uy1,ut1,ux2,uy2,ut2];
% end
% testing the deformation by getting the original from the local one

uY1test = ux1.*sin(theta) + uy1.*cos(theta);
uX1test = ux1.*cos(theta) - uy1.*sin(theta);



mean((Ulocal(:,4)-Ulocal(:,1))./(Ulocal(:,5)-Ulocal(:,2)));
%__________________________________________________________________________________________
% calculating the forces

% stretching part
Fstretch = (Ulocal(:,4)-Ulocal(:,1))./L.*Ar.*e;

% bending and shear part



A = -L./(k.*Ar.*g) + L.^3./(6.*e.*I);
B = -L.^2./(2.*e.*I);
C = uy2-uy1-ut1.*L;

D = -L.^2./(2.*e.*I);
E = +L./(e.*I);
F = ut1-ut2;

Fshear = (C-(B.*F)./E)./(A-(B.*D)./E);
M = (C-A.*Fshear)./B;

% testing the forcess in nodes
% first: transferring the forcess in the global coordination


% second: adding them together to see if they are equal to what I have
% found before



%__________________________________________________________________________________________
% calculating the energy 

Estretch = 1./(2.*e.*Ar).*Fstretch.^2.*L ; % stretching energy
Eshear = 1./(2.*k.*Ar.*g).* Fshear.^2.*L;
Ebending = 1./(2.*e.*I).*(M.^2.*L + Fshear.^2.*L.^3./3 - 2.*Fshear.*M.*L.^2./2);


Ed = zeros(NE,3);

Ed(:,1) = Ebending;
Ed(:,2) = Estretch;
Ed(:,3) = Eshear;

% TE = toc

end