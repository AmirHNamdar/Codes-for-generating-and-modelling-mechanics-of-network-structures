function [PN,ED,nbn,nrb,nlb,ntb,nbb] = DelBF(PN,ED,nbn,nrb,nlb,ntb,nbb)

% find edges that are connected to the boundary node
e1 = ED(:,1) > nrb + nlb & ED(:,1) <= nbn;
e2 = ED(:,2) > nrb + nlb & ED(:,2) <= nbn;
nie1 = nonzeros(e1 .* [1 : size(ED,1)]');
nie2 = nonzeros(e2 .* [1 : size(ED,1)]');
delE = [nie1;nie2];


% delete all edges at once
ED(delE,:) = [];


% delete the nodes and reduce the ED address
PN(nlb+nrb + 1:nbn,:) = [];
mask1 = ED(:,1) > nbn;
mask2 = ED(:,2) > nbn;
shift = ntb+nbb;
ED(mask1,1) = ED(mask1,1) - shift;
ED(mask2,2) = ED(mask2,2) - shift;


% change nbn, nrb, and nlb
nbn = nbn - (ntb+nbb);
ntb = 0;
nbb = 0;


end