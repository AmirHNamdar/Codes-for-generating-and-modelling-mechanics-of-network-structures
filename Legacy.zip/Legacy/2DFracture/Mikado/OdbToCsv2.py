# -*- coding: utf-8 -*-
# Abaqus Python (usually Python 2.7) compatible script
# Exports:
#   1) Global energies history -> <job>_energies.csv
#   2) Element deletion history from STATUS -> <job>_deletion_history.csv
#
# Usage:
#   abaqus python OdbToCsv.py Job-1.odb [INSTANCE_NAME] [ELSET_NAME]

from odbAccess import openOdb
import sys
import os
import csv


def get_total_time_map(odb):
    """
    Return cumulative start time for each step:
    offsets[stepName] = total elapsed time before this step starts
    """
    step_names = list(odb.steps.keys())
    offsets = {}
    cum = 0.0

    for sname in step_names:
        offsets[sname] = cum
        step = odb.steps[sname]
        if len(step.frames) > 0:
            # frameValue is step-local time
            cum += step.frames[-1].frameValue

    return offsets


def export_energies(odb, out_csv, step_offsets=None):
    """
    Export global energy history variables (ALL*, ETOTAL) from history output.
    Output columns:
      step, step_time, total_time, <energy variables...>
    """
    if step_offsets is None:
        step_offsets = get_total_time_map(odb)

    all_vars = set()
    step_region_data = {}

    # First pass: identify variables and build step time maps
    for sname, step in odb.steps.items():
        # Prefer assembly-level history region
        assembly_regions = []
        for hr_name, hr in step.historyRegions.items():
            if "ASSEMBLY" in hr_name.upper():
                assembly_regions.append((hr_name, hr))

        if len(assembly_regions) == 0:
            candidates = list(step.historyRegions.items())
        else:
            candidates = assembly_regions

        chosen = None
        for hr_name, hr in candidates:
            vars_here = []
            for k in hr.historyOutputs.keys():
                ku = k.upper()
                if ku.startswith("ALL") or ku == "ETOTAL":
                    vars_here.append(k)

            if len(vars_here) > 0:
                chosen = (hr_name, hr, vars_here)
                break

        if chosen is None:
            step_region_data[sname] = None
            continue

        hr_name, hr, vars_here = chosen

        for v in vars_here:
            all_vars.add(v)

        # Build time-indexed dict for this step: {step_time: {var: value}}
        time_map = {}
        for v in vars_here:
            data_list = hr.historyOutputs[v].data  # list of (time, value)
            for pair in data_list:
                t = pair[0]
                val = pair[1]
                if t not in time_map:
                    time_map[t] = {}
                time_map[t][v] = val

        step_region_data[sname] = time_map

    all_vars = sorted(list(all_vars))

    # Second pass: write directly (avoids building one huge rows list)
    f = open(out_csv, "wb")  # Py2 csv on Windows expects binary mode
    try:
        writer = csv.DictWriter(f, fieldnames=["step", "step_time", "total_time"] + all_vars)
        writer.writeheader()

        for sname, time_map in step_region_data.items():
            if not time_map:
                continue

            tlist = sorted(time_map.keys())
            step_offset = step_offsets[sname]

            for t in tlist:
                d = time_map[t]
                row = {
                    "step": sname,
                    "step_time": t,
                    "total_time": step_offset + t
                }
                for v in all_vars:
                    if v in d:
                        row[v] = d[v]
                    else:
                        row[v] = ""
                writer.writerow(row)
    finally:
        f.close()

    print("Wrote energies: %s" % out_csv)


def _resolve_region(odb, instance_name=None, elset_name=None):
    """
    Resolve Abaqus region once (for faster frame loop).
    Priority:
      - assembly-level ELSET (if provided and found)
      - instance-level ELSET (if instance + elset provided and found)
      - instance region (if provided and found)
      - None (no filtering)
    """
    root = odb.rootAssembly
    inst_obj = None
    region = None

    if instance_name is not None:
        try:
            if instance_name in root.instances:
                inst_obj = root.instances[instance_name]
        except Exception:
            inst_obj = None

    if elset_name is not None:
        try:
            # Assembly-level elset first
            if elset_name in root.elementSets:
                region = root.elementSets[elset_name]
            # Then instance-level elset
            elif inst_obj is not None and elset_name in inst_obj.elementSets:
                region = inst_obj.elementSets[elset_name]
        except Exception:
            region = None

    if region is None and inst_obj is not None:
        region = inst_obj

    return region


def _status_scalar_from_data(data):
    """
    Convert STATUS-like value to float.
    Handles scalar or length-1 sequence/array.
    """
    try:
        # scalar case
        return float(data)
    except Exception:
        pass

    # tuple/list/array-like case
    try:
        return float(data[0])
    except Exception:
        pass

    # last resort
    return None


def export_deletion_history(odb, out_csv, instance_name=None, elset_name=None,
                            status_var_candidates=("STATUS", "STATUSMP"),
                            delete_threshold=0.5,
                            use_bulk=True):
    """
    Export first deletion event per element based on STATUS-like field output.

    Deletion criterion used here:
      status < delete_threshold  => treated as deleted/failed

    Output columns:
      element_label, instance, step, frame_id, step_time, total_time, status_value
    """
    step_offsets = get_total_time_map(odb)

    # Track first deletion only (membership lookup is the main thing we need)
    seen_deleted = set()

    # Resolve filter region ONCE
    region = _resolve_region(odb, instance_name=instance_name, elset_name=elset_name)

    f = open(out_csv, "wb")
    try:
        writer = csv.writer(f)
        writer.writerow(["element_label", "instance", "step", "frame_id",
                         "step_time", "total_time", "status_value"])

        for sname, step in odb.steps.items():
            step_offset = step_offsets[sname]

            for i_frame, frame in enumerate(step.frames):
                # Find STATUS-like variable in this frame
                field = None
                used_var = None
                fo = frame.fieldOutputs

                for cand in status_var_candidates:
                    # Faster membership check than cand in fo.keys()
                    if cand in fo:
                        field = fo[cand]
                        used_var = cand
                        break

                if field is None:
                    continue

                subset = field
                if region is not None:
                    try:
                        subset = field.getSubset(region=region)
                    except Exception:
                        # Fall back to unfiltered field if subset extraction fails
                        subset = field

                t_step = frame.frameValue
                t_total = step_offset + t_step

                # Fast path: bulkDataBlocks (often much faster than subset.values)
                bulk_ok = False
                if use_bulk:
                    try:
                        blocks = subset.bulkDataBlocks
                        # If attribute exists and is iterable, try to use it
                        for block in blocks:
                            bulk_ok = True

                            # Instance name (best effort)
                            block_inst_name = ""
                            try:
                                if hasattr(block, "instance") and hasattr(block.instance, "name"):
                                    block_inst_name = block.instance.name
                            except Exception:
                                block_inst_name = ""

                            # Element labels (best effort)
                            try:
                                labels = block.elementLabels
                            except Exception:
                                labels = None

                            # Data array/list
                            try:
                                data_arr = block.data
                            except Exception:
                                data_arr = None

                            if labels is None or data_arr is None:
                                continue

                            # Iterate block values
                            # For STATUS this is usually one scalar per element
                            n = len(labels)
                            for j in xrange(n):
                                label = int(labels[j])
                                key = (block_inst_name, label)

                                if key in seen_deleted:
                                    continue

                                sval = _status_scalar_from_data(data_arr[j])
                                if sval is None:
                                    continue

                                if sval < delete_threshold:
                                    seen_deleted.add(key)
                                    writer.writerow([label, block_inst_name, sname, i_frame,
                                                     t_step, t_total, sval])

                        # If no exception but no blocks processed, we'll use fallback
                    except Exception:
                        bulk_ok = False

                # Fallback path (safe for all ODB cases)
                if not bulk_ok:
                    for v in subset.values:
                        label = getattr(v, "elementLabel", None)
                        if label is None:
                            continue

                        if hasattr(v, "instance") and hasattr(v.instance, "name"):
                            inst_name = v.instance.name
                        else:
                            inst_name = ""

                        key = (inst_name, label)
                        if key in seen_deleted:
                            continue

                        sval = _status_scalar_from_data(v.data)
                        if sval is None:
                            continue

                        if sval < delete_threshold:
                            seen_deleted.add(key)
                            writer.writerow([label, inst_name, sname, i_frame,
                                             t_step, t_total, sval])

    finally:
        f.close()

    print("Wrote deletion history: %s" % out_csv)
    print("Note: deletion time is resolved only at output frame times (not exact increment unless output every increment).")


def main():
    if len(sys.argv) < 2:
        print("Usage: abaqus python OdbToCsv.py Job-1.odb [INSTANCE_NAME] [ELSET_NAME]")
        sys.exit(1)

    odb_path = sys.argv[1]

    instance_name = None
    elset_name = None
    if len(sys.argv) >= 3 and sys.argv[2] != "None":
        instance_name = sys.argv[2]
    if len(sys.argv) >= 4 and sys.argv[3] != "None":
        elset_name = sys.argv[3]

    if not os.path.isfile(odb_path):
        print("ODB not found: %s" % odb_path)
        sys.exit(1)

    odb = openOdb(path=odb_path, readOnly=True)

    try:
        base = os.path.splitext(os.path.basename(odb_path))[0]
        out1 = base + "_energies.csv"
        out2 = base + "_deletion_history.csv"

        # Compute once and reuse
        step_offsets = get_total_time_map(odb)

        export_energies(odb, out1, step_offsets=step_offsets)
        export_deletion_history(odb, out2,
                                instance_name=instance_name,
                                elset_name=elset_name)
    finally:
        odb.close()


if __name__ == "__main__":
    main()