function [SDataV] = BackboneCA(SDataV)

% clear 
% clc
% close all
curratio = 1e-12; % zero with possible error of the numerical processes

% in this function the electrical backbone of the netwok will be find. I
% think it is sil=milar to the elastic backbone of the network. This
% information will be used to delete the dangling part to reduce the
% efficiency of the code.

%  example
% PN2 = [10 10; 5 10; 4 10; 9 0; 9 9 ; 10 8;7 8; 6 7; 9 5; 5 9; 6 5; 5 4];
% ED = [1 5; 2 10; 3 10;5 6;5 7;6 9; 7 9; 7 8; 9 4; 11 12; 11 10];
% PN = zeros(12,3);
% PN(:,2:3) = PN2;
% NN = 12;
% NE = 11;
% nrb = 0;
% nlb = 0;
% ntb = 3;
% nbb = 1;

NE = SDataV(1,6); % number of edges
NN = SDataV(1,7); % number of nodes
PN = SDataV(1:NN,1:3); % position of nodes
ED = SDataV(1:NE,4:5); % edge direction (node 1 to node 2)
nrb = SDataV(1,8); % number of boundary nodes on right side
nlb = SDataV(2,8); % number of boundary nodes on left side
ntb = SDataV(3,8); % number of boundary nodes on top side
nbb = SDataV(4,8); % number of boundary nodes on bottom side
nbn = nrb+nlb+ntb+nbb; % number of tottal boundary nodes
% NN
% NE
% % % % % % % % figure1 = figure;
% % % % % % % % for j=1:NE
% % % % % % % %     n=ED(j,1);
% % % % % % % %     m=ED(j,2);
% % % % % % % %     plot([PN2(n,1) PN2(m,1)],[PN2(n,2) PN2(m,2)],'r')
% % % % % % % %     hold on
% % % % % % % % end

pn = zeros(NN,2); % position of nodes 
pn(:,1) = PN(:,2);
pn(:,2) = PN(:,3);

II = zeros(NN,1);
VV = nan(NN,1);


II(1:nrb) = nan;
II(nrb+1:(nlb+nrb)) = nan;
II((nlb+nrb)+1:nlb+nrb+ntb) = nan;
II((nlb+nrb+ntb)+1:nlb+nrb+ntb+nbb) = nan;

VV(1:nrb) = 10;
VV(nrb+1:(nlb+nrb)) = 0;
VV((nlb+nrb)+1:nlb+nrb+ntb) = 10;
VV((nlb+nrb+ntb)+1:nlb+nrb+ntb+nbb) = 0;

L=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=pn(d,1);
    dg=pn(d,2);
    cs=pn(c,1);
    cg=pn(c,2);
    L(i,1)=sqrt((ds-cs)^2+(dg-cg)^2);
end   


% admittance matrix ---------------

M = (zeros(NN));

for i=1:NE
%     i
%     NE
    yy=1/L(i,1);
    
   
    K = zeros(2);
    K(1,1) = yy;
    K(1,2) = -yy;
    K(2,1) = -yy;
    K(2,2) = yy;
    

    M(ED(i,1), ED(i,1)) = K(1,1) + M(ED(i,1), ED(i,1));
    M(ED(i,1), ED(i,2)) = K(1,2) + M(ED(i,1), ED(i,2));
    M(ED(i,2), ED(i,1)) = K(2,1) + M(ED(i,2), ED(i,1));
    M(ED(i,2), ED(i,2)) = K(2,2) + M(ED(i,2), ED(i,2));



end
M = sparse(M);

AtMA = M;

F = II;
U = VV;
AtMa2 = AtMA;

% Solveing -----------
for i=1:NN
    if ~isnan(U(i,1))
        F=-AtMA(:,i)*U(i,1)+F;
    end
end
j=1;
for i=1:NN
    if ~isnan(U(j,1))
        U(j,:)=[];
        AtMa2(:,j)=[];
        AtMa2(j,:)=[];
        F(j,:)=[];
    else
        j=j+1;
    end
end
U=AtMa2\F;
k=1;
for i=1:NN
    if isnan(VV(i,1))
        VV(i,1)=U(k,1);
        k=k+1;
    end
end
VV;
II=AtMA*VV;

% elemental current

cur=zeros(NE,1);
for i=1:NE
    d=ED(i,1);
    c=ED(i,2);
    ds=VV(d,1);
    cs=VV(c,1);
    cur(i,1)=(ds-cs)/L(i,1);
end


% deleting the elements --------------------
% 1- deletin the edge from ED
% 2- if the nodes are not connected to any other edge, delet them to
% 3- changing the number of nodes (in ED and boundary number)

curth = max(cur)*curratio; % zero with possible error of the numerical processes
EDs = size(ED,1); % number of edges

i = 1;
% tic
while i <=EDs
    if abs(cur(i,1)) < curth
        
        
        fN = ED(i,1); % first node number
        sN = ED(i,2); % second node number
        cur(i,:) =[];
        % id it necessary to delete the connected nodes or not?
        necfn = size(find(ED==fN),1); % number of edges connected to the first node
        necsn = size(find(ED==sN),1); % number of edges connected to the first node
        if necfn > 1 && necsn > 1 % the edge can be deleted without further do
            ED(i,:)=[];
        end
        
        if necfn ==1 && necsn > 1
            ED(i,:) = [];
            pn(fN,:) = [];
                for k = 1:size(ED,1)
                    for kk = 1:2
                        if ED(k,kk) > fN
                            ED(k,kk) = ED(k,kk)-1;
                        end
                    end
                end
            if fN < nlb+nrb+ntb+nbb % not a boundary node
                if fN < nrb+1
                    nrb = nrb-1;
                elseif fN < nlb + nrb + 1 && fN>nrb
                    nlb = nlb-1;
                elseif fN < ntb +  nlb + nrb + 1 && fN > nlb + nrb
                    ntb = ntb-1;
                elseif fN< nbb + ntb +  nlb + nrb + 1 && fN > nlb + nrb + ntb
                    nbb = nbb-1;
                end
            end
        end

%         if necfn ==1 && necsn > 1
%             if fN > nlb+nrb+ntb+nbb % not a boundary node
%                 ED(i,:) = [];
%                 pn(fN,:) = [];
%                 for k = 1:size(ED,1)
%                     for kk = 1:2
%                         if ED(k,kk) > fN
%                             ED(k,kk) = ED(k,kk)-1;
%                         end
%                     end
%                 end
%             else 
%                 if fN < nrb+1
%                     nrb = nrb-1;
%                 elseif fN < nlb + nrb + 1 && fN>nrb
%                     nlb = nlb-1;
%                 elseif fN < ntb +  nlb + nrb + 1 && fN > nlb + nrb
%                     ntb = ntb-1;
%                 elseif fN< nbb + ntb +  nlb + nrb + 1 && fN > nlb + nrb + ntb
%                     nbb = nbb-1;
%                 end
%                 ED(i,:) = [];
%                 pn(fN,:) = [];
%                 for k = 1:size(ED,1)
%                     for kk = 1:2
%                         if ED(k,kk) > fN
%                             ED(k,kk) = ED(k,kk)-1;
%                         end
%                     end
%                 end
%             end
%         end


        if necfn > 1 && necsn == 1
            ED(i,:) = [];
            pn(sN,:) = [];
                for k = 1:size(ED,1)
                    for kk = 1:2
                        if ED(k,kk) > sN
                            ED(k,kk) = ED(k,kk)-1;
                        end
                    end
                end
            if sN < nlb+nrb+ntb+nbb % not a boundary node
                if sN < nrb+1
                    nrb = nrb-1;
                elseif sN < nlb + nrb + 1 && sN>nrb
                    nlb = nlb-1;
                elseif sN < ntb +  nlb + nrb + 1 && sN > nlb + nrb
                    ntb = ntb-1;
                elseif sN< nbb + ntb +  nlb + nrb + 1 && sN > nlb + nrb + ntb
                    nbb = nbb-1;
                end
            end
        end
        
        if necfn == 1 && necsn == 1
%             ED
%             pn
%             fN
%             sN
            ED(i,:) = [];
            % I imagine that the fN > sN
            if sN > fN
                ssN = sN;
                sN = fN;
                fN = ssN;
            end
            pn(fN,:) = [];
            pn(sN,:) = [];
                for k = 1:size(ED,1)
                    for kk = 1:2
                        if ED(k,kk) > fN
                            ED(k,kk) = ED(k,kk)-1;
                        end
                    end
                end
                for k = 1:size(ED,1)
                    for kk = 1:2
                        if ED(k,kk) > sN
                            ED(k,kk) = ED(k,kk)-1;
                        end
                    end
                end
            if fN < nlb+nrb+ntb+nbb % not a boundary node
                if fN < nrb+1
                    nrb = nrb-1;
                elseif fN < nlb + nrb + 1 && fN>nrb
                    nlb = nlb-1;
                elseif fN < ntb +  nlb + nrb + 1 && fN > nlb + nrb
                    ntb = ntb-1;
                elseif fN< nbb + ntb +  nlb + nrb + 1 && fN > nlb + nrb + ntb
                    nbb = nbb-1;
                end
            end
            if sN < nlb+nrb+ntb+nbb % not a boundary node
                if sN < nrb+1
                    nrb = nrb-1;
                elseif sN < nlb + nrb + 1 && sN>nrb
                    nlb = nlb-1;
                elseif sN < ntb +  nlb + nrb + 1 && sN > nlb + nrb
                    ntb = ntb-1;
                elseif sN< nbb + ntb +  nlb + nrb + 1 && sN > nlb + nrb + ntb
                    nbb = nbb-1;
                end
            end
        end       
            
        
        
        i = i-1;
    end
    i = i+1;
    EDs = size(ED,1); % number of edges

end
NN = size(pn,1);
NE = size(ED,1);
SDataV = zeros(max(NE,NN),8);

SDataV(1,6) = NE; % number of edges
SDataV(1,7) = NN; % number of nodes
SDataV(1:NN,2:3) = pn; % position of nodes
SDataV(1:NE,4:5) = ED; % edge direction (node 1 to node 2)
SDataV(1,8) = nrb; % number of boundary nodes on right side
SDataV(2,8) = nlb; % number of boundary nodes on left side
SDataV(3,8) = ntb; % number of boundary nodes on top side
SDataV(4,8) = nbb; % number of boundary nodes on bottom side
nbn = nrb+nlb+ntb+nbb; % number of tottal boundary nodes


% figure2 = figure;
% for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
%     plot([pn(n,1) pn(m,1)],[pn(n,2) pn(m,2)],'b')
%     hold on
% end
% curT = toc







end






