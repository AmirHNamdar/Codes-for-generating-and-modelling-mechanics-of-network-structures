function [xi1,yi1,xi2,yi2] = CornerIntersection(xm,ym,x1o,x2o,y1o,y2o,x,y,theta,Acode)



% first finding intersections with x lines
% % for j: y = ax + b
a = (y2o-y1o)/(x2o-x1o);
b = y2o - a*(x2o);


% bottom and top lines
    yb = y(1);
    xb = (y(1) - b)/a;
    yt = y(2);
    xt = (y(2) - b)/a;

% right and left lines
    xl = x(1);
    yl = a*x(1)+b;
    xr = x(2);
    yr = a*x(2)+b;
    
    

% distance from x1o

d = zeros(4,3); % [distance, ] 
dt = sqrt((xt-x1o)^2+(yt-y1o)^2);
db = sqrt((xb-x1o)^2+(yb-y1o)^2);
dr = sqrt((xr-x1o)^2+(yr-y1o)^2);
dl = sqrt((xl-x1o)^2+(yl-y1o)^2);

d = [dt,xt,yt;
db,xb,yb;
dr,xr,yr;
dl,xl,yl];

f = sortrows(d,1);

xi1 = f(1,2);
yi1 = f(1,3);
xi2 = f(2,2);
yi2 = f(2,3);

% figure1 = figure
% plot([f(:,2)],[f(:,3)],'o')
% hold on
% plot([x2o x1o],[y2o y1o],'b');

end


% 
% 
% 
% % it finds intesrction of two straight fibre in 2D space
% 
% ec = 0;
% 
% if Fiber(j,3)>Fiber(j,1)
%     xj2 = Fiber(j,3);
%     xj1 = Fiber(j,1);
%     yj2 = Fiber(j,4);
%     yj1 = Fiber(j,2);
% else
%     xj2 = Fiber(j,1);
%     xj1 = Fiber(j,3);
%     yj2 = Fiber(j,2);
%     yj1 = Fiber(j,4);
% end
% if Fiber(i,3)>Fiber(i,1)
%     xi2 = Fiber(i,3);
%     xi1 = Fiber(i,1);
%     yi2 = Fiber(i,4);
%     yi1 = Fiber(i,2);
% else
%     xi2 = Fiber(i,1);
%     xi1 = Fiber(i,3);
%     yi2 = Fiber(i,2);
%     yi1 = Fiber(i,4);
% end
% 
% 
% 
% % for j: y = ax + b
% a = (yj2-yj1)/(xj2-xj1);
% b = yj2 - a*(xj2);
% 
% % for i: y = cx + d
% c = (yi2-yi1)/(xi2-xi1);
% d = yi2 - c*(xi2);
% 
% xi = (d-b)/(a-c); % x position of intersection 
% yi = a*xi + b; % y position of intersection
% 
% if xi < xj2 && xi > xj1
%     if xi < xi2 && xi > xi1
%         ec = 1;
%     end
% end
% 
% end
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
