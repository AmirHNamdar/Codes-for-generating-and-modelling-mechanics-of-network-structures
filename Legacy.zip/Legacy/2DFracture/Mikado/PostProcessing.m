clear all
clc
close all

nsd = 35; % number of square data
nrd = 800; % number of random data
Ard = 1; % cross  section of the data
Id = 1; % I of the data
Ld = 50; % length of the data
namd = strcat('RSA',num2str(Ard),'I',num2str(Id),'L',num2str(Ld),'-'); % general name of the data for random shear network
namddata = strcat('RSA',num2str(Ard),'I',num2str(Id),'L',num2str(Ld),'-data');

load(namddata) % ----------************

figure1 = figure;

% Create subplot
subplot1 = subplot(2,2,1,'Parent',figure1);
hold(subplot1,'on');
plot(den,G,'DisplayName','Random Network','Parent',subplot1,'Marker','o',...
    'LineStyle','none')
ylabel('Shear modulus');
xlabel('Density of active fibres');
box(subplot1,'on');
hold(subplot1,'off');
legend(subplot1,'show');
hold on

subplot2 = subplot(2,2,2,'Parent',figure1);
hold(subplot2,'on');
plot(denN*L/((y(2)-y(1)+2*L)*(x(2)-x(1)+2*L)),G,'DisplayName','Random Network','Parent',subplot2,'Marker','o',...
    'LineStyle','none')
ylabel('Shear modulus');
xlabel('Density of initial fibres');
box(subplot2,'on');
hold(subplot2,'off');
legend(subplot2,'show');
hold on

subplot3 = subplot(2,2,3,'Parent',figure1);
hold(subplot3,'on');
plot(denf,G,'DisplayName','Random Network','Parent',subplot3,'Marker','o',...
    'LineStyle','none')
ylabel('Shear modulus');
xlabel('Density of fibres inside the studied domain');
box(subplot3,'on');
hold(subplot3,'off');
legend(subplot3,'show');
hold on

load('SSdata') % -----------**************

subplot(2,2,1)
plot(den,G,'DisplayName','Square Network','Parent',subplot1,'Color',[1 0 0])
hold on
% subplot(2,2,2)
% plot(denN*100/((y(2)-y(1))*(x(2)-x(1))),G,'DisplayName','Square Network','Parent',subplot2,'Color',[1 0 0])
% hold on
subplot(2,2,3)
plot(denf,G,'DisplayName','Square Network','Parent',subplot3,'Color',[1 0 0])
hold on


% plotting of three networks at a given density ---------------------------

% first finding the address of the max, min and mid

load(namddata) % -------------***************
urd = 0.22; % upper renge of density
lrd = 0.2; % lower renge of density
npn = 0; % the number of networks with potential to be chosen 
ncn = 0; % the number of chosen networks [max G, minG, closest to middle G]
k = 1;
for i=1:nrd
    if den(i,1) < urd && den(i,1) > lrd
        npn(k,1) = i;
        k = k +1;
    end
end
GG(:,1) = npn(:,1);
GG(:,2) = G(npn(:,1),:);
[rpm, cpm] = find(GG==max(GG(:,2))); % row position of max and column position of max
ncn(1,1) = GG(rpm,1);
[rpm, cpm] = find(GG==min(GG(:,2))); % row position of max and column position of min
ncn(2,1) = GG(rpm,1);
GGm(:,1) = GG(:,1);
GGm(:,2)=(abs(GG(:,2)-(max(GG(:,2))-min(GG(:,2)))/2 - min(GG(:,2)))); % to find closest data to the midlle
[rpm, cpm] = find(GGm==min(GGm(:,2))); % row position of max and column position of min
ncn(3,1) = GGm(rpm,1);
% plotting the chosen data in the shear density plots
subplot1 = subplot(2,2,1,'Parent',figure1);
plot(den(ncn(:,1),1),G(ncn(:,1),1),'DisplayName','chosen data','Parent',subplot1,'Marker','o',...
    'LineStyle','none','color',[0 0 0],'MarkerFaceColor',[0 0 0],'MarkerEdgeColor',[0 0 0],'MarkerSize',6)
hold on
subplot2 = subplot(2,2,2,'Parent',figure1);
plot(denN(ncn(:,1),1)*L/((y(2)-y(1)+2*L)*(x(2)-x(1)+2*L)),G(ncn(:,1),1),'DisplayName','chosen data','Parent',subplot2,'Marker','o',...
    'LineStyle','none','color',[0 0 0],'MarkerFaceColor',[0 0 0],'MarkerEdgeColor',[0 0 0],'MarkerSize',6)
hold on
subplot3 = subplot(2,2,3,'Parent',figure1);
plot(denf(ncn(:,1),1),G(ncn(:,1),1),'DisplayName','chosen data','Parent',subplot3,'Marker','o',...
    'LineStyle','none','color',[0 0 0],'MarkerFaceColor',[0 0 0],'MarkerEdgeColor',[0 0 0],'MarkerSize',6)
hold on
% loading the relative data

nld = strcat(namd,num2str(ncn(1,1))); % name of loading data
load(nld)%-------------**************
PNmax = PN;
EDmax = ED;

nld = strcat(namd,num2str(ncn(2,1))); % name of loading data
load(nld)%-------------**************
PNmin = PN;
EDmin = ED;

nld = strcat(namd,num2str(ncn(3,1))); % name of loading data
load(nld)%-------------**************
PNmid = PN;
EDmid = ED;

figure2 = figure;
for j=1:size(EDmax,1)
    subplot(2,2,1)
    n=EDmax(j,1);
    m=EDmax(j,2);
    plot([PNmax(n,2) PNmax(m,2)],[PNmax(n,3) PNmax(m,3)])
    hold on
end
title('max shear modulus')

for j=1:size(EDmin,1)
    subplot(2,2,2)
    n=EDmin(j,1);
    m=EDmin(j,2);
    plot([PNmin(n,2) PNmin(m,2)],[PNmin(n,3) PNmin(m,3)])
    hold on
end
title('min shear modulus')


for j=1:size(EDmid,1)
    subplot(2,2,3)
    n=EDmid(j,1);
    m=EDmid(j,2);
    plot([PNmid(n,2) PNmid(m,2)],[PNmid(n,3) PNmid(m,3)])
    hold on
end
title('mid shear modulus')


% % plotting the structures with most shear modulus at various densities-----
% 
% load('RSdata') % -------------***************
% 
% ncn = 0; % the number of chosen networks [max G, minG, closest to middle G]
% 
% for j = 1:8
%     npn = 0; % the number of networks with potential to be chosen 
%     GG = [];
%     
%     urd = j*0.05; % upper renge of density
%     lrd = (j-1)*0.05; % lower renge of density
%     
%     k = 1;
% for i=1:nrd
%     if den(i,1) < urd && den(i,1) > lrd
%         npn(k,1) = i;
%         k = k +1;
%     end
% end
% 
% GG(:,1) = npn(:,1);
% GG(:,2) = G(npn(:,1),:);
% [rpm, cpm] = find(GG==max(GG(:,2))); % row position of max and column position of max
% ncn(j,1) = GG(rpm,1);
% end
% 
%     figure3 = figure;
% % loading the relative data and plot
% for i=1:size(ncn,1)
%     nld = strcat('RS11',num2str(ncn(i,1))); % name of loading data
%     load(nld) %-------------**************
%     
% 
%     
%     for j=1:size(ED,1)
%     n=ED(j,1);
%     m=ED(j,2);
%     subploti = subplot(4,2,i,'Parent',figure3);
%     plot([PN(n,2) PN(m,2)],[PN(n,3) PN(m,3)],'Parent',subploti)
%     hold on
%     title(strcat('shear',num2str(G(ncn(i,1),1))))
% end
%     
%     
%     
% end





% plotting the energy storage of networks__________________________________

% loading the relative data
nld = strcat(namd,num2str(ncn(1,1))); % name of loading data
load(nld)%-------------**************
PNmax = PN;
EDmax = ED;
UUmax = UU;
[Mmax,Memax] = stiffnessM(ED,PN); % fiding the stiffness matrix of each element
seemax = zeros(size(ED,1),1); % stored energy of edges
for i = 1:size(ED,1)
    qb = zeros(6,1);
    qb(1,1) = UU(ED(i,1)*3-2);  % qhat
    qb(2,1) = UU(ED(i,1)*3-1);
    qb(3,1) = UU(ED(i,1)*3);
    qb(4,1) = UU(ED(i,2)*3-2);
    qb(5,1) = UU(ED(i,2)*3-1);
    qb(6,1) = UU(ED(i,2)*3);
    Me = Memax(i*6-5:i*6,i*6-5:i*6);
    
    seemax(i,1) = transpose(qb)*Me*qb;
    msmax = max(seemax); % max of energy
end

nld = strcat(namd,num2str(ncn(2,1))); % name of loading data
load(nld)%-------------**************
PNmin = PN;
EDmin = ED;
UUmin = UU;
[Mmin,Memin] = stiffnessM(ED,PN); % fiding the stiffness matrix of each element
seemin = zeros(size(ED,1),1); % stored energy of edges
for i = 1:size(ED,1)
    qb = zeros(6,1);
    qb(1,1) = UU(ED(i,1)*3-2);  % qhat
    qb(2,1) = UU(ED(i,1)*3-1);
    qb(3,1) = UU(ED(i,1)*3);
    qb(4,1) = UU(ED(i,2)*3-2);
    qb(5,1) = UU(ED(i,2)*3-1);
    qb(6,1) = UU(ED(i,2)*3);
    Me = Memin(i*6-5:i*6,i*6-5:i*6);
    
    seemin(i,1) = transpose(qb)*Me*qb;
    msmin = max(seemin); % max of energy
end

nld = strcat(namd,num2str(ncn(3,1))); % name of loading data
load(nld)%-------------**************
PNmid = PN;
EDmid = ED;
UUmid = UU;
[Mmid,Memid] = stiffnessM(ED,PN); % fiding the stiffness matrix of each element
seemid = zeros(size(ED,1),1); % stored energy of edges
for i = 1:size(ED,1)
    qb = zeros(6,1);
    qb(1,1) = UU(ED(i,1)*3-2);  % qhat
    qb(2,1) = UU(ED(i,1)*3-1);
    qb(3,1) = UU(ED(i,1)*3);
    qb(4,1) = UU(ED(i,2)*3-2);
    qb(5,1) = UU(ED(i,2)*3-1);
    qb(6,1) = UU(ED(i,2)*3);
    Me = Memid(i*6-5:i*6,i*6-5:i*6);
    
    seemid(i,1) = transpose(qb)*Me*qb;
    msmid = max(seemid); % max of energy
end


figure4 = figure;
for j=1:size(EDmax,1)
    subplot(2,2,1)
    n=EDmax(j,1);
    m=EDmax(j,2);
    co = seemax(j,1)/msmax*5;
        if co>1
        co=1;
    end
    plot([PNmax(n,2) PNmax(m,2)],[PNmax(n,3) PNmax(m,3)],'color',[co 0 0],'linewidth',2)
    hold on
end
title('max shear modulus')

for j=1:size(EDmin,1)
    subplot(2,2,2)
    n=EDmin(j,1);
    m=EDmin(j,2);
    co = seemin(j,1)/msmin*5;
        if co>1
        co=1;
    end
    plot([PNmin(n,2) PNmin(m,2)],[PNmin(n,3) PNmin(m,3)],'color',[co 0 0],'linewidth',2)
    hold on
end
title('min shear modulus')


for j=1:size(EDmid,1)
     subplot(2,2,3)
    n=EDmid(j,1);
    m=EDmid(j,2);
    co = seemid(j,1)/msmid*5;
    if co>1
        co=1;
    end
    plot([PNmid(n,2) PNmid(m,2)],[PNmid(n,3) PNmid(m,3)],'color',[co 0 0],'linewidth',2)
    hold on
end
% title('mid shear modulus')














