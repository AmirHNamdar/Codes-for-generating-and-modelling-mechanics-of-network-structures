close all
clear 
clc

load SRSA1I1L1Nf150Pr80-200-data

MGeg = zeros(6,1);
MGsg = zeros(6,1);
den = zeros(6,1);
for i=1:6
    den(i,1) = (140+i*10)/4;
end

MGeg(1:6,1) = MGe;
MGsg(1:6,1) = MGs;

load SRSA1I1L1Nf150-200-data
% 
 MGeg2(1:6,1) = MGe;
 MGsg2(1:6,1) = MGs;

load SRSA1I1L1Pr0Nf150-200-data
 
 MGeg3(1:6,1) = MGe;
 MGsg3(1:6,1) = MGs;


loge = log10(MGeg);
logs = log10(MGsg);
logden = log10(den);
loge2 = log10(MGeg2);
logs2 = log10(MGsg2);
loge3 = log10(MGeg3);
logs3 = log10(MGsg3);


figure1 = figure
plot(logden,loge)
hold on
plot(logden,loge2)
hold on
plot(logden,loge3)

figure2 = figure
plot(logden,logs)
hold on
plot(logden,logs2)
hold on
plot(logden,logs3)

figure3 = figure
plot(den,MGeg)
hold on
plot(den,MGeg2)
hold on
plot(den,MGeg3)

figure4 = figure
plot(den,MGsg)
hold on
plot(den,MGsg2)
hold on
plot(den,MGsg3)


(loge(end,1)-loge(1,1))/(logden(end,1)-logden(1,1))
(loge2(end,1)-loge2(1,1))/(logden(end,1)-logden(1,1))
(loge3(end,1)-loge3(1,1))/(logden(end,1)-logden(1,1))

(logs(end,1)-logs(1,1))/(logden(end,1)-logden(1,1))
(logs2(end,1)-logs2(1,1))/(logden(end,1)-logden(1,1))
(logs3(end,1)-logs3(1,1))/(logden(end,1)-logden(1,1))

 load SSdata
 denG = zeros(25,1);
 for i = 1: 25
     denG(i,1) = i*4-2;
 end
 
 figure5 = figure
 plot(log10(denG),log10(G))
 
 
 
 
 
 
 
 
 
 