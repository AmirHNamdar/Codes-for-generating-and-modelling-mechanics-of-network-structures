clear all
clc
close all
% in this code, the dependancy of shear modulus to direction will be
% investigated.

Pr = 0.0;
Dc = 5.637;


% diam2 = [1e-2,1e-5,1e-4,1e-3,1e-2,1e-2,1e-2,1e-2,1e-3,1e-3,1e-3,1e-2];
% density2 = [10,10,10,10,20,25,30,40,15,20,25,100];
% diam2 = [1e-1,1e-1,1e-1,1e-1,1e-1,1e-1,1e-1,1e-1,1e-1];
% density2 = [7,8,9,10,15,20,30,50,70];
thickness2 = [1e-5,1e-5,1e-5,1e-5,1e-4,1e-4,1e-3,1e-3,1e-4,1e-4,1e-3,1e-4,1e-3,1e-5];
% thickness = [1e-5,1e-5,1e-5,1e-5];
% diam = 1e-1;
% diam2 = [1e-3,1e-3,1e-3,1e-3];
density2 = [25,35,50,70,50,70,100,200,100,200,300,150,150,30];
% W = log10(density2.^7.*(thickness2./4).^2);
W = log10(density2.^7.*(thickness2./sqrt(12)).^2);
% lambda2 = zeros(1,size(diam2,2));
% lambda2 = zeros(1,size(thickness,2));

% for la = 1:size(diam2,2)
%     lambda2(1,la) = floor(10^(2.0)/(density2(1,la)-Dc)^(4/3))+1;
%     if lambda2(1,la)<5
%         lambda2(1,la)=5;
%     end
% end

wm = 2; % which method of creating the network? perfect squares = 1, random network wm = 2.
TM = true; % if timoshenko beam then true

N2s = 36; % number of study for each Nf
e = 100; % elastic modulus of beams
g = e/3; % for incompressible fibres

% tCN = zeros(Ns,1); % time allocated to create the network
% tSN = zeros(Ns,1); % time allocated to solve the network
% Nlambda = [28,20];
% Nslambda = (Nlambda(1,2) - Nlambda(1,1))/ Nlambda(1,3) + 1;

% Mslambda = zeros(Nslambda,N2s); % shear modulus relating to a given lambda;
% Melambda = zeros(Nslambda,N2s); % young modulus relating to a given lambda;
% MMslambda = zeros(Nslambda,1); % mean ...
% MMelambda = zeros(Nslambda,1); % mean ...


tic
Ns = size(thickness2,2);
% Ns = size(diam2,2);

    Gs = zeros(N2s,Ns);
    Ge = zeros(N2s,Ns);
    mu = zeros(N2s,Ns);
for j = 1:Ns
    thickness = thickness2(1,j);
% diam = diam2(1,j);
    density = density2(1,j);
%     lambda = lambda2(1,j);
% lambda = 2;
    if density < 36
        lambda = 22;

    elseif density < 56
        lambda = 15;

    elseif density < 76
        lambda = 13;
 
    elseif density < 101
        lambda = 10;

    elseif density < 201
        lambda = 7;   

    elseif density < 501
        lambda = 4;

    end
  
%     lambda = 38;
    
% Ar = pi*diam^2/4; % cross section of beams
Ar = thickness^2; % cross section of square beams
% I = pi*diam^4/64; % second moment
I = (thickness)^4/12; % second moment of square bars

BM = (lambda)/1000; % Boundary movement

 
    
    Nf = (lambda+2)^2*density; % number of fibres data 
%     Ns = ; % number of considered density 


% input:
% Network generation
% lambda = 5;

density = Nf(1,1)/(lambda+2)^2;

x=[0 lambda]; % boundary of x direction
y=[0 lambda]; % boundary of y direction
if wm == 1
N = 2 + 2*(ns); % for square beams
L = 300;
elseif wm == 2
N = Nf; % Number of fibers
L=1; % Length of fibers
end
    Gv = zeros(N2s,1);
    GvE = zeros(N2s,1);
    mu1 = zeros(N2s,1);
parfor ns = 1:N2s

ns
j

flt = 10^(-3)*L/density; % fibre lenght treshold. Edges smaller than flt will be deleted.


% tic % to record time


% e = 100; % elastic modulus of beams
% Ar = 1; % cross section of beams
% I = 1; % second moment


% using function NetworkRand to generate the random network and get the data
if wm == 1
[NN,NE,ED,PN,nrb,nlb,ntb,nbb,Fiber] = SquareBeams(x,y,L,N,lambda);
elseif wm == 2
[SDataH,SDataV,Fiber,Per,SDatatest] = NetworkSemiRand(x,y,L,N,lambda,flt,Pr,density);
end
% tCN(ns,1) = toc;
if Per == false
    continue
end

% continue

NE = SDataV(1,6);
NN = SDataV(1,7);
PN = SDataV(1:NN,1:3);
ED = SDataV(1:NE,4:5);
nrb = SDataV(1,8);
nlb = SDataV(2,8);
ntb = SDataV(3,8);
nbb = SDataV(4,8);



% BC = zeros(12,2);
% deformations
% BC(1,1) = nan; % right x (will be modified inside the code)
% BC(2,1) = nan; % right y (will be modified inside the code)
% BC(3,1) = nan; % right theta 
% BC(4,1) = nan;  % left x (will be modified inside the code)
% BC(5,1) = nan; % left y (will be modified inside the code)
% BC(6,1) = nan;  % left theta
% BC(7,1) = 0; % top x (will be modified inside the code)
% BC(8,1) = BM; % top y (will be modified inside the code)
% BC(9,1) = 0; % top theta
% BC(10,1) = 0; % bottom x (will be modified inside the code)
% BC(11,1) = 0; % bottom y (will be modified inside the code)
% BC(12,1) = 0; % bottom theta
% % forces
% BC(1,2) = 0;
% BC(2,2) = 0;
% BC(3,2) = 0;
% BC(4,2) = 0;
% BC(5,2) = 0;
% BC(6,2) = 0;
% BC(7,2) = nan;
% BC(8,2) = nan;
% BC(9,2) = nan;
% BC(10,2) = nan;
% BC(11,2) = nan;
% BC(12,2) = nan;


% BB
% % M = 0;
% % sM = false;
% % [fov,C3v,FFv,UUv,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);
% % 
% % BC(7,1) = 0;
% % BC(8,1) = BM; % to investigate E
% % sM = true;
% % [fovE,C3vE,FFvE,UUvE,M] = FirstBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,Ar,I,sM,M);

% TB
M = 0;
% sM = false;
% BCvx = BM; 
% BCvy = 0;
% [fov,C3v,FFv,UUv,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy);

BC = zeros(12,2);
% deformations
BC(1,1) = nan; % right x (will be modified inside the code)
BC(2,1) = nan; % right y (will be modified inside the code)
BC(3,1) = nan; % right theta 
BC(4,1) = nan;  % left x (will be modified inside the code)
BC(5,1) = nan; % left y (will be modified inside the code)
BC(6,1) = nan;  % left theta
BC(7,1) = nan; % top x (will be modified inside the code)
BC(8,1) = BM; % top y (will be modified inside the code)
BC(9,1) = nan; % top theta
BC(10,1) = nan; % bottom x (will be modified inside the code)
BC(11,1) = 0; % bottom y (will be modified inside the code)
BC(12,1) = nan; % bottom theta
% forces
BC(1,2) = 0;
BC(2,2) = 0;
BC(3,2) = 0;
BC(4,2) = 0;
BC(5,2) = 0;
BC(6,2) = 0;
BC(7,2) = 0;
BC(8,2) = nan;
BC(9,2) = 0;
BC(10,2) = 0;
BC(11,2) = nan;
BC(12,2) = 0;

BCvx = 0;
BCvy = BM;


sM = false;
[fovE,C3vE,FFvE,UUvE,M] = TimoshenkoBeamFEM(NN,NE,ED,PN,nrb,nlb,ntb,nbb,BC,e,g,Ar,I,sM,M,lambda,BCvx,BCvy);

% shear modulus------------------------------------------------------------
% aggregation of forces in x direction devided by rotation

% sfv = 0; % shear force on the boundary V
% for i = 1:SDataV(3,8)
% sfv = FFv(i*3-2,1)+sfv;
% end
% sfv2 = 0; % the force on bottom boundary (to check the equilibrium)
% for i = ntb+1:ntb+nbb
%     sfv2 = FFv(i*3-2,1)+sfv2;
% end
% UT = transpose(UUv);
% Energy = UT*M*UUv;
% Gv(ns,1) = Energy/(BM)^2;


% sfvE = 0; % shear force on the boundary V
% for i = 1:SDataV(3,8)
%     sfvE = FFvE(i*3-1,1)+sfvE;
% end
% sfvE2 = 0; % the force on bottom boundary (to check the equilibrium)
% for i = ntb+1:ntb+nbb
%     sfvE2 = FFvE(i*3-1,1)+sfvE2;
% end
eer = 0; % the force on bottom boundary (to check the equilibrium)
for i = 1:nrb
    eer = UUvE(i*3-2,1)+eer;
end
eer = eer/nrb;
eel = 0; % the force on bottom boundary (to check the equilibrium)
for i = nrb+1:nrb+nlb
    eel = UUvE(i*3-2,1)+eel;
end
eel = eel/nlb;
mu1(ns,1) = -(eer-eel)/BM;
UTE = transpose(UUvE);
Energy = UTE*M*UUvE;
young2 = Energy/(BM)^2;

% finding mu and then E
% mu = 1-2*Gv(ns,1)/young2;
% GvE(ns,1) = 2*Gv(ns,1)*(1+mu);
GvE(ns,1) = young2;
% GvE(ns,1) = sfvE/lambda / (BM/lambda);


denN(ns,1) = N;

end
mu(:,j) = mu1;
% Gs(:,j) = Gv;
Ge(:,j) = GvE;
% GE(:,3) = Gh;
% GE(:,4) = GhE;

end

Mmu = zeros(1,Ns);
% MGs = zeros(1,Ns); % Mean of Gs 
MGe = zeros(1,Ns); % Mean of Ge



for i = 1: Ns
%     Gs2 = Gs(:,i);
    Ge2 = Ge(:,i);
    mu2 = mu(:,i);
    k=1;
    for j = 1:N2s
        if Ge2(k,1) == 0
%             Gs2(k,:)=[];
            Ge2(k,:)=[];
            mu2(k,:)=[];
            k=k-1;
        end
        k=k+1;
    end
%     MGs(1,i) = mean(Gs2);
    MGe(1,i) = mean(Ge2);
    Mmu(1,i) = mean(mu2);
end

% lMGs = zeros(1,Ns); % Mean of Gs 
lMGe = zeros(1,Ns); % Mean of Ge

for i=1:Ns
% % lMGs(1,i) = log10(MGs(1,i)/0.38/density2(1,i)/(pi/4*diam2(1,i)^2)/e);
% lMGe(1,i) = log10(MGe(1,i)/0.38/density2(1,i)/(pi/4*diam2(1,i)^2)/e);
lMGe(1,i) = log10(MGe(1,i)/0.38/density2(1,i)/(thickness2(1,i)^2)/e);
end
% (log10(MGe(1,5))-log10(MGe(1,1)))/(log10(density2(1,5))-log10(density2(1,1)))

% figure1 = figure;
% plot(W,lMGe,'o')
% figure1 = figure;
% plot(W,Mmu,'o')

% MMslambda(l,1) = MGs
% MMelambda(l,1) = MGe;


timeTottal = toc
% plot(MGs)


if wm ==1
    save('SSdata')      %-------------------*********************
elseif wm==2
%                                 -------------------*********************
    nameS = strcat('nuMC-','Pr',num2str(Pr*100));
    save(nameS)
end

% poly = polyfit(den,G,4);
% x1 = linspace(min(denN),max(denN));
% y1 = polyval(poly,x1);

% subplot(2,2,1)
% plot(den,G,'o')
% hold on
% plot(x1,y1)
% hold on
% subplot(2,2,2)
% plot(denN,G,'o')
% hold on
% subplot(2,2,3)
% plot(denf,G,'o')





